-- 本文件由环境生成代码
--
local envars = {
    local_map_dir_path = "C:\\Users\\xxx\\solar\\solar_rpg_editor\\game_root\\",
    listFile = "Ky+tSAb8"


}
return envars