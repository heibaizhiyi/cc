export default function StateInit() {

}