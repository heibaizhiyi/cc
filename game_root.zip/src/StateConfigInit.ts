

export default function StateConfigInit() {


}