import FrameParent from "@/FrameParent";

export default class Pane extends FrameParent{

}