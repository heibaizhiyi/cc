//1.32重制版才有的api 如果做重制版的图可以取消注释(通常应该没有这些api 因为没人会去做重制版图吧？重制版都没玩家玩)
/**
 * declare function BlzIsLastInstanceObjectFunctionSuccessful(): boolean;
 */
/**
 * declare function BlzSetAbilityBooleanFieldBJ(whichAbility: ability, whichField: abilitybooleanfield, value: boolean): void;
 */
/**
 * declare function BlzSetAbilityIntegerFieldBJ(whichAbility: ability, whichField: abilityintegerfield, value: number): void;
 */
/**
 * declare function BlzSetAbilityRealFieldBJ(whichAbility: ability, whichField: abilityrealfield, value: number): void;
 */
/**
 * declare function BlzSetAbilityStringFieldBJ(whichAbility: ability, whichField: abilitystringfield, value: string): void;
 */
/**
 * declare function BlzSetAbilityBooleanLevelFieldBJ(whichAbility: ability, whichField: abilitybooleanlevelfield, level: number, value: boolean): void;
 */
/**
 * declare function BlzSetAbilityIntegerLevelFieldBJ(whichAbility: ability, whichField: abilityintegerlevelfield, level: number, value: number): void;
 */
/**
 * declare function BlzSetAbilityRealLevelFieldBJ(whichAbility: ability, whichField: abilityreallevelfield, level: number, value: number): void;
 */
/**
 * declare function BlzSetAbilityStringLevelFieldBJ(whichAbility: ability, whichField: abilitystringlevelfield, level: number, value: string): void;
 */
/**
 * declare function BlzSetAbilityBooleanLevelArrayFieldBJ(whichAbility: ability, whichField: abilitybooleanlevelarrayfield, level: number, index: number, value: boolean): void;
 */
/**
 * declare function BlzSetAbilityIntegerLevelArrayFieldBJ(whichAbility: ability, whichField: abilityintegerlevelarrayfield, level: number, index: number, value: number): void;
 */
/**
 * declare function BlzSetAbilityRealLevelArrayFieldBJ(whichAbility: ability, whichField: abilityreallevelarrayfield, level: number, index: number, value: number): void;
 */
/**
 * declare function BlzSetAbilityStringLevelArrayFieldBJ(whichAbility: ability, whichField: abilitystringlevelarrayfield, level: number, index: number, value: string): void;
 */
/**
 * declare function BlzAddAbilityBooleanLevelArrayFieldBJ(whichAbility: ability, whichField: abilitybooleanlevelarrayfield, level: number, value: boolean): void;
 */
/**
 * declare function BlzAddAbilityIntegerLevelArrayFieldBJ(whichAbility: ability, whichField: abilityintegerlevelarrayfield, level: number, value: number): void;
 */
/**
 * declare function BlzAddAbilityRealLevelArrayFieldBJ(whichAbility: ability, whichField: abilityreallevelarrayfield, level: number, value: number): void;
 */
/**
 * declare function BlzAddAbilityStringLevelArrayFieldBJ(whichAbility: ability, whichField: abilitystringlevelarrayfield, level: number, value: string): void;
 */
/**
 * declare function BlzRemoveAbilityBooleanLevelArrayFieldBJ(whichAbility: ability, whichField: abilitybooleanlevelarrayfield, level: number, value: boolean): void;
 */
/**
 * declare function BlzRemoveAbilityIntegerLevelArrayFieldBJ(whichAbility: ability, whichField: abilityintegerlevelarrayfield, level: number, value: number): void;
 */
/**
 * declare function BlzRemoveAbilityRealLevelArrayFieldBJ(whichAbility: ability, whichField: abilityreallevelarrayfield, level: number, value: number): void;
 */
/**
 * declare function BlzRemoveAbilityStringLevelArrayFieldBJ(whichAbility: ability, whichField: abilitystringlevelarrayfield, level: number, value: string): void;
 */
/**
 * declare function BlzItemAddAbilityBJ(whichItem: item, abilCode: number): void;
 */
/**
 * declare function BlzItemRemoveAbilityBJ(whichItem: item, abilCode: number): void;
 */
/**
 * declare function BlzSetItemBooleanFieldBJ(whichItem: item, whichField: itembooleanfield, value: boolean): void;
 */
/**
 * declare function BlzSetItemIntegerFieldBJ(whichItem: item, whichField: itemintegerfield, value: number): void;
 */
/**
 * declare function BlzSetItemRealFieldBJ(whichItem: item, whichField: itemrealfield, value: number): void;
 */
/**
 * declare function BlzSetItemStringFieldBJ(whichItem: item, whichField: itemstringfield, value: string): void;
 */
/**
 * declare function BlzSetUnitBooleanFieldBJ(whichUnit: unit, whichField: unitbooleanfield, value: boolean): void;
 */
/**
 * declare function BlzSetUnitIntegerFieldBJ(whichUnit: unit, whichField: unitintegerfield, value: number): void;
 */
/**
 * declare function BlzSetUnitRealFieldBJ(whichUnit: unit, whichField: unitrealfield, value: number): void;
 */
/**
 * declare function BlzSetUnitStringFieldBJ(whichUnit: unit, whichField: unitstringfield, value: string): void;
 */
/**
 * declare function BlzSetUnitWeaponBooleanFieldBJ(whichUnit: unit, whichField: unitweaponbooleanfield, index: number, value: boolean): void;
 */
/**
 * declare function BlzSetUnitWeaponIntegerFieldBJ(whichUnit: unit, whichField: unitweaponintegerfield, index: number, value: number): void;
 */
/**
 * declare function BlzSetUnitWeaponRealFieldBJ(whichUnit: unit, whichField: unitweaponrealfield, index: number, value: number): void;
 */
/**
 * declare function BlzSetUnitWeaponStringFieldBJ(whichUnit: unit, whichField: unitweaponstringfield, index: number, value: string): void;
 */
