/** @noSelfInFile */

/**
 * 太阳独立游戏可以使用的api
 */

/**
 * 设置主交互样式 0,1
 */
declare function SlSetMainUIStyle(styleId: number): string;