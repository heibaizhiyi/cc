/** @noSelfInFile **/
/**
 * 设置加速倍率
 */
declare function DzSetSpeed(value: number): void;

/**
 * 刷新小地图
 */
declare function DzUpdateMinimap(): void;

/**
 * 修改单位alpha
 */
declare function DzUnitChangeAlpha(whichUnit: unit, alpha: number, forceUpdate: boolean): void;

/**
 * 沉默单位-禁用技能
 */
declare function DzUnitSilence(whichUnit: unit, disable: boolean): void;

/**
 * 禁用攻击
 */
declare function DzUnitDisableAttack(whichUnit: unit, disable: boolean): void;

/**
 * 禁用道具
 */
declare function DzUnitDisableInventory(whichUnit: unit, disable: boolean): void;

/**
 * 设置单位是否可以选中
 */
declare function DzUnitSetCanSelect(whichUnit: unit, state: boolean): void;

/**
 * 修改单位是否可以被设置为目标
 */
declare function DzUnitSetTargetable(whichUnit: unit, state: boolean): void;

/**
 * 保存内存数据
 */
declare function DzSaveMemoryCache(cache: string): void;

/**
 * 读取内存数据
 */
declare function DzGetMemoryCache(): string;

/**
 * 转换世界坐标为屏幕坐标-异步
 */
declare function DzConvertWorldPosition(x: number, y: number, z: number, callback: () => void): boolean;

/**
 * 转换世界坐标为屏幕坐标-获取转换后的X坐标
 */
declare function DzGetConvertWorldPositionX(): number;

/**
 * 转换世界坐标为屏幕坐标-获取转换后的Y坐标
 */
declare function DzGetConvertWorldPositionY(): number;

/**
 * 创建command button
 */
declare function DzCreateCommandButton(parent: number, icon: string, name: string, desc: string): number;

/**
 * 打开QQ群链接
 */
declare function DzOpenQQGroupUrl(url: string): boolean;

/**
 * 获取当前选择的单位
 */
declare function DzGetSelectedLeaderUnit(): unit;

/**
 * 聊天框是否打开
 */
declare function DzIsChatBoxOpen(): boolean;

/**
 * 获取子控件数量
 */
declare function DzFrameGetChildrenCount(frame: number): number;

/**
 * 获取子控件
 */
declare function DzFrameGetChild(frame: number, index: number): number;

/**
 * 获取框选控件
 */
declare function DzFrameGetInfoPanelSelectButton(index: number): number;

/**
 * 获取BUFF控件
 */
declare function DzFrameGetInfoPanelBuffButton(index: number): number;

/**
 * 获取农民控件
 */
declare function DzFrameGetPeonBar(): number;

/**
 * 获取技能右下角数字文本控件
 */
declare function DzFrameGetCommandBarButtonNumberText(frame: number): number;

/**
 * 获取技能右下角数字文本框体
 */
declare function DzFrameGetCommandBarButtonNumberOverlay(frame: number): number;

/**
 * 获取技能冷却指示器
 */
declare function DzFrameGetCommandBarButtonCooldownIndicator(frame: number): number;

/**
 * 获取技能自动施法指示器
 */
declare function DzFrameGetCommandBarButtonAutoCastIndicator(frame: number): number;

/**
 * 转换地图坐标为小地图x坐标
 */
declare function DzFrameWorldToMinimapPosX(x: number, y: number): number;

/**
 * 转换地图坐标为小地图y坐标
 */
declare function DzFrameWorldToMinimapPosY(x: number, y: number): number;

/**
 * 游戏提示信息界面
 */
declare function DzFrameGetWorldFrameMessage(): number;

/**
 * 转换世界坐标为屏幕x坐标
 */
declare function DzConvertWorldPositionX(x: number, y: number, z: number): number;

/**
 * 转换世界坐标为屏幕y坐标
 */
declare function DzConvertWorldPositionY(x: number, y: number, z: number): number;

/**
 * 转换世界坐标为屏幕深度
 */
declare function DzConvertWorldPositionDepth(x: number, y: number, z: number): number;

/**
 * 转换屏幕坐标到世界x坐标
 */
declare function DzConvertScreenPositionX(x: number, y: number): number;

/**
 * 转换屏幕坐标到世界y坐标
 */
declare function DzConvertScreenPositionY(x: number, y: number): number;

/**
 * 获取特效颜色
 */
declare function DzGetEffectVertexColor(whichEffect: effect): number;

/**
 * 获取特效透明度
 */
declare function DzGetEffectVertexAlpha(whichEffect: effect): number;

/**
 * 获取物品技能
 * (PS:与内置的GetItemAbility返回不一样 内置的返回为300以下  这个返回的是100000以上的数字)
 */
declare function DzGetItemAbility(whichItem: item, index: number): ability;

/**
 * 获取商店目标
 */
declare function DzGetActivePatron(store: unit, p: player): unit;

/**
 * 获取玩家选中的单位数量
 */
declare function DzGetLocalSelectUnitCount(): number;

/**
 * 获取玩家选中的单位
 */
declare function DzGetLocalSelectUnit(index: number): unit;

/**
 * 获取字符串数量
 */
declare function DzGetJassStringTableCount(): number;

/**
 * 获取 FPS 帧数
 */
declare function DzGetFPS(): number;

/**
 * 获取建造的命令id
 */
declare function DzGetOnBuildOrderId(): number;

/**
 * 获取建造的命令类型
 */
declare function DzGetOnBuildOrderType(): number;

/**
 * 获取预建造对象
 */
declare function DzGetOnBuildAgent(): widget;

/**
 * 获取监听到的技能
 */
declare function DzGetOnTargetAbilId(): number;

/**
 * 获取监听到技能预选命令
 */
declare function DzGetOnTargetOrderId(): number;

/**
 * 获取监听到技能预选命令类型
 */
declare function DzGetOnTargetOrderType(): number;

/**
 * 获取监听到技能预选目标
 */
declare function DzGetOnTargetAgent(): widget;

/**
 * 获取监听到技能预选目标
 */
declare function DzGetOnTargetInstantTarget(): widget;

/**
 * 设置单位的鼠标指向UI和血条显示/隐藏
 */
declare function DzSetUnitPreselectUIVisible(whichUnit: handle, visible: boolean): void;

/**
 * 设置特效播放动画
 */
declare function DzSetEffectAnimation(whichEffect: effect, index: number, flag: number): void;

/**
 * 设置特效播放动画
 */
declare function DzPlayEffectAnimation(whichEffect: effect, anim: string, link: string): void;

/**
 * 绑定特效
 */
declare function DzBindEffect(parent: widget, attachPoint: string, whichEffect: effect): void;

/**
 * 解除绑定特效
 */
declare function DzUnbindEffect(whichEffect: effect): void;

/**
 * 单位缩放
 */
declare function DzSetWidgetSpriteScale(whichUnit: widget, scale: number): void;

/**
 * 特效缩放
 */
declare function DzSetEffectScale(whichHandle: effect, scale: number): void;

/**
 * 设置特效坐标
 */
declare function DzSetEffectPos(whichEffect: effect, x: number, y: number, z: number): void;

/**
 * 设置特效颜色
 */
declare function DzSetEffectVertexColor(whichEffect: effect, color: number): void;

/**
 * 设置特效透明度
 */
declare function DzSetEffectVertexAlpha(whichEffect: effect, alpha: number): void;

/**
 * 设置控件视口
 */
declare function DzFrameSetClip(frame: number, enable: boolean): void;

/**
 * 设置魔兽窗口大小
 */
declare function DzChangeWindowSize(width: number, height: number): boolean;

/**
 * 解锁BLP像素限制
 */
declare function DzUnlockBlpSizeLimit(enable: boolean): void;

/**
 * 设置FPS显示/隐藏
 */
declare function DzToggleFPS(show: boolean): void;

/**
 * 清除模型内存缓存
 */
declare function DzModelRemoveFromCache(path: string): void;

/**
 * 清除所有模型内存缓存
 */
declare function DzModelRemoveAllFromCache(): void;

/**
 * 自定义指定单位的小地图图标
 */
declare function DzWidgetSetMinimapIcon(whichunit: unit, path: string): void;

/**
 * 开启/关闭自定义指定单位的小地图图标
 */
declare function DzWidgetSetMinimapIconEnable(whichunit: unit, enable: boolean): void;

/**
 * 显示游戏提示信息
 */
declare function DzSimpleMessageFrameAddMessage(frame: number, text: string, color: number, duration: number, permanent: boolean): void;

/**
 * 清理游戏提示信息
 */
declare function DzSimpleMessageFrameClear(frame: number): void;

/**
 * 监听建筑选位置
 */
declare function DzRegisterOnBuildLocal(func: () => void): void;

/**
 * 监听技能选目标
 */
declare function DzRegisterOnTargetLocal(func: () => void): void;

/**
 * 解除界面位置限制
 */
declare function DzFrameEnableClipRect(enable: boolean): void;

/**
 * 设置移动类型 物编完全效果 ExSetUnitMoveType设置不完全 部分判断使用时还是旧物编填的类型
 */
declare function DzSetUnitMoveType(unit: unit, moveType: string): void;

declare function DzSetUnitName(whichUnit: unit, name: string): void;

declare function DzSetUnitPortrait(whichUnit: unit, modelFile: string): void;

declare function DzSetUnitDescription(whichUnit: unit, value: string): void;

declare function DzSetUnitMissileArc(whichUnit: unit, arc: number): void;

declare function DzSetUnitMissileModel(whichUnit: unit, modelFile: string): void;

declare function DzSetUnitProperName(whichUnit: unit, name: string): void;

declare function DzSetUnitMissileHoming(whichUnit: unit, enable: boolean): void;

declare function DzSetUnitMissileSpeed(whichUnit: unit, speed: number): void;

declare function DzSetEffectVisible(whichHandle: effect, enable: boolean): void;

declare function DzReviveUnit(whichUnit: unit, whichPlayer: player, hp: number, mp: number, x: number, y: number): void;

declare function DzGetAttackAbility(whichUnit: unit): ability;

declare function DzAttackAbilityEndCooldown(whichHandle: ability): void;

/** 获取玩家平台ID 返回32位的字符串 */
declare function KKApiPlayerGUID(p: player): string;

/** 获取玩家 在自定义排行榜 上榜的排名 */
declare function DzAPI_Map_CommentTotalCount1(whichPlayer: player, id: number): number;

/** 获取自定义排行榜 上榜的玩家数 */
declare function DzAPI_Map_CustomRankCount(rankKey: number): number;

/** 获取自定义排行榜 指定排名的 玩家名 rankKey = 1-9   index= 0-100 */
declare function DzAPI_Map_CustomRankPlayerName(rankKey: number, index: number): string;

/** 获取自定义排行榜 指定排名的 数值 rankKey = 1-9   index= 0-100 */
declare function DzAPI_Map_CustomRankValue(rankKey: number, index: number): number;

// BeginBatchSaveArchive,  // 开始批量保存存档
declare function KKApiBeginBatchSaveArchive(whichPlayer: player): boolean;

// AddBatchSaveArchive,    // 添加批量保存存档条目
/**
 *
 * @param whichPlayer
 * @param key
 * @param value
 * @param caseInsensitive 是否区分大小写
 * @constructor
 */
declare function KKApiAddBatchSaveArchive(whichPlayer: player, key: string, value: string, caseInsensitive: boolean): boolean;

// EndBatchSaveArchive,    // 结束批量保存存档
/**
 *
 * @param whichPlayer
 * @param abandon true=放弃本次上传，并清空条目，false=上报批量结果，并清空条目。
 * @constructor
 */
declare function KKApiEndBatchSaveArchive(whichPlayer: player, abandon: boolean): boolean;

/**
 * 设置单位技能的 启用/禁用(暗图标)  隐藏图标
 * @param ability see DzUnitFindAbility
 * @param enable
 * @param hideIcon
 * @constructor
 */
declare function DzAbilitySetEnable(ability: ability, enable: boolean, hideIcon: boolean): boolean;

declare function DzUnitFindAbility(u: unit, abilityID: number): ability;

declare function DzDoodadCreate(id: number, val: number, x: number, y: number, z: number, rotate: number, scale: number): number;

declare function DzDoodadGetTypeId(doodad: number): number;

declare function DzDoodadSetModel(doodad: number, modelFile: string): void;

declare function DzDoodadSetTeamColor(doodad: number, color: number): void;

declare function DzDoodadSetColor(doodad: number, color: number): void;

declare function DzDoodadGetX(doodad: number): number;

declare function DzDoodadGetY(doodad: number): number;

declare function DzDoodadGetZ(doodad: number): number;

declare function DzDoodadSetPosition(doodad: number, x: number, y: number, z: number): void;

declare function DzDoodadSetOrientMatrixRotate(doodad: number, angle: number, axisX: number, axisY: number, axisZ: number): void;

declare function DzDoodadSetOrientMatrixScale(doodad: number, x: number, y: number, z: number): void;

declare function DzDoodadSetOrientMatrixResize(doodad: number): void;

declare function DzDoodadSetVisible(doodad: number, enable: boolean): void;

declare function DzDoodadSetAnimation(doodad: number, animName: string, animRandom: boolean): void;

declare function DzDoodadSetTimeScale(doodad: number, scale: number): void;

declare function DzDoodadGetTimeScale(doodad: number): number;

declare function DzDoodadGetCurrentAnimationIndex(doodad: number): number;

declare function DzDoodadGetAnimationCount(doodad: number): number;

declare function DzDoodadGetAnimationName(doodad: number, index: number): string;

declare function DzDoodadGetAnimationTime(doodad: number, index: number): number;

// 查找单位技能
// 修改技能数据-字符串
declare function DzAbilitySetStringData(whichAbility: ability, key: string, value: string): void;

// 启用/禁用技能
// 设置单位移动类型
declare function DzUnitSetMoveType(whichUnit: unit, moveType: string): void;

// 获取控件宽度
declare function DzFrameGetWidth(frame: number): number;

declare function DzFrameSetAnimateByIndex(frame: number, index: number, flag: number): void;

declare function DzSetUnitDataCacheInteger(uid: number, id: number, index: number, v: number): void;

declare function DzUnitUIAddLevelArrayInteger(uid: number, id: number, lv: number, v: number): void;

// GetLotteryUsedCount, // 获取宝箱抽取次数
/**
 *
 * @param whichPlayer
 * @param index 0=第一个宝箱（默认宝箱），1=第二个宝箱，2=第三个宝箱
 * @constructor
 */
declare function DzAPI_Map_GetLotteryUsedCountEx(whichPlayer: player, index: number): number;

/**
 * 获取所有宝箱抽取次数
 * @param whichPlayer
 * @constructor
 */
declare function DzAPI_Map_GetLotteryUsedCount(whichPlayer: player): number;

declare function KKApiRequestBackendLogic(whichPlayer: player, key: string, groupkey: string): boolean;

declare function KKApiCheckBackendLogicExists(whichPlayer: player, key: string): boolean;

declare function KKApiGetBackendLogicIntResult(whichPlayer: player, key: string): number;

declare function KKApiGetBackendLogicUpdateTime(whichPlayer: player, key: string): number;

declare function KKApiGetBackendLogicGroup(whichPlayer: player, key: string): string;

declare function DzSetUnitTypeName(uid: number, name: string): void;

declare function DzItemSetModel(item: item, model: string): void;

declare function DzItemSetPortrait(item: item, model: string): void;

declare function DzItemSetVertexColor(item: item, color: number): void;

declare function DzFrameSetIgnoreTrackEvents(frame: number, ignore: boolean): void;

declare function DzFrameAddModel(parent_frame: number): number;

declare function DzFrameSetModel2(model_frame: number, model_file: string, team_color_id: number): void;

declare function DzFrameAddModelEffect(model_frame: number, attach_point: string, model_file: string): number;

declare function DzFrameRemoveModelEffect(model_frame: number, effect_frame: number): void;

declare function DzFrameSetModelAnimationByIndex(model_frame: number, anim_index: number): void;

declare function DzFrameSetModelAnimation(model_frame: number, animation: string): void;

declare function DzFrameSetModelCameraSource(model_frame: number, x: number, y: number, z: number): void;

declare function DzFrameSetModelCameraTarget(model_frame: number, x: number, y: number, z: number): void;

declare function DzFrameSetModelSize(model_frame: number, size: number): void;

declare function DzFrameGetModelSize(model_frame: number): number;

declare function DzFrameSetModelPosition(model_frame: number, x: number, y: number, z: number): void;

declare function DzFrameSetModelX(model_frame: number, x: number): void;

declare function DzFrameGetModelX(model_frame: number): number;

declare function DzFrameSetModelY(model_frame: number, y: number): void;

declare function DzFrameGetModelY(model_frame: number): number;

declare function DzFrameSetModelZ(model_frame: number, z: number): void;

declare function DzFrameGetModelZ(model_frame: number): number;

declare function DzFrameSetModelSpeed(model_frame: number, speed: number): void;

declare function DzFrameGetModelSpeed(model_frame: number): number;

declare function DzFrameSetModelScale(model_frame: number, x: number, y: number, z: number): void;

declare function DzFrameSetModelMatReset(model_frame: number): void;

declare function DzFrameSetModelRotateX(model_frame: number, x: number): void;

declare function DzFrameSetModelRotateY(model_frame: number, y: number): void;

declare function DzFrameSetModelRotateZ(model_frame: number, z: number): void;

declare function DzFrameSetModelColor(model_frame: number, color: number): void;

declare function DzFrameGetModelColor(model_frame: number): number;

declare function DzFrameSetModelTexture(model_frame: number, texture_file: string, replace_texutre_id: number): void;

declare function DzFrameSetModelParticle2Size(model_frame: number, scale: number): void;

declare function DzGetGlueUI(): number;

declare function DzFrameGetMouse(): number;

declare function DzFrameGetContext(frame: number): number;

declare function DzFrameGetName(frame: number): string;

declare function DzFrameSetNameContext(frame: number, name: string, context: number): void;

declare function DzFrameSetTextFontSpacing(text_frame: number, spacing: number): void;

declare function KKCommandGetCooldownModel(cmd_btn: number): number;

declare function KKCommandSetCooldownModelSize(cmd_btn: number, size: number): void;

declare function KKCommandSetCooldownModelSize2(cmd_btn: number, width: number, height: number): void;

declare function DzGetPlayerLastSelectedItem(p: player): item;

declare function DzGetCacheModelCount(): number;

declare function DzSetMaxFps(max_fps: number): void;

// 2025-10-29
declare function DzSetEffectModel(whichEffect: effect, model: string): void;

declare function DzSetEffectTeamColor(whichHandle: effect, playerId: number): void;

//转换屏幕坐标到世界坐标
//监听建筑选位置
//等于0时是结束事件
//监听技能选目标
//等于0时是结束事件
// 打开QQ群链接
declare function EXSetUnitArrayString(uid: number, id: number, n: number, name: string): boolean;

declare function EXSetUnitInteger(uid: number, id: number, n: number): boolean;

declare function DzSetHeroTypeProperName(uid: number, name: string): void;

declare function DzIsUnitAttackType(whichUnit: unit, index: number, attackType: attacktype): boolean;

declare function DzSetUnitAttackType(whichUnit: unit, index: number, attackType: attacktype): void;

declare function DzIsUnitDefenseType(whichUnit: unit, defenseType: number): boolean;

declare function DzSetUnitDefenseType(whichUnit: unit, defenseType: number): void;

// 地形装饰物
// 解锁JASS字节码限制
declare function DzUnlockOpCodeLimit(enable: boolean): void;

// 设置剪切板内容
declare function DzSetClipboard(content: string): boolean;

//删除装饰物
declare function DzDoodadRemove(doodad: number): void;

//移除科技等级
declare function DzRemovePlayerTechResearched(whichPlayer: player, techid: number, removelevels: number): void;

// 查找单位技能
// 修改技能数据-字符串
// 启用/禁用技能
// 设置单位移动类型
// 获取控件宽度
declare function KKWESetUnitDataCacheInteger(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddUpgradesIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddBuildsIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddResearchesIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddTrainsIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddSellsUnitIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddSellsItemIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddMakesItemIds(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddRequiresUnitCode(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddRequiresTechcode(uid: number, id: number, v: number): void;

declare function KKWEUnitUIAddRequiresAmounts(uid: number, id: number, v: number): void;

// 设置道具模型
// 设置道具颜色
// 设置道具透明度
declare function DzItemSetAlpha(whichItem: item, color: number): void;

// 设置道具头像
declare function DzFrameHookHpBar(func: Function): void;

declare function DzFrameGetTriggerHpBarUnit(): unit;

declare function DzFrameGetTriggerHpBar(): number;

declare function DzFrameGetUnitHpBar(whichUnit: unit): number;

declare function DzGetCursorFrame(): number;

declare function DzFrameGetPointValid(frame: number, anchor: number): boolean;

declare function DzFrameGetPointRelative(frame: number, anchor: number): number;

declare function DzFrameGetPointRelativePoint(frame: number, anchor: number): number;

declare function DzFrameGetPointX(frame: number, anchor: number): number;

declare function DzFrameGetPointY(frame: number, anchor: number): number;

declare function DzIsLeapYear(year: number): boolean;

declare function DzGetTimeDateFromTimestamp(timestamp: number): string;

declare function KKAPIGetTimeDateFromTimestamp(timestamp: number): string;

declare function KKAPIGetTimestampYear(timestamp: number): number;

declare function KKAPIGetTimestampMonth(timestamp: number): number;

declare function KKAPIGetTimestampDay(timestamp: number): number;

declare function DzWriteLog(msg: string): void;

// texttag
declare function DzTextTagGetFont(): string;

declare function DzTextTagSetFont(fileName: string): void;

declare function DzTextTagSetStartAlpha(t: texttag, alpha: number): void;

declare function DzTextTagGetShadowColor(t: texttag): number;

declare function DzTextTagSetShadowColor(t: texttag, color: number): void;

// group
declare function DzGroupGetCount(g: group): number;

declare function DzGroupGetUnitAt(g: group, index: number): unit;

// unit
declare function DzUnitCreateIllusion(p: player, unitId: number, x: number, y: number, face: number): unit;

declare function DzUnitCreateIllusionFromUnit(u: unit): unit;

// string
declare function DzStringContains(s: string, whichString: string, caseSensitive: boolean): boolean;

declare function DzStringFind(s: string, whichString: string, off: number, caseSensitive: boolean): number;

declare function DzStringFindFirstOf(s: string, whichString: string, off: number, caseSensitive: boolean): number;

declare function DzStringFindFirstNotOf(s: string, whichString: string, off: number, caseSensitive: boolean): number;

declare function DzStringFindLastOf(s: string, whichString: string, off: number, caseSensitive: boolean): number;

declare function DzStringFindLastNotOf(s: string, whichString: string, off: number, caseSensitive: boolean): number;

declare function DzStringTrimLeft(s: string): string;

declare function DzStringTrimRight(s: string): string;

declare function DzStringTrim(s: string): string;

declare function DzStringReverse(s: string): string;

declare function DzStringReplace(s: string, whichString: string, replaceWith: string, caseSensitive: boolean): string;

declare function DzStringInsert(s: string, whichPosition: number, whichString: string): string;

// bit
declare function DzBitGet(i: number, byteIndex: number): number;

declare function DzBitSet(i: number, byteIndex: number, byteValue: number): number;

declare function DzBitGetByte(i: number, byteIndex: number): number;

declare function DzBitSetByte(i: number, byteIndex: number, byteValue: number): number;

declare function DzBitNot(i: number): number;

declare function DzBitAnd(a: number, b: number): number;

declare function DzBitOr(a: number, b: number): number;

declare function DzBitXor(a: number, b: number): number;

declare function DzBitShiftLeft(i: number, bitsToShift: number): number;

declare function DzBitShiftRight(i: number, bitsToShift: number): number;

declare function DzBitToInt(b1: number, b2: number, b3: number, b4: number): number;

// issue
declare function DzQueueGroupImmediateOrderById(whichGroup: group, order: number): boolean;

declare function DzQueueGroupPointOrderById(whichGroup: group, order: number, x: number, y: number): boolean;

declare function DzQueueGroupTargetOrderById(whichGroup: group, order: number, targetWidget: widget): boolean;

declare function DzQueueIssueImmediateOrderById(whichUnit: unit, order: number): boolean;

declare function DzQueueIssuePointOrderById(whichUnit: unit, order: number, x: number, y: number): boolean;

declare function DzQueueIssueTargetOrderById(whichUnit: unit, order: number, targetWidget: widget): boolean;

declare function DzQueueIssueInstantPointOrderById(whichUnit: unit, order: number, x: number, y: number, instantTargetWidget: widget): boolean;

declare function DzQueueIssueInstantTargetOrderById(whichUnit: unit, order: number, targetWidget: widget, instantTargetWidget: widget): boolean;

declare function DzQueueIssueBuildOrderById(whichPeon: unit, unitId: number, x: number, y: number): boolean;

declare function DzQueueIssueNeutralImmediateOrderById(forWhichPlayer: player, neutralStructure: unit, unitId: number): boolean;

declare function DzQueueIssueNeutralPointOrderById(forWhichPlayer: player, neutralStructure: unit, unitId: number, x: number, y: number): boolean;

declare function DzQueueIssueNeutralTargetOrderById(forWhichPlayer: player, neutralStructure: unit, unitId: number, target: widget): boolean;

declare function DzUnitOrdersCount(u: unit): number;

declare function DzUnitOrdersClear(u: unit, onlyQueued: boolean): void;

declare function DzUnitOrdersExec(u: unit): void;

declare function DzUnitOrdersForceStop(u: unit, clearQueue: boolean): void;

declare function DzUnitOrdersReverse(u: unit): void;

// xlsx
declare function DzXlsxOpen(filePath: string): number;

declare function DzXlsxClose(docHandle: number): boolean;

declare function DzXlsxWorksheetGetRowCount(docHandle: number, sheetName: string): number;

declare function DzXlsxWorksheetGetColumnCount(docHandle: number, sheetName: string): number;

declare function DzXlsxWorksheetGetCellType(docHandle: number, sheetName: string, row: number, column: number): number;

declare function DzXlsxWorksheetGetCellString(docHandle: number, sheetName: string, row: number, column: number): string;

declare function DzXlsxWorksheetGetCellInteger(docHandle: number, sheetName: string, row: number, column: number): number;

declare function DzXlsxWorksheetGetCellBoolean(docHandle: number, sheetName: string, row: number, column: number): boolean;

declare function DzXlsxWorksheetGetCellFloat(docHandle: number, sheetName: string, row: number, column: number): number;

declare function DzFrameSetTexCoord(frame: number, left: number, top: number, right: number, bottom: number): void;

declare function DzSetUnitAbilityRange(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityRange(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityArea(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityArea(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityCool(Unit: unit, abil_code: number, cool: number, max_cool: number): boolean;

declare function DzGetUnitAbilityCool(Unit: unit, abil_code: number): number;

declare function DzGetUnitAbilityMaxCool(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityDataA(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityDataA(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityDataB(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityDataB(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityDataC(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityDataC(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityDataD(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityDataD(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityDataE(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityDataE(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityButtonPos(Unit: unit, abil_code: number, x: number, y: number): boolean;

declare function DzSetUnitAbilityHotkey(Unit: unit, abil_code: number, key: string): boolean;

declare function DzConvertTargs2Str(targs: number): string;

declare function DzConvertStr2Targs(targs: string): number;

declare function DzSetUnitAbilityTargs(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityTargs(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityCost(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityCost(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityReqLevel(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityReqLevel(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityUnitId(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityUnitId(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityBuildOrderId(Unit: unit, abil_code: number, value: number): boolean;

declare function DzGetUnitAbilityBuildOrderId(Unit: unit, abil_code: number): number;

declare function DzSetUnitAbilityBuildModel(Unit: unit, abil_code: number, model_path: string, model_scale: number): boolean;

declare function DzUnitHasAbility(Unit: unit, abil_code: number): boolean;

declare function KKCreateCommandButton(): number;

declare function KKDestroyCommandButton(btn: number): void;

declare function KKCommandButtonClick(btn: number, mouse_type: number): void;

declare function KKCommandTargetClick(mouse_type: number, target: widget): boolean;

declare function KKCommandTerrainClick(mouse_type: number, x: number, y: number, z: number): boolean;

declare function KKSetCommandUnitAbility(btn: number, Unit: unit, abil_code: number): void;

declare function DzItemGetVertexColor(Item: item): number;

declare function DzItemSetSize(Item: item, size: number): void;

declare function DzItemGetSize(Item: item): number;

declare function DzItemMatRotateX(Item: item, x: number): void;

declare function DzItemMatRotateY(Item: item, y: number): void;

declare function DzItemMatRotateZ(Item: item, z: number): void;

declare function DzItemMatScale(Item: item, x: number, y: number, z: number): void;

declare function DzItemMatReset(Item: item): void;

declare function DzGetLastSelectedItem(): item;

declare function DzSetPariticle2Size(Widget: agent, scale: number): void;

declare function DzSetUnitCollisionSize(Unit: unit, size: number): void;

declare function DzGetUnitCollisionSize(Unit: unit): number;

declare function DzSetWidgetTexture(Handle: agent, TexturePath: string, ReplaceId: number): void;

declare function DzSetUnitSelectScale(Unit: unit, scale: number): void;

declare function DzSetUnitHitIgnore(Unit: unit, ignore: boolean): void;

declare function DzEffectBindEffect(Handle: agent, AttachName: string, eff: effect): void;

declare function KKConvertInt2AbilId(i: number): number;

declare function KKConvertAbilId2Int(i: number): number;

declare function KKConvertInt2Color(i: number): number;

declare function KKConvertColor2Int(i: number): number;