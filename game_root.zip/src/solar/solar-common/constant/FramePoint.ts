enum FramePoint {

    topLeft = 0,

    top = 1,

    topRight = 2,

    left = 3,

    center = 4,

    right = 5,

    bottomLeft = 6,

    bottom = 7,

    bottomRight = 8,

}


export default FramePoint