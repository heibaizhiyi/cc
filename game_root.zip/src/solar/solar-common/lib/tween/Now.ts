let now = function (): number {
    return _g_time
}


export default now
