local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 2,["8"] = 2,["10"] = 2,["11"] = 5,["12"] = 8,["13"] = 5,["14"] = 11,["15"] = 14,["16"] = 14,["17"] = 14,["18"] = 14,["19"] = 14,["20"] = 14,["21"] = 14,["22"] = 14,["23"] = 14,["24"] = 14,["25"] = 11,["26"] = 17,["27"] = 20,["28"] = 20,["29"] = 20,["30"] = 20,["31"] = 20,["32"] = 20,["33"] = 20,["34"] = 20,["35"] = 20,["36"] = 20,["37"] = 17,["38"] = 23,["39"] = 26,["40"] = 23,["41"] = 29,["42"] = 32,["43"] = 32,["44"] = 32,["45"] = 32,["46"] = 32,["47"] = 32,["48"] = 32,["49"] = 32,["50"] = 32,["51"] = 32,["52"] = 29,["53"] = 35,["54"] = 38,["55"] = 38,["56"] = 38,["57"] = 38,["58"] = 38,["59"] = 38,["60"] = 38,["61"] = 38,["62"] = 38,["63"] = 38,["64"] = 35,["65"] = 41,["66"] = 44,["67"] = 44,["68"] = 44,["69"] = 44,["70"] = 44,["71"] = 44,["72"] = 44,["73"] = 44,["74"] = 44,["75"] = 44,["76"] = 41,["77"] = 47,["78"] = 50,["79"] = 50,["80"] = 50,["81"] = 50,["82"] = 50,["83"] = 50,["84"] = 50,["85"] = 50,["86"] = 50,["87"] = 50,["88"] = 47,["89"] = 53,["90"] = 56,["91"] = 56,["92"] = 56,["93"] = 56,["94"] = 56,["95"] = 56,["96"] = 56,["97"] = 56,["98"] = 56,["99"] = 56,["100"] = 53,["101"] = 59,["102"] = 62,["103"] = 62,["104"] = 62,["105"] = 62,["106"] = 62,["107"] = 62,["108"] = 62,["109"] = 62,["110"] = 62,["111"] = 62,["112"] = 59,["113"] = 65,["114"] = 68,["115"] = 68,["116"] = 68,["117"] = 68,["118"] = 68,["119"] = 68,["120"] = 68,["121"] = 68,["122"] = 68,["123"] = 68,["124"] = 65,["125"] = 71,["126"] = 74,["127"] = 75,["129"] = 77,["131"] = 71,["132"] = 80,["133"] = 83,["134"] = 84,["135"] = 84,["136"] = 84,["137"] = 84,["138"] = 84,["139"] = 84,["140"] = 84,["141"] = 84,["142"] = 84,["143"] = 84,["144"] = 85,["145"] = 86,["146"] = 80,["147"] = 89,["148"] = 91,["149"] = 93,["150"] = 94,["151"] = 94,["152"] = 94,["153"] = 94,["154"] = 94,["155"] = 94,["156"] = 94,["157"] = 94,["158"] = 94,["159"] = 94,["160"] = 95,["161"] = 96,["162"] = 97,["163"] = 89,["164"] = 100,["165"] = 103,["166"] = 104,["167"] = 104,["168"] = 104,["169"] = 104,["170"] = 104,["171"] = 105,["172"] = 106,["173"] = 100,["174"] = 109,["175"] = 111,["176"] = 113,["177"] = 114,["178"] = 115,["179"] = 116,["180"] = 117,["181"] = 109,["182"] = 120,["183"] = 123,["184"] = 123,["185"] = 123,["186"] = 123,["187"] = 123,["188"] = 123,["189"] = 123,["190"] = 123,["191"] = 123,["192"] = 123,["193"] = 120,["194"] = 126,["195"] = 129,["196"] = 130,["197"] = 130,["198"] = 130,["199"] = 130,["200"] = 130,["201"] = 131,["202"] = 132,["203"] = 126,["204"] = 135,["205"] = 137,["206"] = 139,["207"] = 140,["208"] = 141,["209"] = 142,["210"] = 143,["211"] = 135,["212"] = 146,["213"] = 149,["214"] = 150,["215"] = 151,["217"] = 153,["219"] = 154,["220"] = 155,["221"] = 146,["222"] = 158,["223"] = 160,["224"] = 162,["225"] = 163,["226"] = 164,["227"] = 165,["229"] = 167,["231"] = 168,["232"] = 169,["233"] = 170,["234"] = 158,["235"] = 173,["236"] = 176,["237"] = 177,["238"] = 178,["239"] = 179,["240"] = 173,["241"] = 182,["242"] = 185,["243"] = 182,["244"] = 188,["245"] = 191,["246"] = 192,["247"] = 192,["248"] = 192,["249"] = 192,["250"] = 192,["251"] = 192,["252"] = 192,["253"] = 192,["254"] = 192,["255"] = 192,["256"] = 193,["257"] = 194,["258"] = 188,["259"] = 197,["260"] = 200,["261"] = 200,["262"] = 200,["263"] = 200,["264"] = 200,["265"] = 200,["266"] = 200,["267"] = 200,["268"] = 200,["269"] = 200,["270"] = 197,["271"] = 203,["272"] = 205,["273"] = 207,["274"] = 208,["275"] = 209,["276"] = 210,["277"] = 211,["278"] = 203,["279"] = 214,["280"] = 216,["281"] = 218,["282"] = 219,["283"] = 220,["284"] = 221,["285"] = 222,["286"] = 214,["287"] = 225,["288"] = 228,["289"] = 230,["290"] = 231,["291"] = 225,["292"] = 234,["293"] = 237,["294"] = 237,["295"] = 237,["296"] = 237,["297"] = 237,["298"] = 234,["299"] = 240,["300"] = 243,["302"] = 247,["303"] = 247,["304"] = 247,["305"] = 247,["306"] = 247,["308"] = 240,["309"] = 256,["310"] = 259,["312"] = 263,["313"] = 263,["314"] = 263,["315"] = 263,["316"] = 263,["318"] = 256,["319"] = 266,["320"] = 268,["321"] = 270,["322"] = 271,["324"] = 273,["325"] = 274,["327"] = 277,["328"] = 278,["329"] = 266,["330"] = 287,["331"] = 290,["332"] = 291,["334"] = 293,["336"] = 287,["337"] = 296,["338"] = 299,["339"] = 296,["340"] = 302,["341"] = 305,["342"] = 305,["343"] = 305,["344"] = 305,["345"] = 305,["346"] = 302,["347"] = 308,["348"] = 311,["349"] = 311,["350"] = 311,["351"] = 311,["352"] = 311,["353"] = 308,["354"] = 314,["355"] = 317,["356"] = 317,["357"] = 317,["358"] = 317,["359"] = 317,["360"] = 317,["361"] = 317,["362"] = 317,["363"] = 317,["364"] = 317,["365"] = 314,["366"] = 320,["367"] = 323,["368"] = 323,["369"] = 323,["370"] = 323,["371"] = 323,["372"] = 323,["373"] = 323,["374"] = 323,["375"] = 323,["376"] = 323,["377"] = 320,["378"] = 326,["379"] = 329,["380"] = 329,["381"] = 329,["382"] = 329,["383"] = 329,["384"] = 329,["385"] = 329,["386"] = 329,["387"] = 329,["388"] = 329,["389"] = 326,["390"] = 332,["391"] = 335,["392"] = 335,["393"] = 335,["394"] = 335,["395"] = 335,["396"] = 335,["397"] = 335,["398"] = 335,["399"] = 335,["400"] = 335,["401"] = 332,["402"] = 338,["403"] = 341,["404"] = 341,["405"] = 341,["406"] = 341,["407"] = 341,["408"] = 341,["409"] = 341,["410"] = 341,["411"] = 341,["412"] = 341,["413"] = 338,["414"] = 344,["415"] = 347,["416"] = 347,["417"] = 347,["418"] = 347,["419"] = 347,["420"] = 347,["421"] = 347,["422"] = 347,["423"] = 347,["424"] = 347,["425"] = 344,["426"] = 350,["427"] = 353,["428"] = 353,["429"] = 353,["430"] = 353,["431"] = 353,["432"] = 353,["433"] = 353,["434"] = 353,["435"] = 353,["436"] = 353,["437"] = 350,["438"] = 357,["439"] = 360,["440"] = 360,["441"] = 360,["442"] = 360,["443"] = 360,["444"] = 360,["445"] = 360,["446"] = 360,["447"] = 360,["448"] = 360,["449"] = 357,["450"] = 363,["451"] = 366,["452"] = 366,["453"] = 366,["454"] = 366,["455"] = 366,["456"] = 366,["457"] = 366,["458"] = 366,["459"] = 366,["460"] = 366,["461"] = 363,["462"] = 369,["463"] = 372,["464"] = 372,["465"] = 372,["466"] = 372,["467"] = 372,["468"] = 372,["469"] = 372,["470"] = 372,["471"] = 372,["472"] = 372,["473"] = 369,["474"] = 376,["475"] = 379,["476"] = 379,["477"] = 379,["478"] = 379,["479"] = 379,["480"] = 379,["481"] = 379,["482"] = 379,["483"] = 379,["484"] = 379,["485"] = 376,["486"] = 383,["487"] = 386,["488"] = 386,["489"] = 386,["490"] = 386,["491"] = 386,["492"] = 386,["493"] = 386,["494"] = 386,["495"] = 386,["496"] = 386,["497"] = 383,["498"] = 390,["499"] = 393,["500"] = 393,["501"] = 393,["502"] = 393,["503"] = 393,["504"] = 393,["505"] = 393,["506"] = 393,["507"] = 393,["508"] = 393,["509"] = 390,["510"] = 397,["511"] = 400,["512"] = 400,["513"] = 400,["514"] = 400,["515"] = 400,["516"] = 400,["517"] = 400,["518"] = 400,["519"] = 400,["520"] = 400,["521"] = 397,["522"] = 404,["523"] = 407,["524"] = 407,["525"] = 407,["526"] = 407,["527"] = 407,["528"] = 407,["529"] = 407,["530"] = 407,["531"] = 407,["532"] = 407,["533"] = 404,["534"] = 411,["535"] = 414,["536"] = 414,["537"] = 414,["538"] = 414,["539"] = 414,["540"] = 414,["541"] = 414,["542"] = 414,["543"] = 414,["544"] = 414,["545"] = 411,["546"] = 418,["547"] = 421,["548"] = 421,["549"] = 421,["550"] = 421,["551"] = 421,["552"] = 421,["553"] = 421,["554"] = 421,["555"] = 421,["556"] = 421,["557"] = 418,["558"] = 425,["559"] = 428,["560"] = 428,["561"] = 428,["562"] = 428,["563"] = 428,["564"] = 428,["565"] = 428,["566"] = 428,["567"] = 428,["568"] = 428,["569"] = 425,["570"] = 432,["571"] = 435,["572"] = 435,["573"] = 435,["574"] = 435,["575"] = 435,["576"] = 435,["577"] = 435,["578"] = 435,["579"] = 435,["580"] = 435,["581"] = 432,["582"] = 439,["583"] = 442,["584"] = 442,["585"] = 442,["586"] = 442,["587"] = 442,["588"] = 442,["589"] = 442,["590"] = 442,["591"] = 442,["592"] = 442,["593"] = 439,["594"] = 445,["595"] = 448,["596"] = 448,["597"] = 448,["598"] = 448,["599"] = 448,["600"] = 448,["601"] = 448,["602"] = 448,["603"] = 448,["604"] = 448,["605"] = 445,["606"] = 451,["607"] = 454,["608"] = 454,["609"] = 454,["610"] = 454,["611"] = 454,["612"] = 454,["613"] = 454,["614"] = 454,["615"] = 454,["616"] = 454,["617"] = 451,["618"] = 458,["619"] = 459,["620"] = 458,["621"] = 462,["622"] = 463,["623"] = 462,["624"] = 466,["625"] = 467,["626"] = 466,["627"] = 472,["628"] = 473,["629"] = 472,["630"] = 476,["631"] = 477,["632"] = 477,["633"] = 477,["634"] = 477,["635"] = 477,["636"] = 476,["637"] = 480,["638"] = 481,["639"] = 481,["640"] = 481,["641"] = 481,["642"] = 481,["643"] = 480,["644"] = 484,["645"] = 485,["646"] = 485,["647"] = 485,["648"] = 485,["649"] = 485,["650"] = 484,["651"] = 488,["652"] = 489,["653"] = 489,["654"] = 489,["655"] = 489,["656"] = 489,["657"] = 488,["658"] = 494,["659"] = 495,["660"] = 495,["661"] = 495,["662"] = 495,["663"] = 495,["664"] = 495,["665"] = 495,["666"] = 495,["667"] = 495,["668"] = 495,["669"] = 494,["670"] = 499,["671"] = 500,["672"] = 500,["673"] = 500,["674"] = 500,["675"] = 500,["676"] = 500,["677"] = 500,["678"] = 500,["679"] = 500,["680"] = 500,["681"] = 499,["682"] = 504,["683"] = 505,["684"] = 505,["685"] = 505,["686"] = 505,["687"] = 505,["688"] = 505,["689"] = 505,["690"] = 505,["691"] = 505,["692"] = 505,["693"] = 504,["694"] = 509,["695"] = 510,["696"] = 510,["697"] = 510,["698"] = 510,["699"] = 510,["700"] = 510,["701"] = 510,["702"] = 510,["703"] = 510,["704"] = 510,["705"] = 509,["706"] = 514,["707"] = 515,["708"] = 515,["709"] = 515,["710"] = 515,["711"] = 515,["712"] = 515,["713"] = 515,["714"] = 514,["715"] = 518,["716"] = 519,["717"] = 519,["718"] = 519,["719"] = 519,["720"] = 519,["721"] = 519,["722"] = 519,["723"] = 518,["724"] = 522,["725"] = 523,["726"] = 522,["727"] = 526,["728"] = 527,["729"] = 526,["730"] = 530,["731"] = 531,["732"] = 530,["733"] = 534,["734"] = 535,["735"] = 534,["736"] = 538,["737"] = 539,["738"] = 538,["739"] = 542,["740"] = 543,["741"] = 542,["742"] = 546,["743"] = 547,["744"] = 546,["745"] = 554,["746"] = 555,["747"] = 555,["748"] = 555,["749"] = 555,["750"] = 555,["751"] = 555,["752"] = 555,["753"] = 555,["754"] = 555,["755"] = 555,["756"] = 554,["757"] = 559,["758"] = 560,["759"] = 560,["760"] = 560,["761"] = 560,["762"] = 560,["763"] = 560,["764"] = 560,["765"] = 560,["766"] = 560,["767"] = 560,["768"] = 559,["769"] = 564,["770"] = 565,["771"] = 565,["772"] = 565,["773"] = 565,["774"] = 565,["775"] = 565,["776"] = 565,["777"] = 565,["778"] = 565,["779"] = 565,["780"] = 564,["781"] = 569,["782"] = 570,["783"] = 570,["784"] = 570,["785"] = 570,["786"] = 570,["787"] = 570,["788"] = 570,["789"] = 570,["790"] = 570,["791"] = 570,["792"] = 569});
local ____exports = {}
____exports.default = __TS__Class()
local DzApiHelper = ____exports.default
DzApiHelper.name = "DzApiHelper"
function DzApiHelper.prototype.____constructor(self)
end
function DzApiHelper.DzAPI_Map_IsPlatformVIP(whichPlayer)
    return DzAPI_Map_GetPlatformVIP(whichPlayer) > 0
end
function DzApiHelper.DzAPI_Map_Global_GetStoreString(key)
    return RequestExtraStringData(
        36,
        GetLocalPlayer(),
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_Global_StoreString(key, value)
    RequestExtraStringData(
        37,
        GetLocalPlayer(),
        key,
        value,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_Global_ChangeMsg(trig)
    DzTriggerRegisterSyncData(trig, "DZGAU", true)
end
function DzApiHelper.DzAPI_Map_ServerArchive(whichPlayer, key)
    return RequestExtraStringData(
        38,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_SaveServerArchive(whichPlayer, key, value)
    RequestExtraBooleanData(
        39,
        whichPlayer,
        key,
        value,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsRPGQuickMatch()
    return RequestExtraBooleanData(
        40,
        nil,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_GetMallItemCount(whichPlayer, key)
    return RequestExtraIntegerData(
        41,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_ConsumeMallItem(whichPlayer, key, count)
    return RequestExtraBooleanData(
        42,
        whichPlayer,
        key,
        nil,
        false,
        count,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_EnablePlatformSettings(whichPlayer, option, enable)
    return RequestExtraBooleanData(
        43,
        whichPlayer,
        nil,
        nil,
        enable,
        option,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsBuyReforged(whichPlayer)
    return RequestExtraBooleanData(
        44,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.GetPlayerServerValueSuccess(whichPlayer)
    if DzAPI_Map_GetServerValueErrorCode(whichPlayer) == 0 then
        return true
    else
        return false
    end
end
function DzApiHelper.DzAPI_Map_StoreIntegerEX(whichPlayer, key, value)
    key = "I" .. key
    RequestExtraBooleanData(
        39,
        whichPlayer,
        key,
        I2S(value),
        false,
        0,
        0,
        0
    )
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredIntegerEX(whichPlayer, key)
    local value
    key = "I" .. key
    value = S2I(RequestExtraStringData(
        38,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    ))
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_StoreInteger(whichPlayer, key, value)
    key = "I" .. key
    DzAPI_Map_SaveServerValue(
        whichPlayer,
        key,
        I2S(value)
    )
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredInteger(whichPlayer, key)
    local value
    key = "I" .. key
    value = S2I(DzAPI_Map_GetServerValue(whichPlayer, key))
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_CommentTotalCount1(whichPlayer, id)
    return RequestExtraIntegerData(
        52,
        whichPlayer,
        nil,
        nil,
        false,
        id,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_StoreReal(whichPlayer, key, value)
    key = "R" .. key
    DzAPI_Map_SaveServerValue(
        whichPlayer,
        key,
        R2S(value)
    )
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredReal(whichPlayer, key)
    local value
    key = "R" .. key
    value = S2R(DzAPI_Map_GetServerValue(whichPlayer, key))
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_StoreBoolean(whichPlayer, key, value)
    key = "B" .. key
    if value then
        DzAPI_Map_SaveServerValue(whichPlayer, key, "1")
    else
        DzAPI_Map_SaveServerValue(whichPlayer, key, "0")
    end
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredBoolean(whichPlayer, key)
    local value
    key = "B" .. key
    key = DzAPI_Map_GetServerValue(whichPlayer, key)
    if key == "1" then
        value = true
    else
        value = false
    end
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_StoreString(whichPlayer, key, value)
    key = "S" .. key
    DzAPI_Map_SaveServerValue(whichPlayer, key, value)
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredString(whichPlayer, key)
    return DzAPI_Map_GetServerValue(whichPlayer, "S" .. key)
end
function DzApiHelper.DzAPI_Map_StoreStringEX(whichPlayer, key, value)
    key = "S" .. key
    RequestExtraBooleanData(
        39,
        whichPlayer,
        key,
        value,
        false,
        0,
        0,
        0
    )
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_GetStoredStringEX(whichPlayer, key)
    return RequestExtraStringData(
        38,
        whichPlayer,
        "S" .. key,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_GetStoredUnitType(whichPlayer, key)
    local value
    key = "I" .. key
    value = S2I(DzAPI_Map_GetServerValue(whichPlayer, key))
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_GetStoredAbilityId(whichPlayer, key)
    local value
    key = "I" .. key
    value = S2I(DzAPI_Map_GetServerValue(whichPlayer, key))
    key = nil
    whichPlayer = nil
    return value
end
function DzApiHelper.DzAPI_Map_FlushStoredMission(whichPlayer, key)
    DzAPI_Map_SaveServerValue(whichPlayer, key, "")
    key = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitIntegerData(whichPlayer, key, value)
    DzAPI_Map_Ladder_SetStat(
        whichPlayer,
        key,
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_Stat_SubmitUnitIdData(whichPlayer, key, value)
    if value == 0 then
    else
        DzAPI_Map_Ladder_SetStat(
            whichPlayer,
            key,
            I2S(value)
        )
    end
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitAblityIdData(whichPlayer, key, value)
    if value == 0 then
    else
        DzAPI_Map_Ladder_SetStat(
            whichPlayer,
            key,
            I2S(value)
        )
    end
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitItemIdData(whichPlayer, key, value)
    local S
    if value == 0 then
        S = "0"
    else
        S = I2S(value)
        DzAPI_Map_Ladder_SetStat(whichPlayer, key, S)
    end
    S = nil
    whichPlayer = nil
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitBooleanData(whichPlayer, key, value)
    if value then
        DzAPI_Map_Ladder_SetStat(whichPlayer, key, "1")
    else
        DzAPI_Map_Ladder_SetStat(whichPlayer, key, "0")
    end
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitTitle(whichPlayer, value)
    DzAPI_Map_Ladder_SetStat(whichPlayer, value, "1")
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitPlayerRank(whichPlayer, value)
    DzAPI_Map_Ladder_SetPlayerStat(
        whichPlayer,
        "RankIndex",
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_Ladder_SubmitPlayerExtraExp(whichPlayer, value)
    DzAPI_Map_Ladder_SetStat(
        whichPlayer,
        "ExtraExp",
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_PlayedGames(whichPlayer)
    return RequestExtraIntegerData(
        45,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_CommentCount(whichPlayer)
    return RequestExtraIntegerData(
        46,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_FriendCount(whichPlayer)
    return RequestExtraIntegerData(
        47,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsConnoisseur(whichPlayer)
    return RequestExtraBooleanData(
        48,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsBattleNetAccount(whichPlayer)
    return RequestExtraBooleanData(
        49,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsAuthor(whichPlayer)
    return RequestExtraBooleanData(
        50,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_CommentTotalCount()
    return RequestExtraIntegerData(
        51,
        nil,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_Statistics(whichPlayer, eventKey, eventType, value)
    RequestExtraBooleanData(
        34,
        whichPlayer,
        eventKey,
        "",
        false,
        value,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_Returns(whichPlayer, label)
    return RequestExtraBooleanData(
        53,
        whichPlayer,
        nil,
        nil,
        false,
        label,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_ContinuousCount(whichPlayer, id)
    return RequestExtraIntegerData(
        54,
        whichPlayer,
        nil,
        nil,
        false,
        id,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_IsPlayer(whichPlayer)
    return RequestExtraBooleanData(
        55,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsTotalPlayed(whichPlayer)
    return RequestExtraIntegerData(
        56,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsLevel(whichPlayer, mapId)
    return RequestExtraIntegerData(
        57,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeGold(whichPlayer, mapId)
    return RequestExtraIntegerData(
        58,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeLumber(whichPlayer, mapId)
    return RequestExtraIntegerData(
        59,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeLv1(whichPlayer, mapId)
    return RequestExtraBooleanData(
        60,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeLv2(whichPlayer, mapId)
    return RequestExtraBooleanData(
        61,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeLv3(whichPlayer, mapId)
    return RequestExtraBooleanData(
        62,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_MapsConsumeLv4(whichPlayer, mapId)
    return RequestExtraBooleanData(
        63,
        whichPlayer,
        nil,
        nil,
        false,
        mapId,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_GetForumData(whichPlayer, whichData)
    return RequestExtraIntegerData(
        65,
        whichPlayer,
        nil,
        nil,
        false,
        whichData,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_OpenMall(whichPlayer, whichkey)
    return RequestExtraBooleanData(
        66,
        whichPlayer,
        whichkey,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_GameResult_CommitData(whichPlayer, key, value)
    RequestExtraIntegerData(
        69,
        whichPlayer,
        key,
        value,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzTriggerRegisterMallItemSyncData(trig)
    DzTriggerRegisterSyncData(trig, "DZMIA", true)
end
function DzApiHelper.DzGetTriggerMallItemPlayer()
    return DzGetTriggerSyncPlayer()
end
function DzApiHelper.DzGetTriggerMallItem()
    return DzGetTriggerSyncData()
end
function DzApiHelper.DzAPI_Map_GameResult_CommitTitle(whichPlayer, value)
    DzAPI_Map_GameResult_CommitData(whichPlayer, value, "1")
end
function DzApiHelper.DzAPI_Map_GameResult_CommitPlayerRank(whichPlayer, value)
    DzAPI_Map_GameResult_CommitData(
        whichPlayer,
        "RankIndex",
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_GameResult_CommitGameMode(value)
    DzAPI_Map_GameResult_CommitData(
        GetLocalPlayer(),
        "InnerGameMode",
        value
    )
end
function DzApiHelper.DzAPI_Map_GameResult_CommitGameResult(whichPlayer, value)
    DzAPI_Map_GameResult_CommitData(
        whichPlayer,
        "GameResult",
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_GameResult_CommitGameResultNoEnd(whichPlayer, value)
    DzAPI_Map_GameResult_CommitData(
        whichPlayer,
        "GameResultNoEnd",
        I2S(value)
    )
end
function DzApiHelper.DzAPI_Map_GetSinceLastPlayedSeconds(whichPlayer)
    return RequestExtraIntegerData(
        70,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_QuickBuy(whichPlayer, key, count, seconds)
    return RequestExtraBooleanData(
        72,
        whichPlayer,
        key,
        nil,
        false,
        count,
        seconds,
        0
    )
end
function DzApiHelper.DzAPI_Map_CancelQuickBuy(whichPlayer)
    return RequestExtraBooleanData(
        73,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_PlayerLoadedItems(whichPlayer)
    return RequestExtraBooleanData(
        77,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function DzApiHelper.DzTriggerRegisterMouseEventTrg(trg, status, btn)
    DzTriggerRegisterMouseEvent(
        trg,
        btn,
        status,
        true,
        nil
    )
end
function DzApiHelper.DzTriggerRegisterKeyEventTrg(trg, status, btn)
    DzTriggerRegisterKeyEvent(
        trg,
        btn,
        status,
        true,
        nil
    )
end
function DzApiHelper.DzTriggerRegisterMouseMoveEventTrg(trg)
    DzTriggerRegisterMouseMoveEvent(trg, true, nil)
end
function DzApiHelper.DzTriggerRegisterMouseWheelEventTrg(trg)
    DzTriggerRegisterMouseWheelEvent(trg, true, nil)
end
function DzApiHelper.DzTriggerRegisterWindowResizeEventTrg(trg)
    DzTriggerRegisterWindowResizeEvent(trg, true, nil)
end
function DzApiHelper.DzF2I(i)
    return i
end
function DzApiHelper.DzI2F(i)
    return i
end
function DzApiHelper.DzK2I(i)
    return i
end
function DzApiHelper.DzI2K(i)
    return i
end
function DzApiHelper.DzAPI_Map_CustomRankCount(id)
    return RequestExtraIntegerData(
        78,
        nil,
        nil,
        nil,
        false,
        id,
        0,
        0
    )
end
function DzApiHelper.DzAPI_Map_CustomRankPlayerName(id, ranking)
    return RequestExtraStringData(
        79,
        nil,
        nil,
        nil,
        false,
        id,
        ranking,
        0
    )
end
function DzApiHelper.DzAPI_Map_CustomRankValue(id, ranking)
    return RequestExtraIntegerData(
        80,
        nil,
        nil,
        nil,
        false,
        id,
        ranking,
        0
    )
end
function DzApiHelper.DzAPI_Map_GetPlayerUserName(whichPlayer)
    return RequestExtraStringData(
        81,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
return ____exports
