local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 7,["7"] = 8,["8"] = 9,["9"] = 10,["10"] = 11,["11"] = 12,["12"] = 13,["13"] = 14,["14"] = 20,["15"] = 23,["16"] = 20,["17"] = 26,["18"] = 28,["19"] = 30,["20"] = 31,["23"] = 32,["25"] = 34,["26"] = 26,["27"] = 37,["28"] = 38,["29"] = 39,["31"] = 42,["32"] = 44,["33"] = 45,["34"] = 45,["35"] = 45,["36"] = 45,["37"] = 45,["38"] = 45,["39"] = 46,["40"] = 46,["41"] = 46,["42"] = 46,["43"] = 46,["44"] = 46,["45"] = 47,["46"] = 47,["47"] = 47,["48"] = 47,["49"] = 47,["50"] = 47,["52"] = 49,["53"] = 50,["54"] = 51,["55"] = 52,["56"] = 53,["58"] = 55,["59"] = 56,["60"] = 57,["61"] = 58,["62"] = 59,["63"] = 60,["64"] = 61,["66"] = 62,["68"] = 64,["69"] = 37,["70"] = 87,["71"] = 90,["72"] = 91,["73"] = 92,["74"] = 87,["75"] = 97,["76"] = 100,["77"] = 97,["78"] = 103,["79"] = 106,["80"] = 103,["81"] = 109,["82"] = 112,["83"] = 113,["85"] = 115,["86"] = 109,["87"] = 118,["88"] = 121,["89"] = 121,["90"] = 121,["91"] = 121,["92"] = 121,["93"] = 121,["94"] = 118,["95"] = 128,["96"] = 131,["97"] = 131,["98"] = 131,["99"] = 131,["100"] = 131,["101"] = 128,["102"] = 137,["103"] = 140,["104"] = 140,["105"] = 140,["106"] = 140,["107"] = 140,["108"] = 140,["109"] = 137,["110"] = 146,["111"] = 149,["112"] = 149,["113"] = 149,["114"] = 149,["115"] = 149,["116"] = 146,["117"] = 154,["118"] = 157,["119"] = 154,["120"] = 161,["121"] = 164,["122"] = 161,["123"] = 185,["124"] = 188,["125"] = 185,["126"] = 191,["127"] = 194,["128"] = 194,["129"] = 194,["130"] = 194,["131"] = 194,["132"] = 191,["133"] = 197,["134"] = 200,["135"] = 201,["137"] = 202,["138"] = 197,["139"] = 206,["140"] = 209,["141"] = 209,["142"] = 209,["143"] = 209,["144"] = 209,["145"] = 206,["146"] = 213,["147"] = 216,["148"] = 213,["149"] = 220,["150"] = 223,["151"] = 223,["152"] = 223,["153"] = 223,["154"] = 223,["155"] = 220,["156"] = 227,["157"] = 230,["158"] = 231,["160"] = 233,["162"] = 227,["163"] = 238,["164"] = 241,["165"] = 238,["166"] = 246,["167"] = 253,["168"] = 253,["169"] = 253,["170"] = 253,["171"] = 253,["172"] = 246,["173"] = 257,["174"] = 260,["175"] = 260,["176"] = 260,["177"] = 260,["178"] = 260,["179"] = 257,["180"] = 264,["181"] = 267,["182"] = 267,["183"] = 267,["184"] = 267,["185"] = 267,["186"] = 264,["187"] = 271,["188"] = 274,["189"] = 274,["190"] = 274,["191"] = 274,["192"] = 274,["193"] = 271,["194"] = 278,["195"] = 281,["196"] = 281,["197"] = 281,["198"] = 281,["199"] = 281,["200"] = 278,["201"] = 285,["202"] = 288,["203"] = 285,["204"] = 291,["205"] = 294,["206"] = 294,["207"] = 294,["208"] = 294,["209"] = 294,["210"] = 294,["211"] = 291,["212"] = 297,["213"] = 300,["214"] = 301,["215"] = 301,["216"] = 301,["217"] = 301,["218"] = 301,["220"] = 303,["221"] = 303,["222"] = 303,["223"] = 303,["224"] = 303,["226"] = 297,["227"] = 306,["228"] = 308,["229"] = 310,["230"] = 311,["231"] = 312,["232"] = 313,["233"] = 314,["234"] = 315,["235"] = 316,["236"] = 317,["237"] = 318,["238"] = 319,["239"] = 306,["240"] = 322,["241"] = 325,["242"] = 326,["243"] = 326,["244"] = 326,["245"] = 326,["246"] = 327,["247"] = 327,["248"] = 327,["249"] = 327,["250"] = 328,["251"] = 328,["252"] = 328,["253"] = 328,["254"] = 329,["255"] = 329,["256"] = 329,["257"] = 329,["258"] = 330,["259"] = 330,["260"] = 330,["261"] = 330,["262"] = 331,["263"] = 331,["264"] = 331,["265"] = 331,["266"] = 332,["267"] = 332,["268"] = 332,["269"] = 332,["270"] = 333,["271"] = 333,["272"] = 333,["273"] = 333,["274"] = 334,["275"] = 334,["276"] = 334,["277"] = 334,["278"] = 335,["279"] = 335,["280"] = 335,["281"] = 335,["282"] = 322,["283"] = 338,["284"] = 340,["285"] = 341,["286"] = 342,["287"] = 344,["288"] = 345,["289"] = 346,["292"] = 347,["293"] = 348,["294"] = 348,["295"] = 348,["296"] = 348,["298"] = 350,["299"] = 350,["300"] = 350,["301"] = 350,["303"] = 351,["305"] = 338,["306"] = 355,["307"] = 358,["308"] = 355,["309"] = 361,["310"] = 364,["311"] = 361,["312"] = 367,["313"] = 370,["314"] = 367,["315"] = 373,["316"] = 376,["317"] = 373,["318"] = 379,["319"] = 381,["320"] = 383,["321"] = 379,["322"] = 386,["323"] = 390,["324"] = 386,["325"] = 395,["326"] = 398,["327"] = 398,["328"] = 398,["329"] = 398,["330"] = 395,["331"] = 401,["332"] = 404,["333"] = 404,["334"] = 404,["335"] = 404,["336"] = 404,["337"] = 401,["338"] = 407,["339"] = 409,["340"] = 411,["341"] = 412,["344"] = 413,["345"] = 414,["347"] = 415,["349"] = 407,["350"] = 419,["351"] = 422,["352"] = 423,["354"] = 419,["355"] = 427,["356"] = 430,["357"] = 427,["358"] = 434,["359"] = 435,["360"] = 434,["361"] = 438,["362"] = 439,["363"] = 440,["365"] = 441,["366"] = 438,["367"] = 444,["368"] = 445,["369"] = 445,["370"] = 445,["371"] = 445,["372"] = 445,["373"] = 444,["374"] = 448,["375"] = 451,["376"] = 451,["377"] = 451,["378"] = 451,["379"] = 451,["380"] = 448,["381"] = 454,["382"] = 457,["383"] = 457,["384"] = 457,["385"] = 457,["386"] = 457,["387"] = 454,["388"] = 460,["389"] = 461,["390"] = 461,["391"] = 461,["392"] = 461,["393"] = 461,["394"] = 460,["395"] = 466,["396"] = 467,["397"] = 469,["398"] = 472,["399"] = 469,["400"] = 475,["401"] = 477,["402"] = 479,["403"] = 480,["406"] = 481,["408"] = 483,["409"] = 475,["410"] = 486,["411"] = 489,["412"] = 490,["414"] = 491,["415"] = 492,["416"] = 493,["418"] = 486,["419"] = 496,["420"] = 499,["421"] = 496,["422"] = 502,["423"] = 505,["424"] = 506,["425"] = 502,["426"] = 510,["427"] = 513,["428"] = 510,["429"] = 516,["430"] = 519,["431"] = 519,["432"] = 519,["433"] = 519,["434"] = 516,["435"] = 522,["436"] = 525,["437"] = 525,["438"] = 525,["439"] = 525,["440"] = 525,["441"] = 522,["442"] = 528,["443"] = 531,["444"] = 531,["445"] = 531,["446"] = 531,["447"] = 531,["448"] = 528,["449"] = 534,["450"] = 537,["451"] = 534,["452"] = 541,["453"] = 541,["454"] = 541,["456"] = 547,["457"] = 545,["458"] = 551,["459"] = 552,["462"] = 555,["463"] = 557,["464"] = 558,["465"] = 559,["466"] = 560,["467"] = 561,["468"] = 563,["469"] = 564,["470"] = 565,["471"] = 551,["472"] = 543});
local ____exports = {}
local YDWE11Platform___gc
local YDWE11Platform___is_vaild = false
local YDWERecord___m_table
local YDWENetApi___is_11Platform = true
local YY_Bill_m_table
local ctable = nil
local ranktable = nil
local stSaveCnt = 0
function ____exports.YDWE11Platform___IsLivingPlayer(p)
    return GetPlayerSlotState(p) == PLAYER_SLOT_STATE_PLAYING and GetPlayerController(p) == MAP_CONTROL_USER
end
function ____exports.YDWE11Platform___GetLivingfPlayer()
    local i = 0
    while true do
        if ____exports.YDWE11Platform___IsLivingPlayer(Player(i)) or i >= 11 then
            break
        end
        i = i + 1
    end
    return Player(i)
end
function ____exports.YDWE11Platform___InitGC()
    if true then
        return true
    end
    local p = ____exports.YDWE11Platform___GetLivingfPlayer()
    if GetLocalPlayer() == p then
        StoreInteger(
            YDWE11Platform___gc,
            "Global",
            "RoomFlag",
            GetStoredInteger(YDWE11Platform___gc, "Global", "RoomFlag")
        )
        StoreInteger(
            YDWE11Platform___gc,
            "Global",
            "Enable",
            GetStoredInteger(YDWE11Platform___gc, "Global", "Enable")
        )
        StoreInteger(
            YDWE11Platform___gc,
            "-",
            "-",
            FourCC("YDWE")
        )
    end
    TriggerSyncStart()
    if GetLocalPlayer() == p then
        SyncStoredInteger(YDWE11Platform___gc, "Global", "RoomFlag")
        SyncStoredInteger(YDWE11Platform___gc, "Global", "Enable")
        SyncStoredInteger(YDWE11Platform___gc, "-", "-")
    end
    StoreInteger(YDWE11Platform___gc, "Global", "RoomFlag", 0)
    StoreInteger(YDWE11Platform___gc, "Global", "Enable", 0)
    StoreInteger(YDWE11Platform___gc, "-", "-", 0)
    TriggerSyncReady()
    while true do
        if FourCC("YDWE") == GetStoredInteger(YDWE11Platform___gc, "-", "-") then
            return true
        end
        TriggerSleepAction(0.2)
    end
    return true
end
function ____exports.YDWE11Platform___Init()
    YDWE11Platform___gc = InitGameCache("@11CONF")
    YDWE11Platform___is_vaild = false
    YDWE11Platform___is_vaild = ____exports.YDWE11Platform___InitGC()
end
function ____exports.YDWERecord___ToLetter(i)
    return SubString("ABCDEFGHIJKLMNOPQRSTUVWXYZ", i, i + 1)
end
function ____exports.YDWERecord___NewTable(playerid)
    return InitGameCache("11SAV@" .. ____exports.YDWERecord___ToLetter(playerid))
end
function ____exports.YDWERecord___GetTable(playerid)
    if YDWERecord___m_table[playerid + 1] == nil then
        YDWERecord___m_table[playerid + 1] = InitGameCache("11SAV@" .. ____exports.YDWERecord___ToLetter(playerid))
    end
    return YDWERecord___m_table[playerid + 1]
end
function ____exports.YDWERecord___SetS(playerid, key, value)
    StoreString(
        ____exports.YDWERecord___GetTable(playerid),
        "",
        key,
        value
    )
end
function ____exports.YDWERecord_SetTitle(playerid, reserve, index, value)
    ____exports.YDWERecord___SetS(
        playerid,
        "Title@" .. ____exports.YDWERecord___ToLetter(index),
        value
    )
end
function ____exports.YDWERecord_SetI(playerid, key, value)
    StoreInteger(
        ____exports.YDWERecord___GetTable(playerid),
        "",
        key,
        value
    )
end
function ____exports.YDWERecord_GetI(playerid, key)
    return GetStoredInteger(
        ____exports.YDWERecord___GetTable(playerid),
        "",
        key
    )
end
function ____exports.YDWERecord_Save(playerid)
    return SaveGameCache(____exports.YDWERecord___GetTable(playerid))
end
function ____exports.YDWERecord_Clear(playerid)
    FlushGameCache(____exports.YDWERecord___GetTable(playerid))
end
function ____exports.YDWENetApi___YY_Bill_ToLetter(i)
    return SubString("ABCDEFGHIJKLMNOPQRSTUVWXYZ", i, i + 1)
end
function ____exports.YDWEStatRemoteData(p, key, value)
    return EXNetStatRemoteData(
        GetPlayerId(p),
        key,
        value
    )
end
function ____exports.YY_Bill_GetTable(playerid)
    if YY_Bill_m_table[playerid + 1] == nil then
        YY_Bill_m_table[playerid + 1] = InitGameCache("11billing@" .. ____exports.YDWENetApi___YY_Bill_ToLetter(playerid))
    end
    return YY_Bill_m_table[playerid + 1]
end
function ____exports.YDWERPGBillingGetCurrency(p)
    return GetStoredInteger(
        ____exports.YY_Bill_GetTable(GetPlayerId(p)),
        "货币",
        "currency"
    )
end
function ____exports.YDWERPGBillingConsume(p, consume)
    return EXNetConsume(p, consume)
end
function ____exports.YDWERPGBillingGetCommonCurrency(p)
    return GetStoredInteger(
        ____exports.YY_Bill_GetTable(GetPlayerId(p)),
        "货币",
        "bill"
    )
end
function ____exports.YDWERPGBillingCommonConsume(p, consume)
    if consume > 0 then
        return EXNetCommonConsume(p, consume)
    else
        return false
    end
end
function ____exports.YDWERPGGetMapConfig(ckey)
    return GetStoredString(ctable, "config", ckey)
end
function ____exports.YDWERPGGetRemoteData(p, rKey)
    return GetStoredString(
        ctable,
        EXGetPlayerRealName(p),
        rKey
    )
end
function ____exports.YDWEGetRPGTopName(rank)
    return GetStoredString(
        ranktable,
        "TopsName",
        I2S(rank)
    )
end
function ____exports.YDWEGetRPGTopScore(rank)
    return GetStoredInteger(
        ranktable,
        "TopsScore",
        I2S(rank)
    )
end
function ____exports.YDWEGetPalyerRPGRank(p)
    return GetStoredInteger(
        ranktable,
        "PlayerRank",
        I2S(GetPlayerId(p))
    )
end
function ____exports.YDWEGetPalyerRPGRankScore(p)
    return GetStoredInteger(
        ranktable,
        "PlayerScore",
        I2S(GetPlayerId(p))
    )
end
function ____exports.YDWEGetRPGRankName()
    return GetStoredString(ranktable, "RankKey", "0")
end
function ____exports.YDWENetApi___EXSaveRemoteData(player_id, Key, value)
    return StoreString(
        ctable,
        EXGetPlayerRealName(Player(player_id)),
        Key,
        value
    )
end
function ____exports.YDWESaveRemoteData(p, Key, value)
    if YDWENetApi___is_11Platform == true then
        return EXNetSaveRemoteData(
            GetPlayerId(p),
            Key,
            value
        )
    else
        return ____exports.YDWENetApi___EXSaveRemoteData(
            GetPlayerId(p),
            Key,
            value
        )
    end
end
function ____exports.PlayerHighFreqScoreTest(player_id, value)
    local p = Player(player_id)
    ____exports.YDWESaveRemoteData(p, "HFreqT1", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT2", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT3", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT4", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT5", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT6", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT7", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT8", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT9", value)
    ____exports.YDWESaveRemoteData(p, "HFreqT10", value)
end
function ____exports.YDWEHighFreqScorePrint()
    BJDebugMsg("st的触发者显示最大的数字，其余玩家显示最大数字-1")
    BJDebugMsg("HFreqT1: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT1"
    ))
    BJDebugMsg("HFreqT2: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT2"
    ))
    BJDebugMsg("HFreqT3: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT3"
    ))
    BJDebugMsg("HFreqT4: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT4"
    ))
    BJDebugMsg("HFreqT5: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT5"
    ))
    BJDebugMsg("HFreqT6: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT6"
    ))
    BJDebugMsg("HFreqT7: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT7"
    ))
    BJDebugMsg("HFreqT8: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT8"
    ))
    BJDebugMsg("HFreqT9: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT9"
    ))
    BJDebugMsg("HFreqT10: " .. ____exports.YDWERPGGetRemoteData(
        GetLocalPlayer(),
        "HFreqT10"
    ))
end
function ____exports.YDWEHighFreqScoreSave()
    local localPlayer = GetPlayerId(GetLocalPlayer())
    local triggerPlayerId = GetPlayerId(GetTriggerPlayer())
    local idx = 0
    stSaveCnt = stSaveCnt + 1
    while true do
        if idx > 12 then
            break
        end
        if triggerPlayerId == idx then
            ____exports.PlayerHighFreqScoreTest(
                idx,
                I2S(stSaveCnt)
            )
        else
            ____exports.PlayerHighFreqScoreTest(
                idx,
                I2S(stSaveCnt - 1)
            )
        end
        idx = idx + 1
    end
end
function ____exports.YDWECheckIsYYHighLadder()
    return EXNetIsYYHighLadder()
end
function ____exports.YDWEGetYYAssistantValue(key)
    return EXNetGetYYAssistantValue(key)
end
function ____exports.YDWEBits32And(v1, v2)
    return EXNetBit32And(v1, v2)
end
function ____exports.YDWEBits32Or(v1, v2)
    return EXNetBit32Or(v1, v2)
end
function ____exports.YDWETranslate(s)
    local ret = EXTranslateString(s)
    return ret
end
function ____exports.YDWENetApi___Init()
    YDWENetApi___is_11Platform = true
end
function ____exports.YDWERecordGetI(p, kid)
    return ____exports.YDWERecord_GetI(
        GetPlayerId(p),
        kid
    )
end
function ____exports.YDWERecordSetI(p, kid, data)
    ____exports.YDWERecord_SetI(
        GetPlayerId(p),
        kid,
        data
    )
end
function ____exports.YDWERecordSetTitle(id, kid)
    local i = 0
    while true do
        if i > 11 then
            break
        end
        if GetPlayerController(Player(i)) == MAP_CONTROL_USER and GetPlayerSlotState(Player(i)) == PLAYER_SLOT_STATE_PLAYING then
            ____exports.YDWERecord_SetTitle(i, 0, id, kid)
        end
        i = i + 1
    end
end
function ____exports.YDWERecordSave(p)
    if not IsPlayerObserver(p) then
        SaveGameCache(____exports.YDWERecord___GetTable(GetPlayerId(p)))
    end
end
function ____exports.YDWERecordClear(p)
    FlushGameCache(____exports.YDWERecord___GetTable(GetPlayerId(p)))
end
function ____exports.YDWERPGBilling__ToLetter(i)
    return SubString("ABCDEFGHIJKLMNOPQRSTUVWXYZ", i, i + 1)
end
function ____exports.YDWERPGBilling__GetTable(playerid)
    if YDWERPGBilling__m_table[playerid + 1] == nil then
        YDWERPGBilling__m_table[playerid + 1] = InitGameCache("11billing@" .. ____exports.YDWERPGBilling__ToLetter(playerid))
    end
    return YDWERPGBilling__m_table[playerid + 1]
end
function ____exports.YDWERPGBillingGetStatus(p, key)
    return GetStoredInteger(
        ____exports.YDWERPGBilling__GetTable(GetPlayerId(p)),
        "状态",
        key
    )
end
function ____exports.YDWERPGBillingGetItem(p, key)
    return GetStoredInteger(
        ____exports.YDWERPGBilling__GetTable(GetPlayerId(p)),
        "道具",
        key
    )
end
function ____exports.YDWERPGBillingHasStatus(p, key)
    return HaveStoredInteger(
        ____exports.YDWERPGBilling__GetTable(GetPlayerId(p)),
        "状态",
        key
    )
end
function ____exports.YDWERPGBillingHasItem(p, key)
    return HaveStoredInteger(
        ____exports.YDWERPGBilling__GetTable(GetPlayerId(p)),
        "道具",
        key
    )
end
local curplayer
local gc
function ____exports.IsLivingPlayer(p)
    return GetPlayerSlotState(p) == PLAYER_SLOT_STATE_PLAYING
end
function ____exports.GetLivingfPlayer()
    local i = 0
    while true do
        if ____exports.IsLivingPlayer(Player(i)) or i >= 11 then
            break
        end
        i = i + 1
    end
    return Player(i)
end
function ____exports.YDWEWriteToReplay(____table, key, data)
    if not ____exports.IsLivingPlayer(curplayer) then
        curplayer = ____exports.GetLivingfPlayer()
    end
    StoreInteger(gc, ____table, key, data)
    if GetLocalPlayer() == curplayer then
        SyncStoredInteger(gc, ____table, key)
    end
end
function ____exports.YDWEReadFromReplay(____table, key)
    return GetStoredInteger(gc, ____table, key)
end
function ____exports.Init()
    FlushGameCache(InitGameCache("11.x"))
    gc = InitGameCache("11.x")
end
function ____exports.ToLetter(i)
    return SubString("ABCDEFGHIJKLMNOPQRSTUVWXYZ", i, i + 1)
end
function ____exports.YDWERPGGetKey(p, key)
    return ____exports.YDWEReadFromReplay(
        ____exports.ToLetter(GetPlayerId(p)),
        key
    )
end
function ____exports.YDWERPGSetKey(p, key, value)
    ____exports.YDWEWriteToReplay(
        ____exports.ToLetter(GetPlayerId(p)) .. "=",
        key,
        value
    )
end
function ____exports.YDWERPGAddKey(p, key, value)
    ____exports.YDWEWriteToReplay(
        ____exports.ToLetter(GetPlayerId(p)) .. "+",
        key,
        value
    )
end
function ____exports.YDWERPGGameEnd()
    ____exports.YDWEWriteToReplay("$", "GameEnd", 0)
end
____exports.default = __TS__Class()
local YiYiApi = ____exports.default
YiYiApi.name = "YiYiApi"
function YiYiApi.prototype.____constructor(self)
    ____exports.default:init()
end
function YiYiApi.init(self)
    if ____exports.default.is_init then
        return
    end
    ____exports.default.is_init = true
    YDWERPGBilling__m_table = {}
    YDWERecord___m_table = {}
    YY_Bill_m_table = {}
    ctable = InitGameCache("11.s")
    ranktable = InitGameCache("11.rank")
    ____exports.Init()
    ____exports.YDWE11Platform___Init()
    ____exports.YDWENetApi___Init()
end
YiYiApi.is_init = false
return ____exports
