local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 5,["16"] = 5,["17"] = 7,["18"] = 7,["19"] = 8,["20"] = 8,["21"] = 9,["22"] = 9,["23"] = 10,["24"] = 10,["25"] = 12,["26"] = 12,["27"] = 12,["29"] = 12,["30"] = 35,["31"] = 36,["34"] = 39,["35"] = 40,["40"] = 58,["43"] = 44,["44"] = 46,["45"] = 48,["52"] = 61,["53"] = 62,["54"] = 63,["55"] = 64,["56"] = 64,["57"] = 64,["58"] = 65,["59"] = 65,["60"] = 65,["61"] = 66,["62"] = 67,["64"] = 65,["65"] = 65,["66"] = 70,["67"] = 64,["68"] = 64,["70"] = 75,["71"] = 76,["72"] = 78,["73"] = 79,["74"] = 82,["75"] = 82,["76"] = 82,["77"] = 82,["78"] = 82,["79"] = 82,["80"] = 82,["81"] = 83,["82"] = 83,["83"] = 83,["84"] = 84,["85"] = 85,["87"] = 87,["88"] = 83,["89"] = 83,["91"] = 90,["92"] = 91,["93"] = 35,["94"] = 94,["95"] = 95,["96"] = 96,["99"] = 99,["100"] = 100,["102"] = 102,["103"] = 103,["105"] = 105,["106"] = 105,["108"] = 105,["110"] = 105,["112"] = 105,["114"] = 105,["117"] = 106,["119"] = 108,["120"] = 109,["121"] = 110,["122"] = 110,["123"] = 110,["124"] = 110,["125"] = 110,["126"] = 110,["127"] = 110,["128"] = 111,["129"] = 112,["130"] = 94,["131"] = 115,["132"] = 116,["133"] = 117,["136"] = 123,["137"] = 124,["138"] = 125,["139"] = 126,["140"] = 127,["143"] = 131,["144"] = 132,["145"] = 133,["148"] = 136,["149"] = 137,["150"] = 138,["153"] = 141,["154"] = 142,["155"] = 143,["158"] = 146,["159"] = 147,["160"] = 148,["163"] = 152,["166"] = 150,["175"] = 157,["176"] = 158,["177"] = 159,["178"] = 160,["182"] = 166,["183"] = 115,["184"] = 170,["185"] = 172,["186"] = 173,["187"] = 174,["188"] = 175,["189"] = 175,["190"] = 177,["191"] = 178,["192"] = 179,["193"] = 180,["195"] = 182,["196"] = 183,["197"] = 183,["199"] = 185,["200"] = 173,["201"] = 188,["202"] = 189,["203"] = 190,["204"] = 191,["205"] = 191,["206"] = 193,["207"] = 194,["208"] = 195,["209"] = 196,["211"] = 198,["212"] = 199,["213"] = 199,["215"] = 201,["216"] = 189,["217"] = 204,["218"] = 204,["219"] = 204,["220"] = 205,["221"] = 204,["222"] = 204,["223"] = 207,["224"] = 208,["225"] = 208,["226"] = 208,["227"] = 209,["228"] = 208,["229"] = 208,["231"] = 213,["232"] = 214,["233"] = 215,["234"] = 215,["235"] = 215,["236"] = 215,["237"] = 215,["238"] = 215,["239"] = 215,["240"] = 216,["241"] = 216,["242"] = 218,["243"] = 219,["244"] = 220,["245"] = 221,["247"] = 223,["248"] = 224,["249"] = 224,["251"] = 226,["252"] = 214,["253"] = 229,["254"] = 230,["255"] = 231,["256"] = 232,["257"] = 232,["258"] = 234,["259"] = 235,["260"] = 236,["261"] = 237,["263"] = 239,["264"] = 240,["265"] = 240,["267"] = 242,["268"] = 230,["269"] = 245,["270"] = 247,["271"] = 248,["272"] = 249,["273"] = 250,["275"] = 252,["276"] = 253,["277"] = 253,["279"] = 245,["280"] = 170,["281"] = 258,["282"] = 259,["283"] = 260,["286"] = 262,["289"] = 265,["290"] = 266,["291"] = 267,["292"] = 268,["293"] = 269,["296"] = 271,["299"] = 274,["300"] = 275,["301"] = 276,["302"] = 277,["303"] = 278,["304"] = 279,["305"] = 280,["308"] = 268,["309"] = 258,["310"] = 286,["311"] = 287,["312"] = 287,["313"] = 289,["314"] = 290,["315"] = 291,["316"] = 292,["318"] = 294,["319"] = 295,["320"] = 295,["322"] = 286,["323"] = 299,["324"] = 300,["325"] = 301,["326"] = 302,["327"] = 302,["328"] = 302,["329"] = 302,["330"] = 302,["331"] = 302,["332"] = 302,["333"] = 303,["334"] = 305,["336"] = 307,["337"] = 308,["339"] = 310,["343"] = 312,["344"] = 313,["345"] = 314,["346"] = 315,["347"] = 317,["348"] = 318,["349"] = 319,["350"] = 320,["352"] = 322,["353"] = 323,["355"] = 325,["356"] = 326,["358"] = 328,["359"] = 329,["361"] = 331,["362"] = 332,["365"] = 336,["368"] = 334,["376"] = 340,["377"] = 341,["378"] = 342,["379"] = 343,["380"] = 299,["381"] = 13,["382"] = 15,["383"] = 16,["384"] = 17,["385"] = 18,["386"] = 19,["387"] = 29,["388"] = 32});
local ____exports = {}
local ____trigger = require("solar.solar-common.w3ts.handles.trigger")
local Trigger = ____trigger.Trigger
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____KeyCode = require("solar.solar-common.constant.KeyCode")
local KeyCode = ____KeyCode.default
local ____SolarConfig = require("solar.solar-common.common.SolarConfig")
local SolarConfig = ____SolarConfig.default
local ____DebugVmUtil = require("solar.solar-common.util.debug.DebugVmUtil")
local DebugVmUtil = ____DebugVmUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____ActorUtil = require("solar.solar-common.actor.util.ActorUtil")
local ActorUtil = ____ActorUtil.default
local ____HookUtil = require("solar.solar-common.util.lang.HookUtil")
local HookUtil = ____HookUtil.default
____exports.default = __TS__Class()
local SolarReload = ____exports.default
SolarReload.name = "SolarReload"
function SolarReload.prototype.____constructor(self)
end
function SolarReload.init(self)
    if _G.SolarReloadInitED then
        return
    end
    _G.SolarReloadInitED = true
    if not local_map_dir_path then
        return
    end
    do
        local function ____catch(e)
            print(e)
        end
        local ____try, ____hasReturned = pcall(function()
            log.debug("local_map_dir_path=" .. local_map_dir_path)
            if isEmbedBrowser and _G.webEngine then
                _G.webEngine.path = (((((((((local_map_dir_path .. "webapp\\dist;") .. local_map_dir_path) .. "webapp\\public\\;") .. local_map_dir_path) .. "webapp;") .. local_map_dir_path) .. "frontend;") .. local_map_dir_path) .. "resource;") .. tostring(_G.webEngine.path)
            end
        end)
        if not ____try then
            ____catch(____hasReturned)
        end
    end
    if SolarConfig.reloadMode == "自动全局" then
        ____exports.default:autoReload()
    elseif SolarConfig.reloadMode == "手动" then
        BaseUtil.runLater(
            1,
            function()
                se:on(
                    "_sl_重载脚本",
                    function(data)
                        for loadedKey in pairs(____exports.default.reloadFileConfig) do
                            ____exports.default:reloadFile(loadedKey)
                        end
                    end
                )
                print("当前热加载模式设置为手动！请按F9重加载@SupportReload()装饰的类")
            end
        )
    end
    local jassCreateTrigger = CreateTrigger
    ____exports.default:hookCreators()
    if DzTriggerRegisterKeyEventByCode and not _G.HasTriggerRegisterKeyEvent then
        local t = jassCreateTrigger()
        DzTriggerRegisterKeyEventByCode(
            t,
            KeyCode.VK_F9,
            1,
            true,
            nil
        )
        TriggerAddAction(
            t,
            function()
                if SolarConfig.reloadMode == "自动全局" then
                    ____exports.default:reload()
                end
                se:emit("_sl_重载脚本")
            end
        )
    end
    _G.HasTriggerRegisterKeyEvent = true
    _G.reloadCount = 1
end
function SolarReload.reloadFile(self, fileModName)
    if PACKAGE.loaded[fileModName] == nil then
        print("未初始化:" .. fileModName)
        return
    else
        PACKAGE.loaded[fileModName] = nil
        ____exports.default:destroyFileHandles(fileModName)
    end
    gv.reloadIng = true
    local requireClassResult = require(fileModName)
    local ____opt_result_2
    if requireClassResult ~= nil then
        ____opt_result_2 = requireClassResult.default
    end
    local ____opt_result_2_5 = ____opt_result_2
    if ____opt_result_2_5 then
        local ____opt_3 = ____exports.default.reloadFileConfig[fileModName]
        if ____opt_3 ~= nil then
            ____opt_3 = ____opt_3.autoNew
        end
        ____opt_result_2_5 = ____opt_3 ~= false
    end
    if ____opt_result_2_5 then
        __TS__New(requireClassResult.default)
    end
    _G.reloadCount = _G.reloadCount + 1
    local info = (("No." .. tostring(_G.reloadCount)) .. " [重新加载代码脚本]!") .. tostring(_g_time)
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        60,
        info
    )
    print(info)
    gv.reloadIng = false
end
function SolarReload.destroyFileHandles(self, fileModName)
    local mapElement = ____exports.default.fileHandlesMap[fileModName]
    if mapElement == nil then
        return
    end
    if mapElement.triggerHandles then
        for ____, handleElement in ipairs(mapElement.triggerHandles) do
            TriggerClearActions(handleElement)
            DisableTrigger(handleElement)
            DestroyTrigger(handleElement)
        end
    end
    if mapElement.timerHandles then
        for ____, handleElement in ipairs(mapElement.timerHandles) do
            DestroyTimer(handleElement)
        end
    end
    if mapElement.unitHandles then
        for ____, handleElement in ipairs(mapElement.unitHandles) do
            RemoveUnit(handleElement)
        end
    end
    if mapElement.itemHandles then
        for ____, handleElement in ipairs(mapElement.itemHandles) do
            RemoveItem(handleElement)
        end
    end
    if mapElement.frameHandles then
        for ____, handleElement in ipairs(mapElement.frameHandles) do
            if handleElement and handleElement > 0 then
                do
                    local function ____catch(e)
                        print((("销毁Frame出错:" .. tostring(handleElement)) .. "=") .. tostring(e))
                    end
                    local ____try, ____hasReturned = pcall(function()
                        DzDestroyFrame(handleElement)
                    end)
                    if not ____try then
                        ____catch(____hasReturned)
                    end
                end
            end
        end
    end
    if mapElement.actors then
        for ____, actor in ipairs(mapElement.actors) do
            if not actor:isDestroyed() then
                actor:destroy(true)
            end
        end
    end
    ____exports.default.fileHandlesMap[fileModName] = {}
end
function SolarReload.hookCreators(self)
    local jassCreateTrigger = CreateTrigger
    _G.CreateTrigger = function()
        local hdl = jassCreateTrigger()
        local ____exports_default_TriggerHandle_6 = ____exports.default.TriggerHandle
        ____exports_default_TriggerHandle_6[#____exports_default_TriggerHandle_6 + 1] = hdl
        local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
        for ____, userScript in ipairs(userScripts) do
            if ____exports.default.fileHandlesMap[userScript] == nil then
                ____exports.default.fileHandlesMap[userScript] = {}
            end
            ____exports.default.fileHandlesMap[userScript].triggerHandles = ____exports.default.fileHandlesMap[userScript].triggerHandles or ({})
            local ____exports_default_fileHandlesMap_userScript_triggerHandles_7 = ____exports.default.fileHandlesMap[userScript].triggerHandles
            ____exports_default_fileHandlesMap_userScript_triggerHandles_7[#____exports_default_fileHandlesMap_userScript_triggerHandles_7 + 1] = hdl
        end
        return hdl
    end
    local jassCreateTimer = CreateTimer
    _G.CreateTimer = function()
        local hdl = jassCreateTimer()
        local ____exports_default_TimerHandle_8 = ____exports.default.TimerHandle
        ____exports_default_TimerHandle_8[#____exports_default_TimerHandle_8 + 1] = hdl
        local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
        for ____, userScript in ipairs(userScripts) do
            if ____exports.default.fileHandlesMap[userScript] == nil then
                ____exports.default.fileHandlesMap[userScript] = {}
            end
            ____exports.default.fileHandlesMap[userScript].timerHandles = ____exports.default.fileHandlesMap[userScript].timerHandles or ({})
            local ____exports_default_fileHandlesMap_userScript_timerHandles_9 = ____exports.default.fileHandlesMap[userScript].timerHandles
            ____exports_default_fileHandlesMap_userScript_timerHandles_9[#____exports_default_fileHandlesMap_userScript_timerHandles_9 + 1] = hdl
        end
        return hdl
    end
    _G.DzCreateFrameByTagName = HookUtil:hookResultNoThis(
        DzCreateFrameByTagName,
        function(____, hdl)
            ____exports.default:hookAddFrameHandles(hdl)
        end
    )
    if FrameAddModel then
        _G.FrameAddModel = HookUtil:hookResultNoThis(
            FrameAddModel,
            function(____, hdl)
                ____exports.default:hookAddFrameHandles(hdl)
            end
        )
    end
    local jassCreateUnit = CreateUnit
    _G.CreateUnit = function(id, unitid, x, y, face)
        local hdl = jassCreateUnit(
            id,
            unitid,
            x,
            y,
            face
        )
        local ____exports_default_unitHandle_10 = ____exports.default.unitHandle
        ____exports_default_unitHandle_10[#____exports_default_unitHandle_10 + 1] = hdl
        local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
        for ____, userScript in ipairs(userScripts) do
            if ____exports.default.fileHandlesMap[userScript] == nil then
                ____exports.default.fileHandlesMap[userScript] = {}
            end
            ____exports.default.fileHandlesMap[userScript].unitHandles = ____exports.default.fileHandlesMap[userScript].unitHandles or ({})
            local ____exports_default_fileHandlesMap_userScript_unitHandles_11 = ____exports.default.fileHandlesMap[userScript].unitHandles
            ____exports_default_fileHandlesMap_userScript_unitHandles_11[#____exports_default_fileHandlesMap_userScript_unitHandles_11 + 1] = hdl
        end
        return hdl
    end
    local jassCreateItem = CreateItem
    _G.CreateItem = function(itemid, x, y)
        local hdl = jassCreateItem(itemid, x, y)
        local ____exports_default_itemHandle_12 = ____exports.default.itemHandle
        ____exports_default_itemHandle_12[#____exports_default_itemHandle_12 + 1] = hdl
        local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
        for ____, userScript in ipairs(userScripts) do
            if ____exports.default.fileHandlesMap[userScript] == nil then
                ____exports.default.fileHandlesMap[userScript] = {}
            end
            ____exports.default.fileHandlesMap[userScript].itemHandles = ____exports.default.fileHandlesMap[userScript].itemHandles or ({})
            local ____exports_default_fileHandlesMap_userScript_itemHandles_13 = ____exports.default.fileHandlesMap[userScript].itemHandles
            ____exports_default_fileHandlesMap_userScript_itemHandles_13[#____exports_default_fileHandlesMap_userScript_itemHandles_13 + 1] = hdl
        end
        return hdl
    end
    ActorUtil:addAnyActorCreatedListener(function(____, actor)
        local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
        for ____, userScript in ipairs(userScripts) do
            if ____exports.default.fileHandlesMap[userScript] == nil then
                ____exports.default.fileHandlesMap[userScript] = {}
            end
            ____exports.default.fileHandlesMap[userScript].actors = ____exports.default.fileHandlesMap[userScript].actors or ({})
            local ____exports_default_fileHandlesMap_userScript_actors_14 = ____exports.default.fileHandlesMap[userScript].actors
            ____exports_default_fileHandlesMap_userScript_actors_14[#____exports_default_fileHandlesMap_userScript_actors_14 + 1] = actor
        end
    end)
end
function SolarReload.autoReload(self)
    _G.scripts_lastModified = -1
    PACKAGE.loaded._SLA_temp = nil
    do
        pcall(function()
            require("_SLA_temp")
        end)
    end
    _G.scripts_last_reload = _G.scripts_lastModified
    local trigger = __TS__New(Trigger)
    trigger:registerTimerEvent(0.5, true)
    trigger:addAction(function()
        PACKAGE.loaded._SLA_temp = nil
        do
            pcall(function()
                require("_SLA_temp")
            end)
        end
        if _G.scripts_lastModified > _G.scripts_last_reload then
            _G.scripts_last_reload = _G.scripts_lastModified
            if time > 3000 then
                print("======自动更新======")
                print("_G.scripts_lastModified=" .. tostring(_G.scripts_lastModified))
                print("_G.scripts_last_reload=" .. tostring(_G.scripts_last_reload))
                ____exports.default:reload()
            end
        end
    end)
end
function SolarReload.hookAddFrameHandles(self, hdl)
    local ____exports_default_frameHandle_15 = ____exports.default.frameHandle
    ____exports_default_frameHandle_15[#____exports_default_frameHandle_15 + 1] = hdl
    local userScripts = DebugVmUtil:getUserScriptRequireModNameByStack()
    for ____, userScript in ipairs(userScripts) do
        if ____exports.default.fileHandlesMap[userScript] == nil then
            ____exports.default.fileHandlesMap[userScript] = {}
        end
        ____exports.default.fileHandlesMap[userScript].frameHandles = ____exports.default.fileHandlesMap[userScript].frameHandles or ({})
        local ____exports_default_fileHandlesMap_userScript_frameHandles_16 = ____exports.default.fileHandlesMap[userScript].frameHandles
        ____exports_default_fileHandlesMap_userScript_frameHandles_16[#____exports_default_fileHandlesMap_userScript_frameHandles_16 + 1] = hdl
    end
end
function SolarReload.reload(self)
    _G.reloadCount = _G.reloadCount + 1
    local info = (("No." .. tostring(_G.reloadCount)) .. " [重新加载代码脚本]!") .. tostring(_g_time)
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        60,
        info
    )
    print(info)
    for loadedKey in pairs(PACKAGE.loaded) do
        do
            if loadedKey and (string.find(loadedKey, "solar.", nil, true) or 0) - 1 >= 0 then
                goto __continue81
            end
            PACKAGE.loaded[loadedKey] = nil
        end
        ::__continue81::
    end
    se:clear()
    SingletonUtil.cache:clear()
    SingletonUtil._sl_cache = {}
    DataBase.dataBaseContext = {}
    for ____, handleElement in ipairs(____exports.default.TriggerHandle) do
        TriggerClearActions(handleElement)
        DisableTrigger(handleElement)
        DestroyTrigger(handleElement)
    end
    for ____, handleElement in ipairs(____exports.default.TimerHandle) do
        DestroyTimer(handleElement)
    end
    for ____, handleElement in ipairs(____exports.default.unitHandle) do
        RemoveUnit(handleElement)
    end
    for ____, handleElement in ipairs(____exports.default.itemHandle) do
        RemoveItem(handleElement)
    end
    for ____, handleElement in ipairs(____exports.default.frameHandle) do
        if handleElement and handleElement > 0 then
            do
                local function ____catch(e)
                    print((("销毁Frame出错:" .. tostring(handleElement)) .. "=") .. tostring(e))
                end
                local ____try, ____hasReturned = pcall(function()
                    DzDestroyFrame(handleElement)
                end)
                if not ____try then
                    ____catch(____hasReturned)
                end
            end
        end
    end
    ____exports.default.TriggerHandle = {}
    ____exports.default.TimerHandle = {}
    ____exports.default.frameHandle = {}
    require("App")
end
SolarReload.config = {}
SolarReload.TriggerHandle = {}
SolarReload.TimerHandle = {}
SolarReload.frameHandle = {}
SolarReload.unitHandle = {}
SolarReload.itemHandle = {}
SolarReload.fileHandlesMap = {}
SolarReload.reloadFileConfig = {}
return ____exports
