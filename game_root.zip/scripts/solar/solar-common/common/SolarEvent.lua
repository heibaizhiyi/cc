local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 2,["8"] = 2,["9"] = 3,["10"] = 3,["11"] = 4,["12"] = 4,["13"] = 5,["14"] = 5,["15"] = 6,["16"] = 6,["17"] = 7,["18"] = 7,["19"] = 8,["20"] = 8,["21"] = 9,["22"] = 9,["23"] = 10,["24"] = 10,["25"] = 11,["26"] = 11,["27"] = 12,["28"] = 12,["29"] = 13,["30"] = 13,["31"] = 14,["32"] = 14,["33"] = 15,["34"] = 15,["35"] = 17,["36"] = 18,["37"] = 25,["38"] = 25,["39"] = 25,["41"] = 29,["42"] = 30,["45"] = 28,["46"] = 41,["47"] = 42,["48"] = 43,["49"] = 43,["50"] = 43,["51"] = 44,["52"] = 45,["53"] = 45,["54"] = 45,["56"] = 46,["57"] = 46,["58"] = 47,["59"] = 46,["62"] = 45,["63"] = 45,["64"] = 50,["65"] = 43,["66"] = 43,["67"] = 52,["68"] = 52,["69"] = 52,["70"] = 53,["71"] = 52,["72"] = 52,["73"] = 52,["74"] = 41,["75"] = 63,["76"] = 64,["77"] = 63,["78"] = 72,["79"] = 72,["80"] = 72,["82"] = 73,["83"] = 73,["84"] = 73,["85"] = 74,["86"] = 73,["87"] = 73,["88"] = 73,["89"] = 72,["90"] = 84,["91"] = 84,["92"] = 84,["94"] = 85,["95"] = 86,["96"] = 86,["97"] = 86,["98"] = 87,["99"] = 88,["101"] = 89,["102"] = 89,["103"] = 90,["104"] = 90,["105"] = 90,["106"] = 90,["107"] = 90,["108"] = 90,["109"] = 89,["112"] = 92,["113"] = 92,["114"] = 92,["116"] = 93,["117"] = 93,["118"] = 94,["119"] = 93,["122"] = 92,["123"] = 92,["124"] = 97,["125"] = 86,["126"] = 86,["127"] = 99,["128"] = 99,["129"] = 99,["130"] = 100,["131"] = 99,["132"] = 99,["133"] = 99,["134"] = 84,["135"] = 108,["136"] = 108,["137"] = 108,["139"] = 109,["140"] = 111,["141"] = 111,["142"] = 111,["143"] = 112,["144"] = 113,["145"] = 114,["146"] = 115,["147"] = 115,["148"] = 115,["150"] = 116,["151"] = 116,["152"] = 117,["153"] = 116,["156"] = 115,["157"] = 115,["158"] = 121,["159"] = 111,["160"] = 111,["161"] = 123,["162"] = 123,["163"] = 123,["164"] = 124,["167"] = 127,["168"] = 127,["169"] = 127,["170"] = 127,["171"] = 127,["172"] = 123,["173"] = 123,["174"] = 123,["175"] = 108,["176"] = 137,["177"] = 137,["178"] = 137,["180"] = 138,["181"] = 139,["182"] = 139,["183"] = 139,["184"] = 140,["185"] = 141,["186"] = 142,["187"] = 143,["188"] = 143,["189"] = 143,["191"] = 144,["192"] = 144,["193"] = 145,["194"] = 144,["197"] = 143,["198"] = 143,["199"] = 148,["200"] = 139,["201"] = 139,["202"] = 150,["203"] = 150,["204"] = 150,["205"] = 151,["208"] = 154,["209"] = 150,["210"] = 150,["211"] = 150,["212"] = 137,["213"] = 161,["214"] = 161,["215"] = 161,["217"] = 162,["218"] = 163,["219"] = 163,["220"] = 163,["221"] = 164,["222"] = 165,["223"] = 166,["224"] = 168,["225"] = 169,["226"] = 170,["227"] = 170,["228"] = 170,["230"] = 171,["231"] = 171,["232"] = 172,["233"] = 171,["236"] = 170,["237"] = 170,["238"] = 175,["239"] = 163,["240"] = 163,["241"] = 177,["242"] = 177,["243"] = 177,["244"] = 178,["245"] = 177,["246"] = 177,["247"] = 177,["248"] = 161,["249"] = 185,["250"] = 185,["251"] = 185,["253"] = 186,["254"] = 187,["255"] = 187,["256"] = 187,["257"] = 188,["258"] = 189,["259"] = 190,["260"] = 192,["261"] = 193,["262"] = 194,["263"] = 194,["264"] = 194,["266"] = 195,["267"] = 195,["268"] = 196,["269"] = 195,["272"] = 194,["273"] = 194,["274"] = 199,["275"] = 187,["276"] = 187,["277"] = 201,["278"] = 201,["279"] = 201,["280"] = 202,["281"] = 201,["282"] = 201,["283"] = 201,["284"] = 185,["285"] = 210,["286"] = 211,["287"] = 212,["288"] = 212,["289"] = 212,["290"] = 213,["291"] = 214,["292"] = 215,["293"] = 215,["294"] = 215,["295"] = 215,["296"] = 217,["297"] = 218,["298"] = 219,["299"] = 219,["300"] = 219,["302"] = 220,["303"] = 220,["304"] = 221,["305"] = 220,["308"] = 219,["309"] = 219,["310"] = 224,["311"] = 212,["312"] = 212,["313"] = 226,["314"] = 226,["315"] = 226,["316"] = 227,["317"] = 226,["318"] = 226,["319"] = 226,["320"] = 210,["321"] = 236,["322"] = 237,["323"] = 237,["324"] = 237,["325"] = 238,["326"] = 237,["327"] = 237,["328"] = 236,["329"] = 246,["330"] = 247,["331"] = 247,["332"] = 247,["333"] = 248,["334"] = 247,["335"] = 247,["336"] = 246,["337"] = 256,["338"] = 257,["339"] = 257,["340"] = 257,["341"] = 258,["342"] = 257,["343"] = 257,["344"] = 256,["345"] = 267,["346"] = 268,["347"] = 268,["348"] = 268,["349"] = 269,["350"] = 268,["351"] = 268,["352"] = 267,["353"] = 278,["354"] = 279,["355"] = 279,["356"] = 279,["357"] = 280,["358"] = 279,["359"] = 279,["360"] = 278,["361"] = 289,["362"] = 290,["363"] = 290,["364"] = 290,["365"] = 291,["366"] = 290,["367"] = 290,["368"] = 289,["369"] = 299,["370"] = 300,["371"] = 300,["372"] = 300,["373"] = 301,["374"] = 300,["375"] = 300,["376"] = 299,["377"] = 309,["378"] = 310,["379"] = 310,["380"] = 310,["381"] = 311,["382"] = 310,["383"] = 310,["384"] = 309,["385"] = 319,["386"] = 320,["387"] = 320,["388"] = 320,["389"] = 321,["390"] = 320,["391"] = 320,["392"] = 319,["393"] = 329,["394"] = 330,["395"] = 330,["396"] = 330,["397"] = 331,["398"] = 330,["399"] = 330,["400"] = 329,["401"] = 339,["402"] = 340,["403"] = 340,["404"] = 340,["405"] = 341,["406"] = 340,["407"] = 340,["408"] = 339,["409"] = 349,["410"] = 350,["411"] = 350,["412"] = 350,["413"] = 351,["414"] = 350,["415"] = 350,["416"] = 349,["417"] = 367,["418"] = 368,["419"] = 368,["420"] = 368,["421"] = 369,["422"] = 370,["423"] = 371,["424"] = 372,["425"] = 373,["428"] = 376,["429"] = 377,["431"] = 379,["432"] = 380,["433"] = 368,["434"] = 368,["435"] = 367,["436"] = 390,["437"] = 391,["438"] = 390,["439"] = 399,["440"] = 400,["441"] = 399,["442"] = 408,["443"] = 409,["444"] = 408,["445"] = 416,["446"] = 417,["447"] = 417,["448"] = 417,["449"] = 418,["450"] = 418,["451"] = 418,["452"] = 418,["453"] = 417,["454"] = 417,["455"] = 416,["456"] = 427,["457"] = 428,["458"] = 429,["459"] = 430,["460"] = 431,["461"] = 431,["462"] = 431,["463"] = 432,["464"] = 431,["465"] = 431,["466"] = 431,["467"] = 427,["468"] = 441,["469"] = 442,["470"] = 442,["471"] = 442,["472"] = 443,["473"] = 442,["474"] = 442,["475"] = 442,["476"] = 441,["477"] = 451,["478"] = 452,["479"] = 452,["480"] = 452,["481"] = 453,["482"] = 452,["483"] = 452,["484"] = 451,["485"] = 461,["486"] = 462,["487"] = 462,["488"] = 462,["489"] = 463,["490"] = 462,["491"] = 462,["492"] = 461,["493"] = 472,["494"] = 473,["495"] = 473,["496"] = 473,["497"] = 474,["498"] = 474,["499"] = 474,["500"] = 474,["501"] = 473,["502"] = 473,["503"] = 472,["504"] = 482,["505"] = 483,["506"] = 483,["507"] = 483,["508"] = 484,["509"] = 483,["510"] = 483,["511"] = 482,["512"] = 492,["513"] = 493,["514"] = 493,["515"] = 493,["516"] = 494,["517"] = 493,["518"] = 493,["519"] = 492,["520"] = 503,["521"] = 504,["522"] = 505,["523"] = 506,["525"] = 504,["526"] = 503,["527"] = 515,["528"] = 516,["529"] = 516,["530"] = 516,["531"] = 517,["532"] = 516,["533"] = 516,["534"] = 515,["535"] = 524,["536"] = 525,["537"] = 526,["538"] = 526,["539"] = 526,["540"] = 528,["541"] = 529,["543"] = 530,["544"] = 530,["545"] = 531,["546"] = 531,["547"] = 531,["548"] = 531,["549"] = 531,["550"] = 531,["551"] = 530,["554"] = 533,["555"] = 533,["556"] = 533,["558"] = 534,["559"] = 534,["560"] = 535,["561"] = 534,["564"] = 538,["565"] = 538,["566"] = 538,["567"] = 538,["568"] = 538,["569"] = 539,["571"] = 540,["572"] = 540,["573"] = 541,["574"] = 540,["578"] = 544,["579"] = 544,["580"] = 544,["581"] = 544,["582"] = 544,["583"] = 545,["585"] = 546,["586"] = 546,["587"] = 547,["588"] = 546,["592"] = 533,["593"] = 533,["594"] = 551,["595"] = 526,["596"] = 526,["597"] = 553,["598"] = 554,["600"] = 556,["601"] = 557,["603"] = 559,["604"] = 559,["605"] = 559,["606"] = 560,["607"] = 560,["608"] = 560,["609"] = 560,["610"] = 559,["611"] = 559,["612"] = 559,["613"] = 524,["614"] = 567,["615"] = 568,["616"] = 569,["617"] = 569,["618"] = 569,["619"] = 571,["620"] = 572,["622"] = 573,["623"] = 573,["624"] = 574,["625"] = 574,["626"] = 574,["627"] = 574,["628"] = 574,["629"] = 574,["630"] = 573,["633"] = 576,["634"] = 576,["635"] = 576,["637"] = 577,["638"] = 577,["639"] = 578,["640"] = 577,["643"] = 581,["644"] = 581,["645"] = 581,["646"] = 581,["647"] = 581,["648"] = 582,["650"] = 583,["651"] = 583,["652"] = 584,["653"] = 583,["657"] = 576,["658"] = 576,["659"] = 588,["660"] = 569,["661"] = 569,["662"] = 590,["663"] = 591,["665"] = 593,["666"] = 593,["667"] = 593,["668"] = 594,["669"] = 593,["670"] = 593,["671"] = 593,["672"] = 567,["673"] = 602,["674"] = 603,["675"] = 604,["676"] = 604,["677"] = 604,["678"] = 606,["679"] = 608,["680"] = 608,["681"] = 608,["682"] = 608,["683"] = 608,["684"] = 609,["685"] = 610,["687"] = 611,["688"] = 611,["689"] = 612,["690"] = 611,["693"] = 614,["695"] = 606,["696"] = 604,["697"] = 604,["698"] = 619,["699"] = 621,["700"] = 622,["701"] = 622,["702"] = 622,["703"] = 623,["704"] = 622,["705"] = 622,["706"] = 622,["707"] = 602,["708"] = 635,["709"] = 637,["710"] = 638,["711"] = 639,["712"] = 640,["713"] = 641,["714"] = 641,["715"] = 641,["717"] = 642,["718"] = 642,["719"] = 643,["720"] = 642,["723"] = 641,["724"] = 641,["725"] = 646,["726"] = 646,["727"] = 646,["728"] = 647,["729"] = 646,["730"] = 646,["731"] = 646,["732"] = 649,["733"] = 650,["734"] = 651,["735"] = 649,["736"] = 653,["737"] = 635,["738"] = 659,["739"] = 660,["740"] = 661,["741"] = 659,["742"] = 665,["743"] = 666,["744"] = 667,["745"] = 668,["746"] = 669,["748"] = 671,["749"] = 672,["751"] = 674,["753"] = 676,["754"] = 676,["755"] = 676,["756"] = 665,["757"] = 679,["758"] = 680,["759"] = 681,["760"] = 682,["761"] = 683,["763"] = 685,["764"] = 686,["766"] = 688,["768"] = 690,["769"] = 690,["770"] = 690,["771"] = 679,["772"] = 694,["773"] = 695,["774"] = 696,["775"] = 697,["776"] = 698,["778"] = 700,["779"] = 701,["781"] = 703,["783"] = 705,["784"] = 705,["785"] = 705,["786"] = 694,["787"] = 709,["788"] = 710,["789"] = 711,["790"] = 711,["791"] = 711,["792"] = 711,["793"] = 712,["794"] = 713,["796"] = 715,["797"] = 716,["799"] = 718,["801"] = 720,["802"] = 720,["803"] = 720,["804"] = 720,["805"] = 720,["806"] = 720,["807"] = 709,["808"] = 361});
local ____exports = {}
local ____mitt = require("solar.solar-common.lib.mitt")
local mitt = ____mitt.default
local ____Cache = require("solar.solar-common.tool.Cache")
local Cache = ____Cache.default
local ____TriggerUtil = require("solar.solar-common.util.system.TriggerUtil")
local TriggerUtil = ____TriggerUtil.default
local ____UnitSpellEvent = require("solar.solar-common.tool.event.UnitSpellEvent")
local UnitSpellEvent = ____UnitSpellEvent.default
local ____UnitDeathEvent = require("solar.solar-common.tool.event.UnitDeathEvent")
local UnitDeathEvent = ____UnitDeathEvent.default
local ____UnitAttackedEvent = require("solar.solar-common.tool.event.UnitAttackedEvent")
local UnitAttackedEvent = ____UnitAttackedEvent.default
local ____UnitDamagedEvent = require("solar.solar-common.tool.event.UnitDamagedEvent")
local UnitDamagedEvent = ____UnitDamagedEvent.default
local ____UnitEvent = require("solar.solar-common.tool.event.UnitEvent")
local UnitEvent = ____UnitEvent.default
local ____UnitItemEvent = require("solar.solar-common.tool.event.UnitItemEvent")
local UnitItemEvent = ____UnitItemEvent.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____SolarTrigger = require("solar.solar-common.common.SolarTrigger")
local SolarTrigger = ____SolarTrigger.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____PlayerEvent = require("solar.solar-common.tool.event.PlayerEvent")
local PlayerEvent = ____PlayerEvent.default
local ____UIFrameEvent = require("solar.solar-common.tool.event.UIFrameEvent")
local UIFrameEvent = ____UIFrameEvent.default
local emitter = mitt()
local cache = __TS__New(Cache)
____exports.default = __TS__Class()
local SolarEvent = ____exports.default
SolarEvent.name = "SolarEvent"
function SolarEvent.prototype.____constructor(self)
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new SolarEvent() 请直接使用全局变量se进行访问")
        return
    end
end
function SolarEvent.prototype.on(self, ____type, handler)
    local key = "on:" .. tostring(____type)
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            emitter:on(
                ____type,
                function(data)
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec(data)
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(____self, data)
            handler(data, ____self)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.emit(self, ____type, data)
    emitter:emit(____type, data)
end
function SolarEvent.prototype.playerChat(self, chatMessageToDetect, callback, exactMatchOnly)
    if exactMatchOnly == nil then
        exactMatchOnly = true
    end
    return self:onPlayerChat(
        chatMessageToDetect,
        function(e, s)
            callback(e.triggerPlayer, e.eventPlayerChatString)
        end,
        exactMatchOnly
    )
end
function SolarEvent.prototype.onPlayerChat(self, chatMessageToDetect, callback, exactMatchOnly)
    if exactMatchOnly == nil then
        exactMatchOnly = true
    end
    local key = (("onPlayerChat:" .. chatMessageToDetect) .. ":") .. tostring(exactMatchOnly)
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local trigger = CreateTrigger()
            do
                local i = 0
                while i < bj_MAX_PLAYER_SLOTS do
                    TriggerRegisterPlayerChatEvent(
                        trigger,
                        Player(i),
                        chatMessageToDetect,
                        exactMatchOnly
                    )
                    i = i + 1
                end
            end
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(PlayerEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.unitDamaged(self, callback, onlyHasDamageSource)
    if onlyHasDamageSource == nil then
        onlyHasDamageSource = true
    end
    local key = "unitDamaged"
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local trigger = CreateTrigger()
            TriggerUtil.SystemAnyUnitDamagedRegistTrigger(trigger)
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function()
            if onlyHasDamageSource and not IsHandle(GetEventDamageSource()) then
                return
            end
            callback(
                GetTriggerUnit(),
                GetEventDamageSource(),
                GetEventDamage()
            )
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onUnitDamaged(self, callback, onlyHasDamageSource)
    if onlyHasDamageSource == nil then
        onlyHasDamageSource = true
    end
    local key = "onUnitDamaged"
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local trigger = CreateTrigger()
            TriggerUtil.SystemAnyUnitDamagedRegistTrigger(trigger)
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            if onlyHasDamageSource and not IsHandle(GetEventDamageSource()) then
                return
            end
            callback(UnitDamagedEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onLeaveRect(self, whichRect, callback)
    if whichRect == nil then
        whichRect = bj_mapInitialPlayableArea
    end
    local key = "onLeaveRect:" .. tostring(GetHandleId(whichRect))
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local rectRegion = CreateRegion()
            RegionAddRect(rectRegion, whichRect)
            local trigger = CreateTrigger()
            TriggerRegisterLeaveRegion(trigger, rectRegion, nil)
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onEnterRect(self, whichRect, callback)
    if whichRect == nil then
        whichRect = bj_mapInitialPlayableArea
    end
    local key = "onEnterRect:" .. tostring(GetHandleId(whichRect))
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local rectRegion = CreateRegion()
            RegionAddRect(rectRegion, whichRect)
            local trigger = CreateTrigger()
            TriggerRegisterEnterRegion(trigger, rectRegion, nil)
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onUnitEnterMapRect(self, callback)
    local key = "onUnitEnterMapRect"
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local rectRegion = CreateRegion()
            RegionAddRect(
                rectRegion,
                GetPlayableMapRect()
            )
            local trigger = CreateTrigger()
            TriggerRegisterEnterRegion(trigger, rectRegion, nil)
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onUnitPawnItem(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_PAWN_ITEM,
        function(triggerUnit, solarTrigger)
            callback(UnitItemEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitSellItem(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_SELL_ITEM,
        function(triggerUnit, solarTrigger)
            callback(UnitItemEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitPickupItem(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_PICKUP_ITEM,
        function(triggerUnit, solarTrigger)
            callback(UnitItemEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitDropItem(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_DROP_ITEM,
        function(triggerUnit, solarTrigger)
            callback(UnitItemEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitUseItem(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_USE_ITEM,
        function(triggerUnit, solarTrigger)
            callback(UnitItemEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitConstructStart(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_CONSTRUCT_START,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitConstructFinish(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_CONSTRUCT_FINISH,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitConstructCancel(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_CONSTRUCT_CANCEL,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitUpgradeFinish(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_UPGRADE_FINISH,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitTrainStart(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_TRAIN_START,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitTrainFinish(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_TRAIN_FINISH,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitSelected(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_SELECTED,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitDoubleClickSelected(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_SELECTED,
        function(triggerUnit, solarTrigger)
            local tu = GetTriggerUnit()
            local playerId = GetPlayerId(GetOwningPlayer(tu))
            local lastSelectInfo = ____exports.default._sl_last_select_info[playerId]
            if lastSelectInfo == nil then
                ____exports.default._sl_last_select_info[playerId] = {unit = tu, time = _g_time}
                return
            end
            if lastSelectInfo.unit == tu and _g_time - lastSelectInfo.time < 1000 then
                callback(UnitEvent.instance, solarTrigger)
            end
            lastSelectInfo.unit = tu
            lastSelectInfo.time = _g_time
        end
    )
end
function SolarEvent.prototype.onUnitSpellChannel(self, callback, abilityId)
    return self:anyUnitSpellEvent(EVENT_PLAYER_UNIT_SPELL_CHANNEL, callback, abilityId)
end
function SolarEvent.prototype.onUnitSpellCast(self, callback, abilityId)
    return self:anyUnitSpellEvent(EVENT_PLAYER_UNIT_SPELL_CAST, callback, abilityId)
end
function SolarEvent.prototype.onUnitSpellEffect(self, callback, abilityId)
    return self:anyUnitSpellEvent(EVENT_PLAYER_UNIT_SPELL_EFFECT, callback, abilityId)
end
function SolarEvent.prototype.unitDeath(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_DEATH,
        function(triggerUnit)
            callback(
                triggerUnit,
                GetKillingUnit()
            )
        end
    )
end
function SolarEvent.prototype.onUnitTypeDeath(self, callback, unitTypeIdStr)
    self:anyUnitEvent(EVENT_PLAYER_UNIT_DEATH, nil)
    local key = "anyUnitEvent:" .. tostring(GetHandleId(EVENT_PLAYER_UNIT_DEATH))
    local solarTriggerSet = ____exports.default:getUnitTypeDataEventHandler(unitTypeIdStr, key, true)
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitDeathEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onUnitDeath(self, callback, unit)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_DEATH,
        function(t, solarTrigger)
            callback(UnitDeathEvent.instance, solarTrigger)
        end,
        unit
    )
end
function SolarEvent.prototype.onUnitResearchStart(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_RESEARCH_START,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitResearchFinish(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_RESEARCH_FINISH,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.unitAttacked(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_ATTACKED,
        function(triggerUnit)
            callback(
                triggerUnit,
                GetAttacker()
            )
        end
    )
end
function SolarEvent.prototype.onUnitAttacked(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_ATTACKED,
        function(triggerUnit, solarTrigger)
            callback(UnitAttackedEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitSellUnit(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_UNIT_SELL,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.onUnitAttackedDamage(self, callback)
    return self:onUnitDamaged(function(e, solarTrigger)
        if 0 ~= EXGetEventDamageData(EVENT_DAMAGE_DATA_IS_ATTACK) then
            callback(e, solarTrigger)
        end
    end)
end
function SolarEvent.prototype.onHeroLevelUp(self, callback)
    return self:anyUnitEvent(
        EVENT_PLAYER_HERO_LEVEL,
        function(triggerUnit, solarTrigger)
            callback(UnitEvent.instance, solarTrigger)
        end
    )
end
function SolarEvent.prototype.anyUnitEvent(self, whichPlayerUnitEvent, callback, unit)
    local key = "anyUnitEvent:" .. tostring(GetHandleId(whichPlayerUnitEvent))
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local trigger = CreateTrigger()
            do
                local i = 0
                while i < bj_MAX_PLAYER_SLOTS do
                    TriggerRegisterPlayerUnitEvent(
                        trigger,
                        Player(i),
                        whichPlayerUnitEvent,
                        nil
                    )
                    i = i + 1
                end
            end
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    local dataEventHandler = ____exports.default:getUnitDataEventHandler(
                        GetTriggerUnit(),
                        key,
                        false
                    )
                    if dataEventHandler then
                        do
                            local i = #dataEventHandler - 1
                            while i >= 0 do
                                dataEventHandler[i + 1]:exec()
                                i = i - 1
                            end
                        end
                    end
                    dataEventHandler = ____exports.default:getUnitTypeDataEventHandler(
                        id2string(GetUnitTypeId(GetTriggerUnit())),
                        key,
                        false
                    )
                    if dataEventHandler then
                        do
                            local i = #dataEventHandler - 1
                            while i >= 0 do
                                dataEventHandler[i + 1]:exec()
                                i = i - 1
                            end
                        end
                    end
                end
            )
            return stSet
        end
    )
    if callback == nil then
        return nil
    end
    if IsHandle(unit) then
        solarTriggerSet = ____exports.default:getUnitDataEventHandler(unit, key, true)
    end
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(
                GetTriggerUnit(),
                solarTrigger
            )
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.anyUnitSpellEvent(self, whichPlayerUnitEvent, callback, spellAbilityId)
    local key = "anyUnitSpellEvent:" .. tostring(GetHandleId(whichPlayerUnitEvent))
    local solarTriggerSet = cache:get(
        key,
        function()
            local stSet = {}
            local trigger = CreateTrigger()
            do
                local i = 0
                while i < bj_MAX_PLAYER_SLOTS do
                    TriggerRegisterPlayerUnitEvent(
                        trigger,
                        Player(i),
                        whichPlayerUnitEvent,
                        nil
                    )
                    i = i + 1
                end
            end
            TriggerAddAction(
                trigger,
                function()
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    local dataEventHandler = ____exports.default:getUnitSpellAbilityDataEventHandler(
                        id2string(GetSpellAbilityId()),
                        key,
                        false
                    )
                    if dataEventHandler then
                        do
                            local i = #dataEventHandler - 1
                            while i >= 0 do
                                dataEventHandler[i + 1]:exec()
                                i = i - 1
                            end
                        end
                    end
                end
            )
            return stSet
        end
    )
    if spellAbilityId then
        solarTriggerSet = ____exports.default:getUnitSpellAbilityDataEventHandler(spellAbilityId, key, true)
    end
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitSpellEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onFrameEvent(self, frame, event, callback)
    local key = "onFrameEvent:" .. tostring(event)
    local funcHandle = cache:get(
        key,
        function()
            return function()
                local dataEventHandler = ____exports.default:getFrameDataEventHandler(
                    DzGetTriggerUIEventFrame(),
                    key,
                    false
                )
                if dataEventHandler then
                    isAsync = true
                    do
                        local i = #dataEventHandler - 1
                        while i >= 0 do
                            dataEventHandler[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    isAsync = false
                end
            end
        end
    )
    DzFrameSetScriptByCode(frame, event, funcHandle, false)
    local solarTriggerSet = ____exports.default:getFrameDataEventHandler(frame, key, true)
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UIFrameEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function SolarEvent.prototype.onUnitInRange(self, unit, range, callback)
    handle_ref(unit)
    local solarTriggerSet = {}
    local t = CreateTrigger()
    TriggerRegisterUnitInRange(t, unit, range, nil)
    TriggerAddAction(
        t,
        function()
            do
                local i = #solarTriggerSet - 1
                while i >= 0 do
                    solarTriggerSet[i + 1]:exec()
                    i = i - 1
                end
            end
        end
    )
    local solarTrigger = __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(UnitSpellEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
    solarTrigger.onDestroy = function(solarTrigger)
        TriggerClearActions(t)
        DestroyTrigger(t)
    end
    return solarTrigger
end
function SolarEvent.prototype.clear(self)
    cache:clear()
    emitter.all:clear()
end
function SolarEvent.getUnitDataEventHandler(self, unit, eventKey, createDefault)
    if createDefault then
        local unitSolarData = DataBase:getUnitSolarData(unit, createDefault)
        if unitSolarData._SL_solarEventHandler == nil then
            unitSolarData._SL_solarEventHandler = {}
        end
        if unitSolarData._SL_solarEventHandler[eventKey] == nil then
            unitSolarData._SL_solarEventHandler[eventKey] = {}
        end
        return unitSolarData._SL_solarEventHandler[eventKey]
    end
    local ____opt_2 = DataBase:getUnitSolarData(unit, createDefault)
    local ____opt_0 = ____opt_2 and ____opt_2._SL_solarEventHandler
    return ____opt_0 and ____opt_0[eventKey]
end
function SolarEvent.getUnitTypeDataEventHandler(self, unitType, eventKey, createDefault)
    if createDefault then
        local unitSolarData = DataBase:getUnitTypeSolarData(unitType, createDefault)
        if unitSolarData._SL_solarEventHandler == nil then
            unitSolarData._SL_solarEventHandler = {}
        end
        if unitSolarData._SL_solarEventHandler[eventKey] == nil then
            unitSolarData._SL_solarEventHandler[eventKey] = {}
        end
        return unitSolarData._SL_solarEventHandler[eventKey]
    end
    local ____opt_6 = DataBase:getUnitTypeSolarData(unitType, createDefault)
    local ____opt_4 = ____opt_6 and ____opt_6._SL_solarEventHandler
    return ____opt_4 and ____opt_4[eventKey]
end
function SolarEvent.getUnitSpellAbilityDataEventHandler(self, abilityIdStr, eventKey, createDefault)
    if createDefault then
        local unitSolarData = DataBase:getAbilityTypeSolarData(abilityIdStr, createDefault)
        if unitSolarData._SL_solarEventHandler == nil then
            unitSolarData._SL_solarEventHandler = {}
        end
        if unitSolarData._SL_solarEventHandler[eventKey] == nil then
            unitSolarData._SL_solarEventHandler[eventKey] = {}
        end
        return unitSolarData._SL_solarEventHandler[eventKey]
    end
    local ____opt_10 = DataBase:getAbilityTypeSolarData(abilityIdStr, createDefault)
    local ____opt_8 = ____opt_10 and ____opt_10._SL_solarEventHandler
    return ____opt_8 and ____opt_8[eventKey]
end
function SolarEvent.getFrameDataEventHandler(self, frame, eventKey, createDefault)
    if createDefault then
        local unitSolarData = DataBase:getDataByTypeId(
            "_SL_Frame_Event",
            tostring(frame)
        )
        if unitSolarData._SL_solarEventHandler == nil then
            unitSolarData._SL_solarEventHandler = {}
        end
        if unitSolarData._SL_solarEventHandler[eventKey] == nil then
            unitSolarData._SL_solarEventHandler[eventKey] = {}
        end
        return unitSolarData._SL_solarEventHandler[eventKey]
    end
    local ____opt_14 = DataBase:getDataByTypeId(
        "_SL_Frame_Event",
        tostring(frame)
    )
    local ____opt_12 = ____opt_14 and ____opt_14._SL_solarEventHandler
    return ____opt_12 and ____opt_12[eventKey]
end
SolarEvent._sl_last_select_info = {}
return ____exports
