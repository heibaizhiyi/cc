local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 2,["9"] = 2,["10"] = 5,["11"] = 5,["12"] = 6,["13"] = 6,["14"] = 7,["15"] = 7,["16"] = 8,["17"] = 8,["18"] = 10,["19"] = 10,["20"] = 11,["21"] = 11,["22"] = 12,["23"] = 12,["24"] = 13,["25"] = 13,["26"] = 16,["27"] = 16,["28"] = 16,["29"] = 16,["30"] = 22,["31"] = 23,["32"] = 16,["35"] = 27,["36"] = 28,["37"] = 28,["38"] = 28,["39"] = 28,["40"] = 28,["41"] = 28,["42"] = 28,["43"] = 16,["44"] = 22,["45"] = 48,["46"] = 49,["47"] = 50,["49"] = 52,["50"] = 53,["51"] = 48,["52"] = 56,["53"] = 57,["54"] = 58,["56"] = 60,["57"] = 61,["58"] = 56,["59"] = 610,["60"] = 611,["61"] = 610,["62"] = 617,["63"] = 618,["64"] = 617,["65"] = 624,["66"] = 625,["67"] = 624,["68"] = 631,["69"] = 632,["70"] = 632,["71"] = 632,["72"] = 632,["73"] = 632,["74"] = 632,["75"] = 632,["76"] = 631,["77"] = 638,["78"] = 639,["79"] = 638,["80"] = 645,["81"] = 646,["82"] = 647,["83"] = 649,["85"] = 651,["86"] = 645,["87"] = 657,["88"] = 658,["89"] = 657,["90"] = 664,["91"] = 665,["92"] = 664,["93"] = 671,["94"] = 672,["95"] = 671,["96"] = 678,["97"] = 679,["98"] = 678,["99"] = 685,["100"] = 686,["101"] = 685,["102"] = 692,["103"] = 693,["104"] = 692,["105"] = 699,["106"] = 700,["107"] = 699,["108"] = 706,["109"] = 707,["110"] = 706,["111"] = 716,["112"] = 717,["113"] = 716,["114"] = 723,["115"] = 724,["116"] = 724,["117"] = 724,["118"] = 724,["119"] = 724,["120"] = 724,["121"] = 724,["122"] = 724,["123"] = 724,["124"] = 724,["125"] = 723,["126"] = 730,["127"] = 731,["128"] = 731,["129"] = 731,["130"] = 731,["131"] = 731,["132"] = 731,["133"] = 731,["134"] = 731,["135"] = 731,["136"] = 731,["137"] = 731,["138"] = 731,["139"] = 731,["140"] = 730,["141"] = 737,["142"] = 738,["143"] = 738,["144"] = 738,["145"] = 738,["146"] = 738,["147"] = 738,["148"] = 738,["149"] = 738,["150"] = 738,["151"] = 738,["152"] = 737,["153"] = 744,["154"] = 745,["155"] = 744,["156"] = 751,["157"] = 751,["158"] = 751,["160"] = 752,["161"] = 753,["162"] = 754,["163"] = 754,["164"] = 754,["165"] = 755,["166"] = 756,["167"] = 757,["168"] = 754,["169"] = 754,["171"] = 760,["172"] = 761,["174"] = 751,["175"] = 773,["176"] = 774,["177"] = 773,["178"] = 780,["179"] = 781,["180"] = 780,["181"] = 788,["182"] = 789,["183"] = 788,["184"] = 815,["185"] = 816,["186"] = 816,["187"] = 816,["188"] = 816,["189"] = 815,["190"] = 822,["191"] = 823,["192"] = 822,["193"] = 833,["194"] = 834,["195"] = 833,["196"] = 881,["197"] = 882,["198"] = 881,["199"] = 888,["200"] = 889,["201"] = 888,["202"] = 895,["203"] = 896,["204"] = 895,["205"] = 902,["206"] = 903,["207"] = 902,["208"] = 909,["209"] = 910,["210"] = 911,["211"] = 912,["213"] = 914,["214"] = 909,["215"] = 921,["216"] = 922,["217"] = 923,["218"] = 924,["220"] = 926,["221"] = 921,["222"] = 932,["223"] = 933,["224"] = 932,["225"] = 939,["226"] = 940,["227"] = 939,["228"] = 946,["229"] = 947,["230"] = 947,["231"] = 947,["232"] = 947,["233"] = 947,["234"] = 947,["235"] = 947,["236"] = 947,["237"] = 947,["238"] = 947,["239"] = 946,["240"] = 953,["241"] = 954,["242"] = 953,["243"] = 960,["245"] = 961,["246"] = 961,["247"] = 962,["248"] = 963,["249"] = 964,["251"] = 961,["254"] = 967,["255"] = 960,["256"] = 977,["257"] = 978,["258"] = 977,["259"] = 984,["260"] = 985,["261"] = 984,["262"] = 991,["263"] = 992,["264"] = 991,["265"] = 998,["266"] = 999,["267"] = 998,["268"] = 1005,["269"] = 1006,["270"] = 1005,["271"] = 1012,["272"] = 1013,["273"] = 1012,["274"] = 1023,["275"] = 1024,["276"] = 1023,["277"] = 1030,["278"] = 1031,["279"] = 1030,["280"] = 1037,["281"] = 1038,["282"] = 1037,["283"] = 1044,["284"] = 1045,["285"] = 1044,["286"] = 1051,["287"] = 1052,["288"] = 1051,["289"] = 1058,["290"] = 1059,["291"] = 1058,["292"] = 1065,["293"] = 1066,["294"] = 1065,["295"] = 1072,["296"] = 1073,["297"] = 1072,["298"] = 1079,["299"] = 1080,["300"] = 1079,["301"] = 1086,["302"] = 1087,["303"] = 1086,["304"] = 1094,["305"] = 1095,["306"] = 1094,["307"] = 1102,["308"] = 1103,["309"] = 1103,["310"] = 1103,["312"] = 1103,["314"] = 1103,["315"] = 1102,["316"] = 1109,["317"] = 1110,["318"] = 1110,["319"] = 1110,["321"] = 1110,["323"] = 1110,["324"] = 1109,["325"] = 1116,["326"] = 1117,["327"] = 1117,["328"] = 1117,["329"] = 1117,["330"] = 1117,["331"] = 1117,["332"] = 1117,["333"] = 1117,["334"] = 1117,["336"] = 1117,["337"] = 1117,["338"] = 1117,["339"] = 1117,["340"] = 1117,["341"] = 1117,["342"] = 1117,["344"] = 1117,["345"] = 1116,["346"] = 1123,["347"] = 1124,["348"] = 1124,["349"] = 1124,["351"] = 1124,["353"] = 1124,["354"] = 1123,["355"] = 1130,["356"] = 1131,["357"] = 1131,["358"] = 1131,["360"] = 1131,["362"] = 1131,["363"] = 1130,["364"] = 1137,["365"] = 1138,["366"] = 1138,["367"] = 1138,["369"] = 1138,["371"] = 1138,["372"] = 1137,["373"] = 1145,["374"] = 1146,["375"] = 1146,["376"] = 1146,["378"] = 1146,["380"] = 1146,["381"] = 1145,["382"] = 1152,["383"] = 1153,["384"] = 1152,["385"] = 1159,["386"] = 1160,["387"] = 1159,["388"] = 1166,["389"] = 1167,["390"] = 1166,["391"] = 1173,["392"] = 1174,["393"] = 1173,["394"] = 1180,["395"] = 1181,["396"] = 1181,["397"] = 1181,["398"] = 1181,["399"] = 1181,["400"] = 1181,["401"] = 1181,["402"] = 1181,["403"] = 1180,["404"] = 1187,["405"] = 1188,["406"] = 1187,["407"] = 1194,["408"] = 1195,["409"] = 1194,["410"] = 1205,["411"] = 1206,["412"] = 1205,["413"] = 1213,["414"] = 1214,["415"] = 1213,["416"] = 1220,["417"] = 1221,["418"] = 1220,["419"] = 1227,["420"] = 1228,["421"] = 1227,["422"] = 1234,["423"] = 1235,["424"] = 1234,["425"] = 1241,["426"] = 1242,["427"] = 1242,["428"] = 1242,["429"] = 1242,["430"] = 1242,["431"] = 1242,["432"] = 1242,["433"] = 1242,["434"] = 1242,["435"] = 1242,["436"] = 1241,["437"] = 1248,["438"] = 1249,["439"] = 1248,["440"] = 1255,["441"] = 1256,["442"] = 1255,["443"] = 1263,["444"] = 1264,["445"] = 1263,["446"] = 1271,["447"] = 1272,["448"] = 1271,["449"] = 1279,["450"] = 1280,["451"] = 1279,["452"] = 1286,["453"] = 1287,["454"] = 1286,["455"] = 1293,["456"] = 1294,["457"] = 1293,["458"] = 1300,["459"] = 1301,["460"] = 1300,["461"] = 1307,["462"] = 1308,["463"] = 1307,["464"] = 1314,["465"] = 1315,["466"] = 1314,["467"] = 1321,["468"] = 1322,["469"] = 1321,["470"] = 1328,["471"] = 1329,["472"] = 1328,["473"] = 1339,["474"] = 1340,["475"] = 1339,["476"] = 1350,["477"] = 1351,["478"] = 1350,["479"] = 1357,["480"] = 1358,["481"] = 1359,["483"] = 1361,["485"] = 1357,["486"] = 1368,["487"] = 1369,["488"] = 1368,["489"] = 1383,["490"] = 1384,["491"] = 1383,["492"] = 1390,["493"] = 1391,["494"] = 1390,["495"] = 1397,["496"] = 1398,["497"] = 1397,["498"] = 1412,["499"] = 1413,["500"] = 1412,["501"] = 1419,["502"] = 1420,["503"] = 1419,["504"] = 1448,["505"] = 1449,["506"] = 1448,["507"] = 1455,["508"] = 1456,["509"] = 1455,["510"] = 1462,["511"] = 1463,["512"] = 1462,["513"] = 1469,["514"] = 1470,["515"] = 1469,["516"] = 1476,["517"] = 1477,["518"] = 1476,["519"] = 1483,["520"] = 1484,["521"] = 1483,["522"] = 1490,["523"] = 1491,["524"] = 1490,["525"] = 1497,["526"] = 1498,["527"] = 1497,["528"] = 1504,["529"] = 1505,["530"] = 1504,["531"] = 1511,["532"] = 1512,["533"] = 1511,["534"] = 1518,["535"] = 1519,["536"] = 1518,["537"] = 1525,["538"] = 1526,["539"] = 1525,["540"] = 1532,["541"] = 1533,["542"] = 1532,["543"] = 1544,["544"] = 1545,["545"] = 1544,["546"] = 1551,["547"] = 1552,["548"] = 1551,["549"] = 1558,["550"] = 1559,["551"] = 1558,["552"] = 1565,["553"] = 1566,["554"] = 1565,["555"] = 1572,["556"] = 1573,["557"] = 1573,["558"] = 1573,["559"] = 1573,["560"] = 1573,["561"] = 1573,["562"] = 1573,["563"] = 1572,["564"] = 1579,["565"] = 1580,["566"] = 1579,["567"] = 1594,["568"] = 1595,["569"] = 1594,["570"] = 1601,["571"] = 1602,["572"] = 1601,["573"] = 1608,["574"] = 1609,["575"] = 1608,["576"] = 1615,["577"] = 1616,["578"] = 1615,["579"] = 1622,["580"] = 1623,["581"] = 1622,["582"] = 1629,["583"] = 1630,["584"] = 1629,["585"] = 1636,["586"] = 1637,["587"] = 1636,["588"] = 1643,["589"] = 1644,["590"] = 1643,["591"] = 1650,["592"] = 1651,["593"] = 1650,["594"] = 1657,["595"] = 1658,["596"] = 1657,["597"] = 1664,["598"] = 1665,["599"] = 1664,["600"] = 1671,["601"] = 1672,["602"] = 1671,["603"] = 1678,["604"] = 1679,["605"] = 1678,["606"] = 1685,["607"] = 1686,["608"] = 1685,["609"] = 1690,["610"] = 1691,["611"] = 1690,["612"] = 1697,["613"] = 1698,["614"] = 1697,["615"] = 1704,["616"] = 1705,["617"] = 1704,["618"] = 1711,["619"] = 1712,["620"] = 1711,["626"] = 37,["628"] = 40,["629"] = 41,["639"] = 78,["641"] = 69,["642"] = 70,["652"] = 85,["654"] = 91,["655"] = 92,["665"] = 114,["667"] = 106,["668"] = 107,["676"] = 124,["677"] = 125,["685"] = 132,["693"] = 139,["701"] = 146,["709"] = 153,["717"] = 160,["725"] = 167,["734"] = 174,["736"] = 180,["737"] = 181,["747"] = 195,["749"] = 187,["750"] = 188,["759"] = 202,["767"] = 209,["775"] = 216,["784"] = 223,["786"] = 229,["787"] = 230,["796"] = 237,["803"] = 243,["804"] = 244,["812"] = 255,["821"] = 267,["823"] = 273,["824"] = 274,["834"] = 281,["836"] = 287,["837"] = 288,["847"] = 295,["849"] = 301,["850"] = 302,["860"] = 316,["862"] = 308,["863"] = 309,["872"] = 323,["880"] = 338,["889"] = 352,["891"] = 344,["892"] = 345,["902"] = 366,["904"] = 358,["905"] = 359,["915"] = 374,["917"] = 380,["918"] = 381,["927"] = 388,["936"] = 402,["938"] = 394,["939"] = 395,["948"] = 409,["956"] = 416,["964"] = 423,["972"] = 430,["981"] = 444,["983"] = 436,["984"] = 437,["994"] = 471,["996"] = 463,["997"] = 464,["1007"] = 486,["1009"] = 492,["1010"] = 493,["1019"] = 500,["1028"] = 507,["1030"] = 513,["1031"] = 514,["1041"] = 528,["1043"] = 520,["1044"] = 521,["1053"] = 535,["1061"] = 542,["1070"] = 549,["1072"] = 555,["1073"] = 556,["1083"] = 570,["1085"] = 562,["1086"] = 563,["1096"] = 577,["1098"] = 584,["1099"] = 585,["1109"] = 592,["1111"] = 599,["1112"] = 600});
local ____exports = {}
local ____destructable = require("solar.solar-common.w3ts.handles.destructable")
local Destructable = ____destructable.Destructable
local ____handle = require("solar.solar-common.w3ts.handles.handle")
local Handle = ____handle.Handle
local ____item = require("solar.solar-common.w3ts.handles.item")
local Item = ____item.Item
local ____player = require("solar.solar-common.w3ts.handles.player")
local MapPlayer = ____player.MapPlayer
local ____point = require("solar.solar-common.w3ts.handles.point")
local Point = ____point.Point
local ____widget = require("solar.solar-common.w3ts.handles.widget")
local Widget = ____widget.Widget
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
____exports.Unit = __TS__Class()
local Unit = ____exports.Unit
Unit.name = "Unit"
__TS__ClassExtends(Unit, Widget)
function Unit.prototype.____constructor(self, owner, unitId, x, y, face)
    if Handle:initFromHandle() then
        Widget.prototype.____constructor(self)
        return
    end
    local p = Player(owner)
    local unitH = CreateUnit(
        p,
        unitId,
        x,
        y,
        face
    )
    Widget.prototype.____constructor(self, unitH)
end
function Unit.prototype.costLife(self, val)
    if self.life < val then
        return false
    end
    self.life = self.life - val
    return true
end
function Unit.prototype.costMana(self, val)
    if self.mana < val then
        return false
    end
    self.mana = self.mana - val
    return true
end
function Unit.prototype.addAbility(self, abilityId)
    return UnitAddAbility(self.handle, abilityId)
end
function Unit.prototype.addAnimationProps(self, animProperties, add)
    AddUnitAnimationProperties(self.handle, animProperties, add)
end
function Unit.prototype.addExperience(self, xpToAdd, showEyeCandy)
    AddHeroXP(self.handle, xpToAdd, showEyeCandy)
end
function Unit.prototype.addIndicator(self, red, blue, green, alpha)
    UnitAddIndicator(
        self.handle,
        red,
        blue,
        green,
        alpha
    )
end
function Unit.prototype.addItem(self, whichItem)
    return UnitAddItem(self.handle, whichItem.handle)
end
function Unit.prototype.addItemById(self, itemId)
    local item = UnitAddItemById(self.handle, itemId)
    if IsHandle(item) then
        return Item:fromHandle(item)
    end
    return nil
end
function Unit.prototype.addItemToSlotById(self, itemId, itemSlot)
    return UnitAddItemToSlotById(self.handle, itemId, itemSlot)
end
function Unit.prototype.addItemToStock(self, itemId, currentStock, stockMax)
    AddItemToStock(self.handle, itemId, currentStock, stockMax)
end
function Unit.prototype.addResourceAmount(self, amount)
    AddResourceAmount(self.handle, amount)
end
function Unit.prototype.addSleepPerm(self, add)
    UnitAddSleepPerm(self.handle, add)
end
function Unit.prototype.addType(self, whichUnitType)
    return UnitAddType(self.handle, whichUnitType)
end
function Unit.prototype.addUnitToStock(self, unitId, currentStock, stockMax)
    AddUnitToStock(self.handle, unitId, currentStock, stockMax)
end
function Unit.prototype.applyTimedLife(self, buffId, duration)
    UnitApplyTimedLife(self.handle, buffId, duration)
end
function Unit.prototype.attachSound(self, sound)
    AttachSoundToUnit(sound.handle, self.handle)
end
function Unit.prototype.canSleepPerm(self)
    return UnitCanSleepPerm(self.handle)
end
function Unit.prototype.countBuffs(self, removePositive, removeNegative, magic, physical, timedLife, aura, autoDispel)
    return UnitCountBuffsEx(
        self.handle,
        removePositive,
        removeNegative,
        magic,
        physical,
        timedLife,
        aura,
        autoDispel
    )
end
function Unit.prototype.damageAt(self, delay, radius, x, y, amount, attack, ranged, attackType, damageType, weaponType)
    return UnitDamagePoint(
        self.handle,
        delay,
        radius,
        x,
        y,
        amount,
        attack,
        ranged,
        attackType,
        damageType,
        weaponType
    )
end
function Unit.prototype.damageTarget(self, target, amount, attack, ranged, attackType, damageType, weaponType)
    return UnitDamageTarget(
        self.handle,
        target,
        amount,
        attack,
        ranged,
        attackType,
        damageType,
        weaponType
    )
end
function Unit.prototype.decAbilityLevel(self, abilCode)
    return DecUnitAbilityLevel(self.handle, abilCode)
end
function Unit.prototype.destroy(self, delay)
    if delay == nil then
        delay = 0
    end
    if delay and delay > 0 then
        handle_ref(self.handle)
        BaseUtil.runLater(
            delay,
            function()
                self.solarData = nil
                handle_unref(self.handle)
                RemoveUnit(self.handle)
            end
        )
    else
        self.solarData = nil
        RemoveUnit(self.handle)
    end
end
function Unit.prototype.dropItem(self, whichItem, x, y)
    return UnitDropItemPoint(self.handle, whichItem.handle, x, y)
end
function Unit.prototype.dropItemFromSlot(self, whichItem, slot)
    return UnitDropItemSlot(self.handle, whichItem.handle, slot)
end
function Unit.prototype.dropItemTarget(self, whichItem, target)
    return UnitDropItemTarget(self.handle, whichItem.handle, target.handle)
end
function Unit.prototype.hasAbility(self, abilId)
    return GetUnitAbilityLevel(
        self.handle,
        FourCC(abilId)
    ) > 0
end
function Unit.prototype.getAbilityLevel(self, abilCode)
    return GetUnitAbilityLevel(self.handle, abilCode)
end
function Unit.prototype.getAgility(self, includeBonuses)
    return GetHeroAgi(self.handle, includeBonuses)
end
function Unit.prototype.getflyHeight(self)
    return GetUnitFlyHeight(self.handle)
end
function Unit.prototype.getHeroLevel(self)
    return GetHeroLevel(self.handle)
end
function Unit.prototype.getIgnoreAlarm(self, flag)
    return UnitIgnoreAlarm(self.handle, flag)
end
function Unit.prototype.getIntelligence(self, includeBonuses)
    return GetHeroInt(self.handle, includeBonuses)
end
function Unit.prototype.getItemInSlot(self, slot)
    local itemHandle = UnitItemInSlot(self.handle, slot)
    if IsHandle(itemHandle) then
        return Item:fromHandle(itemHandle)
    end
    return nil
end
function Unit.prototype.getItemByItemType(self, itemtype)
    local itemHandle = UnitUtil.GetInventoryOfItemType(self.handle, itemtype)
    if IsHandle(itemHandle) then
        return Item:fromHandle(itemHandle)
    end
    return nil
end
function Unit.prototype.getState(self, whichUnitState)
    return GetUnitState(self.handle, whichUnitState)
end
function Unit.prototype.getStrength(self, includeBonuses)
    return GetHeroStr(self.handle, includeBonuses)
end
function Unit.prototype.hasBuffs(self, removePositive, removeNegative, magic, physical, timedLife, aura, autoDispel)
    return UnitHasBuffsEx(
        self.handle,
        removePositive,
        removeNegative,
        magic,
        physical,
        timedLife,
        aura,
        autoDispel
    )
end
function Unit.prototype.hasItem(self, whichItem)
    return UnitHasItem(self.handle, whichItem.handle)
end
function Unit.prototype.hasItemType(self, itemType)
    do
        local i = 0
        while i < 6 do
            local indexItem = UnitItemInSlot(self.handle, i)
            if IsHandle(indexItem) and GetItemTypeId(indexItem) == itemType then
                return true
            end
            i = i + 1
        end
    end
    return false
end
function Unit.prototype.incAbilityLevel(self, abilCode)
    return IncUnitAbilityLevel(self.handle, abilCode)
end
function Unit.prototype.inForce(self, whichForce)
    return IsUnitInForce(self.handle, whichForce.handle)
end
function Unit.prototype.inGroup(self, whichGroup)
    return IsUnitInGroup(self.handle, whichGroup.handle)
end
function Unit.prototype.inRange(self, x, y, distance)
    return IsUnitInRangeXY(self.handle, x, y, distance)
end
function Unit.prototype.inRangeOfPoint(self, whichPoint, distance)
    return IsUnitInRangeLoc(self.handle, whichPoint.handle, distance)
end
function Unit.prototype.inRangeOfUnit(self, otherUnit, distance)
    return IsUnitInRange(self.handle, otherUnit.handle, distance)
end
function Unit.prototype.inTransport(self, whichTransport)
    return IsUnitInTransport(self.handle, whichTransport.handle)
end
function Unit.prototype.isAlive(self)
    return UnitAlive(self.handle)
end
function Unit.prototype.isAlly(self, whichPlayer)
    return IsUnitAlly(self.handle, whichPlayer.handle)
end
function Unit.prototype.isEnemy(self, whichPlayer)
    return IsUnitEnemy(self.handle, whichPlayer.handle)
end
function Unit.prototype.isExperienceSuspended(self)
    return IsSuspendedXP(self.handle)
end
function Unit.prototype.isFogged(self, whichPlayer)
    return IsUnitFogged(self.handle, whichPlayer.handle)
end
function Unit.prototype.isHero(self)
    return IsHeroUnitId(self.typeId)
end
function Unit.prototype.isIllusion(self)
    return IsUnitIllusion(self.handle)
end
function Unit.prototype.isLoaded(self)
    return IsUnitLoaded(self.handle)
end
function Unit.prototype.isMasked(self, whichPlayer)
    return IsUnitMasked(self.handle, whichPlayer.handle)
end
function Unit.prototype.isSelected(self, whichPlayer)
    return IsUnitSelected(self.handle, whichPlayer.handle)
end
function Unit.prototype.issueBuildOrder(self, unit, x, y)
    local ____temp_0
    if type(unit) == "string" then
        ____temp_0 = IssueBuildOrder(self.handle, unit, x, y)
    else
        ____temp_0 = IssueBuildOrderById(self.handle, unit, x, y)
    end
    return ____temp_0
end
function Unit.prototype.issueImmediateOrder(self, order)
    local ____temp_1
    if type(order) == "string" then
        ____temp_1 = IssueImmediateOrder(self.handle, order)
    else
        ____temp_1 = IssueImmediateOrderById(self.handle, order)
    end
    return ____temp_1
end
function Unit.prototype.issueInstantOrderAt(self, order, x, y, instantTargetWidget)
    local ____temp_2
    if type(order) == "string" then
        ____temp_2 = IssueInstantPointOrder(
            self.handle,
            order,
            x,
            y,
            instantTargetWidget.handle
        )
    else
        ____temp_2 = IssueInstantPointOrderById(
            self.handle,
            order,
            x,
            y,
            instantTargetWidget.handle
        )
    end
    return ____temp_2
end
function Unit.prototype.issueInstantTargetOrder(self, order, targetWidget, instantTargetWidget)
    local ____temp_3
    if type(order) == "string" then
        ____temp_3 = IssueInstantTargetOrder(self.handle, order, targetWidget.handle, instantTargetWidget.handle)
    else
        ____temp_3 = IssueInstantTargetOrderById(self.handle, order, targetWidget.handle, instantTargetWidget.handle)
    end
    return ____temp_3
end
function Unit.prototype.issueOrderAt(self, order, x, y)
    local ____temp_4
    if type(order) == "string" then
        ____temp_4 = IssuePointOrder(self.handle, order, x, y)
    else
        ____temp_4 = IssuePointOrderById(self.handle, order, x, y)
    end
    return ____temp_4
end
function Unit.prototype.issuePointOrder(self, order, whichPoint)
    local ____temp_5
    if type(order) == "string" then
        ____temp_5 = IssuePointOrderLoc(self.handle, order, whichPoint.handle)
    else
        ____temp_5 = IssuePointOrderByIdLoc(self.handle, order, whichPoint.handle)
    end
    return ____temp_5
end
function Unit.prototype.issueTargetOrder(self, order, targetWidget)
    local ____temp_6
    if type(order) == "string" then
        ____temp_6 = IssueTargetOrder(self.handle, order, targetWidget.handle)
    else
        ____temp_6 = IssueTargetOrderById(self.handle, order, targetWidget.handle)
    end
    return ____temp_6
end
function Unit.prototype.isUnit(self, whichSpecifiedUnit)
    return IsUnit(self.handle, whichSpecifiedUnit.handle)
end
function Unit.prototype.isUnitType(self, whichUnitType)
    return IsUnitType(self.handle, whichUnitType)
end
function Unit.prototype.isVisible(self, whichPlayer)
    return IsUnitVisible(self.handle, whichPlayer.handle)
end
function Unit.prototype.kill(self)
    KillUnit(self.handle)
end
function Unit.prototype.lookAt(self, whichBone, lookAtTarget, offsetX, offsetY, offsetZ)
    SetUnitLookAt(
        self.handle,
        whichBone,
        lookAtTarget.handle,
        offsetX,
        offsetY,
        offsetZ
    )
end
function Unit.prototype.makeAbilityPermanent(self, permanent, abilityId)
    UnitMakeAbilityPermanent(self.handle, permanent, abilityId)
end
function Unit.prototype.modifySkillPoints(self, skillPointDelta)
    return UnitModifySkillPoints(self.handle, skillPointDelta)
end
function Unit.prototype.pauseTimedLife(self, flag)
    UnitPauseTimedLife(self.handle, flag)
end
function Unit.prototype.queueAnimation(self, whichAnimation)
    QueueUnitAnimation(self.handle, whichAnimation)
end
function Unit.prototype.recycleGuardPosition(self)
    RecycleGuardPosition(self.handle)
end
function Unit.prototype.removeAbility(self, abilityId)
    return UnitRemoveAbility(self.handle, abilityId)
end
function Unit.prototype.removeBuffs(self, removePositive, removeNegative)
    UnitRemoveBuffs(self.handle, removePositive, removeNegative)
end
function Unit.prototype.removeBuffsEx(self, removePositive, removeNegative, magic, physical, timedLife, aura, autoDispel)
    UnitRemoveBuffsEx(
        self.handle,
        removePositive,
        removeNegative,
        magic,
        physical,
        timedLife,
        aura,
        autoDispel
    )
end
function Unit.prototype.removeGuardPosition(self)
    RemoveGuardPosition(self.handle)
end
function Unit.prototype.removeItem(self, whichItem)
    UnitRemoveItem(self.handle, whichItem.handle)
end
function Unit.prototype.removeItemFromSlot(self, itemSlot)
    return Item:fromHandle(UnitRemoveItemFromSlot(self.handle, itemSlot))
end
function Unit.prototype.removeItemFromStock(self, itemId)
    RemoveItemFromStock(self.handle, itemId)
end
function Unit.prototype.removeType(self, whichUnitType)
    return UnitAddType(self.handle, whichUnitType)
end
function Unit.prototype.removeUnitFromStock(self, itemId)
    RemoveUnitFromStock(self.handle, itemId)
end
function Unit.prototype.resetCooldown(self)
    UnitResetCooldown(self.handle)
end
function Unit.prototype.resetLookAt(self)
    ResetUnitLookAt(self.handle)
end
function Unit.prototype.revive(self, x, y, doEyecandy)
    return ReviveHero(self.handle, x, y, doEyecandy)
end
function Unit.prototype.reviveAtPoint(self, whichPoint, doEyecandy)
    return ReviveHeroLoc(self.handle, whichPoint.handle, doEyecandy)
end
function Unit.prototype.select(self, flag)
    SelectUnit(self.handle, flag)
end
function Unit.prototype.selectSkill(self, abilCode)
    SelectHeroSkill(self.handle, abilCode)
end
function Unit.prototype.setAbilityLevel(self, abilCode, level)
    return SetUnitAbilityLevel(self.handle, abilCode, level)
end
function Unit.prototype.setAgility(self, value, permanent)
    SetHeroAgi(self.handle, value, permanent)
end
function Unit.prototype.setAnimation(self, whichAnimation)
    if type(whichAnimation) == "string" then
        SetUnitAnimation(self.handle, whichAnimation)
    else
        SetUnitAnimationByIndex(self.handle, whichAnimation)
    end
end
function Unit.prototype.setAnimationWithRarity(self, whichAnimation, rarity)
    SetUnitAnimationWithRarity(self.handle, whichAnimation, rarity)
end
function Unit.prototype.setBlendTime(self, timeScale)
    SetUnitBlendTime(self.handle, timeScale)
end
function Unit.prototype.setConstructionProgress(self, constructionPercentage)
    UnitSetConstructionProgress(self.handle, constructionPercentage)
end
function Unit.prototype.setCreepGuard(self, creepGuard)
    SetUnitCreepGuard(self.handle, creepGuard)
end
function Unit.prototype.setExperience(self, newXpVal, showEyeCandy)
    SetHeroXP(self.handle, newXpVal, showEyeCandy)
end
function Unit.prototype.setExploded(self, exploded)
    SetUnitExploded(self.handle, exploded)
end
function Unit.prototype.setflyHeight(self, value, rate)
    SetUnitFlyHeight(self.handle, value, rate)
end
function Unit.prototype.setHeroLevel(self, level, showEyeCandy)
    SetHeroLevel(self.handle, level, showEyeCandy)
end
function Unit.prototype.setIntelligence(self, value, permanent)
    SetHeroInt(self.handle, value, permanent)
end
function Unit.prototype.setItemTypeSlots(self, slots)
    SetItemTypeSlots(self.handle, slots)
end
function Unit.prototype.setOwner(self, whichPlayer, changeColor)
    SetUnitOwner(self.handle, whichPlayer.handle, changeColor)
end
function Unit.prototype.setPathing(self, flag)
    SetUnitPathing(self.handle, flag)
end
function Unit.prototype.setPosition(self, x, y)
    SetUnitPosition(self.handle, x, y)
end
function Unit.prototype.setRescuable(self, byWhichPlayer, flag)
    SetUnitRescuable(self.handle, byWhichPlayer.handle, flag)
end
function Unit.prototype.setRescueRange(self, range)
    SetUnitRescueRange(self.handle, range)
end
function Unit.prototype.setScale(self, scaleX, scaleY, scaleZ)
    SetUnitScale(self.handle, scaleX, scaleY, scaleZ)
end
function Unit.prototype.setState(self, whichUnitState, newVal)
    SetUnitState(self.handle, whichUnitState, newVal)
end
function Unit.prototype.setStrength(self, value, permanent)
    SetHeroStr(self.handle, value, permanent)
end
function Unit.prototype.setTimeScale(self, timeScale)
    SetUnitTimeScale(self.handle, timeScale)
end
function Unit.prototype.setUnitTypeSlots(self, slots)
    SetUnitTypeSlots(self.handle, slots)
end
function Unit.prototype.setUpgradeProgress(self, upgradePercentage)
    UnitSetUpgradeProgress(self.handle, upgradePercentage)
end
function Unit.prototype.setUseAltIcon(self, flag)
    UnitSetUsesAltIcon(self.handle, flag)
end
function Unit.prototype.setUseFood(self, useFood)
    SetUnitUseFood(self.handle, useFood)
end
function Unit.prototype.setVertexColor(self, red, green, blue, alpha)
    SetUnitVertexColor(
        self.handle,
        red,
        green,
        blue,
        alpha
    )
end
function Unit.prototype.shareVision(self, whichPlayer, share)
    UnitShareVision(self.handle, whichPlayer.handle, share)
end
function Unit.prototype.stripLevels(self, howManyLevels)
    return UnitStripHeroLevel(self.handle, howManyLevels)
end
function Unit.prototype.suspendDecay(self, suspend)
    UnitSuspendDecay(self.handle, suspend)
end
function Unit.prototype.suspendExperience(self, flag)
    SuspendHeroXP(self.handle, flag)
end
function Unit.prototype.useItem(self, whichItem)
    return UnitUseItem(self.handle, whichItem.handle)
end
function Unit.prototype.useItemAt(self, whichItem, x, y)
    return UnitUseItemPoint(self.handle, whichItem.handle, x, y)
end
function Unit.prototype.useItemTarget(self, whichItem, target)
    return UnitUseItemTarget(self.handle, whichItem.handle, target.handle)
end
function Unit.prototype.wakeUp(self)
    UnitWakeUp(self.handle)
end
function Unit.prototype.waygateGetDestinationX(self)
    return WaygateGetDestinationX(self.handle)
end
function Unit.prototype.waygateGetDestinationY(self)
    return WaygateGetDestinationY(self.handle)
end
function Unit.prototype.waygateSetDestination(self, x, y)
    WaygateSetDestination(self.handle, x, y)
end
function Unit.foodMadeByType(self, unitId)
    return GetFoodMade(unitId)
end
function Unit.foodUsedByType(self, unitId)
    return GetFoodUsed(unitId)
end
function Unit.fromEnum(self)
    return self:fromHandle(GetEnumUnit())
end
function Unit.fromEvent(self)
    return self:fromHandle(GetTriggerUnit())
end
function Unit.fromHandle(self, handle)
    return self:getObject(handle, "+w3u")
end
function Unit.getPointValueByType(self, unitType)
    return GetUnitPointValueByType(unitType)
end
function Unit.isUnitIdHero(self, unitId)
    return IsHeroUnitId(unitId)
end
function Unit.isUnitIdType(self, unitId, whichUnitType)
    return IsUnitIdType(unitId, whichUnitType)
end
__TS__SetDescriptor(
    Unit.prototype,
    "solarData",
    {
        get = function(self)
            return DataBase:getUnitSolarData(self.handle)
        end,
        set = function(self, obj)
            DataBase:setDataByHandle("+w3u", self.handle, obj)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "acquireRange",
    {
        get = function(self)
            return GetUnitAcquireRange(self.handle)
        end,
        set = function(self, value)
            SetUnitAcquireRange(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "agility",
    {
        get = function(self)
            return GetHeroAgi(self.handle, false)
        end,
        set = function(self, value)
            SetHeroAgi(self.handle, value, true)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "sleep",
    {
        get = function(self)
            return UnitCanSleep(self.handle)
        end,
        set = function(self, flag)
            UnitAddSleep(self.handle, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "color",
    {set = function(self, whichColor)
        SetUnitColor(self.handle, whichColor)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "currentOrder",
    {get = function(self)
        return GetUnitCurrentOrder(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "defaultAcquireRange",
    {get = function(self)
        return GetUnitDefaultAcquireRange(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "defaultFlyHeight",
    {get = function(self)
        return GetUnitDefaultFlyHeight(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "defaultMoveSpeed",
    {get = function(self)
        return GetUnitDefaultMoveSpeed(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "defaultPropWindow",
    {get = function(self)
        return GetUnitDefaultPropWindow(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "defaultTurnSpeed",
    {get = function(self)
        return GetUnitDefaultTurnSpeed(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "experience",
    {
        get = function(self)
            return GetHeroXP(self.handle)
        end,
        set = function(self, newXpVal)
            SetHeroXP(self.handle, newXpVal, true)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "facing",
    {
        get = function(self)
            return GetUnitFacing(self.handle)
        end,
        set = function(self, value)
            SetUnitFacing(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "foodMade",
    {get = function(self)
        return GetUnitFoodMade(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "foodUsed",
    {get = function(self)
        return GetUnitFoodUsed(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "ignoreAlarmToggled",
    {get = function(self)
        return UnitIgnoreAlarmToggled(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "intelligence",
    {
        get = function(self)
            return GetHeroInt(self.handle, false)
        end,
        set = function(self, value)
            SetHeroInt(self.handle, value, true)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "inventorySize",
    {get = function(self)
        return UnitInventorySize(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "invulnerable",
    {set = function(self, flag)
        SetUnitInvulnerable(self.handle, flag)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "level",
    {get = function(self)
        return GetUnitLevel(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "mana",
    {
        get = function(self)
            return self:getState(UNIT_STATE_MANA)
        end,
        set = function(self, value)
            self:setState(UNIT_STATE_MANA, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "maxLife",
    {
        get = function(self)
            return GetUnitState(self.handle, UNIT_STATE_MAX_LIFE)
        end,
        set = function(self, value)
            SetUnitState(self.handle, UNIT_STATE_MAX_LIFE, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "maxMana",
    {
        get = function(self)
            return GetUnitState(self.handle, UNIT_STATE_MAX_MANA)
        end,
        set = function(self, value)
            SetUnitState(self.handle, UNIT_STATE_MAX_MANA, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "moveSpeed",
    {
        get = function(self)
            return GetUnitMoveSpeed(self.handle)
        end,
        set = function(self, value)
            SetUnitMoveSpeed(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "name",
    {get = function(self)
        return GetUnitName(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "nameProper",
    {get = function(self)
        return GetHeroProperName(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "owner",
    {
        get = function(self)
            return MapPlayer:fromHandle(GetOwningPlayer(self.handle))
        end,
        set = function(self, whichPlayer)
            SetUnitOwner(self.handle, whichPlayer.handle, true)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "paused",
    {
        get = function(self)
            return IsUnitPaused(self.handle)
        end,
        set = function(self, flag)
            PauseUnit(self.handle, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "point",
    {
        get = function(self)
            return Point:fromHandle(GetUnitLoc(self.handle))
        end,
        set = function(self, whichPoint)
            SetUnitPositionLoc(self.handle, whichPoint.handle)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "pointValue",
    {get = function(self)
        return GetUnitPointValue(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "propWindow",
    {
        get = function(self)
            return GetUnitPropWindow(self.handle)
        end,
        set = function(self, value)
            SetUnitPropWindow(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "race",
    {get = function(self)
        return GetUnitRace(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "rallyDestructable",
    {get = function(self)
        return Destructable:fromHandle(GetUnitRallyDestructable(self.handle))
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "rallyPoint",
    {get = function(self)
        return Point:fromHandle(GetUnitRallyPoint(self.handle))
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "rallyUnit",
    {get = function(self)
        return ____exports.Unit:fromHandle(GetUnitRallyUnit(self.handle))
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "resourceAmount",
    {
        get = function(self)
            return GetResourceAmount(self.handle)
        end,
        set = function(self, amount)
            SetResourceAmount(self.handle, amount)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "show",
    {
        get = function(self)
            return not IsUnitHidden(self.handle)
        end,
        set = function(self, flag)
            ShowUnit(self.handle, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "skillPoints",
    {
        get = function(self)
            return GetHeroSkillPoints(self.handle)
        end,
        set = function(self, skillPointDelta)
            UnitModifySkillPoints(self.handle, skillPointDelta)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "sleeping",
    {get = function(self)
        return UnitIsSleeping(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "strength",
    {
        get = function(self)
            return GetHeroStr(self.handle, false)
        end,
        set = function(self, value)
            SetHeroStr(self.handle, value, true)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "turnSpeed",
    {
        get = function(self)
            return GetUnitTurnSpeed(self.handle)
        end,
        set = function(self, value)
            SetUnitTurnSpeed(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "typeId",
    {get = function(self)
        return GetUnitTypeId(self.handle)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "typeIdString",
    {get = function(self)
        return id2string(GetUnitTypeId(self.handle))
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "userData",
    {
        get = function(self)
            return GetUnitUserData(self.handle)
        end,
        set = function(self, value)
            SetUnitUserData(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "waygateActive",
    {
        get = function(self)
            return WaygateIsActive(self.handle)
        end,
        set = function(self, flag)
            WaygateActivate(self.handle, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "x",
    {
        get = function(self)
            return GetUnitX(self.handle)
        end,
        set = function(self, value)
            SetUnitX(self.handle, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "y",
    {
        get = function(self)
            return GetUnitY(self.handle)
        end,
        set = function(self, value)
            SetUnitY(self.handle, value)
        end
    },
    true
)
return ____exports
