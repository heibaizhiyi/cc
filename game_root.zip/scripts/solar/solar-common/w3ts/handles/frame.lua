local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__TypeOf = ____lualib.__TS__TypeOf
local __TS__New = ____lualib.__TS__New
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 6,["16"] = 6,["17"] = 7,["18"] = 7,["19"] = 8,["20"] = 8,["21"] = 9,["22"] = 9,["23"] = 10,["24"] = 10,["25"] = 53,["26"] = 53,["27"] = 53,["28"] = 62,["29"] = 56,["30"] = 57,["31"] = 59,["32"] = 1047,["33"] = 63,["36"] = 66,["37"] = 67,["38"] = 68,["39"] = 69,["40"] = 69,["41"] = 69,["42"] = 69,["45"] = 72,["46"] = 73,["48"] = 75,["49"] = 76,["51"] = 78,["52"] = 79,["54"] = 81,["55"] = 82,["57"] = 84,["58"] = 85,["59"] = 87,["61"] = 89,["62"] = 89,["63"] = 89,["64"] = 89,["65"] = 89,["66"] = 89,["67"] = 89,["69"] = 98,["70"] = 98,["71"] = 98,["72"] = 98,["73"] = 62,["74"] = 239,["75"] = 240,["76"] = 241,["77"] = 239,["78"] = 247,["79"] = 248,["80"] = 249,["81"] = 247,["82"] = 253,["83"] = 254,["84"] = 255,["85"] = 256,["86"] = 257,["87"] = 253,["88"] = 264,["89"] = 265,["90"] = 266,["91"] = 267,["92"] = 267,["93"] = 267,["94"] = 267,["95"] = 267,["96"] = 267,["97"] = 267,["98"] = 268,["100"] = 270,["101"] = 271,["102"] = 272,["103"] = 273,["104"] = 264,["105"] = 277,["106"] = 278,["107"] = 279,["108"] = 277,["109"] = 283,["110"] = 284,["111"] = 285,["112"] = 283,["113"] = 289,["114"] = 290,["115"] = 291,["116"] = 289,["117"] = 295,["118"] = 296,["119"] = 297,["120"] = 295,["121"] = 306,["122"] = 306,["123"] = 306,["125"] = 306,["126"] = 306,["128"] = 307,["129"] = 308,["130"] = 309,["131"] = 306,["132"] = 315,["133"] = 316,["134"] = 316,["135"] = 315,["136"] = 322,["137"] = 323,["138"] = 323,["139"] = 322,["140"] = 330,["141"] = 331,["142"] = 332,["143"] = 330,["144"] = 339,["145"] = 340,["146"] = 341,["147"] = 339,["148"] = 349,["149"] = 350,["150"] = 351,["151"] = 352,["152"] = 353,["153"] = 349,["154"] = 367,["155"] = 367,["156"] = 367,["158"] = 367,["159"] = 367,["161"] = 368,["162"] = 369,["163"] = 370,["164"] = 367,["165"] = 376,["166"] = 377,["167"] = 378,["168"] = 376,["169"] = 384,["170"] = 385,["171"] = 384,["172"] = 394,["173"] = 395,["174"] = 396,["175"] = 394,["176"] = 402,["177"] = 403,["178"] = 402,["179"] = 410,["180"] = 411,["181"] = 412,["182"] = 410,["183"] = 418,["184"] = 419,["185"] = 418,["186"] = 425,["187"] = 426,["188"] = 427,["189"] = 428,["190"] = 425,["191"] = 434,["192"] = 435,["193"] = 434,["194"] = 441,["195"] = 441,["196"] = 441,["198"] = 441,["199"] = 441,["201"] = 442,["202"] = 443,["203"] = 444,["204"] = 441,["205"] = 450,["206"] = 451,["207"] = 450,["208"] = 454,["209"] = 455,["210"] = 456,["211"] = 454,["212"] = 467,["213"] = 468,["214"] = 469,["216"] = 471,["217"] = 472,["218"] = 473,["219"] = 473,["220"] = 473,["221"] = 473,["222"] = 473,["223"] = 473,["224"] = 473,["225"] = 473,["226"] = 474,["227"] = 474,["228"] = 474,["229"] = 474,["230"] = 474,["231"] = 474,["232"] = 474,["234"] = 476,["235"] = 477,["236"] = 478,["238"] = 480,["239"] = 480,["240"] = 480,["241"] = 480,["242"] = 480,["243"] = 480,["244"] = 480,["245"] = 480,["246"] = 481,["247"] = 481,["248"] = 481,["249"] = 481,["250"] = 481,["251"] = 481,["252"] = 481,["254"] = 487,["255"] = 467,["256"] = 494,["257"] = 495,["258"] = 495,["259"] = 495,["260"] = 495,["261"] = 495,["262"] = 495,["263"] = 495,["264"] = 494,["265"] = 501,["266"] = 505,["267"] = 501,["268"] = 511,["269"] = 512,["270"] = 513,["271"] = 511,["272"] = 519,["273"] = 520,["274"] = 521,["275"] = 522,["277"] = 524,["278"] = 519,["279"] = 533,["280"] = 533,["281"] = 533,["283"] = 534,["284"] = 534,["285"] = 534,["286"] = 534,["287"] = 534,["288"] = 534,["289"] = 534,["290"] = 534,["291"] = 535,["292"] = 535,["293"] = 535,["294"] = 535,["295"] = 535,["296"] = 535,["297"] = 535,["298"] = 535,["299"] = 536,["300"] = 533,["301"] = 539,["302"] = 540,["303"] = 539,["304"] = 543,["305"] = 544,["306"] = 545,["307"] = 546,["308"] = 543,["309"] = 554,["310"] = 555,["311"] = 556,["312"] = 554,["313"] = 562,["314"] = 563,["315"] = 564,["316"] = 562,["317"] = 570,["318"] = 571,["319"] = 572,["320"] = 570,["321"] = 578,["322"] = 579,["323"] = 578,["324"] = 585,["325"] = 586,["326"] = 585,["327"] = 592,["328"] = 593,["329"] = 592,["330"] = 599,["331"] = 600,["332"] = 599,["333"] = 606,["334"] = 607,["335"] = 606,["336"] = 613,["337"] = 614,["338"] = 613,["339"] = 620,["340"] = 621,["341"] = 620,["342"] = 627,["343"] = 628,["344"] = 627,["345"] = 632,["346"] = 633,["347"] = 634,["348"] = 632,["349"] = 640,["350"] = 641,["351"] = 642,["352"] = 643,["353"] = 640,["354"] = 646,["355"] = 647,["356"] = 646,["357"] = 651,["358"] = 652,["359"] = 653,["361"] = 655,["362"] = 656,["363"] = 651,["364"] = 659,["365"] = 660,["366"] = 661,["367"] = 659,["368"] = 669,["369"] = 669,["370"] = 669,["372"] = 670,["373"] = 671,["374"] = 672,["375"] = 669,["376"] = 678,["377"] = 679,["378"] = 678,["379"] = 687,["380"] = 687,["381"] = 687,["383"] = 688,["384"] = 688,["385"] = 688,["386"] = 688,["387"] = 688,["388"] = 688,["389"] = 689,["390"] = 690,["391"] = 691,["392"] = 692,["393"] = 687,["394"] = 700,["395"] = 701,["396"] = 701,["397"] = 701,["398"] = 701,["399"] = 701,["400"] = 701,["401"] = 702,["402"] = 703,["403"] = 704,["404"] = 705,["405"] = 700,["406"] = 708,["407"] = 709,["408"] = 710,["409"] = 708,["410"] = 713,["411"] = 714,["412"] = 715,["413"] = 713,["414"] = 719,["415"] = 720,["416"] = 721,["417"] = 719,["418"] = 725,["419"] = 726,["420"] = 727,["421"] = 728,["422"] = 725,["423"] = 736,["424"] = 737,["425"] = 738,["427"] = 740,["428"] = 736,["429"] = 746,["430"] = 747,["431"] = 746,["432"] = 769,["433"] = 770,["434"] = 771,["435"] = 769,["436"] = 777,["437"] = 778,["438"] = 777,["439"] = 784,["440"] = 785,["441"] = 786,["442"] = 784,["443"] = 792,["444"] = 793,["445"] = 792,["446"] = 799,["447"] = 800,["448"] = 799,["449"] = 806,["450"] = 807,["451"] = 806,["452"] = 844,["453"] = 844,["454"] = 844,["456"] = 845,["457"] = 844,["458"] = 851,["459"] = 851,["460"] = 851,["462"] = 852,["463"] = 851,["464"] = 859,["465"] = 860,["466"] = 861,["467"] = 862,["468"] = 863,["469"] = 864,["471"] = 861,["472"] = 859,["473"] = 872,["474"] = 873,["475"] = 874,["476"] = 875,["477"] = 876,["478"] = 877,["480"] = 874,["481"] = 872,["482"] = 885,["483"] = 885,["484"] = 885,["486"] = 886,["487"] = 885,["488"] = 892,["489"] = 892,["490"] = 892,["492"] = 893,["493"] = 892,["494"] = 899,["495"] = 899,["496"] = 899,["498"] = 900,["499"] = 899,["500"] = 906,["501"] = 906,["502"] = 906,["504"] = 907,["505"] = 906,["506"] = 913,["507"] = 913,["508"] = 913,["510"] = 914,["511"] = 913,["512"] = 920,["513"] = 920,["514"] = 920,["516"] = 921,["517"] = 920,["518"] = 928,["519"] = 928,["520"] = 928,["522"] = 930,["523"] = 928,["524"] = 937,["525"] = 938,["526"] = 937,["527"] = 944,["528"] = 944,["529"] = 944,["531"] = 945,["532"] = 944,["533"] = 951,["534"] = 951,["535"] = 951,["537"] = 952,["538"] = 951,["539"] = 958,["540"] = 958,["541"] = 958,["543"] = 959,["544"] = 958,["545"] = 965,["546"] = 965,["547"] = 965,["549"] = 966,["550"] = 965,["551"] = 972,["552"] = 972,["553"] = 972,["555"] = 973,["556"] = 974,["559"] = 979,["560"] = 980,["561"] = 981,["562"] = 982,["564"] = 985,["565"] = 986,["566"] = 987,["567"] = 988,["568"] = 989,["570"] = 991,["573"] = 972,["574"] = 999,["575"] = 999,["576"] = 999,["578"] = 1000,["579"] = 1001,["582"] = 1004,["583"] = 1004,["584"] = 1004,["585"] = 1005,["586"] = 1006,["587"] = 1007,["588"] = 1008,["589"] = 1009,["590"] = 1010,["591"] = 1011,["592"] = 1012,["595"] = 1008,["596"] = 1016,["598"] = 1018,["599"] = 1019,["600"] = 1019,["601"] = 1019,["602"] = 1019,["603"] = 1020,["604"] = 1021,["606"] = 1019,["607"] = 1019,["609"] = 1025,["610"] = 1025,["611"] = 1025,["612"] = 1025,["613"] = 1026,["614"] = 1027,["616"] = 1025,["617"] = 1025,["618"] = 1025,["620"] = 1032,["621"] = 1004,["622"] = 1004,["623"] = 1034,["624"] = 999,["625"] = 1054,["626"] = 1055,["627"] = 1056,["628"] = 1054,["629"] = 1064,["630"] = 1065,["631"] = 1066,["632"] = 1064,["633"] = 1074,["634"] = 1075,["635"] = 1076,["636"] = 1074,["637"] = 1082,["638"] = 1083,["639"] = 1082,["640"] = 1091,["641"] = 1092,["642"] = 1093,["643"] = 1091,["644"] = 1097,["645"] = 1098,["646"] = 1097,["647"] = 1105,["648"] = 1106,["649"] = 1107,["650"] = 1108,["651"] = 1109,["652"] = 1110,["653"] = 1111,["654"] = 1112,["655"] = 1113,["656"] = 1113,["657"] = 1113,["658"] = 1114,["659"] = 1115,["661"] = 1117,["662"] = 1118,["663"] = 1119,["664"] = 1120,["665"] = 1121,["666"] = 1122,["667"] = 1123,["668"] = 1124,["669"] = 1125,["670"] = 1126,["672"] = 1128,["673"] = 1128,["674"] = 1128,["675"] = 1128,["676"] = 1128,["677"] = 1128,["678"] = 1128,["679"] = 1128,["680"] = 1128,["681"] = 1128,["682"] = 1128,["683"] = 1128,["684"] = 1140,["685"] = 1141,["686"] = 1142,["687"] = 1113,["688"] = 1113,["689"] = 1107,["690"] = 1145,["691"] = 1146,["692"] = 1145,["693"] = 1105,["694"] = 1153,["695"] = 1154,["698"] = 1157,["699"] = 1158,["700"] = 1160,["701"] = 1161,["702"] = 1162,["703"] = 1163,["704"] = 1164,["707"] = 1167,["708"] = 1168,["709"] = 1169,["710"] = 1170,["711"] = 1171,["713"] = 1171,["714"] = 1171,["715"] = 1171,["716"] = 1171,["717"] = 1171,["718"] = 1171,["719"] = 1171,["720"] = 1171,["721"] = 1171,["722"] = 1171,["723"] = 1171,["724"] = 1171,["727"] = 1162,["728"] = 1186,["729"] = 1187,["730"] = 1188,["733"] = 1191,["736"] = 1194,["737"] = 1195,["739"] = 1195,["741"] = 1196,["742"] = 1197,["743"] = 1198,["744"] = 1199,["746"] = 1186,["747"] = 1205,["748"] = 1206,["749"] = 1207,["750"] = 1208,["752"] = 1208,["754"] = 1209,["756"] = 1205,["757"] = 1213,["758"] = 1214,["759"] = 1215,["760"] = 1216,["761"] = 1217,["762"] = 1218,["763"] = 1219,["765"] = 1221,["767"] = 1221,["770"] = 1223,["772"] = 1213,["773"] = 1153,["774"] = 1234,["775"] = 1234,["776"] = 1234,["778"] = 1235,["779"] = 1236,["781"] = 1238,["782"] = 1238,["783"] = 1238,["784"] = 1238,["786"] = 1234,["787"] = 1243,["788"] = 1244,["789"] = 1243,["790"] = 1247,["791"] = 1248,["792"] = 1247,["793"] = 1256,["794"] = 1257,["795"] = 1256,["796"] = 1263,["797"] = 1264,["798"] = 1263,["799"] = 1270,["800"] = 1271,["801"] = 1270,["802"] = 1278,["803"] = 1279,["804"] = 1278,["805"] = 1285,["806"] = 1286,["807"] = 1286,["808"] = 1286,["809"] = 1286,["810"] = 1286,["811"] = 1286,["812"] = 1286,["813"] = 1285,["814"] = 1292,["815"] = 1294,["816"] = 1294,["817"] = 1294,["818"] = 1294,["819"] = 1294,["820"] = 1294,["821"] = 1294,["822"] = 1294,["823"] = 1295,["824"] = 1296,["825"] = 1297,["826"] = 1298,["827"] = 1292,["828"] = 1304,["829"] = 1305,["830"] = 1304,["831"] = 1312,["832"] = 1313,["833"] = 1313,["834"] = 1313,["835"] = 1313,["836"] = 1313,["837"] = 1313,["838"] = 1313,["839"] = 1312,["840"] = 1319,["841"] = 1320,["842"] = 1320,["843"] = 1320,["844"] = 1320,["845"] = 1320,["846"] = 1320,["847"] = 1320,["848"] = 1319,["849"] = 1326,["850"] = 1327,["851"] = 1326,["852"] = 1333,["853"] = 1334,["854"] = 1333,["855"] = 1341,["856"] = 1342,["857"] = 1341,["858"] = 1348,["859"] = 1349,["860"] = 1348,["861"] = 54,["867"] = 103,["868"] = 104,["869"] = 105,["871"] = 107,["872"] = 107,["873"] = 112,["874"] = 112,["875"] = 112,["876"] = 112,["877"] = 107,["878"] = 107,["879"] = 107,["880"] = 107,["883"] = 122,["885"] = 125,["886"] = 126,["896"] = 130,["897"] = 130,["898"] = 130,["899"] = 130,["901"] = 133,["902"] = 134,["903"] = 134,["904"] = 134,["905"] = 134,["906"] = 134,["915"] = 139,["924"] = 149,["926"] = 143,["927"] = 144,["937"] = 171,["939"] = 165,["940"] = 166,["950"] = 182,["951"] = 183,["953"] = 185,["955"] = 174,["956"] = 175,["957"] = 176,["958"] = 177,["969"] = 193,["971"] = 188,["972"] = 189,["982"] = 201,["984"] = 196,["985"] = 197,["995"] = 209,["997"] = 204,["998"] = 205,["1008"] = 217,["1010"] = 212,["1011"] = 213,["1021"] = 227,["1023"] = 221,["1024"] = 222,["1025"] = 223,["1035"] = 236,["1037"] = 230,["1038"] = 231,["1039"] = 232,["1044"] = 357,["1045"] = 358,["1049"] = 754,["1050"] = 755,["1051"] = 756,["1059"] = 763,["1068"] = 821,["1070"] = 813,["1071"] = 814,["1081"] = 835,["1083"] = 827,["1084"] = 828});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____AsyncUtil = require("solar.solar-common.util.net.AsyncUtil")
local AsyncUtil = ____AsyncUtil.default
local ____Cache = require("solar.solar-common.tool.Cache")
local Cache = ____Cache.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____InputUtil = require("solar.solar-common.util.system.InputUtil")
local InputUtil = ____InputUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____SolarEvent = require("solar.solar-common.common.SolarEvent")
local SolarEvent = ____SolarEvent.default
local ____ArrayUtil = require("solar.solar-common.util.lang.ArrayUtil")
local ArrayUtil = ____ArrayUtil.default
____exports.Frame = __TS__Class()
local Frame = ____exports.Frame
Frame.name = "Frame"
function Frame.prototype.____constructor(self, frameOrFrameType, name, parent, template, id)
    self.current = 0
    self.type = ""
    self.propsTemp = nil
    self.startDrag = false
    if not frameOrFrameType then
        return
    end
    local ____type = __TS__TypeOf(frameOrFrameType)
    if ____type == "number" then
        self.current = frameOrFrameType
        ____exports.Frame._sl_cache:put(
            "handle:" .. tostring(self.current),
            self
        )
        return
    end
    if not name then
        name = "Solar:Frame:" .. tostring(AsyncUtil:getUUIDAsync())
    end
    if not parent then
        parent = DzGetGameUI()
    end
    if not template then
        template = ""
    end
    if not id then
        id = 0
    end
    self.type = frameOrFrameType
    if frameOrFrameType == "MODEL" then
        self.current = FrameAddModel(parent)
    else
        self.current = DzCreateFrameByTagName(
            frameOrFrameType,
            name,
            parent,
            template,
            id
        )
    end
    ____exports.Frame._sl_cache:put(
        "handle:" .. tostring(self.current),
        self
    )
end
function Frame.prototype.cageMouse(self, enable)
    DzFrameCageMouse(self.current, enable)
    return self
end
function Frame.prototype.clearPoints(self)
    DzFrameClearAllPoints(self.current)
    return self
end
function Frame.prototype.destroy(self)
    DzDestroyFrame(self.current)
    ____exports.Frame._sl_cache:remove("handle:" .. tostring(self.current))
    self.solarData = nil
    return self
end
function Frame.prototype.setAbsPoint(self, point, x, y)
    local pointObj = self:getPoint()
    if not pointObj then
        pointObj = {
            point = point,
            relative = DzGetGameUI(),
            relativePoint = FramePoint.bottomLeft,
            x = x,
            y = y
        }
        self.props.position = pointObj
    end
    pointObj.x = x
    pointObj.y = y
    DzFrameSetAbsolutePoint(self.current, point, x, y)
    return self
end
function Frame.prototype.setAllPoints(self, relative)
    DzFrameSetAllPoints(self.current, relative)
    return self
end
function Frame.prototype.setAlpha(self, alpha)
    DzFrameSetAlpha(self.current, alpha)
    return self
end
function Frame.prototype.setEnabled(self, flag)
    DzFrameSetEnable(self.current, flag)
    return self
end
function Frame.prototype.setFocus(self, flag)
    DzFrameSetFocus(self.current, flag)
    return self
end
function Frame.prototype.setFont(self, height, filename, flags)
    if filename == nil then
        filename = settings.fontPath
    end
    if flags == nil then
        flags = 0
    end
    DzFrameSetFont(self.current, filename, height, flags)
    self.props.font = {fileName = filename, height = height, flags = flags}
    return self
end
function Frame.prototype.getFontName(self)
    local ____opt_0 = self.props.font
    return ____opt_0 and ____opt_0.fileName
end
function Frame.prototype.getFontSize(self)
    local ____opt_2 = self.props.font
    return ____opt_2 and ____opt_2.height
end
function Frame.prototype.setHeight(self, height)
    self:setSize(self.width, height)
    return self
end
function Frame.prototype.setWidth(self, width)
    self:setSize(width, self.height)
    return self
end
function Frame.prototype.setSize(self, width, height)
    self.props.size.width = width
    self.props.size.height = height
    DzFrameSetSize(self.current, width, height)
    return self
end
function Frame.prototype.setSizeByPixel(self, widthPX, heightPX, screenWidthPX, screenHeightPX)
    if screenWidthPX == nil then
        screenWidthPX = ____exports.Frame.defaultScreenWidthPX
    end
    if screenHeightPX == nil then
        screenHeightPX = ____exports.Frame.defaultScreenHeightPX
    end
    local w = widthPX / screenWidthPX * 0.8
    local h = heightPX / screenHeightPX * 0.6
    self:setSize(w, h)
end
function Frame.prototype.setTextFontSpacing(self, fontSpacing)
    FrameSetTextFontSpacing(self.current, fontSpacing)
    self.props.fontSpacing = fontSpacing
end
function Frame.prototype.getFontSpacing(self)
    return self.props.fontSpacing
end
function Frame.prototype.setTextAlignment(self, alignment)
    DzFrameSetTextAlignment(self.current, alignment)
    self.props.textAlignment = alignment
end
function Frame.prototype.getTextAlignment(self)
    return self.props.textAlignment
end
function Frame.prototype.setLevel(self, level)
    FrameSetLevel(self.current, level)
    return self
end
function Frame.prototype.setFramePort(self, p2)
    FrameSetViewPort(self.current, p2)
end
function Frame.prototype.setMinMaxValue(self, minValue, maxValue)
    DzFrameSetMinMaxValue(self.current, minValue, maxValue)
    self.props.minMaxValue = {min = minValue, max = maxValue}
    return self
end
function Frame.prototype.getMinMaxValue(self)
    return self.props.minMaxValue
end
function Frame.prototype.setModel(self, modelFile, modelType, flag)
    if modelType == nil then
        modelType = 0
    end
    if flag == nil then
        flag = 0
    end
    DzFrameSetModel(self.current, modelFile, modelType, flag)
    self.props.model = {modelFile = modelFile}
    return self
end
function Frame.prototype.getModel(self)
    return self.props.model.modelFile
end
function Frame.prototype.setParent(self, parent)
    DzFrameSetParent(self.current, parent)
    return self
end
function Frame.prototype.setPoint(self, pointObjOrPoint, relative, relativePoint, x, y)
    if pointObjOrPoint == nil then
        return self
    end
    if type(pointObjOrPoint) == "number" then
        local point = pointObjOrPoint
        DzFrameSetPoint(
            self.current,
            point,
            relative,
            relativePoint,
            x or 0,
            y or 0
        )
        self.props.position = {
            point = point,
            relative = relative,
            relativePoint = relativePoint,
            x = x or 0,
            y = y or 0
        }
    else
        local pointObj = pointObjOrPoint
        if not pointObj.relative then
            return self
        end
        DzFrameSetPoint(
            self.current,
            pointObj.point,
            pointObj.relative,
            pointObj.relativePoint,
            pointObj.x,
            pointObj.y
        )
        self.props.position = {
            point = pointObj.point,
            relative = pointObj.relative,
            relativePoint = pointObj.relativePoint,
            x = pointObj.x,
            y = pointObj.y
        }
    end
    return self
end
function Frame.prototype.setPoint2Center(self, relative)
    self:setPoint(
        FramePoint.center,
        relative,
        FramePoint.center,
        0,
        0
    )
end
function Frame.prototype.getPoint(self)
    return self.props.position
end
function Frame.prototype.getRelative(self)
    local p = self.props.position
    return p and p.relative
end
function Frame.prototype.getRelativeXY(self)
    local p = self.props.position
    if not p then
        return nil
    end
    return {x = p.x, y = p.y}
end
function Frame.prototype.setPoints(self, relative, widthGap, heightGap)
    if heightGap == nil then
        heightGap = widthGap
    end
    DzFrameSetPoint(
        self.current,
        FRAMEPOINT_TOPLEFT,
        relative,
        FRAMEPOINT_TOPLEFT,
        -widthGap,
        heightGap
    )
    DzFrameSetPoint(
        self.current,
        FRAMEPOINT_BOTTOMRIGHT,
        relative,
        FRAMEPOINT_BOTTOMRIGHT,
        widthGap,
        -heightGap
    )
    return self
end
function Frame.prototype.getScale(self)
    return self.props.scale
end
function Frame.prototype.setScale(self, scale)
    self.props.scale = scale
    DzFrameSetScale(self.current, scale)
    return self
end
function Frame.prototype.setSpriteAnimate(self, animId, autocast)
    DzFrameSetAnimate(self.current, animId, autocast)
    return self
end
function Frame.prototype.setAnimationByIndex(self, animId)
    FrameSetAnimationByIndex(self.current, animId)
    return self
end
function Frame.prototype.setFrameModelTexture(self, path)
    FrameSetModelTexture(self.current, path, 1)
    self.props.modelTexture = path
end
function Frame.prototype.getFrameModelTexture(self)
    return self.props.modelTexture
end
function Frame.prototype.setModel2(self, path)
    FrameSetModel2(self.current, path, 0)
end
function Frame.prototype.setModelCameraSource(self, x, y, z)
    FrameSetModelCameraSource(self.current, x, y, z)
end
function Frame.prototype.setModelCameraTarget(self, x, y, z)
    FrameSetModelCameraTarget(self.current, x, y, z)
end
function Frame.prototype.setModelPlayAnimation(self, animName)
    FramePlayAnimation(self.current, animName, "")
end
function Frame.prototype.setModelX(self, x)
    FrameSetModelX(self.current, x)
end
function Frame.prototype.setModelY(self, y)
    FrameSetModelY(self.current, y)
end
function Frame.prototype.setModelZ(self, z)
    FrameSetModelZ(self.current, z)
end
function Frame.prototype.setStepSize(self, stepSize)
    DzFrameSetStepValue(self.current, stepSize)
    return self
end
function Frame.prototype.setText(self, text)
    self.props.text = text
    DzFrameSetText(self.current, text)
    return self
end
function Frame.prototype.getText(self)
    return DzFrameGetText(self.current)
end
function Frame.prototype.setTextColor(self, rOrColor, g, b)
    if b ~= nil then
        rOrColor = 255 * 16777216 + rOrColor * 65536 + g * 256 + b
    end
    DzFrameSetTextColor(self.current, rOrColor)
    return self
end
function Frame.prototype.setTextSizeLimit(self, size)
    DzFrameSetTextSizeLimit(self.current, size)
    return self
end
function Frame.prototype.setTexture(self, texFile, flag)
    if flag == nil then
        flag = 0
    end
    DzFrameSetTexture(self.current, texFile, flag)
    self.props.texture = texFile
    return self
end
function Frame.prototype.getTexture(self)
    return self.props.texture
end
function Frame.prototype.addBackgroundImage(self, texFile, flag)
    if flag == nil then
        flag = 0
    end
    local backdropFrame = __TS__New(
        ____exports.Frame,
        "BACKDROP",
        ____exports.Frame:getRandomName(),
        self.current
    )
    backdropFrame:setTexture(texFile, flag)
    backdropFrame:setAllPoints(self.current)
    self.backdropFrame = backdropFrame
    return backdropFrame
end
function Frame.prototype.addTextFrame(self, text)
    local frame = __TS__New(
        ____exports.Frame,
        "TEXT",
        ____exports.Frame:getRandomName(),
        self.current
    )
    frame:setText(text)
    frame:setAllPoints(self.current)
    self.textFrame = frame
    return frame
end
function Frame.prototype.setTooltip(self, tooltip)
    DzFrameSetTooltip(self.current, tooltip)
    return self
end
function Frame.prototype.setValue(self, value)
    DzFrameSetValue(self.current, value)
    return self
end
function Frame.prototype.setVertexColor(self, color)
    DzFrameSetVertexColor(self.current, color)
    return self
end
function Frame.prototype.setVisible(self, flag)
    self.props.visible = flag
    DzFrameShow(self.current, flag)
    return self
end
function Frame.prototype.setModelSize(self, size)
    if FrameSetModelSize then
        FrameSetModelSize(self.current, size)
    end
    self.props.modelSize = size
end
function Frame.prototype.getModelSize(self)
    return self.props.modelSize
end
function Frame.prototype.setModelSpeed(self, Speed)
    FrameSetModelSpeed(self.current, Speed)
    self.props.modelSpeed = Speed
end
function Frame.prototype.getModelSpeed(self)
    return self.props.modelSpeed
end
function Frame.prototype.setAnimateOffset(self, offset)
    DzFrameSetAnimateOffset(self.current, offset)
    self.props.animateOffset = offset
end
function Frame.prototype.getAnimateOffset(self)
    return self.props.animateOffset
end
function Frame.prototype.setIgnoreTrackEvent(self, ign)
    FrameSetIgnoreTrackEvents(self.current, ign)
end
function Frame.prototype.setTexture2Transparent(self)
    self:setTexture("UI\\Widgets\\EscMenu\\Human\\blank-background.blp")
end
function Frame.prototype.setOnClick(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_CONTROL_CLICK, callback, sync)
end
function Frame.prototype.addOnClick(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_CONTROL_CLICK, callback, sync)
end
function Frame.prototype.addOnMouseRightDown(self, callback)
    local current = self.current
    InputUtil:onMouseRightButtonPressed(function()
        local focusUiId = DzGetMouseFocus()
        if focusUiId == current then
            callback()
        end
    end)
end
function Frame.prototype.addOnMouseRightUp(self, callback)
    local current = self.current
    InputUtil:onMouseRightButtonReleased(function()
        local focusUiId = DzGetMouseFocus()
        if focusUiId == current then
            callback()
        end
    end)
end
function Frame.prototype.setOnDoubleClick(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_DOUBLECLICK, callback, sync)
end
function Frame.prototype.addOnDoubleClick(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_MOUSE_DOUBLECLICK, callback, sync)
end
function Frame.prototype.setOnMouseEnter(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_ENTER, callback, sync)
end
function Frame.prototype.addOnMouseEnter(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_MOUSE_ENTER, callback, sync)
end
function Frame.prototype.setOnMouseLeave(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_LEAVE, callback, sync)
end
function Frame.prototype.addOnMouseLeave(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_MOUSE_LEAVE, callback, sync)
end
function Frame.prototype.setOnMouseDown(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_DOWN, callback, sync)
end
function Frame.prototype.addOnMouseDown(self, callback)
    self:addEventCallback(FRAMEEVENT_MOUSE_DOWN, callback, false)
end
function Frame.prototype.setOnMouseUp(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_UP, callback, sync)
end
function Frame.prototype.addOnMouseUp(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_MOUSE_UP, callback, sync)
end
function Frame.prototype.setOnMouseWheel(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:setEventCallback(FRAMEEVENT_MOUSE_WHEEL, callback, sync)
end
function Frame.prototype.addOnMouseWheel(self, callback, sync)
    if sync == nil then
        sync = false
    end
    self:addEventCallback(FRAMEEVENT_MOUSE_WHEEL, callback, sync)
end
function Frame.prototype.setEventCallback(self, event, callback, sync)
    if sync == nil then
        sync = false
    end
    if sync and isAsync then
        log.errorWithTraceBack("无法在异步中注册同步方法！请在同步方法中执行！")
        return
    end
    local array = ____exports.Frame._sl_cache:get((tostring(self.current) .. "aecb") .. tostring(event))
    if array then
        log.errorWithTraceBack("你之前已经使用addEventCallback添加了此事件!请再次使用addEventCallback 以禁用此警告")
        array[#array + 1] = callback
    else
        if sync == false then
            local key = "onFrameEvent:" .. tostring(event)
            local solarTriggers = SolarEvent:getFrameDataEventHandler(self.current, key, false)
            ArrayUtil:clear(solarTriggers)
            se:onFrameEvent(self.handle, event, callback)
        else
            DzFrameSetScriptByCode(self.current, event, callback, sync)
        end
    end
end
function Frame.prototype.addEventCallback(self, event, callback, sync)
    if sync == nil then
        sync = false
    end
    if sync and isAsync then
        log.errorWithTraceBack("无法在异步中注册同步方法！请在同步方法中执行！")
        return
    end
    local array = ____exports.Frame._sl_cache:get(
        (tostring(self.current) .. "aecb") .. tostring(event),
        function()
            local array_temp = {}
            if event == FRAMEEVENT_MOUSE_DOWN then
                local current = self.current
                InputUtil:onMouseLeftButtonPressed(function()
                    local focusUiId = DzGetMouseFocus()
                    if focusUiId == current then
                        for ____, cb in ipairs(array_temp) do
                            cb()
                        end
                    end
                end)
                return array_temp
            end
            if sync == false then
                se:onFrameEvent(
                    self.handle,
                    event,
                    function()
                        for ____, cb in ipairs(array_temp) do
                            cb()
                        end
                    end
                )
            else
                DzFrameSetScriptByCode(
                    self.current,
                    event,
                    function()
                        for ____, cb in ipairs(array_temp) do
                            cb()
                        end
                    end,
                    sync
                )
            end
            return array_temp
        end
    )
    array[#array + 1] = callback
end
function Frame.prototype.setOnRightDragStart(self, onRightDragStart)
    self:_sl_InitRightDragEvent(self)
    self._sl_onRightDragStart = onRightDragStart
end
function Frame.prototype.setOnRightDragOver(self, onRightDragOver)
    self:_sl_InitRightDragEvent(self)
    self._sl_onRightDragOver = onRightDragOver
end
function Frame.prototype.setOnRightDragEnd(self, onRightDragEnd)
    self:_sl_InitRightDragEvent(self)
    self._sl_onRightDragEnd = onRightDragEnd
end
function Frame.prototype.getOnRightDragEnd(self)
    return self._sl_onRightDragEnd
end
function Frame.prototype.setOnRightDragDrop(self, onRightDragDrop)
    self:_sl_InitRightDragEvent(self)
    self._sl_onRightDragDrop = onRightDragDrop
end
function Frame.fromEvent(self)
    return self:fromHandle(DzGetTriggerUIEventFrame())
end
function Frame.prototype.addOnDragOver(self, onDrag)
    local f = self
    self:addOnMouseDown(function()
        f.startDrag = true
        local bX = InputUtil:getMouseSceneX()
        local bY = InputUtil:getMouseSceneY()
        local startDragX = InputUtil:getMouseSceneX()
        local startDragY = InputUtil:getMouseSceneY()
        BaseUtil.onTimer(
            0.03,
            function()
                if not f.startDrag then
                    return false
                end
                local screenX = DzGetMouseX()
                local screenY = DzGetMouseY()
                local sceneX = InputUtil:getMouseSceneX()
                local sceneY = InputUtil:getMouseSceneY()
                local x = 0
                local y = 0
                local point = f:getPoint()
                if point and point.x and point.y then
                    x = sceneX - point.x
                    y = sceneY - point.y
                end
                onDrag({
                    x = x,
                    y = y,
                    deltaX = sceneX - bX,
                    deltaY = sceneY - bY,
                    sceneX = sceneX,
                    sceneY = sceneY,
                    screenX = screenX,
                    screenY = screenY,
                    startDragX = startDragX,
                    startDragY = startDragY
                })
                bX = sceneX
                bY = sceneY
                return true
            end
        )
    end)
    InputUtil:onMouseLeftButtonReleased(function()
        f.startDrag = false
    end)
end
function Frame.prototype._sl_InitRightDragEvent(self, frame)
    if self._sl_FrameEvent_RightDragInit == true then
        return
    end
    self._sl_FrameEvent_RightDragInit = true
    local MouseMoveEventKey = "RightDrag_" .. tostring(frame.current)
    local bX = InputUtil:getMouseSceneX()
    local bY = InputUtil:getMouseSceneY()
    local function onMouseMoveEventCallBack()
        if not frame.startDrag then
            InputUtil:removeMouseMoveEvent(MouseMoveEventKey)
            return
        end
        local screenX = DzGetMouseX()
        local screenY = DzGetMouseY()
        local sceneX = InputUtil:getMouseSceneX()
        local sceneY = InputUtil:getMouseSceneY()
        local ____opt_8 = frame._sl_onRightDragOver
        if ____opt_8 ~= nil then
            ____opt_8({
                x = 0,
                y = 0,
                deltaX = sceneX - bX,
                deltaY = sceneY - bY,
                sceneX = sceneX,
                sceneY = sceneY,
                screenX = screenX,
                screenY = screenY,
                startDragX = bX,
                startDragY = bY
            })
        end
        return
    end
    frame:addOnMouseRightUp(function()
        if frame.startDrag then
            frame.startDrag = false
            return
        end
        if time - (frame._sl_FrameEvent_startDragTime or 0) < 500 then
            return
        end
        frame.startDrag = true
        local ____opt_10 = frame._sl_onRightDragStart
        if ____opt_10 ~= nil then
            ____opt_10()
        end
        if frame.startDrag then
            bX = InputUtil:getMouseSceneX()
            bY = InputUtil:getMouseSceneY()
            InputUtil:onMouseMoveEvent(onMouseMoveEventCallBack, MouseMoveEventKey)
        end
    end)
    InputUtil:onMouseRightButtonPressed(function()
        if frame.startDrag then
            frame._sl_FrameEvent_startDragTime = time
            local ____opt_12 = frame._sl_onRightDragEnd
            if ____opt_12 ~= nil then
                ____opt_12()
            end
            frame.startDrag = false
        end
    end)
    InputUtil:onMouseLeftButtonPressed(function()
        if frame.startDrag then
            frame._sl_FrameEvent_startDragTime = time
            if frame._sl_onRightDragDrop then
                local mouseFocus = DzGetMouseFocus()
                local targetFrame = ____exports.Frame:fromHandle(mouseFocus, true)
                frame._sl_onRightDragDrop(targetFrame)
            else
                local ____opt_14 = frame:getOnRightDragEnd()
                if ____opt_14 ~= nil then
                    ____opt_14()
                end
            end
            frame.startDrag = false
        end
    end)
end
function Frame.fromHandle(self, handle, onlyCache)
    if onlyCache == nil then
        onlyCache = false
    end
    if onlyCache then
        return ____exports.Frame._sl_cache:get("handle:" .. tostring(handle))
    else
        return ____exports.Frame._sl_cache:get(
            "handle:" .. tostring(handle),
            function() return __TS__New(____exports.Frame, handle) end
        )
    end
end
function Frame.fromName(self, name, createContext)
    return self:fromHandle(DzFrameFindByName(name, createContext))
end
function Frame.loadTOC(self, filename)
    return DzLoadToc(filename)
end
function Frame.getRandomName(self)
    return "Solar:Frame:" .. tostring(AsyncUtil:getUUIDAsync())
end
function Frame.createFrame(self, parent)
    return __TS__New(____exports.Frame, "FRAME", nil, parent)
end
function Frame.createBackDrop(self, parent)
    return __TS__New(____exports.Frame, "BACKDROP", nil, parent)
end
function Frame.createTEXT(self, parent)
    return __TS__New(____exports.Frame, "TEXT", nil, parent)
end
function Frame.createShadowTEXT(self, parent)
    return __TS__New(
        ____exports.Frame,
        "TEXT",
        nil,
        parent,
        "_sl_shadowtext"
    )
end
function Frame.createTEXTWithBorderBackDrop(self, parent)
    local bdFrame = __TS__New(
        ____exports.Frame,
        "BACKDROP",
        nil,
        parent,
        "_sl_border_backdrop",
        0
    )
    local textFrame = ____exports.Frame:createTEXT(parent)
    textFrame.backdropFrame = bdFrame
    bdFrame:setPoints(textFrame.current, 0.01, 0.01)
    return textFrame
end
function Frame.createGLUETEXTBUTTON(self, parent)
    return __TS__New(____exports.Frame, "GLUETEXTBUTTON", nil, parent)
end
function Frame.createBUTTON(self, parent)
    return __TS__New(
        ____exports.Frame,
        "BUTTON",
        nil,
        parent,
        "ScoreScreenTabButtonTemplate"
    )
end
function Frame.createGLUEBUTTON(self, parent)
    return __TS__New(
        ____exports.Frame,
        "GLUEBUTTON",
        nil,
        parent,
        "ScoreScreenTabButtonTemplate"
    )
end
function Frame.createTEXTBUTTON(self, parent)
    return __TS__New(____exports.Frame, "TEXTBUTTON", nil, parent)
end
function Frame.createTEXTAREA(self, parent)
    return __TS__New(____exports.Frame, "TEXTAREA", nil, parent)
end
function Frame.createSPRITE(self, parent)
    return __TS__New(____exports.Frame, "SPRITE", nil, parent)
end
function Frame.createMODEL(self, parent)
    return __TS__New(____exports.Frame, "MODEL", nil, parent)
end
Frame._sl_cache = __TS__New(Cache)
__TS__SetDescriptor(
    Frame.prototype,
    "props",
    {
        get = function(self)
            if not self.propsTemp then
                if self.current == 0 then
                    self.propsTemp = {size = {}, position = {relative = 0, x = 0, y = 0}, visible = true, scale = 1}
                else
                    self.propsTemp = {
                        size = {width = 0, height = 0},
                        position = {
                            relative = DzFrameGetParent(self.current),
                            x = 0,
                            y = 0
                        },
                        visible = true,
                        scale = 1
                    }
                end
            end
            return self.propsTemp
        end,
        set = function(self, obj)
            self.propsTemp = obj
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "solarData",
    {
        get = function(self)
            return DataBase:getDataByTypeId(
                "_SL_Frame",
                tostring(self.current)
            )
        end,
        set = function(self, obj)
            DataBase:setDataByTypeId(
                "_SL_Frame",
                tostring(self.current),
                obj
            )
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "handle",
    {get = function(self)
        return self.current
    end},
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "alpha",
    {
        get = function(self)
            return DzFrameGetAlpha(self.current)
        end,
        set = function(self, alpha)
            DzFrameSetAlpha(self.current, alpha)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "enabled",
    {
        get = function(self)
            return DzFrameGetEnable(self.current)
        end,
        set = function(self, flag)
            DzFrameSetEnable(self.current, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "height",
    {
        get = function(self)
            if self.current == 0 then
                return self.props.size.height
            end
            return DzFrameGetHeight(self.current)
        end,
        set = function(self, height)
            self.props.size.height = height
            if self.current ~= 0 then
                DzFrameSetSize(self.current, self.width, height)
            end
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "parent",
    {
        get = function(self)
            return DzFrameGetParent(self.current)
        end,
        set = function(self, parent)
            DzFrameSetParent(self.current, parent)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "text",
    {
        get = function(self)
            return self:getText()
        end,
        set = function(self, text)
            self:setText(text)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "textSizeLimit",
    {
        get = function(self)
            return DzFrameGetTextSizeLimit(self.current)
        end,
        set = function(self, size)
            DzFrameSetTextSizeLimit(self.current, size)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "value",
    {
        get = function(self)
            return DzFrameGetValue(self.current)
        end,
        set = function(self, value)
            DzFrameSetValue(self.current, value)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "visible",
    {
        get = function(self)
            return self.props.visible
        end,
        set = function(self, flag)
            self.props.visible = flag
            DzFrameShow(self.current, flag)
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "width",
    {
        get = function(self)
            return self.props.size.width
        end,
        set = function(self, width)
            self.props.size.width = width
            DzFrameSetSize(self.current, width, self.height)
        end
    },
    true
)
Frame.defaultScreenWidthPX = 1920
Frame.defaultScreenHeightPX = 1080
__TS__SetDescriptor(
    Frame.prototype,
    "setModelPariticleSize",
    {set = function(self, size)
        FrameSetModelPariticle2Size(self.current, size)
        self.props.modelPariticleSize = size
    end},
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "getModelPariticleSize",
    {get = function(self)
        return self.props.modelPariticleSize
    end},
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "backdropFrame",
    {
        get = function(self)
            return self.props.backdropFrame
        end,
        set = function(self, frame)
            self.props.backdropFrame = frame
        end
    },
    true
)
__TS__SetDescriptor(
    Frame.prototype,
    "textFrame",
    {
        get = function(self)
            return self.props.textFrame
        end,
        set = function(self, frame)
            self.props.textFrame = frame
        end
    },
    true
)
return ____exports
