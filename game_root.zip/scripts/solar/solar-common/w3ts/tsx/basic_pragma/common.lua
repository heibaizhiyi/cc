local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 3,["8"] = 5});
local ____exports = {}
---
-- @noSelfInFile *
____exports.TEXT_ELEMENT = "TEXT ELEMENT"
____exports.isLua = _G._VERSION ~= nil
return ____exports
