local ____lualib = require("lualib_bundle")
local WeakMap = ____lualib.WeakMap
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 11,["8"] = 13});
local ____exports = {}
____exports.hookContext = {}
____exports.hookMap = __TS__New(WeakMap)
return ____exports
