local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 2,["8"] = 3,["9"] = 3,["10"] = 4,["11"] = 4,["12"] = 5,["13"] = 5,["14"] = 7,["15"] = 8,["16"] = 9,["17"] = 8,["18"] = 12,["19"] = 13,["20"] = 12,["21"] = 16,["22"] = 17,["23"] = 18,["24"] = 24,["25"] = 24,["27"] = 26,["28"] = 27,["31"] = 30,["32"] = 18,["33"] = 33,["35"] = 34,["38"] = 33,["39"] = 37,["41"] = 38,["42"] = 40,["44"] = 41,["46"] = 43,["48"] = 44,["50"] = 46,["52"] = 47,["54"] = 48,["56"] = 49,["59"] = 37,["60"] = 54,["61"] = 54,["62"] = 54,["64"] = 54,["65"] = 56,["66"] = 57,["67"] = 58,["68"] = 59,["69"] = 60,["70"] = 61,["73"] = 64,["75"] = 66,["76"] = 67,["79"] = 69,["80"] = 70,["82"] = 71,["85"] = 73,["88"] = 56,["89"] = 81,["90"] = 83,["91"] = 83,["92"] = 83,["94"] = 83,["95"] = 85,["97"] = 86,["98"] = 266,["99"] = 87,["102"] = 88,["106"] = 91,["109"] = 92,["113"] = 95,["116"] = 96,["120"] = 99,["123"] = 100,["124"] = 101,["125"] = 101,["126"] = 101,["127"] = 101,["128"] = 101,["130"] = 102,["131"] = 102,["132"] = 102,["134"] = 101,["138"] = 105,["141"] = 106,["142"] = 106,["143"] = 106,["144"] = 106,["145"] = 106,["147"] = 107,["148"] = 107,["149"] = 107,["151"] = 106,["155"] = 110,["158"] = 111,["162"] = 114,["165"] = 115,["169"] = 118,["172"] = 119,["176"] = 122,["179"] = 123,["183"] = 126,["186"] = 127,["190"] = 130,["193"] = 131,["194"] = 131,["195"] = 131,["196"] = 131,["197"] = 131,["199"] = 131,["200"] = 132,["201"] = 132,["202"] = 132,["204"] = 131,["205"] = 131,["206"] = 131,["207"] = 131,["208"] = 131,["212"] = 135,["215"] = 136,["219"] = 139,["222"] = 140,["223"] = 141,["224"] = 142,["225"] = 143,["227"] = 145,["228"] = 145,["229"] = 145,["230"] = 145,["231"] = 145,["232"] = 146,["233"] = 147,["235"] = 149,["239"] = 152,["241"] = 153,["244"] = 155,["247"] = 156,["248"] = 157,["249"] = 158,["250"] = 158,["251"] = 158,["253"] = 159,["254"] = 159,["255"] = 159,["257"] = 160,["258"] = 160,["259"] = 160,["261"] = 156,["265"] = 164,["268"] = 165,["269"] = 166,["270"] = 167,["271"] = 167,["272"] = 167,["274"] = 168,["275"] = 168,["276"] = 168,["278"] = 165,["282"] = 172,["285"] = 173,["289"] = 176,["292"] = 177,["293"] = 177,["294"] = 177,["295"] = 177,["296"] = 177,["298"] = 177,["302"] = 180,["305"] = 181,["309"] = 184,["312"] = 185,["313"] = 186,["314"] = 187,["315"] = 188,["316"] = 189,["318"] = 191,["319"] = 191,["320"] = 191,["321"] = 191,["322"] = 191,["323"] = 191,["330"] = 198,["333"] = 199,["337"] = 202,["340"] = 203,["341"] = 203,["342"] = 203,["343"] = 203,["344"] = 203,["345"] = 203,["346"] = 203,["350"] = 206,["353"] = 207,["357"] = 210,["360"] = 211,["364"] = 214,["367"] = 215,["371"] = 218,["374"] = 219,["378"] = 222,["381"] = 223,["385"] = 226,["388"] = 227,["392"] = 230,["395"] = 231,["399"] = 234,["402"] = 235,["406"] = 238,["409"] = 239,["413"] = 242,["416"] = 243,["420"] = 246,["423"] = 247,["427"] = 250,["430"] = 251,["431"] = 251,["436"] = 254,["440"] = 265,["442"] = 266,["443"] = 267,["444"] = 268,["447"] = 270,["449"] = 271,["450"] = 272,["451"] = 272,["452"] = 272,["453"] = 272,["454"] = 273,["455"] = 274,["456"] = 272,["457"] = 272,["458"] = 272,["462"] = 279,["464"] = 280,["465"] = 281,["466"] = 281,["467"] = 281,["468"] = 281,["469"] = 282,["470"] = 281,["471"] = 281,["472"] = 281,["477"] = 287,["480"] = 81,["481"] = 292,["482"] = 293,["485"] = 296,["486"] = 297,["487"] = 298,["488"] = 299,["491"] = 302,["492"] = 303,["493"] = 303,["494"] = 303,["495"] = 303,["498"] = 306,["499"] = 307,["500"] = 308,["501"] = 308,["502"] = 308,["503"] = 308,["504"] = 308,["505"] = 308,["506"] = 308,["507"] = 308,["510"] = 315,["511"] = 316,["512"] = 317,["513"] = 317,["514"] = 317,["515"] = 317,["516"] = 317,["517"] = 317,["518"] = 317,["519"] = 317,["522"] = 292});
local ____exports = {}
local ____basic_pragma = require("solar.solar-common.w3ts.tsx.basic_pragma.index")
local render = ____basic_pragma.render
local ____CreateFrameUtil = require("solar.solar-common.w3ts.tsx.CreateFrameUtil")
local CreateFrameUtil = ____CreateFrameUtil.default
local ____FrameDefault = require("solar.solar-common.w3ts.tsx.FrameDefault")
local frameDefaults = ____FrameDefault.frameDefaults
local ____FramePropUtil = require("solar.solar-common.w3ts.tsx.FramePropUtil")
local FramePropUtil = ____FramePropUtil.default
local scale = 1600 * 1.25
local function smartSize(size)
    return size < 1 and size > -1 and size or size / scale
end
____exports.setPixelScale = function(newScale)
    scale = newScale * 1.25
end
____exports.tooltipMap = {}
local defaultSync = false
local function setEventProp(frame, event, val, oldValue, sync)
    if sync == nil then
        sync = false
    end
    if sync and isAsync then
        log.errorWithTraceBack("无法在异步中注册同步方法！请在同步方法中执行！")
        return
    end
    DzFrameSetScriptByCode(frame, event, val, sync)
end
local function absurd(value)
    error(
        ("Got " .. tostring(value)) .. " when expected nothing",
        0
    )
end
local function previousToParentPoint(relative)
    repeat
        local ____switch8 = relative
        local ____cond8 = ____switch8 == FRAMEPOINT_RIGHT
        if ____cond8 then
            return FRAMEPOINT_LEFT
        end
        ____cond8 = ____cond8 or ____switch8 == FRAMEPOINT_BOTTOM
        if ____cond8 then
            return FRAMEPOINT_TOP
        end
        ____cond8 = ____cond8 or ____switch8 == FRAMEPOINT_BOTTOMLEFT
        if ____cond8 then
            return FRAMEPOINT_TOPLEFT
        end
        ____cond8 = ____cond8 or ____switch8 == FRAMEPOINT_BOTTOMRIGHT
        if ____cond8 then
            return FRAMEPOINT_TOPRIGHT
        end
    until true
end
____exports.default = __TS__Class()
local AdapterUtil = ____exports.default
AdapterUtil.name = "AdapterUtil"
function AdapterUtil.prototype.____constructor(self)
end
function AdapterUtil.resolveRelative(frame, relative, relativePoint)
    if not relative then
        if frame ~= 0 then
            local parent = DzFrameGetParent(frame)
            if parent and parent > 0 then
                return parent
            end
        end
        return DzGetGameUI()
    end
    if type(relative) ~= "string" then
        return relative
    end
    repeat
        local ____switch15 = relative
        local ____cond15 = ____switch15 == "parent"
        if ____cond15 then
            return DzFrameGetParent(frame)
        end
        do
            log.error("relative 错误=" .. tostring(relative))
        end
    until true
end
function AdapterUtil.setProp(frame, prop, value, oldValue)
    local ____value_0 = value
    if ____value_0 == nil then
        ____value_0 = frameDefaults[prop]
    end
    local val = ____value_0
    local _oldValue = oldValue
    repeat
        local ____switch17 = prop
        local backdropFrame
        local ____cond17 = ____switch17 == "text"
        if ____cond17 then
            do
                DzFrameSetText(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "maxLength"
        if ____cond17 then
            do
                DzFrameSetTextSizeLimit(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "textColor"
        if ____cond17 then
            do
                DzFrameSetTextColor(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "texture"
        if ____cond17 then
            do
                local val2 = type(val) == "string" and ({texFile = val}) or val
                local ____DzFrameSetTexture_4 = DzFrameSetTexture
                local ____frame_3 = frame
                local ____val2_texFile_1 = val2.texFile
                if ____val2_texFile_1 == nil then
                    ____val2_texFile_1 = frameDefaults.texture.texFile
                end
                local ____val2_flag_2 = val2.flag
                if ____val2_flag_2 == nil then
                    ____val2_flag_2 = frameDefaults.texture.flag
                end
                ____DzFrameSetTexture_4(____frame_3, ____val2_texFile_1, ____val2_flag_2)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "model"
        if ____cond17 then
            do
                local ____DzFrameSetModel_8 = DzFrameSetModel
                local ____frame_7 = frame
                local ____val_modelFile_5 = val.modelFile
                if ____val_modelFile_5 == nil then
                    ____val_modelFile_5 = frameDefaults.model.modelFile
                end
                local ____val_cameraIndex_6 = val.cameraIndex
                if ____val_cameraIndex_6 == nil then
                    ____val_cameraIndex_6 = frameDefaults.model.cameraIndex
                end
                ____DzFrameSetModel_8(____frame_7, ____val_modelFile_5, ____val_cameraIndex_6, 1)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "alpha"
        if ____cond17 then
            do
                DzFrameSetAlpha(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "visible"
        if ____cond17 then
            do
                DzFrameShow(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "enabled"
        if ____cond17 then
            do
                DzFrameSetEnable(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "vertexColor"
        if ____cond17 then
            do
                DzFrameSetVertexColor(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "value"
        if ____cond17 then
            do
                DzFrameSetValue(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "size"
        if ____cond17 then
            do
                local ____DzFrameSetSize_13 = DzFrameSetSize
                local ____frame_11 = frame
                local ____val_width_9 = val.width
                if ____val_width_9 == nil then
                    ____val_width_9 = frameDefaults.size.width
                end
                local ____smartSize_result_12 = smartSize(____val_width_9)
                local ____val_height_10 = val.height
                if ____val_height_10 == nil then
                    ____val_height_10 = frameDefaults.size.height
                end
                ____DzFrameSetSize_13(
                    ____frame_11,
                    ____smartSize_result_12,
                    smartSize(____val_height_10)
                )
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "stepSize"
        if ____cond17 then
            do
                DzFrameSetStepValue(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "tooltip"
        if ____cond17 then
            do
                local existingTooltip = ____exports.tooltipMap["FT_" .. tostring(frame)]
                local tooltip
                if existingTooltip then
                    tooltip = existingTooltip
                else
                    tooltip = CreateFrameUtil.createFrame(
                        "container",
                        DzGetGameUI(),
                        {name = "Tooltip"}
                    )
                    ____exports.tooltipMap["FT_" .. tostring(frame)] = tooltip
                    DzFrameSetTooltip(frame, tooltip)
                end
                render(val, tooltip)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "frametip"
        if ____cond17 then
            FramePropUtil:setProp_frametip(frame, prop, value)
            break
        end
        ____cond17 = ____cond17 or ____switch17 == "font"
        if ____cond17 then
            do
                local ____DzFrameSetFont_18 = DzFrameSetFont
                local ____frame_17 = frame
                local ____val_fileName_14 = val.fileName
                if ____val_fileName_14 == nil then
                    ____val_fileName_14 = frameDefaults.font.fileName
                end
                local ____val_height_15 = val.height
                if ____val_height_15 == nil then
                    ____val_height_15 = frameDefaults.font.height
                end
                local ____val_flags_16 = val.flags
                if ____val_flags_16 == nil then
                    ____val_flags_16 = frameDefaults.font.flags
                end
                ____DzFrameSetFont_18(____frame_17, ____val_fileName_14, ____val_height_15, ____val_flags_16)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "minMaxValue"
        if ____cond17 then
            do
                local ____DzFrameSetMinMaxValue_22 = DzFrameSetMinMaxValue
                local ____frame_21 = frame
                local ____val_min_19 = val.min
                if ____val_min_19 == nil then
                    ____val_min_19 = frameDefaults.minMaxValue.min
                end
                local ____val_max_20 = val.max
                if ____val_max_20 == nil then
                    ____val_max_20 = frameDefaults.minMaxValue.max
                end
                ____DzFrameSetMinMaxValue_22(____frame_21, ____val_min_19, ____val_max_20)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "scale"
        if ____cond17 then
            do
                DzFrameSetScale(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "textAlignment"
        if ____cond17 then
            do
                local ____DzFrameSetTextAlignment_25 = DzFrameSetTextAlignment
                local ____frame_24 = frame
                local ____val_23 = val
                if ____val_23 == nil then
                    ____val_23 = frameDefaults.textAlignment
                end
                ____DzFrameSetTextAlignment_25(____frame_24, ____val_23)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "position"
        if ____cond17 then
            do
                ____exports.default.setProp_position(frame, val)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "absPosition"
        if ____cond17 then
            do
                if val ~= nil then
                    local positions = (val == "clear" or val.point ~= nil) and ({val}) or val
                    for ____, absPosition in ipairs(positions) do
                        if absPosition == "clear" then
                            DzFrameClearAllPoints(frame)
                        else
                            DzFrameSetAbsolutePoint(
                                frame,
                                absPosition.point,
                                smartSize(absPosition.x or 0),
                                smartSize(absPosition.y or 0)
                            )
                        end
                    end
                end
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onClick"
        if ____cond17 then
            do
                setEventProp(frame, 1, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onClickSync"
        if ____cond17 then
            do
                setEventProp(
                    frame,
                    1,
                    val,
                    _oldValue,
                    true
                )
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onMouseEnter"
        if ____cond17 then
            do
                setEventProp(frame, 2, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onMouseLeave"
        if ____cond17 then
            do
                setEventProp(frame, 3, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onMouseUp"
        if ____cond17 then
            do
                setEventProp(frame, 4, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onMouseDown"
        if ____cond17 then
            do
                setEventProp(frame, 5, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onMouseWheel"
        if ____cond17 then
            do
                setEventProp(frame, 6, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onCheckboxChecked"
        if ____cond17 then
            do
                setEventProp(frame, 7, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onCheckboxUnchecked"
        if ____cond17 then
            do
                setEventProp(frame, 8, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onEditboxTextChanged"
        if ____cond17 then
            do
                setEventProp(frame, 9, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onPopupmenuItemChanged"
        if ____cond17 then
            do
                setEventProp(frame, 11, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onDoubleClick"
        if ____cond17 then
            do
                setEventProp(frame, 12, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "onSpriteAnimUpdate"
        if ____cond17 then
            do
                setEventProp(frame, 13, val, _oldValue)
                break
            end
        end
        ____cond17 = ____cond17 or ____switch17 == "ref"
        if ____cond17 then
            do
                if val then
                    val.current = frame
                end
                break
            end
        end
        ____cond17 = ____cond17 or (____switch17 == "id" or ____switch17 == "name" or ____switch17 == "priority" or ____switch17 == "isSimple" or ____switch17 == "typeName" or ____switch17 == "inherits" or ____switch17 == "children" or ____switch17 == "context" or ____switch17 == "key")
        if ____cond17 then
            break
        end
        ____cond17 = ____cond17 or ____switch17 == "background-image"
        if ____cond17 then
            backdropFrame = CreateFrameUtil.createFrame("backdrop", frame, {})
            DzFrameSetTexture(backdropFrame, val, 0)
            DzFrameSetAllPoints(backdropFrame, frame)
            break
        end
        ____cond17 = ____cond17 or ____switch17 == "hideParentOnClick"
        if ____cond17 then
            if val then
                DzFrameSetScriptByCode(
                    frame,
                    1,
                    function()
                        local parent = DzFrameGetParent(frame)
                        DzFrameShow(parent, false)
                    end,
                    defaultSync
                )
            end
            break
        end
        ____cond17 = ____cond17 or ____switch17 == "showRefOnClick"
        if ____cond17 then
            if val and val.current then
                DzFrameSetScriptByCode(
                    frame,
                    1,
                    function()
                        DzFrameShow(val.current, true)
                    end,
                    defaultSync
                )
            end
            break
        end
        do
            absurd(prop)
        end
    until true
end
function AdapterUtil.setProp_position(frame, val)
    if val == nil then
        return
    end
    local positions = (val == "parent" or val == "clear" or val.x ~= nil) and ({val}) or val
    for ____, position in ipairs(positions) do
        if position == "clear" then
            DzFrameClearAllPoints(frame)
            return
        end
        if position == "parent" then
            DzFrameSetAllPoints(
                frame,
                DzFrameGetParent(frame)
            )
            return
        end
        local relative = ____exports.default.resolveRelative(frame, position.relative, position.relativePoint)
        if relative then
            DzFrameSetPoint(
                frame,
                position.point or 6,
                relative or DzFrameGetParent(frame),
                position.relativePoint or 6,
                smartSize(position.x or 0),
                smartSize(position.y or 0)
            )
            return
        end
        local parentRelative = previousToParentPoint(position.relativePoint)
        if parentRelative then
            DzFrameSetPoint(
                frame,
                position.point,
                DzFrameGetParent(frame),
                parentRelative,
                smartSize(position.x or 0),
                smartSize(position.y or 0)
            )
        end
    end
end
return ____exports
