local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 1,["6"] = 1,["7"] = 1,["8"] = 1,["9"] = 1,["10"] = 1,["11"] = 1,["12"] = 1,["13"] = 1,["14"] = 1,["15"] = 1,["16"] = 1,["17"] = 1,["18"] = 1,["19"] = 1,["20"] = 1,["21"] = 1,["22"] = 1,["23"] = 1,["24"] = 37});
local ____exports = {}
local TargetAttach = TargetAttach or ({})
TargetAttach.overhead = "overhead"
TargetAttach.head = "head"
TargetAttach.chest = "chest"
TargetAttach.origin = "origin"
TargetAttach.hand = "hand"
TargetAttach.foot = "foot"
TargetAttach.weapon = "weapon"
TargetAttach.sprite = "sprite"
TargetAttach.medium = "medium"
TargetAttach.large = "large"
TargetAttach.mount = "mount"
TargetAttach.rear = "rear"
TargetAttach.left = "left"
TargetAttach.right = "right"
TargetAttach.hand_left = "hand left"
TargetAttach.hand_right = "hand right"
TargetAttach.foot_left = "foot left"
TargetAttach.foot_right = "foot right"
____exports.default = TargetAttach
return ____exports
