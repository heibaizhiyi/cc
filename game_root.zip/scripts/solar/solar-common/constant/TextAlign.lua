local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 1,["6"] = 1,["7"] = 1,["8"] = 1,["9"] = 1,["10"] = 1,["11"] = 1,["12"] = 1,["13"] = 1,["14"] = 1,["15"] = 1,["16"] = 1,["17"] = 1,["18"] = 1,["19"] = 1,["20"] = 1,["21"] = 1,["22"] = 1,["23"] = 1,["24"] = 16});
local ____exports = {}
local TextAlign = TextAlign or ({})
TextAlign.topLeft = 11
TextAlign[TextAlign.topLeft] = "topLeft"
TextAlign.top = 17
TextAlign[TextAlign.top] = "top"
TextAlign.topRight = 37
TextAlign[TextAlign.topRight] = "topRight"
TextAlign.center = 18
TextAlign[TextAlign.center] = "center"
TextAlign.left = 10
TextAlign[TextAlign.left] = "left"
TextAlign.right = 34
TextAlign[TextAlign.right] = "right"
TextAlign.bottomLeft = 12
TextAlign[TextAlign.bottomLeft] = "bottomLeft"
TextAlign.bottom = 20
TextAlign[TextAlign.bottom] = "bottom"
TextAlign.bottomRight = 36
TextAlign[TextAlign.bottomRight] = "bottomRight"
____exports.default = TextAlign
return ____exports
