local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 5,["15"] = 5,["16"] = 6,["17"] = 6,["18"] = 7,["19"] = 7,["20"] = 8,["21"] = 8,["37"] = 29,["38"] = 30,["39"] = 31,["40"] = 32,["41"] = 32,["42"] = 32,["44"] = 36,["45"] = 37,["48"] = 40,["49"] = 41,["50"] = 42,["51"] = 43,["52"] = 44,["53"] = 35,["54"] = 52,["55"] = 54,["56"] = 55,["57"] = 56,["58"] = 57,["59"] = 57,["60"] = 57,["61"] = 57,["62"] = 57,["63"] = 57,["64"] = 57,["65"] = 57,["66"] = 57,["67"] = 57,["68"] = 55,["69"] = 52,["70"] = 63,["71"] = 65,["72"] = 66,["73"] = 67,["76"] = 70,["77"] = 70,["78"] = 70,["79"] = 70,["80"] = 70,["81"] = 72,["83"] = 72,["84"] = 72,["86"] = 72,["87"] = 73,["89"] = 76,["90"] = 77,["91"] = 78,["93"] = 66,["94"] = 82,["95"] = 83,["96"] = 84,["99"] = 87,["100"] = 87,["101"] = 87,["102"] = 87,["103"] = 87,["104"] = 89,["106"] = 89,["107"] = 89,["109"] = 89,["110"] = 90,["112"] = 83,["113"] = 94,["114"] = 95,["115"] = 96,["118"] = 99,["119"] = 99,["120"] = 99,["121"] = 99,["122"] = 99,["123"] = 101,["125"] = 101,["126"] = 101,["128"] = 101,["129"] = 102,["131"] = 105,["132"] = 106,["134"] = 95,["135"] = 111,["136"] = 112,["137"] = 113,["138"] = 114,["140"] = 116,["141"] = 116,["142"] = 117,["143"] = 118,["145"] = 120,["146"] = 112,["147"] = 122,["148"] = 123,["149"] = 124,["150"] = 125,["152"] = 127,["153"] = 127,["154"] = 128,["155"] = 129,["157"] = 131,["158"] = 123,["159"] = 133,["160"] = 134,["161"] = 135,["162"] = 136,["164"] = 138,["165"] = 138,["166"] = 139,["167"] = 140,["169"] = 142,["170"] = 134,["171"] = 63,["172"] = 150,["173"] = 152,["174"] = 154,["176"] = 156,["177"] = 157,["178"] = 158,["181"] = 162,["182"] = 163,["183"] = 163,["184"] = 163,["185"] = 163,["186"] = 163,["187"] = 164,["188"] = 166,["190"] = 166,["191"] = 166,["193"] = 166,["194"] = 167,["195"] = 168,["196"] = 169,["198"] = 171,["200"] = 173,["201"] = 174,["202"] = 174,["203"] = 174,["204"] = 174,["205"] = 174,["206"] = 175,["207"] = 179,["208"] = 180,["209"] = 181,["211"] = 183,["213"] = 183,["214"] = 183,["216"] = 183,["217"] = 184,["219"] = 186,["220"] = 187,["221"] = 188,["223"] = 190,["224"] = 192,["225"] = 192,["226"] = 192,["227"] = 192,["228"] = 192,["229"] = 193,["231"] = 195,["233"] = 197,["234"] = 198,["235"] = 199,["237"] = 201,["238"] = 202,["239"] = 202,["240"] = 202,["241"] = 202,["242"] = 202,["243"] = 203,["245"] = 205,["247"] = 207,["248"] = 208,["249"] = 208,["250"] = 209,["251"] = 210,["252"] = 211,["254"] = 213,["256"] = 215,["257"] = 216,["258"] = 216,["259"] = 217,["260"] = 218,["261"] = 219,["263"] = 221,["266"] = 224,["268"] = 157,["269"] = 228,["270"] = 229,["271"] = 230,["272"] = 231,["274"] = 234,["275"] = 235,["276"] = 235,["277"] = 236,["278"] = 237,["279"] = 238,["281"] = 240,["282"] = 241,["283"] = 242,["284"] = 242,["285"] = 243,["286"] = 244,["287"] = 245,["289"] = 247,["290"] = 249,["291"] = 252,["292"] = 252,["293"] = 253,["294"] = 254,["295"] = 255,["297"] = 258,["298"] = 259,["299"] = 260,["300"] = 260,["301"] = 261,["302"] = 262,["303"] = 263,["305"] = 266,["306"] = 267,["307"] = 275,["312"] = 275,["313"] = 276,["314"] = 277,["315"] = 278,["317"] = 280,["318"] = 281,["319"] = 283,["320"] = 284,["322"] = 286,["325"] = 289,["326"] = 290,["329"] = 293,["330"] = 294,["331"] = 295,["332"] = 296,["333"] = 298,["334"] = 298,["335"] = 300,["336"] = 301,["337"] = 303,["338"] = 304,["339"] = 308,["340"] = 310,["341"] = 311,["345"] = 316,["346"] = 318,["347"] = 320,["348"] = 321,["350"] = 325,["351"] = 326,["352"] = 327,["353"] = 327,["354"] = 328,["355"] = 329,["356"] = 330,["357"] = 331,["358"] = 332,["359"] = 333,["360"] = 334,["363"] = 337,["364"] = 338,["365"] = 339,["366"] = 340,["367"] = 341,["369"] = 343,["371"] = 345,["372"] = 229,["373"] = 150,["374"] = 353,["375"] = 355,["376"] = 356,["377"] = 357,["380"] = 361,["381"] = 362,["382"] = 364,["383"] = 365,["384"] = 365,["385"] = 365,["386"] = 365,["387"] = 366,["389"] = 366,["390"] = 366,["392"] = 366,["393"] = 367,["394"] = 368,["396"] = 370,["397"] = 371,["398"] = 371,["399"] = 371,["400"] = 371,["401"] = 372,["403"] = 372,["404"] = 372,["406"] = 372,["407"] = 373,["408"] = 374,["411"] = 356,["412"] = 380,["413"] = 381,["414"] = 382,["415"] = 383,["417"] = 386,["418"] = 387,["419"] = 387,["420"] = 389,["421"] = 390,["422"] = 390,["424"] = 393,["425"] = 381,["426"] = 396,["427"] = 397,["428"] = 398,["429"] = 398,["430"] = 398,["432"] = 399,["433"] = 399,["434"] = 400,["435"] = 401,["436"] = 403,["437"] = 404,["438"] = 405,["439"] = 406,["440"] = 407,["442"] = 409,["443"] = 410,["444"] = 412,["447"] = 416,["448"] = 417,["449"] = 418,["450"] = 419,["452"] = 421,["453"] = 422,["454"] = 424,["458"] = 399,["461"] = 398,["462"] = 398,["463"] = 353,["464"] = 436,["465"] = 436,["466"] = 436,["468"] = 437,["469"] = 438,["470"] = 439,["471"] = 440,["472"] = 441,["473"] = 442,["474"] = 443,["476"] = 445,["477"] = 436});
local ____exports = {}
local ____AttributeUtil = require("solar.solar-common.util.system.AttributeUtil")
local AttributeUtil = ____AttributeUtil.default
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____HeroUtil = require("solar.solar-common.util.unit.HeroUtil")
local HeroUtil = ____HeroUtil.default
local ____NativeFrameUtil = require("solar.solar-common.util.frame.NativeFrameUtil")
local NativeFrameUtil = ____NativeFrameUtil.default
local ____TextUtil = require("solar.solar-common.util.text.TextUtil")
local TextUtil = ____TextUtil.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____MathUtil = require("solar.solar-common.util.math.MathUtil")
local MathUtil = ____MathUtil.default
--- PS: 此类使用局限性很大。 对魔兽不熟悉的作者请不要使用此类制作大数值，以免被无穷的各种问题折磨。
-- 
-- 模拟属性(支持大数值 注意部分魔兽原生实数数值的上限为340涧 但是lua层的数字可以达到 1e+308 如果不进魔兽层的计算可以超大数值计算)
-- 
-- 此状态下各种属性均使用自定义变量存储。所有修改属性的 均使用代码来修改 通过原生物品属性书 或等级升级奖励的属性值将不可用
-- 
-- 通过自定义实数number类型 存储数值
-- 
-- 在魔兽原本的设置属性和获取属性  走自定义属性值
-- 
-- 如果超过上限 则底层设置到限制值 属性值走自定义变量存储  显示时需自行需自行用UI显示这些大值
-- 
-- 注意：在大数值模式下一些方法计算并不严谨和准确 如果对数值扣的很细很准 请不要做大数值！
-- （在大属性模式下 不能斤斤计较）
-- link solar_attribute.d.ts ArmorReducesDamageFactor
local CJ = require("jass.common")
local BaseAttributeMax = 10000000
local BaseRealMax = 8e+37
____exports.default = __TS__Class()
local BigAttributeCompatibleState = ____exports.default
BigAttributeCompatibleState.name = "BigAttributeCompatibleState"
function BigAttributeCompatibleState.prototype.____constructor(self)
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new BigAttributeCompatibleState()")
        return
    end
    isBigAttributeMode = true
    self:playerAttributeCompatible()
    self:unitAttributeCompatible()
    self:heroAttributeCompatible()
    self:damageCompatible()
end
function BigAttributeCompatibleState.prototype.damageCompatible(self)
    local oldUnitDamageTarget = UnitDamageTarget
    _G.UnitDamageTarget = function(whichUnit, target, amount, attack, ranged, attackType, damageType, weaponType)
        gv._sl_lastDamage = amount
        return oldUnitDamageTarget(
            whichUnit,
            target,
            amount,
            attack,
            ranged,
            attackType,
            damageType,
            weaponType
        )
    end
end
function BigAttributeCompatibleState.prototype.heroAttributeCompatible(self)
    local oldSetHeroStr = SetHeroStr
    _G.SetHeroStr = function(whichHero, newStr, permanent)
        if not IsHandle(whichHero) then
            return
        end
        oldSetHeroStr(
            whichHero,
            MathUtil.clamp(newStr, -BaseAttributeMax, BaseAttributeMax),
            permanent
        )
        local ____temp_2 = newStr >= BaseAttributeMax
        if not ____temp_2 then
            local ____opt_0 = AttributeUtil:getUnitAttribute(whichHero, false)
            ____temp_2 = ____opt_0 and ____opt_0._SL_BA_str
        end
        if ____temp_2 then
            AttributeUtil:getUnitAttribute(whichHero, true)._SL_BA_str = newStr
        end
        if StrHpBonus > 0 and newStr > BaseAttributeMax then
            local addHp = (newStr - BaseAttributeMax) * StrHpBonus
            UnitUtil.setExtraHp(whichHero, addHp, "_SL_SetHeroStr")
        end
    end
    local oldSetHeroAgi = SetHeroAgi
    _G.SetHeroAgi = function(whichHero, newAgi, permanent)
        if not IsHandle(whichHero) then
            return
        end
        oldSetHeroAgi(
            whichHero,
            MathUtil.clamp(newAgi, -BaseAttributeMax, BaseAttributeMax),
            permanent
        )
        local ____temp_5 = newAgi >= BaseAttributeMax
        if not ____temp_5 then
            local ____opt_3 = AttributeUtil:getUnitAttribute(whichHero, false)
            ____temp_5 = ____opt_3 and ____opt_3._SL_BA_agi
        end
        if ____temp_5 then
            AttributeUtil:getUnitAttribute(whichHero, true)._SL_BA_agi = newAgi
        end
    end
    local oldSetHeroInt = SetHeroInt
    _G.SetHeroInt = function(whichHero, newInt, permanent)
        if not IsHandle(whichHero) then
            return
        end
        oldSetHeroInt(
            whichHero,
            MathUtil.clamp(newInt, -BaseAttributeMax, BaseAttributeMax),
            permanent
        )
        local ____temp_8 = newInt >= BaseAttributeMax
        if not ____temp_8 then
            local ____opt_6 = AttributeUtil:getUnitAttribute(whichHero, false)
            ____temp_8 = ____opt_6 and ____opt_6._SL_BA_int
        end
        if ____temp_8 then
            AttributeUtil:getUnitAttribute(whichHero, true)._SL_BA_int = newInt
        end
        if IntManaBonus > 0 and newInt > BaseAttributeMax then
            UnitUtil.setExtraMana(whichHero, (newInt - BaseAttributeMax) * IntManaBonus, "_SL_SetHeroInt")
        end
    end
    local oldGetHeroStr = GetHeroStr
    _G.GetHeroStr = function(whichHero, includeBonuses)
        if not IsHandle(whichHero) then
            return 0
        end
        local ____opt_9 = AttributeUtil:getUnitAttribute(whichHero)
        local val = ____opt_9 and ____opt_9._SL_BA_str or oldGetHeroStr(whichHero, false)
        if includeBonuses then
            val = val + UnitUtil.getExtraStr(whichHero)
        end
        return val
    end
    local oldGetHeroAgi = GetHeroAgi
    _G.GetHeroAgi = function(whichHero, includeBonuses)
        if not IsHandle(whichHero) then
            return 0
        end
        local ____opt_11 = AttributeUtil:getUnitAttribute(whichHero)
        local val = ____opt_11 and ____opt_11._SL_BA_agi or oldGetHeroAgi(whichHero, false)
        if includeBonuses then
            val = val + UnitUtil.getExtraAgi(whichHero)
        end
        return val
    end
    local oldGetHeroInt = GetHeroInt
    _G.GetHeroInt = function(whichHero, includeBonuses)
        if not IsHandle(whichHero) then
            return 0
        end
        local ____opt_13 = AttributeUtil:getUnitAttribute(whichHero)
        local val = ____opt_13 and ____opt_13._SL_BA_int or oldGetHeroInt(whichHero, false)
        if includeBonuses then
            val = val + UnitUtil.getExtraInt(whichHero)
        end
        return val
    end
end
function BigAttributeCompatibleState.prototype.unitAttributeCompatible(self)
    if PrimaryAttackBonus > 14 then
        log.errorWithTraceBack("PrimaryAttackBonus 不能超过14!")
    end
    local oldSetUnitState = SetUnitState
    _G.SetUnitState = function(whichUnit, whichUnitState, newVal)
        if not IsHandle(whichUnit) then
            return
        end
        if whichUnitState == UnitStateDamageBase then
            oldSetUnitState(
                whichUnit,
                whichUnitState,
                MathUtil.clamp(newVal, -2000000000, 2000000000)
            )
            local realBaseDamage = newVal
            local ____temp_17 = realBaseDamage >= 2000000000
            if not ____temp_17 then
                local ____opt_15 = AttributeUtil:getUnitAttribute(whichUnit, false)
                ____temp_17 = ____opt_15 and ____opt_15._SL_BA_damage_base
            end
            if ____temp_17 then
                if HeroUtil:isHero(whichUnit) then
                    local pab = HeroUtil:getHeroPrimaryValue(whichUnit, true) * PrimaryAttackBonus
                    realBaseDamage = newVal - pab
                end
                AttributeUtil:getUnitAttribute(whichUnit, true)._SL_BA_damage_base = realBaseDamage
            end
        elseif whichUnitState == UnitStateArmor then
            oldSetUnitState(
                whichUnit,
                whichUnitState,
                MathUtil.clamp(newVal, -BaseAttributeMax, BaseAttributeMax)
            )
            local realBaseArmor = newVal - UnitUtil.getExtraDef(whichUnit)
            if HeroUtil:isHero(whichUnit) then
                local greenArmor = GetHeroAgi(whichUnit, true) * AgiDefenseBonus
                realBaseArmor = realBaseArmor - greenArmor
            end
            local ____temp_20 = realBaseArmor >= BaseAttributeMax
            if not ____temp_20 then
                local ____opt_18 = AttributeUtil:getUnitAttribute(whichUnit, false)
                ____temp_20 = ____opt_18 and ____opt_18._SL_BA_armor
            end
            if ____temp_20 then
                AttributeUtil:getUnitAttribute(whichUnit, true)._SL_BA_armor = realBaseArmor
            end
        elseif whichUnitState == UNIT_STATE_MAX_LIFE then
            if isDebug and newVal < 0 then
                log.errorWithTraceBack("不能对单位设置负数最大生命值!")
            end
            if newVal >= BaseRealMax then
                oldSetUnitState(
                    whichUnit,
                    whichUnitState,
                    MathUtil.min(BaseRealMax, newVal)
                )
                AttributeUtil:getUnitAttribute(whichUnit, true)._SL_BA_max_life = newVal
            else
                oldSetUnitState(whichUnit, whichUnitState, newVal)
            end
        elseif whichUnitState == UNIT_STATE_MAX_MANA then
            if isDebug and newVal < 0 then
                log.errorWithTraceBack("不能对单位设置负数最大魔法值值!")
            end
            if newVal >= BaseRealMax then
                oldSetUnitState(
                    whichUnit,
                    whichUnitState,
                    MathUtil.min(BaseRealMax, newVal)
                )
                AttributeUtil:getUnitAttribute(whichUnit, true)._SL_BA_max_mana = newVal
            else
                oldSetUnitState(whichUnit, whichUnitState, newVal)
            end
        elseif whichUnitState == UNIT_STATE_LIFE then
            local ____opt_21 = AttributeUtil:getUnitAttribute(whichUnit, false)
            local _SL_BA_max_life = ____opt_21 and ____opt_21._SL_BA_max_life
            if _SL_BA_max_life and _SL_BA_max_life >= BaseRealMax then
                local moNiLife = newVal / _SL_BA_max_life * BaseRealMax
                oldSetUnitState(whichUnit, whichUnitState, moNiLife)
            else
                oldSetUnitState(whichUnit, whichUnitState, newVal)
            end
        elseif whichUnitState == UNIT_STATE_MANA then
            local ____opt_23 = AttributeUtil:getUnitAttribute(whichUnit, false)
            local _SL_BA_max_mana = ____opt_23 and ____opt_23._SL_BA_max_mana
            if _SL_BA_max_mana and _SL_BA_max_mana >= BaseRealMax then
                local moNiMana = newVal / _SL_BA_max_mana * BaseRealMax
                oldSetUnitState(whichUnit, whichUnitState, moNiMana)
            else
                oldSetUnitState(whichUnit, whichUnitState, newVal)
            end
        else
            oldSetUnitState(whichUnit, whichUnitState, newVal)
        end
    end
    local oldGetUnitState = GetUnitState
    _G.GetUnitState = function(whichUnit, whichUnitState)
        if not IsHandle(whichUnit) then
            return 0
        end
        if whichUnitState == UNIT_STATE_MAX_LIFE then
            local ____opt_25 = AttributeUtil:getUnitAttribute(whichUnit)
            local val = ____opt_25 and ____opt_25._SL_BA_max_life
            if val == nil then
                local ba = oldGetUnitState(whichUnit, whichUnitState)
                return ba
            end
            return val
        elseif whichUnitState == UNIT_STATE_MAX_MANA then
            local ____opt_27 = AttributeUtil:getUnitAttribute(whichUnit)
            local val = ____opt_27 and ____opt_27._SL_BA_max_mana
            if val == nil then
                local ba = oldGetUnitState(whichUnit, whichUnitState)
                return ba
            end
            return val
        elseif whichUnitState == UNIT_STATE_LIFE then
            local ____opt_29 = AttributeUtil:getUnitAttribute(whichUnit, false)
            local _SL_BA_max_life = ____opt_29 and ____opt_29._SL_BA_max_life
            if _SL_BA_max_life == nil or _SL_BA_max_life < BaseRealMax then
                local ba = oldGetUnitState(whichUnit, whichUnitState)
                return ba
            end
            return oldGetUnitState(whichUnit, whichUnitState) / BaseRealMax * _SL_BA_max_life
        elseif whichUnitState == UNIT_STATE_MANA then
            local ____opt_31 = AttributeUtil:getUnitAttribute(whichUnit, false)
            local _SL_BA_max_mana = ____opt_31 and ____opt_31._SL_BA_max_mana
            if _SL_BA_max_mana == nil or _SL_BA_max_mana < BaseRealMax then
                local ba = oldGetUnitState(whichUnit, whichUnitState)
                return ba
            end
            return oldGetUnitState(whichUnit, whichUnitState) / BaseRealMax * _SL_BA_max_mana
        elseif whichUnitState == UnitStateDamageBase then
            local ____opt_33 = AttributeUtil:getUnitAttribute(whichUnit)
            --- 基础伤害
            -- 基础攻击力 = 物编里定义的 dmgplus1
            -- 白字攻击 =   基础攻击力+白字主属性奖励的攻击
            -- unitstate UnitStateDamageBase获取的攻击 = 基础攻击力+白字主属性奖励的攻击+绿字主属性奖励的攻击
            local dmgplus = ____opt_33 and ____opt_33._SL_BA_damage_base
            if HeroUtil:isHero(whichUnit) then
                if dmgplus == nil then
                    dmgplus = oldGetUnitState(whichUnit, whichUnitState) - ____exports.default:getHeroPrimaryValueByBaseCJ(whichUnit, true) * PrimaryAttackBonus
                end
                local primaryValue = HeroUtil:getHeroPrimaryValue(whichUnit, true)
                local val = dmgplus + primaryValue * PrimaryAttackBonus
                if val > 0 and val < 2100000000 then
                    return oldGetUnitState(whichUnit, whichUnitState)
                else
                    return val
                end
            else
                if dmgplus == nil then
                    return oldGetUnitState(whichUnit, whichUnitState)
                end
            end
            return dmgplus
        elseif whichUnitState == UnitStateDamageBonus then
            return UnitUtil.getExtraAttack(whichUnit)
        elseif whichUnitState == UnitStateArmor then
            local ____opt_35 = AttributeUtil:getUnitAttribute(whichUnit)
            local val = ____opt_35 and ____opt_35._SL_BA_armor
            if val == nil then
                val = oldGetUnitState(whichUnit, whichUnitState)
                if UnitStateUtil:isAlive(whichUnit) then
                    val = val - UnitUtil.getExtraDef(whichUnit)
                    if HeroUtil:isHero(whichUnit) then
                        local greenArmor = CJ.GetHeroAgi(whichUnit, true) * AgiDefenseBonus
                        val = val - greenArmor
                    end
                end
            end
            val = val + UnitUtil.getExtraDef(whichUnit)
            if HeroUtil:isHero(whichUnit) and AgiDefenseBonus > 0 then
                local primaryAndBonusValue = GetHeroAgi(whichUnit, true)
                val = val + primaryAndBonusValue * AgiDefenseBonus
            end
            return val
        elseif whichUnitState == UnitStateDamageMix or whichUnitState == UnitStateDamageMax then
            local ____opt_37 = AttributeUtil:getUnitAttribute(whichUnit)
            local dmgplus = ____opt_37 and ____opt_37._SL_BA_damage_base
            local isHero = HeroUtil:isHero(whichUnit)
            if dmgplus == nil then
                dmgplus = oldGetUnitState(whichUnit, UnitStateDamageBase)
                if isHero then
                    local primaryAndBonusValue = ____exports.default:getHeroPrimaryValueByBaseCJ(whichUnit, true)
                    local zsyAB = primaryAndBonusValue * PrimaryAttackBonus
                    dmgplus = dmgplus - zsyAB
                end
            end
            local extVal = UnitUtil.getExtraAttack(whichUnit)
            local dmgMax = dmgplus + extVal
            if isHero then
                local primaryAndBonusValue = HeroUtil:getHeroPrimaryValue(whichUnit, true)
                dmgMax = dmgMax + primaryAndBonusValue * PrimaryAttackBonus
            end
            return dmgMax
        end
        return oldGetUnitState(whichUnit, whichUnitState)
    end
end
function BigAttributeCompatibleState.prototype.playerAttributeCompatible(self)
    local oldSetPlayerState = SetPlayerState
    _G.SetPlayerState = function(whichPlayer, whichPlayerState, value)
        if not IsHandle(whichPlayer) then
            return
        end
        local temp = math.min(value, 1000000)
        oldSetPlayerState(whichPlayer, whichPlayerState, temp)
        if whichPlayerState == PLAYER_STATE_RESOURCE_GOLD then
            DzFrameSetText(
                NativeFrameUtil:getGoldText(),
                TextUtil:toCnUnit(value)
            )
            local ____temp_41 = value > 1000000
            if not ____temp_41 then
                local ____opt_39 = AttributeUtil:getPlayerAttribute(whichPlayer, false)
                ____temp_41 = ____opt_39 and ____opt_39._SL_BA_gold
            end
            if ____temp_41 then
                AttributeUtil:getPlayerAttribute(whichPlayer, true)._SL_BA_gold = value
                AttributeUtil:getPlayerAttribute(whichPlayer, true)._SL_BA_gold_temp = temp
            end
        elseif whichPlayerState == PLAYER_STATE_RESOURCE_LUMBER then
            DzFrameSetText(
                NativeFrameUtil:getLumberText(),
                TextUtil:toCnUnit(value)
            )
            local ____temp_44 = value > 1000000
            if not ____temp_44 then
                local ____opt_42 = AttributeUtil:getPlayerAttribute(whichPlayer, false)
                ____temp_44 = ____opt_42 and ____opt_42._SL_BA_lumber
            end
            if ____temp_44 then
                AttributeUtil:getPlayerAttribute(whichPlayer, true)._SL_BA_lumber = value
                AttributeUtil:getPlayerAttribute(whichPlayer, true)._SL_BA_lumber_temp = temp
            end
        end
    end
    local oldGetPlayerState = GetPlayerState
    _G.GetPlayerState = function(whichPlayer, whichPlayerState)
        if not IsHandle(whichPlayer) then
            return 0
        end
        if whichPlayerState == PLAYER_STATE_RESOURCE_GOLD then
            local ____opt_45 = AttributeUtil:getPlayerAttribute(whichPlayer)
            return ____opt_45 and ____opt_45._SL_BA_gold or oldGetPlayerState(whichPlayer, whichPlayerState)
        elseif whichPlayerState == PLAYER_STATE_RESOURCE_LUMBER then
            local ____opt_47 = AttributeUtil:getPlayerAttribute(whichPlayer)
            return ____opt_47 and ____opt_47._SL_BA_lumber or oldGetPlayerState(whichPlayer, whichPlayerState)
        end
        return oldGetPlayerState(whichPlayer, whichPlayerState)
    end
    local updateTrigger = CreateTrigger()
    TriggerRegisterTimerEvent(updateTrigger, 1, true)
    TriggerAddAction(
        updateTrigger,
        function()
            do
                local i = 0
                while i < bj_MAX_PLAYER_SLOTS do
                    local player = Player(i)
                    if GetPlayerController(player) == MAP_CONTROL_USER and GetPlayerSlotState(player) == PLAYER_SLOT_STATE_PLAYING then
                        local playerAttribute = AttributeUtil:getPlayerAttribute(player, true)
                        local nowTempGold = oldGetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD)
                        if playerAttribute._SL_BA_gold then
                            if not playerAttribute._SL_BA_gold_temp then
                                playerAttribute._SL_BA_gold_temp = nowTempGold
                            else
                                local add = nowTempGold - playerAttribute._SL_BA_gold_temp
                                playerAttribute._SL_BA_gold = playerAttribute._SL_BA_gold + add
                                SetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD, playerAttribute._SL_BA_gold)
                            end
                        end
                        local nowTempLumber = oldGetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER)
                        if playerAttribute._SL_BA_lumber then
                            if not playerAttribute._SL_BA_lumber_temp then
                                playerAttribute._SL_BA_lumber_temp = nowTempLumber
                            else
                                local addL = nowTempLumber - playerAttribute._SL_BA_lumber_temp
                                playerAttribute._SL_BA_lumber = playerAttribute._SL_BA_lumber + addL
                                SetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER, playerAttribute._SL_BA_lumber)
                            end
                        end
                    end
                    i = i + 1
                end
            end
        end
    )
end
function BigAttributeCompatibleState.getHeroPrimaryValueByBaseCJ(self, handle, includeBonuses)
    if includeBonuses == nil then
        includeBonuses = true
    end
    local Primary = HeroUtil:getHeroPrimary(handle)
    if Primary == "STR" then
        return CJ.GetHeroStr(handle, includeBonuses)
    elseif Primary == "AGI" then
        return CJ.GetHeroAgi(handle, includeBonuses)
    elseif Primary == "INT" then
        return CJ.GetHeroInt(handle, includeBonuses)
    end
    return 0
end
return ____exports
