local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ArrayPushArray = ____lualib.__TS__ArrayPushArray
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 7,["21"] = 7,["22"] = 27,["23"] = 27,["24"] = 27,["26"] = 48,["27"] = 49,["28"] = 50,["31"] = 53,["32"] = 54,["33"] = 53,["34"] = 56,["35"] = 57,["36"] = 58,["37"] = 58,["38"] = 58,["39"] = 59,["40"] = 58,["41"] = 58,["42"] = 56,["43"] = 63,["44"] = 63,["45"] = 63,["46"] = 65,["47"] = 66,["48"] = 67,["50"] = 63,["51"] = 63,["52"] = 71,["53"] = 72,["54"] = 73,["56"] = 71,["57"] = 47,["58"] = 35,["59"] = 36,["60"] = 36,["61"] = 38,["62"] = 39,["64"] = 35,["65"] = 78,["66"] = 80,["67"] = 81,["68"] = 83,["69"] = 84,["70"] = 84,["71"] = 85,["75"] = 89,["76"] = 90,["77"] = 91,["79"] = 93,["80"] = 94,["82"] = 97,["83"] = 98,["84"] = 101,["85"] = 103,["86"] = 105,["87"] = 106,["88"] = 107,["89"] = 108,["90"] = 109,["95"] = 115,["96"] = 78,["97"] = 28,["98"] = 29});
local ____exports = {}
local ____ActorUtil = require("solar.solar-common.actor.util.ActorUtil")
local ActorUtil = ____ActorUtil.default
local ____ItemAttributeState = require("solar.solar-common.attribute.ItemAttributeState")
local ItemAttributeState = ____ItemAttributeState.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____GameCenter = require("solar.solar-common.common.GameCenter")
local GameCenter = ____GameCenter.default
local ____ActorBuffUtil = require("solar.solar-common.actor.util.ActorBuffUtil")
local ActorBuffUtil = ____ActorBuffUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
____exports.default = __TS__Class()
local UniqueAttributeState = ____exports.default
UniqueAttributeState.name = "UniqueAttributeState"
function UniqueAttributeState.prototype.____constructor(self)
    ____exports.default._sl_isStart = true
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new UniqueAttributeState()")
        return
    end
    se:onUnitPickupItem(function(e)
        ____exports.default:updateMaxAttribute(e.trigUnit)
    end)
    se:onUnitDropItem(function(e)
        local unit = e.trigUnit
        BaseUtil.runLater(
            0.01,
            function()
                ____exports.default:updateMaxAttribute(unit)
            end
        )
    end)
    se:on(
        "属性刷新",
        function()
            local allUnits = GameCenter:getAllUnits()
            for ____, unitHandle in ipairs(allUnits) do
                ____exports.default:updateMaxAttribute(unitHandle)
            end
        end
    )
    ActorBuffUtil:addAnyActorBuffCreatedListener(function(____, buff)
        if buff.attribute then
            ____exports.default:updateMaxAttribute(buff.unit)
        end
    end)
end
function UniqueAttributeState.registerUniqueAttribute(self, uniqueAttributeInfo)
    local ____exports_default_uniqueAttributeInfos_0 = ____exports.default.uniqueAttributeInfos
    ____exports_default_uniqueAttributeInfos_0[#____exports_default_uniqueAttributeInfos_0 + 1] = uniqueAttributeInfo
    if not ____exports.default._sl_isStart then
        __TS__New(____exports.default)
    end
end
function UniqueAttributeState.updateMaxAttribute(self, unit)
    local itemAttributes = ItemAttributeState:getItemsAttributes(unit)
    local actorAttributes = ActorUtil:getUnitAllActorAttributes(unit)
    if itemAttributes == nil and actorAttributes == nil then
        local ____opt_1 = DataBase:getUnitSolarData(unit, false)
        if ____opt_1 and ____opt_1.maxUniqueAttributes then
            DataBase:getUnitSolarData(unit, true).maxUniqueAttributes = {}
        end
        return
    end
    local attributeList = {}
    if itemAttributes then
        __TS__ArrayPushArray(attributeList, itemAttributes)
    end
    if actorAttributes then
        __TS__ArrayPushArray(attributeList, actorAttributes)
    end
    local maxUniqueAttributes = {}
    local _sl_maxUniqueAttributeWeights = {}
    for ____, attribute in ipairs(attributeList) do
        for ____, uniqueAttributeInfo in ipairs(____exports.default.uniqueAttributeInfos) do
            if attribute[uniqueAttributeInfo.key] then
                local weight = uniqueAttributeInfo:weightAlgorithm(attribute)
                if weight > (_sl_maxUniqueAttributeWeights[uniqueAttributeInfo.key] or 0) then
                    _sl_maxUniqueAttributeWeights[uniqueAttributeInfo.key] = weight
                    maxUniqueAttributes[uniqueAttributeInfo.key] = attribute
                end
            end
        end
    end
    DataBase:getUnitSolarData(unit, true).maxUniqueAttributes = maxUniqueAttributes
end
UniqueAttributeState.uniqueAttributeInfos = {}
UniqueAttributeState._sl_isStart = false
return ____exports
