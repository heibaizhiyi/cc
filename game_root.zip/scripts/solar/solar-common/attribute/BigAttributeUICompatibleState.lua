local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 5,["16"] = 5,["17"] = 6,["18"] = 6,["19"] = 7,["20"] = 7,["21"] = 8,["22"] = 8,["23"] = 9,["24"] = 9,["25"] = 10,["26"] = 10,["27"] = 11,["28"] = 11,["29"] = 12,["30"] = 12,["31"] = 13,["32"] = 13,["33"] = 14,["34"] = 14,["35"] = 17,["36"] = 18,["37"] = 18,["38"] = 18,["40"] = 50,["41"] = 51,["44"] = 54,["45"] = 54,["46"] = 54,["47"] = 55,["48"] = 56,["49"] = 58,["50"] = 59,["51"] = 60,["52"] = 54,["53"] = 54,["54"] = 49,["55"] = 65,["56"] = 66,["57"] = 66,["58"] = 66,["59"] = 66,["60"] = 66,["61"] = 66,["62"] = 66,["63"] = 67,["64"] = 67,["65"] = 67,["66"] = 67,["67"] = 67,["68"] = 67,["69"] = 67,["70"] = 70,["71"] = 71,["72"] = 72,["75"] = 75,["76"] = 76,["78"] = 78,["80"] = 82,["81"] = 83,["82"] = 84,["83"] = 85,["84"] = 86,["85"] = 87,["86"] = 88,["87"] = 89,["89"] = 91,["91"] = 93,["92"] = 95,["93"] = 96,["94"] = 97,["95"] = 98,["96"] = 99,["97"] = 100,["99"] = 103,["100"] = 104,["101"] = 105,["102"] = 107,["103"] = 108,["105"] = 110,["106"] = 111,["107"] = 112,["109"] = 114,["110"] = 115,["112"] = 117,["113"] = 118,["114"] = 119,["115"] = 120,["116"] = 121,["118"] = 123,["120"] = 125,["121"] = 125,["122"] = 125,["123"] = 125,["125"] = 129,["126"] = 130,["127"] = 131,["128"] = 132,["129"] = 135,["130"] = 136,["131"] = 137,["133"] = 139,["134"] = 140,["135"] = 142,["137"] = 145,["139"] = 147,["140"] = 148,["141"] = 149,["142"] = 150,["143"] = 151,["146"] = 154,["147"] = 155,["149"] = 157,["150"] = 159,["151"] = 160,["152"] = 161,["153"] = 162,["154"] = 163,["156"] = 165,["157"] = 167,["158"] = 168,["159"] = 169,["160"] = 170,["161"] = 171,["163"] = 174,["164"] = 176,["165"] = 177,["166"] = 178,["167"] = 179,["168"] = 180,["170"] = 182,["171"] = 65,["172"] = 189,["173"] = 200,["174"] = 201,["175"] = 202,["176"] = 204,["177"] = 209,["178"] = 210,["179"] = 211,["180"] = 213,["181"] = 214,["182"] = 215,["183"] = 217,["184"] = 219,["185"] = 220,["186"] = 222,["187"] = 224,["188"] = 225,["189"] = 227,["190"] = 228,["191"] = 229,["192"] = 229,["193"] = 229,["194"] = 229,["195"] = 229,["196"] = 229,["197"] = 229,["198"] = 229,["199"] = 232,["200"] = 234,["201"] = 234,["202"] = 234,["203"] = 234,["204"] = 234,["205"] = 234,["206"] = 234,["207"] = 234,["208"] = 236,["209"] = 238,["210"] = 239,["211"] = 239,["212"] = 239,["213"] = 239,["214"] = 239,["215"] = 239,["216"] = 239,["217"] = 239,["218"] = 241,["219"] = 246,["220"] = 247,["221"] = 248,["222"] = 249,["223"] = 251,["224"] = 252,["225"] = 253,["226"] = 254,["227"] = 256,["228"] = 257,["229"] = 258,["230"] = 260,["231"] = 261,["232"] = 262,["233"] = 189,["234"] = 271,["235"] = 275,["236"] = 276,["237"] = 277,["238"] = 277,["239"] = 277,["240"] = 277,["241"] = 277,["242"] = 277,["243"] = 277,["244"] = 277,["246"] = 279,["247"] = 280,["248"] = 281,["249"] = 281,["250"] = 281,["251"] = 281,["252"] = 281,["253"] = 281,["254"] = 281,["255"] = 281,["257"] = 289,["258"] = 290,["259"] = 290,["260"] = 290,["261"] = 290,["262"] = 290,["263"] = 290,["264"] = 290,["265"] = 290,["266"] = 292,["267"] = 293,["268"] = 293,["269"] = 293,["270"] = 293,["271"] = 293,["272"] = 293,["273"] = 293,["274"] = 293,["275"] = 295,["276"] = 296,["277"] = 296,["278"] = 296,["279"] = 296,["280"] = 296,["281"] = 296,["282"] = 296,["283"] = 296,["284"] = 299,["285"] = 299,["286"] = 299,["287"] = 299,["288"] = 299,["289"] = 299,["290"] = 299,["291"] = 300,["292"] = 301,["293"] = 301,["294"] = 301,["295"] = 301,["296"] = 301,["297"] = 301,["298"] = 301,["299"] = 301,["300"] = 302,["301"] = 303,["302"] = 304,["303"] = 305,["305"] = 307,["306"] = 308,["307"] = 309,["309"] = 311,["310"] = 312,["311"] = 302,["312"] = 316,["313"] = 317,["314"] = 316,["315"] = 321,["316"] = 322,["317"] = 322,["318"] = 322,["319"] = 322,["320"] = 322,["321"] = 322,["322"] = 322,["323"] = 322,["324"] = 325,["325"] = 326,["326"] = 326,["327"] = 326,["328"] = 326,["329"] = 326,["330"] = 326,["331"] = 326,["332"] = 326,["333"] = 328,["334"] = 329,["335"] = 329,["336"] = 329,["337"] = 329,["338"] = 329,["339"] = 329,["340"] = 329,["341"] = 329,["342"] = 331,["343"] = 332,["344"] = 332,["345"] = 332,["346"] = 332,["347"] = 332,["348"] = 332,["349"] = 332,["350"] = 332,["351"] = 334,["352"] = 335,["353"] = 335,["354"] = 335,["355"] = 335,["356"] = 335,["357"] = 335,["358"] = 337,["359"] = 338,["360"] = 338,["361"] = 338,["362"] = 338,["363"] = 338,["364"] = 338,["365"] = 340,["366"] = 341,["367"] = 341,["368"] = 341,["369"] = 341,["370"] = 341,["371"] = 341,["372"] = 343,["373"] = 344,["374"] = 344,["375"] = 344,["376"] = 344,["377"] = 344,["378"] = 344,["379"] = 271,["380"] = 347,["381"] = 347,["382"] = 347,["384"] = 348,["385"] = 349,["386"] = 350,["387"] = 351,["388"] = 352,["389"] = 353,["390"] = 354,["391"] = 347,["392"] = 360,["393"] = 361,["394"] = 363,["395"] = 364,["396"] = 365,["397"] = 366,["399"] = 368,["400"] = 369,["401"] = 371,["402"] = 372,["403"] = 373,["404"] = 374,["406"] = 376,["407"] = 377,["409"] = 379,["410"] = 382,["411"] = 383,["412"] = 384,["413"] = 385,["415"] = 387,["416"] = 388,["417"] = 389,["418"] = 360,["419"] = 19});
local ____exports = {}
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____NativeFrameUtil = require("solar.solar-common.util.frame.NativeFrameUtil")
local NativeFrameUtil = ____NativeFrameUtil.default
local ____TextUtil = require("solar.solar-common.util.text.TextUtil")
local TextUtil = ____TextUtil.default
local ____trigger = require("solar.solar-common.w3ts.handles.trigger")
local Trigger = ____trigger.Trigger
local ____ColorStr = require("solar.solar-common.constant.ColorStr")
local ColorStr = ____ColorStr.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____SelectUtil = require("solar.solar-common.util.unit.SelectUtil")
local SelectUtil = ____SelectUtil.default
local ____HeroUtil = require("solar.solar-common.util.unit.HeroUtil")
local HeroUtil = ____HeroUtil.default
local ____ExFrameApiUtil = require("solar.solar-common.util.frame.ExFrameApiUtil")
local ExFrameApiUtil = ____ExFrameApiUtil.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____ActorFrameUtil = require("solar.solar-common.actor.util.ActorFrameUtil")
local ActorFrameUtil = ____ActorFrameUtil.default
local textHeight = 0.01
____exports.default = __TS__Class()
local BigAttributeUICompatibleState = ____exports.default
BigAttributeUICompatibleState.name = "BigAttributeUICompatibleState"
function BigAttributeUICompatibleState.prototype.____constructor(self)
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new BigAttributeUICompatibleState()")
        return
    end
    BaseUtil.runLater(
        0.1,
        function()
            self:moveNativeFrame()
            self:createUI()
            local trigger = __TS__New(Trigger)
            trigger:registerTimerEvent(0.1, true)
            trigger:addAction(self.refreshSolarUI)
        end
    )
end
function BigAttributeUICompatibleState.prototype.refreshSolarUI()
    DzFrameSetText(
        ____exports.default.goldFrame,
        TextUtil:toCnUnit(GetPlayerState(
            GetLocalPlayer(),
            PLAYER_STATE_RESOURCE_GOLD
        ))
    )
    DzFrameSetText(
        ____exports.default.lumberFrame,
        TextUtil:toCnUnit(GetPlayerState(
            GetLocalPlayer(),
            PLAYER_STATE_RESOURCE_LUMBER
        ))
    )
    local unit = SelectUtil.getRealSelectUnit()
    if not IsHandle(unit) then
        ____exports.default:showSolarUI(false)
        return
    end
    if HeroUtil:isHero(unit) then
        ____exports.default:showSolarUI(true, true)
    else
        ____exports.default:showSolarUI(true, false)
    end
    local life = GetUnitState(unit, UNIT_STATE_LIFE)
    local maxLife = GetUnitState(unit, UNIT_STATE_MAX_LIFE)
    local bfbLife = R2I(life * 100 / maxLife)
    local hpText = ((TextUtil:toCnUnit(life) .. "/") .. TextUtil:toCnUnit(maxLife)) .. ("(" .. tostring(bfbLife)) .. ")%"
    if bfbLife > 80 then
        hpText = ColorStr.green .. hpText
    elseif bfbLife > 40 then
        hpText = ColorStr.yellow .. hpText
    else
        hpText = ColorStr.red .. hpText
    end
    DzFrameSetText(____exports.default.hpFrame, hpText)
    local mana = GetUnitState(unit, UNIT_STATE_MANA)
    local maxMana = GetUnitState(unit, UNIT_STATE_MAX_MANA)
    if maxMana and maxMana > 0 then
        local bfbMana = tostring(R2I(mana * 100 / maxMana)) .. "%"
        local manaText = ((TextUtil:toCnUnit(mana) .. " / ") .. TextUtil:toCnUnit(maxMana)) .. ("(" .. bfbMana) .. ")"
        DzFrameSetText(____exports.default.manaFrame, manaText)
    end
    local aAttack = GetUnitState(unit, UnitStateDamageMix)
    if ____exports.default.config.isShowGreenAttack then
        local lvAttack = GetUnitState(unit, UnitStateDamageBonus)
        if HeroUtil:isHero(unit) then
            lvAttack = lvAttack + HeroUtil:getHeroPrimaryBonusValue(unit) * PrimaryAttackBonus
        end
        local bAttack = aAttack - lvAttack
        if bAttack < 2100000000 and bAttack > -2100000000 then
            bAttack = math.floor(bAttack + 0.5)
        end
        if lvAttack < 2100000000 and lvAttack > -2100000000 then
            lvAttack = math.floor(lvAttack + 0.5)
        end
        local blText = TextUtil:toCnUnit(bAttack)
        if lvAttack > 0 then
            blText = (((blText .. "  ") .. ColorStr.green) .. "+") .. TextUtil:toCnUnit(lvAttack)
        elseif lvAttack < -20 then
            blText = ((blText .. "  ") .. ColorStr.red) .. TextUtil:toCnUnit(lvAttack)
        end
        DzFrameSetText(____exports.default.attackValueFrame, blText)
    else
        DzFrameSetText(
            ____exports.default.attackValueFrame,
            TextUtil:toCnUnit(aAttack)
        )
    end
    local armorText = nil
    if UnitStateUtil:isInvulnerable(unit) then
        armorText = "|cffff0000无敌的"
    elseif ____exports.default.config.isShowGreenArmor then
        local greenArmor = UnitUtil.getExtraDef(unit)
        if HeroUtil:isHero(unit) then
            greenArmor = greenArmor + (GetHeroAgi(unit, true) - GetHeroAgi(unit, false)) * AgiDefenseBonus
        end
        local baseDef = GetUnitState(unit, UnitStateArmor) - greenArmor
        if baseDef < 1000000 then
            armorText = TextUtil:toCnUnit(math.floor(baseDef + 0.5))
        else
            armorText = TextUtil:toCnUnit(baseDef)
        end
        local greenArmorText = TextUtil:toCnUnit(greenArmor > 1000000 and greenArmor or math.floor(greenArmor + 0.5))
        if greenArmor > 0 then
            armorText = (((tostring(armorText) .. "  ") .. ColorStr.green) .. "+") .. greenArmorText
        elseif greenArmor < 0 then
            armorText = ((tostring(armorText) .. "  ") .. ColorStr.red) .. greenArmorText
        end
    else
        local allDef = GetUnitState(unit, UnitStateArmor)
        armorText = TextUtil:toCnUnit(allDef > 1000000 and allDef or math.floor(allDef + 0.5))
    end
    DzFrameSetText(____exports.default.armorValueFrame, armorText)
    local bStr = GetHeroStr(unit, false)
    local blStr = GetHeroStr(unit, true)
    local strText = TextUtil:toCnUnit(bStr)
    if bStr ~= blStr then
        strText = (((strText .. "  ") .. ColorStr.green) .. "+") .. TextUtil:toCnUnit(blStr - bStr)
    end
    DzFrameSetText(____exports.default.heroStrValueFrame, strText)
    local bAgi = GetHeroAgi(unit, false)
    local blAgi = GetHeroAgi(unit, true)
    local agiText = TextUtil:toCnUnit(bAgi)
    if bAgi ~= blAgi then
        agiText = (((agiText .. "  ") .. ColorStr.green) .. "+") .. TextUtil:toCnUnit(blAgi - bAgi)
    end
    DzFrameSetText(____exports.default.heroAgiValueFrame, agiText)
    local bInt = GetHeroInt(unit, false)
    local blInt = GetHeroInt(unit, true)
    local intText = TextUtil:toCnUnit(bInt)
    if bInt ~= blInt then
        intText = (((intText .. "  ") .. ColorStr.green) .. "+") .. TextUtil:toCnUnit(blInt - bInt)
    end
    DzFrameSetText(____exports.default.heroIntValueFrame, intText)
end
function BigAttributeUICompatibleState.prototype.createUI(self)
    ____exports.default.unitUIContainer = ExFrameApiUtil:createBaseFrameInSimpleFrame(NativeFrameUtil:getUnitStatePanel())
    ____exports.default.unitArmorContainer = ExFrameApiUtil:createBaseFrameInSimpleFrame(DzSimpleFrameFindByName("SimpleInfoPanelIconArmor", 0))
    ____exports.default.heroUIContainer = ExFrameApiUtil:createBaseFrameInSimpleFrame(NativeFrameUtil:getHeroStatePanel())
    local textFont = settings.fontPath
    ____exports.default.goldFrame = __TS__New(Frame, "TEXT").current
    DzFrameSetAbsolutePoint(____exports.default.goldFrame, FRAMEPOINT_TOPRIGHT, 0.533, 0.595)
    DzFrameSetFont(____exports.default.goldFrame, textFont, textHeight, 0)
    ____exports.default.lumberFrame = __TS__New(Frame, "TEXT").current
    DzFrameSetAbsolutePoint(____exports.default.lumberFrame, FRAMEPOINT_TOPRIGHT, 0.621, 0.595)
    DzFrameSetFont(____exports.default.lumberFrame, textFont, textHeight, 0)
    ____exports.default.attackValueFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.unitUIContainer).current
    DzFrameSetAbsolutePoint(____exports.default.attackValueFrame, FRAMEPOINT_TOPLEFT, 0.35, 0.07)
    DzFrameSetFont(____exports.default.attackValueFrame, textFont, textHeight, 0)
    ____exports.default.armorValueFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.unitArmorContainer).current
    DzFrameSetAbsolutePoint(____exports.default.armorValueFrame, FRAMEPOINT_TOPLEFT, 0.35, 0.036)
    DzFrameSetFont(____exports.default.armorValueFrame, textFont, textHeight, 0)
    ____exports.default.heroStrValueFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.heroUIContainer).current
    DzFrameSetFont(____exports.default.heroStrValueFrame, textFont, textHeight, 0)
    DzFrameSetPoint(
        ____exports.default.heroStrValueFrame,
        FRAMEPOINT_TOPLEFT,
        NativeFrameUtil:getHeroStrLabel(),
        FRAMEPOINT_BOTTOMLEFT,
        0.005,
        0
    )
    ____exports.default.heroAgiValueFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.heroUIContainer).current
    DzFrameSetPoint(
        ____exports.default.heroAgiValueFrame,
        FRAMEPOINT_TOPLEFT,
        NativeFrameUtil:getHeroAgiLabel(),
        FRAMEPOINT_BOTTOMLEFT,
        0.005,
        0
    )
    DzFrameSetFont(____exports.default.heroAgiValueFrame, textFont, textHeight, 0)
    ____exports.default.heroIntValueFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.heroUIContainer).current
    DzFrameSetPoint(
        ____exports.default.heroIntValueFrame,
        FRAMEPOINT_TOPLEFT,
        NativeFrameUtil:getHeroIntLabel(),
        FRAMEPOINT_BOTTOMLEFT,
        0.005,
        0
    )
    DzFrameSetFont(____exports.default.heroIntValueFrame, textFont, textHeight, 0)
    ____exports.default.hpBackdropFrame = __TS__New(Frame, "BACKDROP", nil, ____exports.default.unitArmorContainer).current
    DzFrameSetTexture(____exports.default.hpBackdropFrame, "UI\\Glues\\SinglePlayer\\HumanCampaign3D\\Black32.blp", 0)
    DzFrameSetSize(____exports.default.hpBackdropFrame, 0.076, 0.012)
    DzFrameSetAbsolutePoint(____exports.default.hpBackdropFrame, FRAMEPOINT_CENTER, 0.254, 0.023)
    ____exports.default.manaBackdropFrame = __TS__New(Frame, "BACKDROP", nil, ____exports.default.unitArmorContainer).current
    DzFrameSetSize(____exports.default.manaBackdropFrame, 0.076, 0.012)
    DzFrameSetTexture(____exports.default.manaBackdropFrame, "UI\\Glues\\SinglePlayer\\HumanCampaign3D\\Black32.blp", 0)
    DzFrameSetAbsolutePoint(____exports.default.manaBackdropFrame, FRAMEPOINT_CENTER, 0.254, 0.009)
    ____exports.default.hpFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.unitArmorContainer).current
    DzFrameSetFont(____exports.default.hpFrame, textFont, textHeight, 0)
    DzFrameSetAbsolutePoint(____exports.default.hpFrame, FRAMEPOINT_CENTER, 0.254, 0.023)
    ____exports.default.manaFrame = __TS__New(Frame, "TEXT", nil, ____exports.default.unitArmorContainer).current
    DzFrameSetAbsolutePoint(____exports.default.manaFrame, FRAMEPOINT_CENTER, 0.254, 0.009)
    DzFrameSetFont(____exports.default.manaFrame, textFont, textHeight, 0)
end
function BigAttributeUICompatibleState.prototype.moveNativeFrame(self)
    if ____exports.default.config.removeAttackIcon then
        DzFrameClearAllPoints(NativeFrameUtil:getUnitAttackIcon(0))
        DzFrameSetPoint(
            NativeFrameUtil:getUnitAttackIcon(0),
            4,
            DzGetGameUI(),
            4,
            0,
            -0.5
        )
    end
    if ____exports.default.config.removeArmorIcon then
        DzFrameClearAllPoints(NativeFrameUtil:getUnitArmorIcon())
        DzFrameSetPoint(
            NativeFrameUtil:getUnitArmorIcon(),
            4,
            DzGetGameUI(),
            4,
            0,
            -0.5
        )
    end
    DzFrameClearAllPoints(NativeFrameUtil:getGoldText())
    DzFrameSetPoint(
        NativeFrameUtil:getGoldText(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getLumberText())
    DzFrameSetPoint(
        NativeFrameUtil:getLumberText(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getUnitAttackValue(0))
    DzFrameSetPoint(
        NativeFrameUtil:getUnitAttackValue(0),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    local button = __TS__New(
        Frame,
        "BUTTON",
        nil,
        ____exports.default.heroUIContainer,
        ""
    )
    button:setSize(0.062, 0.048)
    DzFrameSetPoint(
        button.handle,
        FramePoint.right,
        NativeFrameUtil:getHeroAgiLabel(),
        FramePoint.right,
        0,
        0
    )
    button:addOnMouseEnter(function()
        local hero = selection()
        if not IsHandle(hero) then
            return nil
        end
        local heroPrimary = HeroUtil:getHeroPrimary(hero)
        if heroPrimary == nil then
            return nil
        end
        local iconTip = ____exports.default:getPrimaryIconTip(hero, heroPrimary)
        ActorFrameUtil:showTooltipByInfo({describe = iconTip})
    end)
    button:addOnMouseLeave(function()
        ActorFrameUtil:hideTooltip()
    end)
    DzFrameClearAllPoints(NativeFrameUtil:getUnitArmorValue())
    DzFrameSetPoint(
        NativeFrameUtil:getUnitArmorValue(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getHeroStrValue())
    DzFrameSetPoint(
        NativeFrameUtil:getHeroStrValue(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getHeroAgiValue())
    DzFrameSetPoint(
        NativeFrameUtil:getHeroAgiValue(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getHeroIntValue())
    DzFrameSetPoint(
        NativeFrameUtil:getHeroIntValue(),
        4,
        DzGetGameUI(),
        4,
        0,
        -0.5
    )
    DzFrameClearAllPoints(NativeFrameUtil:getUnitAttackLabel(0))
    DzFrameSetAbsolutePoint(
        NativeFrameUtil:getUnitAttackLabel(0),
        FRAMEPOINT_TOPLEFT,
        0.34,
        0.08
    )
    DzFrameClearAllPoints(NativeFrameUtil:getUnitArmorLabel())
    DzFrameSetAbsolutePoint(
        NativeFrameUtil:getUnitArmorLabel(),
        FRAMEPOINT_TOPLEFT,
        0.34,
        0.048
    )
    DzFrameClearAllPoints(NativeFrameUtil:getHeroAgiLabel())
    DzFrameSetAbsolutePoint(
        NativeFrameUtil:getHeroAgiLabel(),
        FRAMEPOINT_TOPLEFT,
        0.44,
        0.06
    )
    DzFrameClearAllPoints(NativeFrameUtil:getHeroIntLabel())
    DzFrameSetAbsolutePoint(
        NativeFrameUtil:getHeroIntLabel(),
        FRAMEPOINT_TOPLEFT,
        0.44,
        0.04
    )
end
function BigAttributeUICompatibleState.showSolarUI(self, showAttackAndArmor, showHeroAtts)
    if showHeroAtts == nil then
        showHeroAtts = showAttackAndArmor
    end
    DzFrameShow(____exports.default.hpFrame, showAttackAndArmor)
    DzFrameShow(____exports.default.manaFrame, showAttackAndArmor)
    DzFrameShow(____exports.default.attackValueFrame, showAttackAndArmor)
    DzFrameShow(____exports.default.armorValueFrame, showAttackAndArmor)
    DzFrameShow(____exports.default.heroStrValueFrame, showHeroAtts)
    DzFrameShow(____exports.default.heroAgiValueFrame, showHeroAtts)
    DzFrameShow(____exports.default.heroIntValueFrame, showHeroAtts)
end
function BigAttributeUICompatibleState.getPrimaryIconTip(self, hero, heroPrimary)
    local tip = "属性说明:|r|n|n"
    tip = tip .. "力量:|r|n"
    if heroPrimary == "STR" then
        tip = tip .. " -|cffFFFF00主属性|r|n"
        tip = tip .. (" -每点增加" .. tostring(math.floor(PrimaryAttackBonus + 0.5))) .. "的攻击力|r|n"
    end
    tip = tip .. (" -每点增加" .. tostring(math.floor(StrHpBonus + 0.5))) .. "的生命值|r|n"
    tip = tip .. " -每点增加生命值恢复速度|r|n"
    tip = tip .. "敏捷:|r|n"
    if heroPrimary == "AGI" then
        tip = tip .. " -|cffFFFF00主属性|r|n"
        tip = tip .. (" -每点增加" .. tostring(math.floor(PrimaryAttackBonus + 0.5))) .. "的攻击力|r|n"
    end
    if AgiDefenseBonus ~= 0 then
        tip = tip .. (" -每" .. tostring(math.floor(1 / AgiDefenseBonus + 0.5))) .. "点增加一点的护甲|r|n"
    end
    tip = tip .. " -每点增加攻击速度|r|n"
    tip = tip .. "智力:|r|n"
    if heroPrimary == "INT" then
        tip = tip .. " -|cffFFFF00主属性|r|n"
        tip = tip .. (" -每点增加" .. tostring(math.floor(PrimaryAttackBonus + 0.5))) .. "的攻击力|r|n"
    end
    tip = tip .. (" -每点增加" .. tostring(math.floor(IntManaBonus + 0.5))) .. "的魔法值|r|n"
    tip = tip .. " -每点增加魔法恢复速度|r|n"
    return tip
end
BigAttributeUICompatibleState.config = {isShowGreenAttack = true, isShowGreenArmor = true, removeAttackIcon = false, removeArmorIcon = false}
return ____exports
