local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 11,["21"] = 11,["22"] = 11,["23"] = 11,["24"] = 26,["25"] = 11,["26"] = 29,["29"] = 32,["30"] = 33,["31"] = 34,["34"] = 38,["35"] = 39,["36"] = 40,["37"] = 41,["38"] = 41,["39"] = 41,["40"] = 41,["41"] = 42,["43"] = 44,["45"] = 47,["46"] = 48,["47"] = 50,["48"] = 51,["49"] = 26,["50"] = 55,["51"] = 11,["52"] = 57,["53"] = 58,["57"] = 61,["58"] = 62,["60"] = 63,["63"] = 65,["65"] = 66,["68"] = 68,["70"] = 69,["73"] = 71,["75"] = 72,["76"] = 73,["78"] = 75,["79"] = 75,["80"] = 76,["81"] = 77,["86"] = 81,["88"] = 82,["91"] = 84,["93"] = 87,["94"] = 88,["95"] = 89,["96"] = 90,["97"] = 91,["98"] = 91,["99"] = 91,["100"] = 91,["104"] = 94,["106"] = 95,["107"] = 95,["108"] = 95,["109"] = 95,["110"] = 95,["113"] = 97,["115"] = 98,["116"] = 98,["117"] = 98,["118"] = 98,["119"] = 98,["120"] = 98,["123"] = 100,["125"] = 101,["128"] = 103,["130"] = 104,["133"] = 106,["135"] = 107,["136"] = 108,["137"] = 109,["139"] = 111,["143"] = 114,["145"] = 115,["148"] = 117,["150"] = 118,["151"] = 119,["154"] = 121,["156"] = 122,["159"] = 124,["161"] = 125,["165"] = 55,["166"] = 130,["167"] = 11,["168"] = 130,["169"] = 141,["170"] = 142,["171"] = 141,["172"] = 146,["173"] = 147,["174"] = 146,["175"] = 151,["176"] = 11,["177"] = 153,["178"] = 151,["179"] = 160,["180"] = 161,["181"] = 162,["184"] = 165,["185"] = 166,["186"] = 167,["187"] = 160,["188"] = 171,["189"] = 172,["190"] = 173,["191"] = 174,["194"] = 177,["195"] = 178,["196"] = 178,["197"] = 178,["198"] = 178,["199"] = 178,["200"] = 179,["201"] = 180,["202"] = 181,["204"] = 183,["205"] = 171,["206"] = 186,["207"] = 187,["208"] = 189,["209"] = 191,["210"] = 192,["211"] = 192,["212"] = 193,["213"] = 194,["217"] = 186,["218"] = 204,["219"] = 205,["220"] = 206,["222"] = 208,["223"] = 204,["224"] = 214,["225"] = 215,["226"] = 214,["227"] = 222,["228"] = 223,["229"] = 222,["230"] = 230,["231"] = 231,["232"] = 231,["233"] = 231,["234"] = 231,["235"] = 231,["236"] = 230,["237"] = 238,["238"] = 239,["239"] = 239,["240"] = 239,["241"] = 239,["242"] = 238,["243"] = 246,["244"] = 247,["245"] = 246,["246"] = 251,["247"] = 252,["250"] = 11,["251"] = 256,["252"] = 257,["255"] = 260,["256"] = 262,["257"] = 263,["258"] = 263,["259"] = 263,["260"] = 264,["261"] = 265,["262"] = 265,["263"] = 265,["264"] = 265,["266"] = 267,["267"] = 268,["268"] = 268,["269"] = 268,["270"] = 268,["272"] = 270,["273"] = 263,["274"] = 263,["276"] = 251,["277"] = 275,["278"] = 276,["281"] = 11,["282"] = 275,["283"] = 283,["284"] = 284,["285"] = 11,["286"] = 286,["287"] = 283,["288"] = 13,["293"] = 138});
local ____exports = {}
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
local ____ObjectTemplateUtil = require("solar.solar-common.util.object.ObjectTemplateUtil")
local ObjectTemplateUtil = ____ObjectTemplateUtil.default
local ____AbilityUtil = require("solar.solar-common.util.ability.AbilityUtil")
local AbilityUtil = ____AbilityUtil.default
local ____AbilityButtonUtil = require("solar.solar-common.util.ability.AbilityButtonUtil")
local AbilityButtonUtil = ____AbilityButtonUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
____exports.default = __TS__Class()
local ActorAbility = ____exports.default
ActorAbility.name = "ActorAbility"
__TS__ClassExtends(ActorAbility, Actor)
function ActorAbility.prototype.____constructor(self, actorTypeId, unit, startPosNum)
    Actor.prototype.____constructor(self, actorTypeId)
    if self._actorType == nil then
        return
    end
    ____exports.default.allActorAbilitys[self.uuid] = self
    self.startPosNum = startPosNum
    if unit == nil then
        return
    end
    if startPosNum ~= nil then
        self.posNum = ObjectTemplateUtil:getUnitAbilityTemplateNextNumber(unit, startPosNum)
    elseif self:get("y") ~= nil then
        local basePos = AbilityButtonUtil:getNumberByPos(
            self:get("x", 0),
            self:get("y")
        )
        self.posNum = ObjectTemplateUtil:getUnitAbilityTemplateNextNumber(unit, basePos)
    else
        self.posNum = ObjectTemplateUtil:getUnitAbilityTemplateNextNumber(unit, 1)
    end
    self.unit = unit
    self:addUnitAbilityTemplate(self.posNum)
    self:_sl_init()
    self:update()
end
function ActorAbility.prototype._sl_rawset(self, key, value)
    Actor.prototype._sl_rawset(self, key, value)
    local ability = self:getAbility()
    if ability == nil then
        return
    end
    repeat
        local ____switch10 = key
        local ____cond10 = ____switch10 == "id"
        if ____cond10 then
            EXSetAbilityDataString(ability, 1, ABILITY_DATA_NAME, self.uuid)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "name"
        if ____cond10 then
            EXSetAbilityDataString(ability, 1, ABILITY_DATA_TIP, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "icon"
        if ____cond10 then
            EXSetAbilityDataString(ability, 1, ABILITY_DATA_ART, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "disable"
        if ____cond10 then
            if self:get("disable") then
                self:getRootFrameControl():getDisableFrame().visible = true
            else
                local ____opt_0 = self:getRootFrameControl(false)
                local disableFrame = ____opt_0 and ____opt_0:getDisableFrame(false)
                if disableFrame then
                    disableFrame.visible = false
                end
            end
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "describe"
        if ____cond10 then
            EXSetAbilityDataString(ability, 1, ABILITY_DATA_UBERTIP, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "passive"
        if ____cond10 then
            if value == true then
                EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
                EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 0)
            elseif self:get("targetType") ~= nil then
                AbilityUtil:setTargetType(
                    ability,
                    self:get("targetType")
                )
            end
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "hide"
        if ____cond10 then
            SetPlayerAbilityAvailable(
                GetOwningPlayer(self.unit),
                self.abilityId,
                not value
            )
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "hotKey"
        if ____cond10 then
            EXSetAbilityDataInteger(
                ability,
                1,
                ABILITY_DATA_HOTKET,
                char2number(value) or 0
            )
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "range"
        if ____cond10 then
            EXSetAbilityDataReal(ability, 1, 107, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "area"
        if ____cond10 then
            EXSetAbilityDataReal(ability, 1, 106, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "targetType"
        if ____cond10 then
            if self:isPassive() then
                EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
                EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 0)
            else
                AbilityUtil:setTargetType(ability, value)
            end
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "targetAllow"
        if ____cond10 then
            AbilityUtil:setTargetAllow(ability, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "dur"
        if ____cond10 then
            EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_DUR, value)
            EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_HERODUR, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "manaCost"
        if ____cond10 then
            EXSetAbilityDataInteger(ability, 1, 104, value)
            break
        end
        ____cond10 = ____cond10 or ____switch10 == "maxCd"
        if ____cond10 then
            EXSetAbilityDataReal(ability, 1, ABILITY_DATA_COOL, value)
            break
        end
    until true
end
function ActorAbility.prototype.get(self, key, defaultValue)
    return Actor.prototype.get(self, key, defaultValue)
end
function ActorAbility.prototype.setPassive(self, passive)
    self:set("passive", passive)
end
function ActorAbility.prototype.isPassive(self)
    return self:get("passive", false)
end
function ActorAbility.prototype.setXY(self, x, y)
    Actor.prototype.setXY(self, x, y)
    self:setAbilityPos(AbilityButtonUtil:getNumberByPos(x, y))
end
function ActorAbility.prototype.setAbilityPos(self, pos)
    local ability = self:getAbility()
    if ability == nil then
        return
    end
    self:removeUnitAbilityTemplate()
    self:addUnitAbilityTemplate(pos)
    self:update()
end
function ActorAbility.prototype.addUnitAbilityTemplate(self, pos)
    self.abilityId = ObjectTemplateUtil:addUnitAbilityTemplate(self.unit, pos, self.templateCacheKey, self.uuid)
    if self.abilityId == nil then
        log.errorWithTraceBack("获取技能模版id为null。可能当前位置已有技能了!pos=" .. tostring(pos))
        return
    end
    self.templateId = self.abilityId
    SetPlayerAbilityAvailable(
        GetOwningPlayer(self.unit),
        self.abilityId,
        true
    )
    local unitSolarData = DataBase:getUnitSolarData(self.unit, true)
    if unitSolarData._SL_solarActorAbilitys == nil then
        unitSolarData._SL_solarActorAbilitys = {}
    end
    unitSolarData._SL_solarActorAbilitys[self.templateId] = self
end
function ActorAbility.prototype.removeUnitAbilityTemplate(self)
    if self.abilityId ~= nil then
        if self.unit ~= nil then
            ObjectTemplateUtil:removeUnitAbilityTemplate(self.unit, self.abilityId, self.templateCacheKey, self.uuid)
            local ____opt_2 = DataBase:getUnitSolarData(self.unit, false)
            local solarActorAbilitys = ____opt_2 and ____opt_2._SL_solarActorAbilitys
            if solarActorAbilitys and solarActorAbilitys[self.abilityId] then
                solarActorAbilitys[self.abilityId] = nil
            end
        end
    end
end
function ActorAbility.prototype.getAbility(self)
    if self.abilityId ~= nil and self.unit ~= nil then
        return EXGetUnitAbility(self.unit, self.abilityId)
    end
    return nil
end
function ActorAbility.prototype.getMaxCd(self)
    return self:get("maxCd", 0)
end
function ActorAbility.prototype.setMaxCd(self, maxCd)
    self:set("maxCd", maxCd)
end
function ActorAbility.prototype.setCooldown(self, cd)
    EXSetAbilityState(
        self:getAbility(),
        1,
        cd
    )
end
function ActorAbility.prototype.getCooldown(self)
    return EXGetAbilityState(
        self:getAbility(),
        1
    )
end
function ActorAbility.prototype.setHotKey(self, hotKey)
    self:set("hotKey", hotKey)
end
function ActorAbility.prototype.update(self)
    if self._sl_isDestroyed then
        return
    end
    Actor.prototype.update(self)
    local ability = self:getAbility()
    if ability == nil then
        return
    end
    AbilityUtil:refreshAbility(self.unit, self.abilityId)
    if self:get("targetAllow") or self:get("targetType") then
        BaseUtil.runLater(
            0.01,
            function()
                if self:get("targetType") then
                    self:_sl_rawset(
                        "targetType",
                        self:get("targetType")
                    )
                end
                if self:get("targetAllow") then
                    self:_sl_rawset(
                        "targetAllow",
                        self:get("targetAllow")
                    )
                end
                AbilityUtil:refreshAbility(self.unit, self.abilityId)
            end
        )
    end
end
function ActorAbility.prototype.action(self, x, y, targetUnit)
    if self:isPassive() then
        return
    end
    Actor.prototype.action(self, x, y, targetUnit)
end
function ActorAbility.prototype.destroy(self)
    self:removeUnitAbilityTemplate()
    Actor.prototype.destroy(self)
    deleteKey(____exports.default.allActorAbilitys, self.uuid)
end
ActorAbility.allActorAbilitys = {}
__TS__SetDescriptor(
    ActorAbility.prototype,
    "actorType",
    {get = function(self)
        return self._actorType
    end},
    true
)
return ____exports
