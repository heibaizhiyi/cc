local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__InstanceOf = ____lualib.__TS__InstanceOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 8,["21"] = 8,["22"] = 8,["24"] = 8,["25"] = 22,["26"] = 22,["27"] = 22,["29"] = 22,["30"] = 22,["32"] = 23,["33"] = 24,["34"] = 25,["35"] = 26,["36"] = 27,["37"] = 26,["39"] = 30,["40"] = 30,["41"] = 30,["42"] = 30,["43"] = 30,["44"] = 30,["45"] = 30,["46"] = 30,["47"] = 30,["48"] = 30,["50"] = 32,["51"] = 32,["52"] = 32,["53"] = 32,["54"] = 32,["55"] = 32,["56"] = 32,["57"] = 32,["58"] = 34,["60"] = 22,["61"] = 49,["62"] = 49,["63"] = 49,["65"] = 49,["66"] = 49,["68"] = 50,["70"] = 51,["71"] = 51,["72"] = 52,["73"] = 52,["74"] = 52,["75"] = 52,["76"] = 52,["77"] = 52,["78"] = 52,["79"] = 53,["80"] = 54,["81"] = 54,["83"] = 51,["86"] = 56,["87"] = 49,["88"] = 66,["89"] = 67,["90"] = 67,["91"] = 68,["94"] = 71,["97"] = 74,["98"] = 66,["99"] = 83,["100"] = 84,["101"] = 84,["102"] = 85,["103"] = 86,["105"] = 88,["106"] = 89,["108"] = 91,["109"] = 83,["110"] = 100,["111"] = 101,["112"] = 101,["113"] = 102,["114"] = 103,["116"] = 105,["117"] = 106,["119"] = 108,["120"] = 100,["121"] = 116,["122"] = 117,["123"] = 117,["124"] = 118,["125"] = 119,["127"] = 121,["128"] = 122,["130"] = 124,["131"] = 116,["132"] = 131,["133"] = 132,["134"] = 132,["135"] = 133,["136"] = 134,["138"] = 136,["139"] = 131,["140"] = 143,["141"] = 144,["142"] = 144,["143"] = 145,["144"] = 143,["145"] = 154,["146"] = 155,["147"] = 156,["148"] = 157,["149"] = 157,["150"] = 157,["151"] = 157,["152"] = 157,["154"] = 158,["155"] = 158,["156"] = 159,["157"] = 160,["160"] = 163,["161"] = 163,["162"] = 164,["163"] = 165,["165"] = 167,["166"] = 158,["169"] = 169,["170"] = 170,["171"] = 154,["172"] = 178,["173"] = 179,["174"] = 180,["175"] = 181,["177"] = 183,["178"] = 178,["179"] = 189,["180"] = 190,["181"] = 190,["182"] = 191,["183"] = 192,["185"] = 190,["186"] = 189});
local ____exports = {}
local ____ActorUnit = require("solar.solar-common.actor.ActorUnit")
local ActorUnit = ____ActorUnit.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____ActorTypeUtil = require("solar.solar-common.actor.util.ActorTypeUtil")
local ActorTypeUtil = ____ActorTypeUtil.default
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____GroupUtil = require("solar.solar-common.util.unit.GroupUtil")
local GroupUtil = ____GroupUtil.default
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
____exports.default = __TS__Class()
local ActorUnitUtil = ____exports.default
ActorUnitUtil.name = "ActorUnitUtil"
function ActorUnitUtil.prototype.____constructor(self)
end
function ActorUnitUtil.createUnit(self, player, actorUnitTypeId, x, y, face, count, callBack)
    if face == nil then
        face = 0
    end
    if count == nil then
        count = 1
    end
    if ActorTypeUtil:hasActorType(actorUnitTypeId) then
        local actorCallBack = nil
        if callBack then
            actorCallBack = function(____, actorUnit)
                callBack(nil, actorUnit and actorUnit.unit)
            end
        end
        local ____opt_2 = ____exports.default:createActorUnit(
            player,
            actorUnitTypeId,
            x,
            y,
            face,
            count,
            actorCallBack
        )
        return ____opt_2 and ____opt_2.unit
    else
        local unit = UnitUtil.createUnit(
            player,
            actorUnitTypeId,
            x,
            y,
            face,
            count
        )
        return unit
    end
end
function ActorUnitUtil.createActorUnit(self, player, actorUnitTypeId, x, y, face, count, callBack)
    if face == nil then
        face = 0
    end
    if count == nil then
        count = 1
    end
    local actorUnit = nil
    do
        local i = 0
        while i < count do
            actorUnit = __TS__New(
                ActorUnit,
                actorUnitTypeId,
                player,
                x,
                y
            )
            SetUnitFacing(actorUnit.unit, face)
            if callBack ~= nil then
                callBack(nil, actorUnit)
            end
            i = i + 1
        end
    end
    return actorUnit
end
function ActorUnitUtil.ifHasActorUnit(self, unit, callBack, actorTypeId)
    local ____opt_6 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_6 and ____opt_6._SL_solarActorUnit
    if actor == nil then
        return
    end
    if actorTypeId ~= nil and actorTypeId ~= actor.actorTypeId then
        return
    end
    callBack(nil, actor)
end
function ActorUnitUtil.hasActorUnit(self, unit, callBack, actorTypeId)
    local ____opt_8 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_8 and ____opt_8._SL_solarActorUnit
    if actor == nil then
        return false
    end
    if actorTypeId ~= nil and actorTypeId ~= actor.actorTypeId then
        return false
    end
    return true
end
function ActorUnitUtil.getActorUnit(self, unit, actorTypeId)
    local ____opt_10 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_10 and ____opt_10._SL_solarActorUnit
    if actor == nil then
        return nil
    end
    if actorTypeId ~= nil and actorTypeId ~= actor.actorTypeId then
        return nil
    end
    return actor
end
function ActorUnitUtil.isActorUnitType(self, unit, actorTypeId)
    local ____opt_12 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_12 and ____opt_12._SL_solarActorUnit
    if actor == nil then
        return false
    end
    if actorTypeId == actor.actorTypeId then
        return true
    end
    return false
end
function ActorUnitUtil.getUnitId(self, unit)
    local ____opt_14 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_14 and ____opt_14._SL_solarActorUnit
    if actor == nil then
        return id2string(GetUnitTypeId(unit))
    end
    return actor.actorTypeId
end
function ActorUnitUtil.getActorUnitTypeId(self, unit)
    local ____opt_16 = DataBase:getUnitSolarData(unit, false)
    local actor = ____opt_16 and ____opt_16._SL_solarActorUnit
    return actor and actor.actorTypeId
end
function ActorUnitUtil.getPlayerActorUnits(self, playerIndex, actorUnitType)
    local resultUnits = {}
    local group = GroupUtil.groupObjectPool:borrowObject()
    GroupEnumUnitsOfPlayer(
        group,
        Player(playerIndex),
        nil
    )
    do
        local i = 0
        while i <= 1000000 do
            local unitHandle = FirstOfGroup(group)
            if not IsHandle(unitHandle) then
                break
            end
            local ____opt_20 = DataBase:getUnitSolarData(unitHandle, false)
            local actor = ____opt_20 and ____opt_20._SL_solarActorUnit
            if actor and UnitAlive(unitHandle) and (actorUnitType == nil or actor.actorTypeId == actorUnitType) then
                resultUnits[#resultUnits + 1] = actor
            end
            GroupRemoveUnit(group, unitHandle)
            i = i + 1
        end
    end
    GroupUtil.groupObjectPool:returnObject(group)
    return resultUnits
end
function ActorUnitUtil.getUnitName(self, whichUnit)
    local actorUnit = ____exports.default:getActorUnit(whichUnit)
    if actorUnit ~= nil then
        return actorUnit:getName()
    end
    return GetUnitName(whichUnit)
end
function ActorUnitUtil.addAnyActorUnitCreatedListener(self, onActorUnitCreatedListener)
    local ____Actor__sl_anyActorCreatedListeners_22 = Actor._sl_anyActorCreatedListeners
    ____Actor__sl_anyActorCreatedListeners_22[#____Actor__sl_anyActorCreatedListeners_22 + 1] = function(____, actorUnit)
        if __TS__InstanceOf(actorUnit, ActorUnit) then
            onActorUnitCreatedListener(nil, actorUnit)
        end
    end
end
return ____exports
