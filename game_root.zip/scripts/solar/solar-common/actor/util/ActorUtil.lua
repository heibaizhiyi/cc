local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 23,["12"] = 23,["13"] = 23,["15"] = 23,["16"] = 30,["17"] = 31,["18"] = 30,["19"] = 41,["20"] = 42,["21"] = 43,["22"] = 44,["25"] = 47,["26"] = 48,["27"] = 49,["30"] = 52,["31"] = 53,["32"] = 54,["35"] = 57,["36"] = 58,["37"] = 59,["40"] = 62,["41"] = 63,["43"] = 41,["44"] = 73,["45"] = 74,["46"] = 75,["48"] = 77,["49"] = 78,["50"] = 79,["51"] = 81,["52"] = 82,["53"] = 83,["55"] = 86,["56"] = 87,["57"] = 88,["58"] = 89,["60"] = 91,["61"] = 92,["62"] = 93,["63"] = 94,["67"] = 99,["68"] = 100,["69"] = 101,["70"] = 102,["71"] = 103,["73"] = 105,["77"] = 109,["79"] = 110,["80"] = 110,["81"] = 111,["82"] = 112,["83"] = 113,["84"] = 113,["85"] = 114,["86"] = 115,["87"] = 116,["89"] = 118,["92"] = 110,["95"] = 122,["96"] = 73,["97"] = 131,["98"] = 132,["99"] = 133,["103"] = 136,["104"] = 136,["105"] = 137,["106"] = 138,["107"] = 139,["109"] = 136,["112"] = 131,["113"] = 149,["114"] = 150,["115"] = 151,["118"] = 154,["120"] = 155,["121"] = 155,["122"] = 156,["123"] = 157,["124"] = 158,["126"] = 155,["129"] = 161,["130"] = 149,["131"] = 169,["132"] = 170,["133"] = 171,["136"] = 174,["138"] = 175,["139"] = 175,["140"] = 176,["141"] = 177,["142"] = 178,["144"] = 175,["147"] = 181,["148"] = 169,["149"] = 191,["150"] = 192,["151"] = 193,["154"] = 196,["156"] = 197,["157"] = 197,["159"] = 198,["160"] = 199,["161"] = 200,["163"] = 202,["164"] = 203,["166"] = 205,["167"] = 206,["169"] = 208,["172"] = 197,["175"] = 210,["176"] = 191,["177"] = 218,["178"] = 219,["179"] = 220,["180"] = 221,["181"] = 222,["182"] = 223,["185"] = 226,["186"] = 218,["187"] = 235,["188"] = 236,["189"] = 237,["191"] = 239,["192"] = 240,["193"] = 241,["194"] = 242,["196"] = 244,["197"] = 245,["198"] = 246,["199"] = 247,["202"] = 250,["204"] = 252,["205"] = 253,["206"] = 254,["207"] = 255,["209"] = 257,["210"] = 258,["211"] = 259,["212"] = 260,["213"] = 261,["214"] = 262,["215"] = 263,["218"] = 266,["222"] = 270,["223"] = 235,["224"] = 280,["225"] = 281,["226"] = 282,["229"] = 285,["230"] = 286,["231"] = 287,["235"] = 280,["236"] = 298,["237"] = 299,["238"] = 300,["239"] = 301,["241"] = 303,["242"] = 304,["243"] = 305,["246"] = 308,["247"] = 298,["248"] = 314,["249"] = 315,["250"] = 315,["251"] = 314,["252"] = 321,["253"] = 322,["254"] = 322,["255"] = 321,["256"] = 328,["257"] = 329,["258"] = 329,["259"] = 328});
local ____exports = {}
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
____exports.default = __TS__Class()
local ActorUtil = ____exports.default
ActorUtil.name = "ActorUtil"
function ActorUtil.prototype.____constructor(self)
end
function ActorUtil.getActor(self, uuid)
    return Actor.allActors[uuid]
end
function ActorUtil.copyExtDatas(self, fromActor, toActor)
    if fromActor.extData then
        for key in pairs(fromActor.extData) do
            toActor.extData[key] = fromActor.extData[key]
        end
    end
    if fromActor._sl_extAttributes then
        for key in pairs(fromActor._sl_extAttributes) do
            toActor:setExtAttribute(key, fromActor._sl_extAttributes[key])
        end
    end
    if fromActor._sl_extDescribes then
        for key in pairs(fromActor._sl_extDescribes) do
            toActor:setExtDescribe(key, fromActor._sl_extDescribes[key])
        end
    end
    if fromActor._sl_extDescribesFirst then
        for key in pairs(fromActor._sl_extDescribesFirst) do
            toActor:setExtDescribeFirst(key, fromActor._sl_extDescribesFirst[key])
        end
    end
    if fromActor.numberOverlay then
        toActor.numberOverlay = fromActor.numberOverlay
    end
end
function ActorUtil.getUnitAllActorList(self, unit)
    if not IsHandle(unit) then
        return nil
    end
    local actorList = nil
    local solarData = DataBase:getUnitSolarData(unit, false)
    if solarData ~= nil then
        local actor = solarData._SL_solarActorUnit
        if actor ~= nil then
            actorList = {actor}
        end
        local actorAbilitys = solarData._SL_solarActorAbilitys
        if actorAbilitys ~= nil then
            if actorList == nil then
                actorList = {}
            end
            for abilityTemplateKey in pairs(actorAbilitys) do
                local actor = actorAbilitys[abilityTemplateKey]
                if actor ~= nil then
                    actorList[#actorList + 1] = actor
                end
            end
        end
        local _SL_solarActorBuffSet = solarData._SL_solarActorBuffs
        if _SL_solarActorBuffSet then
            for ____, actor in ipairs(_SL_solarActorBuffSet) do
                if actorList == nil then
                    actorList = {}
                end
                actorList[#actorList + 1] = actor
            end
        end
    end
    local invSize = UnitInventorySize(unit)
    do
        local i = 0
        while i < invSize do
            local item = UnitItemInSlot(unit, i)
            if IsHandle(item) then
                local ____opt_0 = DataBase:getItemSolarData(item, false)
                local actor = ____opt_0 and ____opt_0._SL_solarActorItem
                if actor ~= nil then
                    if actorList == nil then
                        actorList = {}
                    end
                    actorList[#actorList + 1] = actor
                end
            end
            i = i + 1
        end
    end
    return actorList
end
function ActorUtil.forUnitAllActorList(self, unit, callback, clazz)
    local actorList = ____exports.default:getUnitAllActorList(unit)
    if actorList == nil then
        return
    end
    do
        local i = #actorList - 1
        while i >= 0 do
            local actor = actorList[i + 1]
            if clazz == nil or clazz == actor:get("class") then
                callback(nil, actor)
            end
            i = i - 1
        end
    end
end
function ActorUtil.getUnitAllActorListByActorTypeId(self, unit, actorTypeId)
    local actorList = ____exports.default:getUnitAllActorList(unit)
    if actorList == nil then
        return
    end
    local result = {}
    do
        local i = #actorList - 1
        while i >= 0 do
            local actor = actorList[i + 1]
            if actorTypeId == nil or actorTypeId == actor.actorTypeId then
                result[#result + 1] = actor
            end
            i = i - 1
        end
    end
    return result
end
function ActorUtil.getUnitAllActorListByClass(self, unit, clazz)
    local actorList = ____exports.default:getUnitAllActorList(unit)
    if actorList == nil then
        return
    end
    local result = {}
    do
        local i = #actorList - 1
        while i >= 0 do
            local actor = actorList[i + 1]
            if clazz == nil or clazz == actor:get("class") then
                result[#result + 1] = actor
            end
            i = i - 1
        end
    end
    return result
end
function ActorUtil.getUnitAllActorListAndWhere(self, unit, clazz, kind, tag)
    local actorList = ____exports.default:getUnitAllActorList(unit)
    if actorList == nil then
        return
    end
    local result = {}
    do
        local i = #actorList - 1
        while i >= 0 do
            do
                local actor = actorList[i + 1]
                if clazz ~= nil and clazz ~= actor:get("class") then
                    goto __continue54
                end
                if kind ~= nil and kind ~= actor:get("kind") then
                    goto __continue54
                end
                if tag ~= nil and tag ~= actor:get("tag") then
                    goto __continue54
                end
                result[#result + 1] = actor
            end
            ::__continue54::
            i = i - 1
        end
    end
    return result
end
function ActorUtil.getUnitAllActorAttributes(self, unit, attributeHandlers)
    local attributeArray = nil
    local actorList = ____exports.default:getUnitAllActorList(unit)
    if actorList and #actorList > 0 then
        for ____, actor in ipairs(actorList) do
            attributeArray = ____exports.default:collectActorAllAttributes(attributeArray, actor, attributeHandlers)
        end
    end
    return attributeArray
end
function ActorUtil.collectActorAllAttributes(self, resultAttributeArray, actor, attributeHandlers)
    if actor == nil then
        return resultAttributeArray
    end
    local resultAttribute = actor.attribute
    if resultAttribute then
        if resultAttributeArray == nil then
            resultAttributeArray = {}
        end
        if attributeHandlers and #attributeHandlers > 0 then
            resultAttribute = __TS__ObjectAssign({}, actor.attribute)
            for ____, attributeHandler in ipairs(attributeHandlers) do
                resultAttribute = attributeHandler(nil, actor, resultAttribute)
            end
        end
        resultAttributeArray[#resultAttributeArray + 1] = resultAttribute
    end
    local _sl_extAttributes = actor._sl_extAttributes
    if _sl_extAttributes then
        if resultAttributeArray == nil then
            resultAttributeArray = {}
        end
        for extName in pairs(_sl_extAttributes) do
            local resultAttribute = _sl_extAttributes[extName]
            if resultAttribute then
                if attributeHandlers and #attributeHandlers > 0 then
                    resultAttribute = __TS__ObjectAssign({}, actor.attribute)
                    for ____, attributeHandler in ipairs(attributeHandlers) do
                        resultAttribute = attributeHandler(nil, actor, resultAttribute)
                    end
                end
                resultAttributeArray[#resultAttributeArray + 1] = resultAttribute
            end
        end
    end
    return resultAttributeArray
end
function ActorUtil.ifUnitHasActor(self, unit, actorTypeId, callBack)
    local unitAllActorList = ____exports.default:getUnitAllActorList(unit)
    if unitAllActorList == nil then
        return
    end
    for ____, actor in ipairs(unitAllActorList) do
        if actor.actorTypeId == actorTypeId then
            callBack(nil, actor)
            return
        end
    end
end
function ActorUtil.isUnitHasActor(self, unit, actorTypeId)
    local unitAllActorList = ____exports.default:getUnitAllActorList(unit)
    if unitAllActorList == nil then
        return false
    end
    for ____, actor in ipairs(unitAllActorList) do
        if actor.actorTypeId == actorTypeId then
            return true
        end
    end
    return false
end
function ActorUtil.addAnyActorCreatedListener(self, onActorCreatedListener)
    local ____Actor__sl_anyActorCreatedListeners_2 = Actor._sl_anyActorCreatedListeners
    ____Actor__sl_anyActorCreatedListeners_2[#____Actor__sl_anyActorCreatedListeners_2 + 1] = onActorCreatedListener
end
function ActorUtil.addAnyActorLevelChangeListener(self, onActorLevelChangeListener)
    local ____Actor__sl_anyActorLevelChangeListeners_3 = Actor._sl_anyActorLevelChangeListeners
    ____Actor__sl_anyActorLevelChangeListeners_3[#____Actor__sl_anyActorLevelChangeListeners_3 + 1] = onActorLevelChangeListener
end
function ActorUtil.addAnyActorDestroyListener(self, onActorDestroyListener)
    local ____Actor__sl_anyActorDestroyListeners_4 = Actor._sl_anyActorDestroyListeners
    ____Actor__sl_anyActorDestroyListeners_4[#____Actor__sl_anyActorDestroyListeners_4 + 1] = onActorDestroyListener
end
return ____exports
