local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__InstanceOf = ____lualib.__TS__InstanceOf
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 7,["21"] = 7,["22"] = 8,["23"] = 8,["24"] = 9,["25"] = 9,["26"] = 10,["27"] = 10,["28"] = 11,["29"] = 11,["30"] = 12,["31"] = 12,["32"] = 28,["33"] = 28,["34"] = 28,["36"] = 28,["37"] = 50,["38"] = 50,["39"] = 50,["41"] = 51,["42"] = 50,["43"] = 54,["44"] = 54,["45"] = 54,["47"] = 55,["48"] = 54,["49"] = 58,["50"] = 58,["51"] = 58,["53"] = 59,["54"] = 58,["55"] = 69,["56"] = 69,["57"] = 69,["59"] = 70,["60"] = 71,["62"] = 73,["65"] = 76,["66"] = 77,["67"] = 78,["68"] = 79,["69"] = 80,["70"] = 80,["71"] = 80,["72"] = 81,["73"] = 82,["74"] = 82,["75"] = 82,["76"] = 82,["77"] = 82,["78"] = 82,["79"] = 82,["80"] = 80,["81"] = 80,["82"] = 80,["83"] = 80,["84"] = 84,["85"] = 84,["86"] = 84,["87"] = 85,["88"] = 86,["89"] = 87,["90"] = 84,["91"] = 84,["92"] = 69,["93"] = 96,["94"] = 97,["97"] = 100,["98"] = 101,["101"] = 104,["104"] = 96,["105"] = 109,["106"] = 110,["109"] = 113,["110"] = 113,["111"] = 113,["112"] = 113,["113"] = 113,["114"] = 118,["115"] = 119,["116"] = 120,["118"] = 122,["119"] = 123,["121"] = 125,["122"] = 126,["123"] = 109,["124"] = 129,["125"] = 130,["128"] = 133,["129"] = 138,["130"] = 139,["132"] = 141,["133"] = 142,["134"] = 129,["135"] = 149,["136"] = 150,["139"] = 153,["140"] = 154,["141"] = 155,["142"] = 156,["143"] = 159,["144"] = 161,["145"] = 162,["146"] = 163,["147"] = 164,["148"] = 165,["150"] = 167,["152"] = 169,["153"] = 170,["154"] = 171,["155"] = 172,["157"] = 174,["158"] = 175,["160"] = 177,["161"] = 178,["162"] = 179,["164"] = 181,["165"] = 182,["167"] = 185,["168"] = 186,["169"] = 187,["170"] = 188,["171"] = 189,["172"] = 190,["174"] = 192,["175"] = 193,["177"] = 195,["178"] = 196,["179"] = 197,["180"] = 198,["181"] = 199,["183"] = 201,["184"] = 202,["186"] = 204,["187"] = 205,["188"] = 206,["189"] = 207,["190"] = 208,["192"] = 210,["193"] = 211,["195"] = 213,["196"] = 215,["197"] = 216,["198"] = 217,["200"] = 219,["201"] = 149,["202"] = 226,["203"] = 227,["204"] = 229,["205"] = 230,["206"] = 231,["207"] = 231,["208"] = 231,["209"] = 231,["210"] = 235,["211"] = 236,["212"] = 237,["213"] = 238,["215"] = 240,["216"] = 241,["217"] = 241,["218"] = 241,["219"] = 241,["220"] = 242,["221"] = 243,["223"] = 245,["224"] = 249,["225"] = 250,["226"] = 251,["227"] = 251,["228"] = 251,["229"] = 251,["231"] = 257,["232"] = 258,["233"] = 259,["234"] = 259,["235"] = 259,["236"] = 259,["239"] = 266,["240"] = 267,["241"] = 268,["242"] = 268,["243"] = 268,["244"] = 268,["245"] = 272,["246"] = 273,["247"] = 274,["248"] = 275,["250"] = 277,["251"] = 278,["252"] = 278,["253"] = 278,["254"] = 278,["255"] = 279,["256"] = 280,["258"] = 282,["259"] = 286,["260"] = 287,["261"] = 287,["262"] = 287,["263"] = 287,["264"] = 292,["265"] = 293,["266"] = 294,["267"] = 294,["268"] = 294,["269"] = 294,["272"] = 301,["273"] = 302,["274"] = 303,["275"] = 303,["276"] = 303,["277"] = 303,["278"] = 307,["279"] = 308,["280"] = 308,["281"] = 308,["282"] = 308,["283"] = 313,["284"] = 314,["285"] = 315,["286"] = 316,["287"] = 317,["288"] = 317,["289"] = 317,["290"] = 317,["292"] = 319,["293"] = 319,["294"] = 319,["295"] = 319,["296"] = 319,["298"] = 321,["299"] = 322,["300"] = 323,["302"] = 325,["304"] = 330,["305"] = 226,["306"] = 337,["307"] = 338,["308"] = 339,["309"] = 340,["310"] = 340,["311"] = 340,["312"] = 340,["314"] = 345,["315"] = 346,["316"] = 346,["317"] = 346,["318"] = 346,["320"] = 351,["321"] = 352,["322"] = 352,["323"] = 352,["324"] = 352,["326"] = 357,["327"] = 337,["328"] = 361,["329"] = 362,["330"] = 363,["332"] = 365,["333"] = 366,["334"] = 367,["335"] = 361,["336"] = 370,["337"] = 372,["340"] = 376,["341"] = 376,["342"] = 376,["343"] = 376,["344"] = 376,["345"] = 376,["346"] = 376,["347"] = 376,["348"] = 377,["349"] = 378,["350"] = 380,["351"] = 381,["352"] = 382,["353"] = 384,["354"] = 385,["355"] = 385,["356"] = 385,["357"] = 385,["358"] = 385,["359"] = 385,["360"] = 385,["361"] = 386,["362"] = 388,["363"] = 389,["364"] = 390,["365"] = 390,["366"] = 390,["367"] = 390,["368"] = 390,["369"] = 390,["370"] = 390,["371"] = 392,["372"] = 393,["373"] = 394,["374"] = 394,["375"] = 394,["376"] = 394,["377"] = 394,["378"] = 394,["379"] = 394,["380"] = 396,["381"] = 397,["382"] = 398,["383"] = 398,["384"] = 398,["385"] = 398,["386"] = 398,["387"] = 398,["388"] = 398,["389"] = 402,["390"] = 403,["391"] = 404,["392"] = 405,["393"] = 406,["394"] = 406,["395"] = 406,["396"] = 406,["397"] = 406,["398"] = 406,["399"] = 406,["400"] = 407,["401"] = 407,["402"] = 407,["403"] = 407,["404"] = 407,["405"] = 407,["406"] = 407,["407"] = 409,["408"] = 410,["409"] = 411,["410"] = 412,["411"] = 413,["412"] = 413,["413"] = 413,["414"] = 413,["415"] = 413,["416"] = 413,["417"] = 413,["418"] = 414,["419"] = 414,["420"] = 414,["421"] = 414,["422"] = 414,["423"] = 414,["424"] = 414,["425"] = 416,["426"] = 417,["427"] = 418,["428"] = 419,["429"] = 420,["430"] = 420,["431"] = 420,["432"] = 420,["433"] = 420,["434"] = 420,["435"] = 420,["436"] = 421,["437"] = 421,["438"] = 421,["439"] = 421,["440"] = 421,["441"] = 421,["442"] = 421,["443"] = 425,["444"] = 425,["445"] = 425,["446"] = 425,["447"] = 425,["448"] = 425,["449"] = 425,["450"] = 425,["451"] = 426,["452"] = 426,["453"] = 426,["454"] = 426,["455"] = 426,["456"] = 426,["457"] = 426,["458"] = 426,["459"] = 429,["460"] = 431,["461"] = 431,["462"] = 431,["463"] = 431,["464"] = 431,["465"] = 431,["466"] = 431,["467"] = 431,["468"] = 431,["469"] = 431,["470"] = 431,["471"] = 431,["472"] = 431,["473"] = 431,["474"] = 370,["475"] = 448,["476"] = 449,["478"] = 450,["479"] = 450,["480"] = 450,["481"] = 450,["482"] = 450,["483"] = 450,["484"] = 450,["485"] = 450,["486"] = 450,["487"] = 450,["488"] = 451,["489"] = 452,["490"] = 453,["492"] = 456,["493"] = 457,["495"] = 462,["496"] = 448});
local ____exports = {}
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____SolarConfig = require("solar.solar-common.common.SolarConfig")
local SolarConfig = ____SolarConfig.default
local ____TextUtil = require("solar.solar-common.util.text.TextUtil")
local TextUtil = ____TextUtil.default
local ____ActorItem = require("solar.solar-common.actor.ActorItem")
local ActorItem = ____ActorItem.default
local ____ActorAbility = require("solar.solar-common.actor.ActorAbility")
local ActorAbility = ____ActorAbility.default
local ____TipFrameUtil = require("solar.solar-common.util.frame.TipFrameUtil")
local TipFrameUtil = ____TipFrameUtil.default
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local ____ActorBuff = require("solar.solar-common.actor.ActorBuff")
local ActorBuff = ____ActorBuff.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
____exports.default = __TS__Class()
local ActorFrameUtil = ____exports.default
ActorFrameUtil.name = "ActorFrameUtil"
function ActorFrameUtil.prototype.____constructor(self)
end
function ActorFrameUtil.showWarnText(self, actor, tipText, dur, showPlayer)
    if dur == nil then
        dur = 1
    end
    ____exports.default:showTipText(actor, SolarConfig.defaultWarnTextColor .. tipText, dur, showPlayer)
end
function ActorFrameUtil.showFailText(self, actor, tipText, dur, showPlayer)
    if dur == nil then
        dur = 1
    end
    ____exports.default:showTipText(actor, SolarConfig.defaultFailTextColor .. tipText, dur, showPlayer)
end
function ActorFrameUtil.showSuccessText(self, actor, tipText, dur, showPlayer)
    if dur == nil then
        dur = 1
    end
    ____exports.default:showTipText(actor, SolarConfig.defaultSuccessTextColor .. tipText, dur, showPlayer)
end
function ActorFrameUtil.showTipText(self, actor, tipText, dur, showPlayer)
    if dur == nil then
        dur = 1
    end
    if showPlayer == nil and IsHandle(actor.unit) then
        showPlayer = actor.unitOwner
    end
    if showPlayer ~= nil and GetLocalPlayer() ~= showPlayer then
        return
    end
    local frame = TipFrameUtil._sl_tipTextFrameObjectPool:borrowObject()
    frame:setText(tipText)
    frame.visible = true
    DzFrameShow(frame.backdropFrame.handle, true)
    BaseUtil.runLater(
        0.03,
        function(count, maxCount)
            local y = 0.01 + 0.002 * count
            frame:setPoint(
                FramePoint.bottom,
                actor:getRootFrameControl().rootFrame.handle,
                FramePoint.top,
                0,
                y
            )
        end,
        30,
        true
    )
    BaseUtil.runLater(
        dur,
        function()
            frame.visible = false
            DzFrameShow(frame.backdropFrame.handle, false)
            TipFrameUtil._sl_tipTextFrameObjectPool:returnObject(frame)
        end
    )
end
function ActorFrameUtil.showTooltip(self, actorOrActorType)
    if actorOrActorType == nil then
        return
    end
    if __TS__InstanceOf(actorOrActorType, Actor) then
        ____exports.default:showTooltipByActor(actorOrActorType)
        return
    else
        ____exports.default:showTooltipByActorType(actorOrActorType)
        return
    end
end
function ActorFrameUtil.showTooltipByActor(self, actor)
    if actor == nil then
        return
    end
    local info = {
        name = actor:getName(),
        icon = actor:getIcon(),
        describe = actor:getDescribe(true)
    }
    local hotKey = actor:get("hotKey")
    if hotKey ~= nil and #hotKey > 0 and __TS__InstanceOf(actor, ActorAbility) and not actor:isPassive() then
        info.hotKey = hotKey
    end
    if actor:isDisable() and actor:get("requiredTip") ~= nil then
        info.requiredTip = actor:get("requiredTip")
    end
    info.labelInfos = ____exports.default:getActorLabelInfo(actor)
    ____exports.default:showTooltipByInfo(info)
end
function ActorFrameUtil.showTooltipByActorType(self, actorType)
    if actorType == nil then
        return
    end
    local info = {name = actorType.name or actorType.id, icon = actorType.icon, describe = actorType.describe}
    if not actorType.uiEnable and actorType.requiredTip ~= nil then
        info.requiredTip = actorType.requiredTip
    end
    info.labelInfos = ____exports.default:getActorTypeLabelInfo(actorType)
    ____exports.default:showTooltipByInfo(info)
end
function ActorFrameUtil.showTooltipByInfo(self, info)
    if info == nil then
        return
    end
    ____exports.default:_sl_initTooltip()
    local tooltip = DzFrameGetTooltip()
    DzFrameClearAllPoints(tooltip)
    DzFrameSetAbsolutePoint(tooltip, FramePoint.bottomLeft, 0.81, 0)
    local tooltipFrames = ____exports.default._sl_tooltipFrames
    tooltipFrames.name:setText(info.name)
    local hotKey = info.hotKey
    if hotKey ~= nil then
        tooltipFrames.hotKey:setText(("(|cffeeee00" .. hotKey) .. "|r)")
        tooltipFrames.hotKey.visible = true
    else
        tooltipFrames.hotKey.visible = false
    end
    if info.icon then
        tooltipFrames.icon:setTexture(info.icon)
        tooltipFrames.icon:setSize(0.03, 0.04)
        tooltipFrames.icon.visible = true
    else
        tooltipFrames.icon:setSize(0.001, 0.001)
        tooltipFrames.icon.visible = false
    end
    if info.requiredTip ~= nil then
        tooltipFrames.requiredTip:setText("|cffffff00需要:|n - " .. info.requiredTip)
        tooltipFrames.requiredTip.visible = true
    else
        tooltipFrames.requiredTip:setText("")
        tooltipFrames.requiredTip.visible = false
    end
    local labelInfos = info.labelInfos or ({})
    if #labelInfos > 0 then
        tooltipFrames.labelIcon1:setTexture(labelInfos[1].icon)
        tooltipFrames.label1:setText(labelInfos[1].text)
        tooltipFrames.labelIcon1.visible = labelInfos[1].icon ~= nil and labelInfos[1].icon ~= ""
        tooltipFrames.label1.visible = true
    else
        tooltipFrames.labelIcon1.visible = false
        tooltipFrames.label1.visible = false
    end
    if #labelInfos > 1 then
        tooltipFrames.labelIcon2:setTexture(labelInfos[2].icon)
        tooltipFrames.label2:setText(labelInfos[2].text)
        tooltipFrames.labelIcon2.visible = labelInfos[2].icon ~= nil and labelInfos[2].icon ~= ""
        tooltipFrames.label2.visible = true
    else
        tooltipFrames.labelIcon2.visible = false
        tooltipFrames.label2.visible = false
    end
    if #labelInfos > 2 then
        tooltipFrames.labelIcon3:setTexture(labelInfos[3].icon)
        tooltipFrames.label3:setText(labelInfos[3].text)
        tooltipFrames.labelIcon3.visible = labelInfos[3].icon ~= nil and labelInfos[3].icon ~= ""
        tooltipFrames.label3.visible = true
    else
        tooltipFrames.labelIcon3.visible = false
        tooltipFrames.label3.visible = false
    end
    tooltipFrames.describe:setText(info.describe)
    if SolarConfig.defaultTooltipFrameAbsY ~= 0 then
        tooltipFrames.describe:clearPoints()
        tooltipFrames.describe:setAbsPoint(FramePoint.bottomRight, SolarConfig.defaultTooltipFrameAbsX, SolarConfig.defaultTooltipFrameAbsY)
    end
    tooltipFrames.root.visible = true
end
function ActorFrameUtil.getActorLabelInfo(self, actor)
    local labelInfo = {}
    local goldCost = actor:get("goldCost")
    if actor:get("tooltipLabel1") then
        labelInfo[#labelInfo + 1] = {
            icon = actor:get("tooltipLabelIcon1") or SolarConfig.defaultResourceGoldPath,
            text = actor:get("tooltipLabel1")
        }
    elseif goldCost and goldCost > 0 then
        local text = nil
        if __TS__InstanceOf(actor, ActorItem) then
            text = TextUtil:toCnUnit(actor:getPawnGold())
        else
            text = TextUtil:toCnUnit(goldCost)
            local playerState = GetPlayerState(
                GetLocalPlayer(),
                PLAYER_STATE_RESOURCE_GOLD
            )
            text = tostring(text) .. (playerState >= goldCost and SolarConfig.defaultSuccessTextColor or SolarConfig.defaultFailTextColor)
            text = tostring(text) .. (" 【已拥有:" .. TextUtil:toCnUnit(playerState)) .. "】|r"
        end
        labelInfo[#labelInfo + 1] = {icon = SolarConfig.defaultResourceGoldPath, text = text}
    elseif __TS__InstanceOf(actor, ActorAbility) then
        if not actor:isPassive() and actor:get("maxCd") ~= nil and actor:get("maxCd") > 2 then
            labelInfo[#labelInfo + 1] = {
                icon = "UI\\Widgets\\ToolTips\\Human\\ToolTipStonesIcon.blp",
                text = TextUtil:secondsToHMS(actor:get("maxCd"))
            }
        end
    elseif __TS__InstanceOf(actor, ActorBuff) then
        if actor.level and actor.level ~= 1 then
            labelInfo[#labelInfo + 1] = {
                icon = "UI\\Widgets\\EscMenu\\Orc\\orc-slider-knob.blp",
                text = "Lv." .. tostring(actor.level)
            }
        end
    end
    local lumberCost = actor:get("lumberCost")
    if actor:get("tooltipLabel2") then
        labelInfo[#labelInfo + 1] = {
            icon = actor:get("tooltipLabelIcon2") or SolarConfig.defaultResourceLumberPath,
            text = actor:get("tooltipLabel2")
        }
    elseif lumberCost and lumberCost > 0 then
        local text = nil
        if __TS__InstanceOf(actor, ActorItem) then
            text = TextUtil:toCnUnit(actor:getPawnLumber())
        else
            text = TextUtil:toCnUnit(lumberCost)
            local playerState = GetPlayerState(
                GetLocalPlayer(),
                PLAYER_STATE_RESOURCE_LUMBER
            )
            text = tostring(text) .. (playerState >= goldCost and SolarConfig.defaultSuccessTextColor or SolarConfig.defaultFailTextColor)
            text = tostring(text) .. (" 【已拥有:" .. TextUtil:toCnUnit(playerState)) .. "】|r"
        end
        labelInfo[#labelInfo + 1] = {icon = SolarConfig.defaultResourceLumberPath, text = text}
    elseif actor:get("manaCost") ~= nil and actor:get("manaCost") > 0 then
        labelInfo[#labelInfo + 1] = {
            icon = "UI\\Widgets\\ToolTips\\Human\\ToolTipManaIcon.blp",
            text = tostring(actor:get("manaCost")) .. "魔法"
        }
    elseif __TS__InstanceOf(actor, ActorBuff) then
        if actor:get("tag") ~= "光环" and actor:get("dur", 0) > 3 then
            labelInfo[#labelInfo + 1] = {
                icon = "UI\\Widgets\\BattleNet\\bnet-tournament-clock.blp",
                text = TextUtil:secondsToHMS(math.ceil(actor:getRemainingTime()))
            }
        end
    end
    local foodCost = actor:get("foodCost")
    if actor:get("tooltipLabel3") then
        labelInfo[#labelInfo + 1] = {
            icon = actor:get("tooltipLabelIcon3") or "UI\\Feedback\\Resources\\ResourceUndead.blp",
            text = actor:get("tooltipLabel3")
        }
    elseif foodCost and foodCost > 0 then
        labelInfo[#labelInfo + 1] = {
            icon = "UI\\Widgets\\ToolTips\\Human\\ToolTipSupplyIcon.blp",
            text = tostring(foodCost) .. ""
        }
    elseif actor:get("killsCost") ~= nil and actor:get("killsCost") > 0 then
        local text = tostring(actor:get("killsCost")) .. "杀敌数"
        local playerState = nil
        if functions["获取玩家杀敌数"] then
            playerState = functions["获取玩家杀敌数"](
                functions,
                GetLocalPlayer()
            )
        else
            local ____opt_0 = DataBase:getPlayerSolarData(
                GetLocalPlayer(),
                false
            )
            playerState = ____opt_0 and ____opt_0.killCount
        end
        if playerState and playerState > 0 then
            text = text .. (playerState >= actor:get("killsCost") and SolarConfig.defaultSuccessTextColor or SolarConfig.defaultFailTextColor)
            text = text .. (" 【已拥有:" .. TextUtil:toCnUnit(playerState)) .. "】|r"
        end
        labelInfo[#labelInfo + 1] = {icon = "UI\\Feedback\\Resources\\ResourceUndead.blp", text = text}
    end
    return labelInfo
end
function ActorFrameUtil.getActorTypeLabelInfo(self, actorType)
    local labelInfos = {}
    if actorType.goldCost and actorType.goldCost ~= 0 then
        labelInfos[#labelInfos + 1] = {
            icon = SolarConfig.defaultResourceGoldPath,
            text = tostring(actorType.goldCost) .. ""
        }
    end
    if actorType.lumberCost and actorType.lumberCost ~= 0 then
        labelInfos[#labelInfos + 1] = {
            icon = SolarConfig.defaultResourceLumberPath,
            text = tostring(actorType.lumberCost) .. ""
        }
    end
    if actorType.foodCost and actorType.foodCost ~= 0 then
        labelInfos[#labelInfos + 1] = {
            icon = SolarConfig.defaultResourceSupplyPath,
            text = tostring(actorType.foodCost) .. ""
        }
    end
    return labelInfos
end
function ActorFrameUtil.hideTooltip(self)
    if ____exports.default._sl_tooltipFrames ~= nil then
        ____exports.default._sl_tooltipFrames.root.visible = false
    end
    local tooltip = DzFrameGetTooltip()
    DzFrameClearAllPoints(tooltip)
    DzFrameSetAbsolutePoint(tooltip, FramePoint.bottomRight, SolarConfig.defaultTooltipFrameAbsX + 0.01, SolarConfig.defaultTooltipFrameAbsY - 0.01)
end
function ActorFrameUtil._sl_initTooltip(self)
    if ____exports.default._sl_tooltipFrames ~= nil then
        return
    end
    local root = __TS__New(
        Frame,
        "BACKDROP",
        nil,
        DzGetGameUI(),
        "_sl_border_backdrop",
        0
    )
    local gap = 0.008
    local fontSize = 0.0113
    local describe = Frame:createTEXT(root.handle)
    describe:setFont(fontSize)
    DzFrameSetSize(describe.handle, 0.2, -1)
    local requiredTip = Frame:createTEXT(root.handle)
    requiredTip:setPoint(
        FramePoint.bottomLeft,
        describe.handle,
        FramePoint.topLeft,
        0,
        gap
    )
    DzFrameSetSize(requiredTip.handle, 0.2, -1)
    local icon = Frame:createBackDrop(root.handle)
    icon:setSize(0.03, 0.04)
    icon:setPoint(
        FramePoint.bottomLeft,
        requiredTip.handle,
        FramePoint.topLeft,
        0,
        gap
    )
    local name = Frame:createTEXT(root.handle)
    name:setFont(fontSize)
    name:setPoint(
        FramePoint.topLeft,
        icon.handle,
        FramePoint.topRight,
        gap,
        0
    )
    local hotKey = Frame:createTEXT(root.handle)
    hotKey:setFont(fontSize)
    hotKey:setPoint(
        FramePoint.left,
        name.handle,
        FramePoint.right,
        0.001,
        0
    )
    local labelIcon1 = Frame:createBackDrop(root.handle)
    local label1 = Frame:createTEXT(root.handle)
    label1:setFont(fontSize)
    labelIcon1:setSize(0.009, 0.012)
    labelIcon1:setPoint(
        FramePoint.topLeft,
        name.handle,
        FramePoint.bottomLeft,
        0,
        -gap
    )
    label1:setPoint(
        FramePoint.left,
        labelIcon1.handle,
        FramePoint.right,
        0.002,
        0
    )
    local labelIcon2 = Frame:createBackDrop(root.handle)
    local label2 = Frame:createTEXT(root.handle)
    label2:setFont(fontSize)
    labelIcon2:setSize(0.009, 0.012)
    labelIcon2:setPoint(
        FramePoint.left,
        label1.handle,
        FramePoint.right,
        gap,
        0
    )
    label2:setPoint(
        FramePoint.left,
        labelIcon2.handle,
        FramePoint.right,
        0.002,
        0
    )
    local labelIcon3 = Frame:createBackDrop(root.handle)
    local label3 = Frame:createTEXT(root.handle)
    label3:setFont(fontSize)
    labelIcon3:setSize(0.009, 0.012)
    labelIcon3:setPoint(
        FramePoint.left,
        label2.handle,
        FramePoint.right,
        gap,
        0
    )
    label3:setPoint(
        FramePoint.left,
        labelIcon3.handle,
        FramePoint.right,
        0.002,
        0
    )
    DzFrameSetPoint(
        root.handle,
        FRAMEPOINT_TOPLEFT,
        icon.handle,
        FRAMEPOINT_TOPLEFT,
        -gap,
        gap
    )
    DzFrameSetPoint(
        root.handle,
        FRAMEPOINT_BOTTOMRIGHT,
        describe.handle,
        FRAMEPOINT_BOTTOMRIGHT,
        gap,
        -gap
    )
    describe:setAbsPoint(FramePoint.bottomRight, SolarConfig.defaultTooltipFrameAbsX, SolarConfig.defaultTooltipFrameAbsY)
    ____exports.default._sl_tooltipFrames = {
        root = root,
        name = name,
        hotKey = hotKey,
        icon = icon,
        requiredTip = requiredTip,
        describe = describe,
        labelIcon1 = labelIcon1,
        label1 = label1,
        labelIcon2 = labelIcon2,
        label2 = label2,
        labelIcon3 = labelIcon3,
        label3 = label3
    }
end
function ActorFrameUtil.localClickActorType(self, actorType, btn, x, y)
    isAsync = true
    local ____this_3
    ____this_3 = actorType
    local ____opt_2 = ____this_3.onLocalClick
    local b = ____opt_2 and ____opt_2(
        ____this_3,
        nil,
        btn,
        x,
        y,
        actorType
    )
    isAsync = false
    if b == false then
        return false
    end
    if actorType.onClick ~= nil then
        SyncUtil.syncObjData("_sl_:at:onClick", {i = actorType.id, b = btn})
    end
    return true
end
return ____exports
