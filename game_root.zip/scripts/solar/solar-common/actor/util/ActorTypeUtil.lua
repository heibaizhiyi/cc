local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 11,["17"] = 11,["18"] = 11,["20"] = 11,["21"] = 26,["22"] = 27,["23"] = 28,["24"] = 29,["26"] = 31,["28"] = 33,["29"] = 34,["30"] = 35,["33"] = 39,["34"] = 40,["35"] = 41,["36"] = 41,["37"] = 42,["38"] = 42,["39"] = 42,["40"] = 43,["41"] = 42,["42"] = 42,["44"] = 46,["46"] = 48,["47"] = 26,["48"] = 55,["49"] = 56,["50"] = 57,["52"] = 59,["53"] = 60,["55"] = 62,["56"] = 55,["57"] = 70,["58"] = 71,["59"] = 72,["60"] = 73,["62"] = 75,["63"] = 76,["64"] = 77,["66"] = 79,["67"] = 70,["68"] = 86,["69"] = 87,["70"] = 86,["71"] = 96,["72"] = 96,["73"] = 98,["74"] = 99,["75"] = 100,["76"] = 101,["77"] = 102,["78"] = 103,["82"] = 107,["83"] = 108,["84"] = 109,["87"] = 96,["88"] = 121,["89"] = 122,["90"] = 123,["91"] = 121,["92"] = 132,["93"] = 133,["94"] = 134,["95"] = 134,["96"] = 135,["97"] = 136,["99"] = 134,["101"] = 140,["102"] = 140,["104"] = 132,["105"] = 152,["106"] = 153,["109"] = 156,["110"] = 157,["111"] = 158,["114"] = 161,["115"] = 152,["116"] = 171,["117"] = 172,["120"] = 175,["121"] = 176,["122"] = 177,["125"] = 180,["126"] = 171,["127"] = 188,["128"] = 189,["129"] = 190,["130"] = 191,["132"] = 193,["133"] = 194,["135"] = 196,["136"] = 197,["138"] = 199,["139"] = 200,["141"] = 202,["142"] = 203,["144"] = 205,["145"] = 206,["147"] = 208,["148"] = 209,["150"] = 211,["151"] = 188,["152"] = 223,["153"] = 223,["154"] = 223,["156"] = 223,["157"] = 223,["159"] = 224,["160"] = 225,["161"] = 226,["162"] = 227,["164"] = 229,["165"] = 230,["166"] = 231,["167"] = 232,["168"] = 233,["169"] = 234,["171"] = 236,["172"] = 237,["174"] = 239,["175"] = 240,["177"] = 242,["178"] = 243,["180"] = 245,["181"] = 246,["183"] = 248,["184"] = 249,["185"] = 250,["186"] = 251,["187"] = 252,["188"] = 253,["189"] = 254,["191"] = 250,["193"] = 258,["194"] = 223,["195"] = 13,["196"] = 17});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____ActorItem = require("solar.solar-common.actor.ActorItem")
local ActorItem = ____ActorItem.default
local ____ArrayUtil = require("solar.solar-common.util.lang.ArrayUtil")
local ArrayUtil = ____ArrayUtil.default
local ____TextUtil = require("solar.solar-common.util.text.TextUtil")
local TextUtil = ____TextUtil.default
____exports.default = __TS__Class()
local ActorTypeUtil = ____exports.default
ActorTypeUtil.name = "ActorTypeUtil"
function ActorTypeUtil.prototype.____constructor(self)
end
function ActorTypeUtil.registerActorType(self, actorTypeIdOrActorType)
    local actorType = nil
    if type(actorTypeIdOrActorType) == "string" then
        actorType = {id = actorTypeIdOrActorType}
    else
        actorType = actorTypeIdOrActorType
    end
    if actorType.id == nil or actorType.id.length == 0 then
        print_r(actorType)
        log.errorWithTraceBack("ActorType id必须赋值！")
        return
    end
    if DataBase:getSolarActorType(actorType.id) == nil or gv.reloadIng == true then
        DataBase:setSolarActorType(actorType.id, actorType)
        local ____exports_default_actorTypes_0 = ____exports.default.actorTypes
        ____exports_default_actorTypes_0[#____exports_default_actorTypes_0 + 1] = actorType
        ArrayUtil:forEach(
            ____exports.default._sl_onRegisterActorTypeListeners,
            function(____, registerActorTypeListener)
                registerActorTypeListener(nil, actorType)
            end
        )
    else
        log.errorWithTraceBack((("不能重复注册ActorType:" .. tostring(actorType.id)) .. " -> ") .. tostring(actorType.name))
    end
    return actorType
end
function ActorTypeUtil.hasActorType(self, actorTypeId)
    if actorTypeId == nil or #actorTypeId == 0 then
        return false
    end
    if DataBase:getSolarActorType(actorTypeId) == nil then
        return false
    end
    return true
end
function ActorTypeUtil.getActorType(self, actorTypeId)
    if actorTypeId == nil then
        log.errorWithTraceBack("actorTypeId不能为null!")
        return nil
    end
    local actorType = DataBase:getSolarActorType(actorTypeId)
    if actorType == nil then
        print("没有此类型演员:" .. actorTypeId)
    end
    return actorType
end
function ActorTypeUtil.getAllActorTypes(self)
    return ____exports.default.actorTypes
end
function ActorTypeUtil.forAllActorTypes(self, callback, ...)
    local actorTypeClass = {...}
    local index = 0
    if actorTypeClass and #actorTypeClass > 0 then
        for ____, actorType in ipairs(____exports.default.actorTypes) do
            if __TS__ArrayIncludes(actorTypeClass, actorType.class) then
                callback(nil, actorType, index)
                index = index + 1
            end
        end
    else
        for ____, actorType in ipairs(____exports.default.actorTypes) do
            callback(nil, actorType, index)
            index = index + 1
        end
    end
end
function ActorTypeUtil.forAllActorTypesAndLaterRegister(self, actorTypeListener)
    ____exports.default:forAllActorTypes(actorTypeListener)
    ____exports.default:addRegisterActorTypeListener(actorTypeListener)
end
function ActorTypeUtil.addRegisterActorTypeListener(self, registerActorTypeListener, actorTypeID)
    if actorTypeID then
        local ____exports_default__sl_onRegisterActorTypeListeners_1 = ____exports.default._sl_onRegisterActorTypeListeners
        ____exports_default__sl_onRegisterActorTypeListeners_1[#____exports_default__sl_onRegisterActorTypeListeners_1 + 1] = function(____, actorType)
            if actorTypeID == actorType.id then
                registerActorTypeListener(nil, actorType)
            end
        end
    else
        local ____exports_default__sl_onRegisterActorTypeListeners_2 = ____exports.default._sl_onRegisterActorTypeListeners
        ____exports_default__sl_onRegisterActorTypeListeners_2[#____exports_default__sl_onRegisterActorTypeListeners_2 + 1] = registerActorTypeListener
    end
end
function ActorTypeUtil.setUiEnable(self, actorTypeId, uiEnable, player)
    if player ~= nil and GetLocalPlayer() ~= player then
        return
    end
    local actorType = ____exports.default:getActorType(actorTypeId)
    if actorType == nil then
        print("设置未注册的Actor图标:" .. actorTypeId)
        return
    end
    actorType.uiEnable = uiEnable
end
function ActorTypeUtil.setTypeDescribe(self, actorTypeId, describe, player)
    if player ~= nil and GetLocalPlayer() ~= player then
        return
    end
    local actorType = ____exports.default:getActorType(actorTypeId)
    if actorType == nil then
        print("设置未注册的Actor提示:" .. actorTypeId)
        return
    end
    actorType.describe = describe
end
function ActorTypeUtil.generateDescribeByActorTypeId(self, actorType)
    local describe = ""
    if actorType.damage then
        describe = describe .. ("攻击力: " .. TextUtil:toCnUnit(actorType.damage)) .. "|r|n"
    end
    if actorType.damageCd then
        describe = describe .. ("攻击间隔: " .. tostring(actorType.damageCd)) .. "|r|n"
    end
    if actorType.maxLife then
        describe = describe .. ("生命值: " .. TextUtil:toCnUnit(actorType.maxLife)) .. "|r|n"
    end
    if actorType.def then
        describe = describe .. ("护甲: " .. TextUtil:toCnUnit(actorType.def)) .. "|r|n"
    end
    if actorType.strength then
        describe = describe .. ("力量: " .. TextUtil:toCnUnit(actorType.strength)) .. "|r|n"
    end
    if actorType.agility then
        describe = describe .. ("敏捷: " .. TextUtil:toCnUnit(actorType.agility)) .. "|r|n"
    end
    if actorType.intelligence then
        describe = describe .. ("智力: " .. TextUtil:toCnUnit(actorType.intelligence)) .. "|r|n"
    end
    return describe
end
function ActorTypeUtil.registerActorTypeFromBaseItemType(self, itemTypeIdStr, baseData, bindItemAndActor)
    if baseData == nil then
        baseData = {}
    end
    if bindItemAndActor == nil then
        bindItemAndActor = false
    end
    local itemObjInfo = _g_objs.item[itemTypeIdStr]
    if itemObjInfo == nil then
        log.errorWithTraceBack("不存在此物品id:" .. itemTypeIdStr)
        return nil
    end
    baseData.id = itemTypeIdStr
    baseData.name = itemObjInfo.Tip
    baseData.icon = itemObjInfo.Art
    baseData.describe = itemObjInfo.Ubertip
    if itemObjInfo.file then
        baseData.model = itemObjInfo.file
    end
    if itemObjInfo.pawnable then
        baseData.pawnable = itemObjInfo.pawnable == "1"
    end
    if itemObjInfo.droppable then
        baseData.droppable = itemObjInfo.droppable == "1"
    end
    if itemObjInfo.goldcost then
        baseData.goldCost = math.floor(tonumber(itemObjInfo.goldcost))
    end
    if itemObjInfo.lumbercost then
        baseData.lumberCost = math.floor(tonumber(itemObjInfo.lumbercost))
    end
    ____exports.default:registerActorType(baseData)
    if bindItemAndActor then
        se:onUnitPickupItem(function(e)
            if e.manipulatedItemTypeIdStr == itemTypeIdStr then
                RemoveItem(e.manipulatedItem)
                local actorItem = __TS__New(ActorItem, itemTypeIdStr)
                UnitAddItem(e.trigUnit, actorItem.item)
            end
        end)
    end
    return baseData
end
ActorTypeUtil.actorTypes = {}
ActorTypeUtil._sl_onRegisterActorTypeListeners = {}
return ____exports
