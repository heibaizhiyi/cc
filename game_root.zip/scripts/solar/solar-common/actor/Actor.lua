local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__New = ____lualib.__TS__New
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["9"] = 1,["10"] = 1,["11"] = 2,["12"] = 2,["13"] = 3,["14"] = 3,["15"] = 4,["16"] = 4,["17"] = 5,["18"] = 5,["19"] = 6,["20"] = 6,["21"] = 7,["22"] = 7,["23"] = 8,["24"] = 8,["25"] = 11,["26"] = 48,["27"] = 48,["28"] = 48,["29"] = 138,["30"] = 55,["31"] = 55,["32"] = 55,["33"] = 61,["34"] = 70,["35"] = 71,["36"] = 72,["37"] = 97,["38"] = 113,["39"] = 115,["40"] = 135,["41"] = 136,["42"] = 139,["43"] = 140,["44"] = 141,["47"] = 144,["48"] = 145,["49"] = 146,["51"] = 148,["52"] = 149,["53"] = 150,["54"] = 151,["55"] = 152,["56"] = 153,["57"] = 154,["58"] = 155,["59"] = 156,["60"] = 157,["61"] = 158,["62"] = 159,["67"] = 138,["68"] = 169,["69"] = 170,["72"] = 173,["75"] = 176,["76"] = 177,["77"] = 178,["78"] = 179,["79"] = 180,["80"] = 181,["83"] = 184,["84"] = 185,["86"] = 188,["87"] = 189,["88"] = 190,["89"] = 190,["90"] = 190,["91"] = 191,["92"] = 190,["93"] = 190,["95"] = 195,["97"] = 195,["99"] = 197,["100"] = 198,["102"] = 201,["103"] = 169,["104"] = 220,["105"] = 221,["106"] = 220,["107"] = 224,["108"] = 225,["109"] = 226,["110"] = 224,["111"] = 230,["112"] = 231,["113"] = 232,["115"] = 234,["116"] = 234,["117"] = 235,["119"] = 237,["120"] = 230,["121"] = 244,["122"] = 245,["125"] = 249,["126"] = 250,["127"] = 251,["128"] = 252,["131"] = 256,["132"] = 257,["134"] = 259,["136"] = 259,["138"] = 244,["139"] = 285,["140"] = 286,["141"] = 285,["142"] = 289,["143"] = 289,["144"] = 289,["146"] = 290,["147"] = 291,["149"] = 293,["150"] = 289,["151"] = 441,["152"] = 441,["153"] = 441,["155"] = 442,["156"] = 443,["157"] = 444,["159"] = 446,["160"] = 441,["161"] = 474,["162"] = 474,["163"] = 474,["165"] = 475,["166"] = 476,["167"] = 477,["169"] = 474,["170"] = 507,["171"] = 508,["172"] = 509,["173"] = 510,["175"] = 512,["176"] = 513,["177"] = 514,["178"] = 507,["179"] = 521,["180"] = 522,["181"] = 521,["182"] = 525,["183"] = 526,["184"] = 527,["185"] = 528,["187"] = 530,["188"] = 525,["189"] = 537,["190"] = 538,["191"] = 537,["192"] = 541,["193"] = 542,["194"] = 541,["195"] = 549,["196"] = 550,["197"] = 549,["198"] = 553,["199"] = 554,["200"] = 553,["201"] = 561,["202"] = 562,["203"] = 561,["204"] = 565,["205"] = 565,["206"] = 565,["208"] = 566,["209"] = 567,["210"] = 568,["212"] = 571,["213"] = 572,["215"] = 574,["216"] = 575,["218"] = 577,["219"] = 579,["220"] = 579,["221"] = 579,["222"] = 580,["223"] = 579,["224"] = 579,["226"] = 583,["227"] = 584,["229"] = 586,["230"] = 587,["232"] = 589,["233"] = 591,["234"] = 591,["235"] = 591,["236"] = 592,["237"] = 591,["238"] = 591,["240"] = 595,["241"] = 565,["242"] = 603,["243"] = 604,["244"] = 605,["246"] = 607,["247"] = 603,["248"] = 614,["249"] = 615,["250"] = 614,["251"] = 621,["252"] = 622,["253"] = 621,["254"] = 630,["255"] = 631,["256"] = 632,["258"] = 634,["259"] = 630,["260"] = 641,["261"] = 642,["262"] = 641,["263"] = 648,["264"] = 649,["265"] = 648,["266"] = 657,["267"] = 658,["268"] = 659,["270"] = 661,["271"] = 657,["272"] = 668,["273"] = 669,["274"] = 668,["275"] = 675,["276"] = 676,["277"] = 675,["278"] = 684,["279"] = 685,["280"] = 684,["281"] = 688,["282"] = 689,["283"] = 688,["284"] = 693,["285"] = 694,["286"] = 696,["287"] = 693,["288"] = 699,["289"] = 700,["290"] = 699,["291"] = 707,["292"] = 708,["293"] = 709,["294"] = 707,["295"] = 715,["296"] = 716,["297"] = 716,["298"] = 716,["299"] = 716,["300"] = 715,["301"] = 720,["302"] = 721,["303"] = 720,["304"] = 724,["305"] = 725,["306"] = 724,["307"] = 729,["308"] = 729,["309"] = 739,["310"] = 741,["311"] = 742,["312"] = 743,["313"] = 744,["316"] = 747,["317"] = 748,["318"] = 748,["319"] = 748,["320"] = 748,["321"] = 748,["322"] = 748,["323"] = 748,["324"] = 748,["325"] = 748,["326"] = 749,["327"] = 750,["328"] = 751,["330"] = 754,["331"] = 755,["333"] = 760,["334"] = 739,["335"] = 763,["336"] = 764,["339"] = 767,["341"] = 767,["342"] = 767,["343"] = 767,["344"] = 767,["345"] = 767,["346"] = 767,["347"] = 767,["349"] = 769,["350"] = 763,["351"] = 772,["352"] = 773,["355"] = 776,["356"] = 777,["357"] = 778,["358"] = 780,["360"] = 782,["361"] = 783,["362"] = 784,["363"] = 785,["364"] = 787,["367"] = 772,["368"] = 795,["369"] = 796,["370"] = 795,["371"] = 803,["372"] = 803,["373"] = 803,["375"] = 805,["378"] = 808,["379"] = 809,["380"] = 810,["381"] = 811,["385"] = 816,["386"] = 817,["388"] = 819,["389"] = 820,["390"] = 821,["392"] = 821,["394"] = 822,["396"] = 822,["398"] = 823,["399"] = 824,["400"] = 825,["402"] = 827,["404"] = 829,["405"] = 830,["406"] = 831,["408"] = 833,["409"] = 834,["410"] = 835,["411"] = 836,["413"] = 839,["414"] = 840,["415"] = 842,["416"] = 842,["417"] = 842,["418"] = 842,["419"] = 842,["420"] = 842,["423"] = 845,["424"] = 846,["425"] = 847,["426"] = 803,["427"] = 854,["428"] = 855,["429"] = 855,["430"] = 855,["431"] = 857,["432"] = 855,["433"] = 855,["434"] = 854,["435"] = 51,["436"] = 52,["441"] = 209,["450"] = 213,["452"] = 216,["453"] = 217,["463"] = 264,["464"] = 265,["466"] = 267,["468"] = 270,["469"] = 271,["478"] = 278,["486"] = 300,["495"] = 304,["497"] = 307,["498"] = 308,["501"] = 311,["502"] = 312,["503"] = 313,["505"] = 313,["507"] = 316,["508"] = 318,["509"] = 319,["510"] = 320,["511"] = 321,["512"] = 321,["513"] = 321,["514"] = 322,["515"] = 321,["516"] = 321,["519"] = 326,["520"] = 328,["521"] = 329,["523"] = 332,["524"] = 334,["525"] = 336,["526"] = 337,["527"] = 337,["528"] = 337,["529"] = 337,["530"] = 338,["532"] = 338,["533"] = 338,["534"] = 338,["535"] = 338,["536"] = 338,["538"] = 337,["539"] = 337,["541"] = 343,["542"] = 346,["544"] = 349,["554"] = 359,["562"] = 366,["570"] = 373,["571"] = 374,["573"] = 376,["574"] = 376,["575"] = 377,["576"] = 378,["578"] = 380,["586"] = 387,["594"] = 394,["602"] = 401,["610"] = 408,["619"] = 465,["621"] = 452,["622"] = 453,["623"] = 454,["624"] = 455,["626"] = 457,["628"] = 457,["640"] = 482,["642"] = 485,["643"] = 486,["646"] = 489,["647"] = 490,["648"] = 492,["649"] = 493,["651"] = 495,["653"] = 495,["655"] = 497,["660"] = 865,["661"] = 866,["662"] = 867});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____ObjectTemplateUtil = require("solar.solar-common.util.object.ObjectTemplateUtil")
local ObjectTemplateUtil = ____ObjectTemplateUtil.default
local ____LangUtil = require("solar.solar-common.util.lang.LangUtil")
local LangUtil = ____LangUtil.default
local ____STimer = require("solar.solar-common.tool.STimer")
local STimer = ____STimer.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____FrameControl = require("solar.solar-common.framex.control.FrameControl")
local FrameControl = ____FrameControl.default
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local index = 0
____exports.default = __TS__Class()
local Actor = ____exports.default
Actor.name = "Actor"
function Actor.prototype.____constructor(self, actorTypeId)
    local ____index_0 = index
    index = ____index_0 + 1
    self.uuid = "sa" .. tostring(____index_0)
    self.updating = false
    self._sl_level = 0
    self._sl_isInitializedOnUnitInRangeEvent = false
    self._sl_lastReadyTime = {}
    self.childDestroyList = {}
    self.data = {}
    self.extData = {}
    self._sl_isInitialized = false
    self._sl_isDestroyed = false
    self._actorType = DataBase:getSolarActorType(actorTypeId)
    if self._actorType == nil then
        log.errorWithTraceBack("不能创建不存在的演员类型:" .. tostring(actorTypeId))
        return
    end
    if self._actorType.attribute then
        self._attribute = __TS__ObjectAssign({}, self._actorType.attribute)
        ____exports.default._sl_needUpdateAttribute = true
    end
    ____exports.default.allActors[self.uuid] = self
    if self.templateCacheKey == nil then
        if self._actorType.templateAllocPolicy == "actorTypeShare" then
            self.templateCacheKey = "_sltap_ats:" .. self._actorType.id
        elseif self._actorType.templateAllocPolicy == "templateTypeShare" then
            self.templateCacheKey = "_sltap_tts:" .. self._actorType.templateType
        elseif self._actorType.templateType == "建造者" then
            local builds = self._actorType.builds
            if builds then
                self.templateCacheKey = "_sltap_jzz:"
                for ____, build in ipairs(builds) do
                    self.templateCacheKey = (self.templateCacheKey .. ":") .. build
                end
            end
        end
    end
end
function Actor.prototype._sl_init(self)
    if self._sl_isInitialized then
        return
    end
    if self._actorType == nil then
        return
    end
    self._sl_isInitialized = true
    self.creationTime = _g_time / 1000
    for key in pairs(self._actorType) do
        local value = self._actorType[key]
        if not LangUtil:isFunction(value) and "attribute" ~= key then
            self:_sl_rawset(key, value)
        end
    end
    if self._actorType.name == nil then
        self:setName(self._actorType.id)
    end
    local timeoutS = self:get("interval")
    if timeoutS ~= nil and timeoutS > 0 and self:get("onInterval") ~= nil then
        self:startIntervalTimer(
            timeoutS,
            function()
                self:interval()
            end
        )
    end
    local ____opt_1 = self:get("onCreated")
    if ____opt_1 ~= nil then
        ____opt_1(nil, self)
    end
    for ____, listner in ipairs(____exports.default._sl_anyActorCreatedListeners) do
        listner(nil, self)
    end
    self.level = 1
end
function Actor.prototype._sl_rawset(self, key, value)
    ____exports.default._sl_needUpdateAttribute = true
end
function Actor.prototype.set(self, key, value)
    self.data[key] = value
    self:_sl_rawset(key, value)
end
function Actor.prototype.get(self, key, defaultValue)
    if self.data[key] ~= nil then
        return self.data[key]
    end
    local ____opt_3 = self._actorType
    if (____opt_3 and ____opt_3[key]) ~= nil then
        return self._actorType[key]
    end
    return defaultValue
end
function Actor.prototype.update(self)
    if self._sl_isDestroyed then
        return
    end
    for key in pairs(self._actorType) do
        local value = self._actorType[key]
        if not LangUtil:isFunction(value) and "attribute" ~= key then
            self:_sl_rawset(key, value)
        end
    end
    for dataKey in pairs(self.data) do
        self:_sl_rawset(dataKey, self.data[dataKey])
    end
    local ____opt_5 = self:get("onUpdate")
    if ____opt_5 ~= nil then
        ____opt_5(nil, self)
    end
end
function Actor.prototype.getTemplateType(self)
    return self:get("templateType")
end
function Actor.prototype.getAttribute(self, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    if not self._attribute and createDefault then
        self._attribute = {}
    end
    return self._attribute
end
function Actor.prototype.getRootFrameControl(self, createDefault, parent)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_rootFrameControl == nil then
        self._sl_rootFrameControl = __TS__New(FrameControl, parent)
        self._sl_rootFrameControl.rootFrame:setSize(0.04, 0.04)
    end
    return self._sl_rootFrameControl
end
function Actor.prototype.ifReady(self, timeSec, onReady, timerKey)
    if timerKey == nil then
        timerKey = "base"
    end
    if _g_time / 1000 - (self._sl_lastReadyTime[timerKey] or -10000) >= timeSec then
        self._sl_lastReadyTime[timerKey] = _g_time / 1000
        onReady(nil)
    end
end
function Actor.prototype.startIntervalTimer(self, timeoutS, handlerFunc)
    if self._sl_intervalTimer ~= nil then
        log.errorWithTraceBack("已经启动过计时器了。 再启动新计时器请手动在外部自行管理。(有interval事件的演员会自动启动计时器!)")
        return nil
    end
    self._sl_intervalTimer = __TS__New(STimer)
    self._sl_intervalTimer:start(timeoutS, handlerFunc, true)
    return self._sl_intervalTimer
end
function Actor.prototype.setName(self, name)
    self:set("name", name)
end
function Actor.prototype.getName(self)
    local name = self:get("name")
    if name == nil then
        return self.actorTypeId
    end
    return name
end
function Actor.prototype.setIcon(self, icon)
    self:set("icon", icon)
end
function Actor.prototype.getIcon(self)
    return self:get("icon")
end
function Actor.prototype.setModel(self, model)
    self:set("model", model)
end
function Actor.prototype.getModel(self)
    return self:get("model")
end
function Actor.prototype.setDescribe(self, describe)
    self:set("describe", describe)
end
function Actor.prototype.getDescribe(self, includeExts)
    if includeExts == nil then
        includeExts = false
    end
    local realDescribe = self:get("describe", "")
    if includeExts == false then
        return realDescribe
    end
    if self.extDescribeFirst2 and #self.extDescribeFirst2 > 0 then
        realDescribe = (self.extDescribeFirst2 .. "|r|n") .. realDescribe
    end
    if self.extDescribeFirst1 and #self.extDescribeFirst1 > 0 then
        realDescribe = (self.extDescribeFirst1 .. "|r|n") .. realDescribe
    end
    if self._sl_extDescribesFirst then
        LangUtil:forEachSort(
            self._sl_extDescribesFirst,
            function(____, name, text)
                realDescribe = (tostring(name + text) .. "|r|n") .. realDescribe
            end
        )
    end
    if self.extDescribeLast1 and #self.extDescribeLast1 > 0 then
        realDescribe = realDescribe .. "|r|n" .. self.extDescribeLast1
    end
    if self.extDescribeLast2 and #self.extDescribeLast2 > 0 then
        realDescribe = realDescribe .. "|r|n" .. self.extDescribeLast2
    end
    if self._sl_extDescribes then
        LangUtil:forEachSort(
            self._sl_extDescribes,
            function(____, name, text)
                realDescribe = realDescribe .. ("|r|n" .. tostring(name)) .. tostring(text)
            end
        )
    end
    return realDescribe
end
function Actor.prototype.setExtDescribeFirst(self, name, text)
    if self._sl_extDescribesFirst == nil then
        self._sl_extDescribesFirst = {}
    end
    self._sl_extDescribesFirst[name] = text
end
function Actor.prototype.removeExtDescribeFirst(self, name)
    deleteKey(self._sl_extDescribesFirst, name)
end
function Actor.prototype.clearExtDescribesFirst(self)
    LangUtil:clearObject(self._sl_extDescribesFirst)
end
function Actor.prototype.setExtDescribe(self, name, text)
    if self._sl_extDescribes == nil then
        self._sl_extDescribes = {}
    end
    self._sl_extDescribes[name] = text
end
function Actor.prototype.removeExtDescribe(self, name)
    deleteKey(self._sl_extDescribes, name)
end
function Actor.prototype.clearExtDescribes(self)
    LangUtil:clearObject(self._sl_extDescribes)
end
function Actor.prototype.setExtAttribute(self, name, attribute)
    if self._sl_extAttributes == nil then
        self._sl_extAttributes = {}
    end
    self._sl_extAttributes[name] = attribute
end
function Actor.prototype.removeExtAttribute(self, name)
    deleteKey(self._sl_extAttributes, name)
end
function Actor.prototype.clearExtAttributes(self)
    LangUtil:clearObject(self._sl_extAttributes)
end
function Actor.prototype.setDur(self, dur)
    self:set("dur", dur)
end
function Actor.prototype.getDur(self)
    return self:get("dur")
end
function Actor.prototype.setDisable(self, disable)
    self:set("disable", disable)
    ____exports.default._sl_needUpdateAttribute = true
end
function Actor.prototype.isDisable(self)
    return self:get("disable", false)
end
function Actor.prototype.setXY(self, x, y)
    self:set("x", x)
    self:set("y", y)
end
function Actor.prototype.getXY(self)
    return {
        x = self:get("x"),
        y = self:get("y")
    }
end
function Actor.prototype.setHide(self, hide)
    self:set("hide", hide)
end
function Actor.prototype.isHide(self)
    return self:get("hide", false)
end
function Actor.prototype.clone(self)
end
function Actor.prototype.localClick(self, btn, x, y)
    if self._sl_rootFrameControl ~= nil then
        local disableFrame = self._sl_rootFrameControl:getDisableFrame(false)
        if (disableFrame and disableFrame.visible) == true then
            return false
        end
    end
    isAsync = true
    local ____opt_9 = self:get("onLocalClick")
    local b = ____opt_9 and ____opt_9(
        nil,
        self,
        btn,
        x,
        y,
        self.actorType
    )
    isAsync = false
    if b == false then
        return false
    end
    if self:get("onClick") ~= nil then
        SyncUtil.syncObjData("_sl_:a:onClick", {i = self.uuid, b = btn})
    end
    return true
end
function Actor.prototype.action(self, x, y, targetUnit)
    if self:isDisable() then
        return
    end
    local ____opt_11 = self:get("onAction")
    if ____opt_11 ~= nil then
        ____opt_11(
            nil,
            self,
            x,
            y,
            targetUnit
        )
    end
    ____exports.default._sl_needUpdateAttribute = true
end
function Actor.prototype.interval(self)
    if self:isDisable() then
        return
    end
    local onInterval = self:get("onInterval")
    if onInterval then
        onInterval(nil, self)
        ____exports.default._sl_needUpdateAttribute = true
    end
    if self._sl_unit ~= nil and UnitStateUtil:isAlive(self._sl_unit) then
        local onUnitInterval = self:get("onUnitInterval")
        if onUnitInterval then
            onUnitInterval(nil, self)
            ____exports.default._sl_needUpdateAttribute = true
        end
    end
end
function Actor.prototype.isDestroyed(self)
    return self._sl_isDestroyed
end
function Actor.prototype.destroy(self, forceDestroy)
    if forceDestroy == nil then
        forceDestroy = false
    end
    if self._sl_isDestroyed then
        return
    end
    local onDestroy = self:get("onDestroy")
    if onDestroy then
        local flag = onDestroy(nil, self)
        if flag == false and forceDestroy == false then
            return
        end
    end
    for ____, listener in ipairs(____exports.default._sl_anyActorDestroyListeners) do
        listener(nil, self)
    end
    self.unit = nil
    self._sl_isDestroyed = true
    local ____opt_13 = self.sTimer
    if ____opt_13 ~= nil then
        ____opt_13:destroy()
    end
    local ____opt_15 = self._sl_intervalTimer
    if ____opt_15 ~= nil then
        ____opt_15:destroy()
    end
    if self.childDestroyList and #self.childDestroyList > 0 then
        for ____, destroyable in ipairs(self.childDestroyList) do
            destroyable:destroy()
        end
        self.childDestroyList = nil
    end
    if self.effect then
        DestroyEffect(self.effect)
        self.effect = nil
    end
    if self._sl_rootFrameControl ~= nil then
        self._sl_rootFrameControl.rootFrame.visible = false
        self._sl_rootFrameControl:destroy()
        self._sl_rootFrameControl = nil
    end
    if self.templateId ~= nil then
        if self:getTemplateType() ~= nil then
            ObjectTemplateUtil:returnTemplate(
                self:getTemplateType(),
                self.templateId,
                self.templateCacheKey,
                self.uuid
            )
        end
    end
    self.solarData = nil
    deleteKey(____exports.default.allActors, self.uuid)
    ____exports.default._sl_needUpdateAttribute = true
end
function Actor.prototype.destroyLater(self, timeOut)
    BaseUtil.runLater(
        timeOut,
        function()
            self:destroy()
        end
    )
end
Actor._sl_needUpdateAttribute = false
Actor.allActors = {}
__TS__SetDescriptor(
    Actor.prototype,
    "actorType",
    {get = function(self)
        return self._actorType
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "solarData",
    {
        get = function(self)
            return DataBase:getSolarActorSolarData(self.uuid)
        end,
        set = function(self, obj)
            DataBase:setSolarActorSolarData(self.uuid, obj)
        end
    },
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "attribute",
    {
        get = function(self)
            if self:isDisable() then
                return nil
            end
            return self._attribute
        end,
        set = function(self, value)
            self._attribute = value
        end
    },
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "actorTypeId",
    {get = function(self)
        return self._actorType.id
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "lastUnit",
    {get = function(self)
        return self._sl_lastUnit
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unit",
    {
        get = function(self)
            return self._sl_unit
        end,
        set = function(self, value)
            if self._sl_isDestroyed then
                return
            end
            local oldUnit = self._sl_unit
            self._sl_unit = value
            local ____opt_17 = self:get("onUnitChange")
            if ____opt_17 ~= nil then
                ____opt_17(nil, self, value, oldUnit)
            end
            if self._sl_intervalTimer == nil then
                if self:get("onUnitInterval") ~= nil and IsHandle(self._sl_unit) then
                    local timeoutS = self:get("interval")
                    if timeoutS ~= nil and timeoutS > 0 then
                        self:startIntervalTimer(
                            timeoutS,
                            function()
                                self:interval()
                            end
                        )
                    end
                end
            elseif value == nil and self:get("onUnitInterval") ~= nil and self:get("onInterval") == nil then
                self._sl_intervalTimer:destroy()
                self._sl_intervalTimer = nil
            end
            if IsHandle(self._sl_unit) then
                if self._sl_isInitializedOnUnitInRangeEvent == false and self.actorType.onUnitInRange ~= nil and self:get("unitInRangeValue") ~= nil then
                    self._sl_isInitializedOnUnitInRangeEvent = true
                    se:onUnitInRange(
                        value,
                        self:get("unitInRangeValue"),
                        function()
                            local ____opt_19 = self:get("onUnitInRange")
                            if ____opt_19 ~= nil then
                                ____opt_19(
                                    nil,
                                    self,
                                    GetEnteringUnit()
                                )
                            end
                        end
                    )
                end
                se:emit("_sl_:单位获得演员", {u = self.unit, a = self})
                self._sl_lastUnit = self._sl_unit
            else
                se:emit("_sl_:单位失去演员", {u = self._sl_lastUnit, a = self})
            end
        end
    },
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitX",
    {get = function(self)
        return GetUnitX(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitY",
    {get = function(self)
        return GetUnitY(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitName",
    {get = function(self)
        if not IsHandle(self._sl_unit) then
            return nil
        end
        local ____opt_21 = DataBase:getUnitSolarData(self._sl_unit, false)
        local actor = ____opt_21 and ____opt_21._SL_solarActorUnit
        if actor ~= nil then
            return actor:getName()
        end
        return GetUnitName(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitLevel",
    {get = function(self)
        return GetUnitLevel(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitFacing",
    {get = function(self)
        return GetUnitFacing(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitOwner",
    {get = function(self)
        return GetOwningPlayer(self._sl_unit)
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "unitOwnerId",
    {get = function(self)
        return GetPlayerId(GetOwningPlayer(self._sl_unit))
    end},
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "numberOverlay",
    {
        get = function(self)
            return self._sl_numberOverlay
        end,
        set = function(self, num)
            self._sl_numberOverlay = num
            if num then
                self:getRootFrameControl():setNumberOverlayText("" .. tostring(num))
            else
                local ____opt_23 = self:getRootFrameControl(false)
                if ____opt_23 ~= nil then
                    ____opt_23:setNumberOverlayText(nil)
                end
            end
        end
    },
    true
)
__TS__SetDescriptor(
    Actor.prototype,
    "level",
    {
        get = function(self)
            return self._sl_level
        end,
        set = function(self, value)
            if value == nil then
                return
            end
            local delta = value - (self._sl_level or 0)
            self._sl_level = value
            for ____, listener in ipairs(____exports.default._sl_anyActorLevelChangeListeners) do
                listener(nil, self, delta)
            end
            local ____opt_25 = self:get("onActorLevelChange")
            if ____opt_25 ~= nil then
                ____opt_25(nil, self, delta)
            end
            ____exports.default._sl_needUpdateAttribute = true
        end
    },
    true
)
Actor._sl_anyActorCreatedListeners = {}
Actor._sl_anyActorLevelChangeListeners = {}
Actor._sl_anyActorDestroyListeners = {}
return ____exports
