local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__InstanceOf = ____lualib.__TS__InstanceOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 5,["16"] = 5,["17"] = 6,["18"] = 6,["19"] = 7,["20"] = 7,["21"] = 8,["22"] = 8,["23"] = 9,["24"] = 9,["25"] = 10,["26"] = 10,["27"] = 11,["28"] = 11,["29"] = 13,["30"] = 13,["31"] = 15,["32"] = 15,["33"] = 17,["34"] = 17,["35"] = 18,["36"] = 18,["37"] = 19,["38"] = 19,["39"] = 20,["40"] = 20,["41"] = 21,["42"] = 21,["43"] = 23,["44"] = 23,["45"] = 25,["46"] = 25,["47"] = 25,["49"] = 39,["50"] = 40,["53"] = 43,["56"] = 46,["57"] = 47,["58"] = 48,["59"] = 49,["60"] = 46,["61"] = 52,["62"] = 53,["63"] = 54,["66"] = 58,["68"] = 52,["69"] = 61,["70"] = 63,["71"] = 64,["72"] = 65,["73"] = 66,["75"] = 71,["76"] = 72,["77"] = 74,["78"] = 75,["79"] = 76,["80"] = 77,["81"] = 78,["86"] = 84,["87"] = 63,["90"] = 94,["91"] = 94,["93"] = 95,["94"] = 95,["95"] = 96,["96"] = 97,["97"] = 98,["98"] = 99,["99"] = 100,["100"] = 101,["101"] = 100,["102"] = 103,["103"] = 95,["106"] = 94,["110"] = 109,["111"] = 109,["112"] = 110,["113"] = 111,["114"] = 112,["115"] = 113,["116"] = 114,["117"] = 113,["118"] = 116,["119"] = 109,["122"] = 119,["123"] = 120,["124"] = 121,["126"] = 119,["127"] = 124,["128"] = 124,["129"] = 124,["130"] = 125,["131"] = 126,["132"] = 127,["133"] = 128,["135"] = 124,["136"] = 124,["137"] = 38,["138"] = 134,["139"] = 135,["140"] = 136,["142"] = 138,["143"] = 139,["144"] = 140,["146"] = 142,["147"] = 143,["148"] = 134,["149"] = 147,["150"] = 148,["151"] = 149,["154"] = 152,["155"] = 153,["156"] = 154,["157"] = 155,["158"] = 156,["159"] = 157,["161"] = 147,["162"] = 161,["163"] = 162,["164"] = 163,["167"] = 167,["168"] = 169,["169"] = 170,["170"] = 171,["173"] = 174,["174"] = 180,["175"] = 181,["176"] = 182,["178"] = 184,["179"] = 185,["181"] = 187,["182"] = 188,["185"] = 191,["187"] = 161,["188"] = 195,["189"] = 196,["190"] = 197,["191"] = 197,["192"] = 197,["193"] = 197,["194"] = 198,["197"] = 201,["198"] = 202,["199"] = 203,["200"] = 204,["201"] = 195,["202"] = 207,["203"] = 208,["204"] = 209,["205"] = 210,["206"] = 211,["207"] = 212,["209"] = 214,["210"] = 207,["211"] = 217,["212"] = 218,["213"] = 219,["214"] = 220,["216"] = 222,["219"] = 225,["220"] = 225,["221"] = 225,["222"] = 226,["223"] = 227,["224"] = 225,["225"] = 225,["226"] = 217,["227"] = 232,["228"] = 234,["230"] = 235,["231"] = 235,["232"] = 236,["233"] = 237,["234"] = 238,["235"] = 239,["236"] = 240,["237"] = 241,["240"] = 244,["241"] = 246,["242"] = 247,["243"] = 248,["244"] = 249,["245"] = 250,["247"] = 252,["248"] = 253,["249"] = 254,["250"] = 255,["252"] = 257,["255"] = 235,["258"] = 232,["259"] = 264,["261"] = 266,["262"] = 266,["264"] = 267,["265"] = 268,["266"] = 269,["267"] = 270,["268"] = 271,["269"] = 272,["271"] = 274,["273"] = 276,["274"] = 276,["275"] = 276,["276"] = 276,["277"] = 277,["278"] = 278,["279"] = 279,["280"] = 280,["283"] = 283,["284"] = 285,["285"] = 286,["286"] = 287,["287"] = 288,["288"] = 289,["290"] = 291,["291"] = 292,["292"] = 293,["293"] = 294,["295"] = 296,["300"] = 266,["303"] = 264,["304"] = 303,["305"] = 305,["306"] = 306,["307"] = 307,["308"] = 308,["309"] = 308,["310"] = 308,["311"] = 309,["312"] = 310,["313"] = 310,["314"] = 310,["315"] = 310,["316"] = 308,["317"] = 308,["320"] = 316,["322"] = 317,["323"] = 318,["324"] = 319,["326"] = 321,["327"] = 322,["330"] = 325,["331"] = 326,["332"] = 327,["334"] = 329,["335"] = 330,["336"] = 331,["337"] = 332,["338"] = 333,["340"] = 335,["342"] = 338,["343"] = 339,["344"] = 340,["345"] = 341,["347"] = 343,["348"] = 344,["349"] = 345,["351"] = 347,["352"] = 348,["356"] = 303,["357"] = 30,["358"] = 32,["359"] = 33,["360"] = 34,["361"] = 36});
local ____exports = {}
local ____FrameCallbackUtil = require("solar.solar-common.util.frame.FrameCallbackUtil")
local FrameCallbackUtil = ____FrameCallbackUtil.default
local ____ActorItemUtil = require("solar.solar-common.actor.util.ActorItemUtil")
local ActorItemUtil = ____ActorItemUtil.default
local ____AbilityButtonUtil = require("solar.solar-common.util.ability.AbilityButtonUtil")
local AbilityButtonUtil = ____AbilityButtonUtil.default
local ____ActorAbilityUtil = require("solar.solar-common.actor.util.ActorAbilityUtil")
local ActorAbilityUtil = ____ActorAbilityUtil.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____ActorUnit = require("solar.solar-common.actor.ActorUnit")
local ActorUnit = ____ActorUnit.default
local ____CameraUtil = require("solar.solar-common.util.game.CameraUtil")
local CameraUtil = ____CameraUtil.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____GameUtil = require("solar.solar-common.util.game.GameUtil")
local GameUtil = ____GameUtil.default
local ____ActorFrameUtil = require("solar.solar-common.actor.util.ActorFrameUtil")
local ActorFrameUtil = ____ActorFrameUtil.default
local ____InputUtil = require("solar.solar-common.util.system.InputUtil")
local InputUtil = ____InputUtil.default
local ____ActorAbility = require("solar.solar-common.actor.ActorAbility")
local ActorAbility = ____ActorAbility.default
local ____MessageUtil = require("solar.solar-common.util.system.MessageUtil")
local MessageUtil = ____MessageUtil.default
local ____NativeFrameUtil = require("solar.solar-common.util.frame.NativeFrameUtil")
local NativeFrameUtil = ____NativeFrameUtil.default
local ____ActorUnitUtil = require("solar.solar-common.actor.util.ActorUnitUtil")
local ActorUnitUtil = ____ActorUnitUtil.default
local ____ActorTypeBuildUtil = require("solar.solar-common.actor.util.ActorTypeBuildUtil")
local ActorTypeBuildUtil = ____ActorTypeBuildUtil.default
local ____ObjectDataUtil = require("solar.solar-common.util.object.ObjectDataUtil")
local ObjectDataUtil = ____ObjectDataUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
____exports.default = __TS__Class()
local SolarActorFrameState = ____exports.default
SolarActorFrameState.name = "SolarActorFrameState"
function SolarActorFrameState.prototype.____constructor(self)
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new SolarActorFrameState()")
        return
    end
    if DzFrameGetCommandBarButton == nil then
        return
    end
    FrameCallbackUtil:addFrameSetUpdateCallback(function()
        ____exports.default:updateItemFrame()
        ____exports.default:updateAbilityFrame()
        ____exports.default:updateUnitFrame()
    end)
    InputUtil:onMouseRightButtonReleased(function()
        if ____exports.default.mouseFocusActor then
            if ____exports.default.mouseFocusActor:isDisable() or ____exports.default.mouseFocusActor:isHide() then
                return
            end
            ____exports.default.mouseFocusActor:localClick(2, 0, 0)
        end
    end)
    if isEmbedJapi then
        MessageUtil:addWindowEventCallBack(function(eventId)
            if eventId == 1 then
                local actor = ____exports.default.mouseFocusActor
                if actor == nil then
                end
                if actor ~= nil and __TS__InstanceOf(actor, ActorAbility) then
                    if actor:isPassive() or actor:isDisable() or actor:isHide() then
                        local sceneX = InputUtil:getMouseSceneX()
                        local sceneY = InputUtil:getMouseSceneY()
                        local xyObj = AbilityButtonUtil:getPosBySceneXY(sceneX, sceneY)
                        if xyObj ~= nil then
                            return true
                        end
                    end
                end
            end
            return false
        end)
    end
    do
        local x = 0
        while x <= 3 do
            do
                local y = 0
                while y <= 2 do
                    local cmdButton = DzFrameGetCommandBarButton(y, x)
                    local cmdButtonFrame = Frame:fromHandle(cmdButton)
                    local fx = x
                    local fy = y
                    cmdButtonFrame:addOnMouseEnter(function()
                        ____exports.default.showCommandBarButtonActorTooltip(fx, fy)
                    end)
                    cmdButtonFrame:addOnMouseLeave(____exports.default.hideTooltip)
                    y = y + 1
                end
            end
            x = x + 1
        end
    end
    do
        local i = 0
        while i < 6 do
            local cmdButton = DzFrameGetItemBarButton(i)
            local cmdButtonFrame = Frame:fromHandle(cmdButton)
            local fi = i
            cmdButtonFrame:addOnMouseEnter(function()
                ____exports.default.showItemTooltip(fi)
            end)
            cmdButtonFrame:addOnMouseLeave(____exports.default.hideTooltip)
            i = i + 1
        end
    end
    se:onUnitSelected(function(e)
        if ____exports.default._sl_mouseFocusItemIndex >= 0 then
            ____exports.default.showItemTooltip(____exports.default._sl_mouseFocusItemIndex)
        end
    end)
    se:on(
        "刷新UI",
        function()
            if ____exports.default._sl_mouseFocusItemIndex >= 0 then
                ____exports.default.showItemTooltip(____exports.default._sl_mouseFocusItemIndex)
            elseif ____exports.default.mouseFocusActor ~= nil then
                ActorFrameUtil:showTooltip(____exports.default.mouseFocusActor)
            end
        end
    )
end
function SolarActorFrameState.getMouseFocusItem(self)
    if ____exports.default._sl_mouseFocusItemIndex < 0 then
        return nil
    end
    local u = selection()
    if not IsHandle(u) then
        return nil
    end
    local item = UnitItemInSlot(u, ____exports.default._sl_mouseFocusItemIndex)
    return ActorItemUtil:getActorItem(item)
end
function SolarActorFrameState.showItemTooltip(i)
    local u = selection()
    if not IsHandle(u) then
        return
    end
    ____exports.default._sl_mouseFocusItemIndex = i
    local item = UnitItemInSlot(u, i)
    local actorItem = ActorItemUtil:getActorItem(item)
    if actorItem ~= nil then
        ActorFrameUtil:showTooltip(actorItem)
        ____exports.default:_sl_startUpdateActorFrameTooltipTimer(actorItem)
    end
end
function SolarActorFrameState.showCommandBarButtonActorTooltip(x, y)
    local ability, order, arg = button(x, y)
    if ability == nil or ability == 0 then
        return
    end
    if (1096114805 == ability or 1095262837 == ability) and arg == 8 then
        local unitIdStr = id2string(order)
        local zwActorType = ActorTypeBuildUtil.zwId2UnitIdMap[unitIdStr]
        if zwActorType == nil then
            return
        end
        local info = {name = zwActorType.name or zwActorType.id, icon = zwActorType.icon, describe = zwActorType.describe}
        local hotKey = ObjectDataUtil:getUnitDataString(unitIdStr, "Hotkey")
        if hotKey ~= nil and #hotKey > 0 then
            info.hotKey = hotKey
        end
        if zwActorType.requiredTip ~= nil and ActorTypeBuildUtil:isLocalPlayerActorUnitTypeDisableState(zwActorType.id) then
            info.requiredTip = zwActorType.requiredTip
        end
        info.labelInfos = ActorFrameUtil:getActorTypeLabelInfo(zwActorType)
        ActorFrameUtil:showTooltipByInfo(info)
        return
    else
        ____exports.default.showAbilityTooltip(ability)
    end
end
function SolarActorFrameState.showAbilityTooltip(ability)
    local abilityIdStr = id2string(ability)
    local actorAbility = ActorAbilityUtil:getActorAbilityByBaseId(
        abilityIdStr,
        selection()
    )
    if actorAbility == nil then
        return
    end
    ____exports.default._sl_mouseFocusItemIndex = -1
    ____exports.default.mouseFocusActor = actorAbility
    ActorFrameUtil:showTooltip(actorAbility)
    ____exports.default:_sl_startUpdateActorFrameTooltipTimer(actorAbility)
end
function SolarActorFrameState.hideTooltip()
    ActorFrameUtil:hideTooltip()
    ____exports.default.mouseFocusActor = nil
    if ____exports.default._sl_updateActorFrameTooltipTimer then
        ____exports.default._sl_updateActorFrameTooltipTimer:destroy()
        ____exports.default._sl_updateActorFrameTooltipTimer = nil
    end
    ____exports.default._sl_mouseFocusItemIndex = -1
end
function SolarActorFrameState._sl_startUpdateActorFrameTooltipTimer(self, showTooltipActor)
    if ____exports.default._sl_updateActorFrameTooltipTimer then
        ____exports.default._sl_updateActorFrameTooltipTimer:destroy()
        ____exports.default._sl_updateActorFrameTooltipTimer = nil
    end
    if showTooltipActor == nil then
        return
    end
    ____exports.default._sl_updateActorFrameTooltipTimer = BaseUtil.onTimer(
        1,
        function()
            ActorFrameUtil:showTooltip(showTooltipActor)
            return true
        end
    )
end
function SolarActorFrameState.updateItemFrame(self)
    local unit = selection()
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(unit, i)
            local actorItem = ActorItemUtil:getActorItem(item)
            if actorItem == nil then
                if ____exports.default.itemBarButtonActorFrames[i] then
                    ____exports.default.itemBarButtonActorFrames[i].rootFrame.visible = false
                    ____exports.default.itemBarButtonActorFrames[i] = nil
                end
            else
                local buttonFrame = DzFrameGetItemBarButton(i)
                local frame = actorItem:getRootFrameControl(false)
                if frame ~= ____exports.default.itemBarButtonActorFrames[i] then
                    if ____exports.default.itemBarButtonActorFrames[i] then
                        ____exports.default.itemBarButtonActorFrames[i].rootFrame.visible = false
                        ____exports.default.itemBarButtonActorFrames[i] = nil
                    end
                    if frame then
                        frame.rootFrame:clearPoints()
                        frame.rootFrame:setAllPoints(buttonFrame)
                        frame.rootFrame.visible = true
                    end
                    ____exports.default.itemBarButtonActorFrames[i] = frame
                end
            end
            i = i + 1
        end
    end
end
function SolarActorFrameState.updateAbilityFrame(self)
    do
        local i = 1
        while i <= 12 do
            do
                local pos = AbilityButtonUtil:getPosByNumber(i)
                local button_abilityId, orderID, orderType = button(pos.x, pos.y)
                if button_abilityId == nil or button_abilityId == 0 then
                    if ____exports.default.commandBarButtonActorFrames[i] then
                        ____exports.default.commandBarButtonActorFrames[i].rootFrame.visible = false
                        ____exports.default.commandBarButtonActorFrames[i] = nil
                    end
                    goto __continue61
                end
                local actorAbility = ActorAbilityUtil:getActorAbilityByBaseId(
                    id2string(button_abilityId),
                    selection()
                )
                if actorAbility == nil then
                    if ____exports.default.commandBarButtonActorFrames[i] then
                        ____exports.default.commandBarButtonActorFrames[i].rootFrame.visible = false
                        ____exports.default.commandBarButtonActorFrames[i] = nil
                    end
                else
                    local buttonFrame = DzFrameGetCommandBarButton(pos.y, pos.x)
                    local frame = actorAbility:getRootFrameControl(false)
                    if frame ~= ____exports.default.commandBarButtonActorFrames[i] then
                        if ____exports.default.commandBarButtonActorFrames[i] then
                            ____exports.default.commandBarButtonActorFrames[i].rootFrame.visible = false
                            ____exports.default.commandBarButtonActorFrames[i] = nil
                        end
                        if frame then
                            frame.rootFrame:clearPoints()
                            frame.rootFrame:setAllPoints(buttonFrame)
                            frame.rootFrame.visible = true
                        end
                        ____exports.default.commandBarButtonActorFrames[i] = frame
                    end
                end
            end
            ::__continue61::
            i = i + 1
        end
    end
end
function SolarActorFrameState.updateUnitFrame(self)
    if isEmbedJapi == false then
        local unit = selection()
        if IsHandle(unit) then
            ActorUnitUtil:ifHasActorUnit(
                unit,
                function(____, actor)
                    local simpleNameFrame = NativeFrameUtil:getUnitName()
                    DzFrameSetText(
                        simpleNameFrame,
                        actor:getName()
                    )
                end
            )
        end
    end
    for actorUuid in pairs(ActorUnit._sl_hasFrameActorUnits) do
        do
            local actorUnit = ActorUnit._sl_hasFrameActorUnits[actorUuid]
            if actorUnit == nil or actorUnit:isDestroyed() then
                goto __continue74
            end
            local rootFrame = actorUnit:getRootFrameControl(false)
            if rootFrame == nil then
                return
            end
            if not UnitAlive(actorUnit.unit) then
                rootFrame.rootFrame.visible = false
                goto __continue74
            end
            local x = actorUnit.unitX
            local y = actorUnit.unitY
            local z = GameUtil:getTerrainHeight(x, y)
            if unit_overhead then
                z = z + unit_overhead(actorUnit.unit) - 50
            else
                z = z + 150
            end
            local scoordinates = CameraUtil:getScreenCoordinates(x, y, z)
            if scoordinates.x <= 0 or scoordinates.x >= 0.8 then
                rootFrame.rootFrame.visible = false
                goto __continue74
            end
            if scoordinates.y <= 0.13 or scoordinates.y >= 0.56 then
                rootFrame.rootFrame.visible = false
                goto __continue74
            end
            rootFrame.rootFrame:setAbsPoint(FramePoint.bottom, scoordinates.x, scoordinates.y)
            rootFrame.rootFrame.visible = true
        end
        ::__continue74::
    end
end
SolarActorFrameState.mouseFocusActor = nil
SolarActorFrameState._sl_mouseFocusItemIndex = -1
SolarActorFrameState.commandBarButtonActorFrames = {}
SolarActorFrameState.itemBarButtonActorFrames = {}
SolarActorFrameState._sl_updateActorFrameTooltipTimer = nil
return ____exports
