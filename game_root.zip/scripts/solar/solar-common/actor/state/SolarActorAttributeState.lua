local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 5,["16"] = 5,["17"] = 6,["18"] = 6,["19"] = 7,["20"] = 7,["21"] = 8,["22"] = 8,["23"] = 9,["24"] = 9,["25"] = 12,["26"] = 12,["27"] = 13,["28"] = 13,["29"] = 15,["30"] = 15,["31"] = 15,["33"] = 31,["34"] = 32,["38"] = 36,["39"] = 37,["40"] = 38,["41"] = 39,["42"] = 41,["43"] = 42,["46"] = 45,["47"] = 46,["48"] = 48,["49"] = 49,["50"] = 48,["51"] = 39,["52"] = 54,["53"] = 54,["54"] = 54,["55"] = 56,["56"] = 57,["57"] = 58,["59"] = 54,["60"] = 54,["61"] = 62,["62"] = 63,["63"] = 64,["65"] = 62,["66"] = 67,["67"] = 68,["68"] = 69,["69"] = 69,["70"] = 69,["71"] = 70,["72"] = 69,["73"] = 69,["74"] = 67,["75"] = 73,["76"] = 75,["77"] = 76,["78"] = 76,["79"] = 76,["80"] = 77,["81"] = 76,["82"] = 76,["83"] = 73,["84"] = 30,["85"] = 83,["86"] = 85,["89"] = 88,["90"] = 89,["91"] = 89,["92"] = 90,["93"] = 91,["97"] = 95,["99"] = 100,["100"] = 101,["101"] = 102,["103"] = 105,["104"] = 106,["105"] = 108,["106"] = 110,["107"] = 83,["108"] = 118,["109"] = 119,["110"] = 120,["111"] = 122,["112"] = 124,["114"] = 124,["116"] = 124,["117"] = 125,["118"] = 126,["120"] = 129,["121"] = 130,["122"] = 131,["123"] = 132,["125"] = 134,["126"] = 135,["129"] = 139,["130"] = 140,["131"] = 141,["132"] = 142,["136"] = 146,["137"] = 147,["139"] = 148,["140"] = 148,["141"] = 149,["142"] = 150,["143"] = 151,["144"] = 151,["145"] = 152,["146"] = 153,["147"] = 154,["149"] = 156,["152"] = 148,["156"] = 161,["157"] = 118,["158"] = 24,["159"] = 25,["160"] = 27});
local ____exports = {}
local ____trigger = require("solar.solar-common.w3ts.handles.trigger")
local Trigger = ____trigger.Trigger
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____ActorBuffUtil = require("solar.solar-common.actor.util.ActorBuffUtil")
local ActorBuffUtil = ____ActorBuffUtil.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____AttributeUtil = require("solar.solar-common.util.system.AttributeUtil")
local AttributeUtil = ____AttributeUtil.default
local ____UnitAttributeState = require("solar.solar-common.attribute.UnitAttributeState")
local UnitAttributeState = ____UnitAttributeState.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____GameCenter = require("solar.solar-common.common.GameCenter")
local GameCenter = ____GameCenter.default
local ____ActorUtil = require("solar.solar-common.actor.util.ActorUtil")
local ActorUtil = ____ActorUtil.default
____exports.default = __TS__Class()
local SolarActorAttributeState = ____exports.default
SolarActorAttributeState.name = "SolarActorAttributeState"
function SolarActorAttributeState.prototype.____constructor(self)
    if SingletonUtil:notFirstTime(____exports.default) then
        print("不能重复new SolarActorAttributeState()")
        return
    end
    --- buff 属性更新到单位属性
    local trigger2 = __TS__New(Trigger)
    local noUpdateAttributeTime = 0
    trigger2:registerTimerEvent(0.99, true)
    trigger2:addAction(function()
        if Actor._sl_needUpdateAttribute == false and noUpdateAttributeTime < 5 then
            noUpdateAttributeTime = noUpdateAttributeTime + 1
            return
        end
        Actor._sl_needUpdateAttribute = false
        noUpdateAttributeTime = 0
        DataBase:forUnitSolarDatas(function(____, u, solarData)
            ____exports.default:refreshActorAttributes2UnitSolarAttribute(u)
        end)
    end)
    se:on(
        "属性刷新",
        function()
            local allUnits = GameCenter:getAllUnits()
            for ____, unitHandle in ipairs(allUnits) do
                ____exports.default:refreshActorAttributes2UnitSolarAttribute(unitHandle)
            end
        end
    )
    ActorBuffUtil:addAnyActorBuffCreatedListener(function(____, buff)
        if buff.attribute then
            ____exports.default:refreshActorAttributes2UnitSolarAttribute(buff.unit)
        end
    end)
    se:onUnitPickupItem(function(e)
        local trigUnit = e.trigUnit
        BaseUtil.runLater(
            0.1,
            function()
                ____exports.default:refreshActorAttributes2UnitSolarAttribute(trigUnit)
            end
        )
    end)
    se:onUnitDropItem(function(e)
        local trigUnit = e.trigUnit
        BaseUtil.runLater(
            0.1,
            function()
                ____exports.default:refreshActorAttributes2UnitSolarAttribute(trigUnit)
            end
        )
    end)
end
function SolarActorAttributeState.refreshActorAttributes2UnitSolarAttribute(self, unitHandle)
    if not UnitStateUtil:isAlive(unitHandle) then
        return
    end
    local attributes = ____exports.default:getUnitAllActorAttributes(unitHandle)
    local ____opt_0 = DataBase:getUnitSolarData(unitHandle, false)
    local oldAttr = ____opt_0 and ____opt_0._SL_totalActorsSolarAttribute
    if oldAttr == nil then
        if attributes == nil or #attributes == 0 then
            return
        end
    end
    local totalAttribute = AttributeUtil:sumAttributes(attributes)
    --- 属性 系统
    local solarData = DataBase:getUnitSolarData(unitHandle)
    if not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    AttributeUtil:subtract(solarData._SL_solarAttribute, oldAttr)
    AttributeUtil:add(solarData._SL_solarAttribute, totalAttribute)
    solarData._SL_totalActorsSolarAttribute = totalAttribute
    UnitAttributeState:refreshUnitSolarAttribute(unitHandle)
end
function SolarActorAttributeState.getUnitAllActorAttributes(self, unit)
    local attributeArray = nil
    local solarData = DataBase:getUnitSolarData(unit, false)
    if solarData ~= nil then
        local ____opt_2 = solarData._SL_solarActorUnit
        if ____opt_2 ~= nil then
            ____opt_2 = ____opt_2.attribute
        end
        local attribute = ____opt_2
        if attribute ~= nil then
            attributeArray = {attribute}
        end
        local actorAbilitys = solarData._SL_solarActorAbilitys
        if actorAbilitys ~= nil then
            if attributeArray == nil then
                attributeArray = {}
            end
            for abilityTemplateKey in pairs(actorAbilitys) do
                attributeArray = ActorUtil:collectActorAllAttributes(attributeArray, actorAbilitys[abilityTemplateKey])
            end
        end
        local _SL_solarActorBuffSet = solarData._SL_solarActorBuffs
        if _SL_solarActorBuffSet then
            for ____, actorBuff in ipairs(_SL_solarActorBuffSet) do
                attributeArray = ActorUtil:collectActorAllAttributes(attributeArray, actorBuff, ____exports.default.buffAttributeHandlers)
            end
        end
    end
    if ____exports.default.enableItemAttribute then
        local invSize = UnitInventorySize(unit)
        do
            local i = 0
            while i < invSize do
                local item = UnitItemInSlot(unit, i)
                if IsHandle(item) then
                    local ____opt_4 = DataBase:getItemSolarData(item, false)
                    local actorItem = ____opt_4 and ____opt_4._SL_solarActorItem
                    if actorItem and actorItem.attribute ~= nil then
                        if attributeArray == nil then
                            attributeArray = {}
                        end
                        attributeArray = ActorUtil:collectActorAllAttributes(attributeArray, actorItem, ____exports.default.itemAttributeHandlers)
                    end
                end
                i = i + 1
            end
        end
    end
    return attributeArray
end
SolarActorAttributeState.itemAttributeHandlers = {}
SolarActorAttributeState.buffAttributeHandlers = {}
SolarActorAttributeState.enableItemAttribute = true
return ____exports
