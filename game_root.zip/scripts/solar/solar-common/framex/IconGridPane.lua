local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__InstanceOf = ____lualib.__TS__InstanceOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["9"] = 1,["10"] = 1,["11"] = 2,["12"] = 2,["13"] = 3,["14"] = 3,["15"] = 4,["16"] = 4,["17"] = 5,["18"] = 5,["19"] = 6,["20"] = 6,["21"] = 7,["22"] = 7,["23"] = 8,["24"] = 8,["25"] = 9,["26"] = 9,["27"] = 10,["28"] = 10,["29"] = 11,["30"] = 11,["31"] = 12,["32"] = 12,["33"] = 13,["34"] = 13,["35"] = 31,["36"] = 31,["37"] = 31,["38"] = 95,["39"] = 95,["40"] = 95,["42"] = 41,["43"] = 42,["44"] = 44,["45"] = 44,["46"] = 44,["47"] = 44,["48"] = 44,["49"] = 44,["50"] = 44,["51"] = 49,["52"] = 55,["53"] = 57,["54"] = 59,["55"] = 61,["56"] = 61,["57"] = 61,["58"] = 61,["59"] = 61,["60"] = 61,["61"] = 61,["62"] = 61,["63"] = 61,["64"] = 61,["65"] = 61,["66"] = 61,["67"] = 61,["68"] = 61,["69"] = 61,["70"] = 61,["71"] = 61,["72"] = 61,["73"] = 61,["74"] = 61,["75"] = 61,["76"] = 91,["77"] = 93,["78"] = 406,["79"] = 96,["80"] = 97,["81"] = 98,["82"] = 95,["83"] = 101,["84"] = 101,["85"] = 101,["87"] = 101,["88"] = 101,["90"] = 101,["91"] = 101,["93"] = 102,["94"] = 103,["95"] = 104,["96"] = 105,["97"] = 106,["99"] = 108,["100"] = 111,["101"] = 112,["102"] = 113,["103"] = 114,["105"] = 117,["107"] = 119,["108"] = 120,["109"] = 121,["110"] = 122,["111"] = 123,["113"] = 119,["114"] = 126,["115"] = 126,["116"] = 126,["117"] = 127,["118"] = 128,["120"] = 126,["121"] = 126,["122"] = 131,["123"] = 132,["124"] = 133,["125"] = 134,["126"] = 101,["127"] = 137,["128"] = 138,["130"] = 140,["131"] = 141,["132"] = 142,["135"] = 145,["136"] = 145,["137"] = 146,["138"] = 146,["139"] = 145,["142"] = 148,["143"] = 149,["144"] = 149,["146"] = 152,["147"] = 153,["150"] = 156,["153"] = 159,["157"] = 162,["158"] = 162,["159"] = 163,["160"] = 164,["161"] = 165,["162"] = 165,["164"] = 162,["167"] = 152,["168"] = 169,["169"] = 170,["170"] = 171,["171"] = 172,["173"] = 173,["174"] = 173,["175"] = 173,["176"] = 173,["177"] = 174,["180"] = 176,["181"] = 176,["182"] = 177,["183"] = 178,["184"] = 179,["185"] = 179,["187"] = 176,["195"] = 185,["197"] = 186,["198"] = 186,["199"] = 187,["201"] = 188,["202"] = 188,["203"] = 189,["204"] = 190,["205"] = 191,["207"] = 193,["208"] = 188,["211"] = 196,["212"] = 196,["213"] = 186,["216"] = 137,["217"] = 202,["218"] = 203,["220"] = 204,["221"] = 204,["222"] = 205,["223"] = 206,["225"] = 208,["227"] = 204,["230"] = 212,["231"] = 202,["232"] = 215,["233"] = 216,["234"] = 217,["236"] = 219,["237"] = 220,["238"] = 221,["240"] = 222,["241"] = 222,["242"] = 223,["243"] = 224,["244"] = 226,["245"] = 227,["246"] = 228,["248"] = 229,["249"] = 229,["250"] = 230,["251"] = 231,["252"] = 232,["253"] = 233,["254"] = 234,["258"] = 229,["261"] = 240,["262"] = 241,["263"] = 242,["264"] = 244,["265"] = 245,["266"] = 246,["267"] = 247,["268"] = 248,["269"] = 249,["270"] = 250,["272"] = 252,["273"] = 253,["274"] = 254,["278"] = 258,["280"] = 261,["281"] = 262,["283"] = 265,["284"] = 267,["285"] = 269,["286"] = 222,["289"] = 272,["290"] = 215,["291"] = 275,["292"] = 276,["295"] = 279,["296"] = 281,["297"] = 281,["298"] = 281,["299"] = 282,["300"] = 283,["301"] = 284,["302"] = 286,["303"] = 287,["304"] = 287,["305"] = 288,["306"] = 288,["307"] = 289,["308"] = 293,["309"] = 293,["310"] = 293,["311"] = 293,["312"] = 293,["313"] = 293,["314"] = 293,["315"] = 293,["316"] = 294,["317"] = 295,["319"] = 298,["320"] = 299,["321"] = 300,["322"] = 301,["323"] = 301,["325"] = 302,["326"] = 303,["327"] = 303,["328"] = 303,["329"] = 303,["330"] = 303,["331"] = 303,["332"] = 303,["333"] = 304,["334"] = 305,["335"] = 306,["337"] = 309,["338"] = 310,["340"] = 313,["341"] = 313,["342"] = 314,["343"] = 315,["344"] = 316,["347"] = 318,["348"] = 318,["349"] = 320,["350"] = 321,["351"] = 322,["352"] = 323,["353"] = 324,["354"] = 325,["355"] = 325,["356"] = 325,["357"] = 325,["358"] = 325,["359"] = 325,["360"] = 325,["361"] = 326,["362"] = 328,["363"] = 329,["364"] = 330,["365"] = 330,["366"] = 330,["367"] = 330,["368"] = 330,["369"] = 330,["370"] = 330,["371"] = 332,["372"] = 333,["373"] = 335,["374"] = 336,["375"] = 337,["376"] = 338,["377"] = 338,["378"] = 338,["379"] = 338,["380"] = 338,["381"] = 338,["382"] = 338,["383"] = 339,["384"] = 340,["385"] = 340,["386"] = 342,["387"] = 343,["388"] = 344,["389"] = 345,["390"] = 346,["391"] = 346,["392"] = 349,["393"] = 350,["394"] = 351,["395"] = 318,["398"] = 313,["401"] = 355,["402"] = 358,["403"] = 359,["404"] = 359,["405"] = 359,["406"] = 360,["407"] = 362,["408"] = 362,["409"] = 362,["410"] = 363,["411"] = 364,["412"] = 365,["413"] = 365,["414"] = 365,["415"] = 366,["416"] = 367,["417"] = 368,["418"] = 368,["419"] = 368,["420"] = 368,["421"] = 368,["422"] = 368,["423"] = 368,["424"] = 369,["425"] = 371,["426"] = 372,["427"] = 373,["428"] = 373,["429"] = 373,["430"] = 373,["431"] = 373,["432"] = 373,["433"] = 373,["434"] = 374,["435"] = 376,["436"] = 377,["437"] = 378,["438"] = 379,["439"] = 380,["440"] = 378,["441"] = 384,["442"] = 385,["443"] = 386,["444"] = 386,["445"] = 386,["446"] = 386,["447"] = 386,["448"] = 386,["449"] = 386,["450"] = 387,["451"] = 389,["452"] = 390,["453"] = 391,["454"] = 392,["455"] = 393,["456"] = 391,["457"] = 396,["458"] = 396,["459"] = 396,["460"] = 397,["461"] = 396,["462"] = 396,["463"] = 399,["464"] = 399,["465"] = 399,["466"] = 400,["467"] = 399,["468"] = 399,["469"] = 275,["470"] = 408,["471"] = 409,["472"] = 411,["473"] = 412,["474"] = 413,["477"] = 414,["480"] = 416,["481"] = 417,["482"] = 418,["483"] = 408,["484"] = 421,["485"] = 422,["486"] = 423,["487"] = 424,["490"] = 427,["491"] = 428,["494"] = 429,["495"] = 430,["498"] = 431,["499"] = 432,["502"] = 433,["503"] = 434,["504"] = 434,["505"] = 434,["506"] = 434,["507"] = 434,["509"] = 436,["510"] = 436,["511"] = 436,["512"] = 436,["513"] = 436,["514"] = 436,["516"] = 422,["517"] = 421,["518"] = 441,["519"] = 442,["520"] = 443,["523"] = 445,["524"] = 446,["527"] = 447,["528"] = 448,["531"] = 449,["532"] = 450,["533"] = 450,["534"] = 450,["535"] = 450,["536"] = 450,["538"] = 452,["539"] = 452,["540"] = 452,["541"] = 452,["542"] = 452,["543"] = 452,["545"] = 441,["546"] = 457,["547"] = 458,["548"] = 459,["551"] = 460,["552"] = 461,["555"] = 462,["556"] = 463,["559"] = 464,["560"] = 465,["561"] = 466,["562"] = 467,["563"] = 468,["564"] = 457,["565"] = 472,["566"] = 473,["567"] = 472,["568"] = 35,["569"] = 39});
local ____exports = {}
local ____Actor = require("solar.solar-common.actor.Actor")
local Actor = ____Actor.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____TextAlign = require("solar.solar-common.constant.TextAlign")
local TextAlign = ____TextAlign.default
local ____ActorFrameUtil = require("solar.solar-common.actor.util.ActorFrameUtil")
local ActorFrameUtil = ____ActorFrameUtil.default
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____PlayerUtil = require("solar.solar-common.util.game.PlayerUtil")
local PlayerUtil = ____PlayerUtil.default
local ____ActorBuffUtil = require("solar.solar-common.actor.util.ActorBuffUtil")
local ActorBuffUtil = ____ActorBuffUtil.default
local ____ActorTypeUtil = require("solar.solar-common.actor.util.ActorTypeUtil")
local ActorTypeUtil = ____ActorTypeUtil.default
local ____InputUtil = require("solar.solar-common.util.system.InputUtil")
local InputUtil = ____InputUtil.default
local ____KeyCode = require("solar.solar-common.constant.KeyCode")
local KeyCode = ____KeyCode.default
local ____FrameControl = require("solar.solar-common.framex.control.FrameControl")
local FrameControl = ____FrameControl.default
local ____ShortIDUtil = require("solar.solar-common.util.game.ShortIDUtil")
local ShortIDUtil = ____ShortIDUtil.default
____exports.default = __TS__Class()
local IconGridPane = ____exports.default
IconGridPane.name = "IconGridPane"
function IconGridPane.prototype.____constructor(self, title)
    if title == nil then
        title = "吞噬面板"
    end
    self._sl_inited = false
    self.datas = {}
    self.showActorClasss = {
        "吞噬",
        "神器",
        "传说",
        "史诗",
        "宝物"
    }
    self.showActorClassCounts = {-1}
    self.defaultShowActorTypeIds = {}
    self.uiShowTypes = {"吞噬面板"}
    self._sl_realIndexLimits = {1}
    self.config = {
        ["标题颜色"] = "|cffff0000",
        ["标题"] = "吞噬面板",
        ["显示标题"] = false,
        ["开关背景"] = "UI\\Widgets\\Console\\Human\\human-transport-slot.blp",
        ["背景模版"] = "_sl_border_backdrop_black",
        ["背景"] = nil,
        ["边框"] = "UI\\Console\\Human\\human-transport-slot.blp",
        ["透明"] = "UI\\Widgets\\EscMenu\\Human\\blank-background.blp",
        ["箭头左"] = "ReplaceableTextures\\WorldEditUI\\Editor-Toolbar-Undo.blp",
        ["箭头右"] = "ReplaceableTextures\\WorldEditUI\\Editor-Toolbar-Redo.blp",
        ["行数"] = 6,
        ["列数"] = 8,
        ["指定每行列数"] = {},
        ["格子宽"] = 0.03,
        ["格子高"] = 0.04,
        ["格子间距"] = 0.003,
        ["面板描点"] = FramePoint.center,
        ["面板x"] = 0.4,
        ["面板y"] = 0.35
    }
    self["按钮列表"] = {}
    self.visibleSwitchButton = nil
    self._page = 1
    self.config["标题"] = title
    ____exports.default.lastInstance = self
    ____exports.default.instances[title] = self
end
function IconGridPane.prototype.createVisibleSwitchButton(self, text, x, y)
    if text == nil then
        text = "|cffff0000吞 噬"
    end
    if x == nil then
        x = 0.1
    end
    if y == nil then
        y = 0.57
    end
    local button = __TS__New(FrameControl)
    button:getBackgroundImageFrame().visible = false
    if self.config["开关背景"] then
        button:getBackgroundImageFrame():setTexture(self.config["开关背景"])
        button:getBackgroundImageFrame().visible = true
    end
    if text and #text > 0 then
        local textFrame = Frame:createShadowTEXT(button.rootFrame.handle)
        textFrame:setAllPoints(button.rootFrame.handle)
        textFrame:setTextAlignment(TextAlign.center)
        textFrame:setText(text)
    else
        button:getImageFrame().visible = false
    end
    button:getButtonFrame():setOnClick(function()
        self.root.visible = not self.root.visible
        if self.root.visible then
            se:emit("打开UI", self.config["标题"])
            self:update()
        end
    end)
    se:on(
        "打开UI",
        function(ui)
            if ui ~= self.config["标题"] then
                self.root.visible = false
            end
        end
    )
    button:setSize(0.04, 0.04)
    button:setAbsPoint(FramePoint.topLeft, x, y)
    self.visibleSwitchButton = button
    return button
end
function IconGridPane.prototype._sl_updateData(self)
    self.datas = {}
    --- 主控英雄单位的演员数据
    local hero = selection()
    if GetOwningPlayer(hero) ~= GetLocalPlayer() or not UnitUtil.isHero(hero) then
        hero = PlayerUtil:getHero(GetLocalPlayer())
    end
    do
        local i = 0
        while i < #self.showActorClasss do
            local ____self_datas_0 = self.datas
            ____self_datas_0[#____self_datas_0 + 1] = {}
            i = i + 1
        end
    end
    for ____, actorTypeId in ipairs(self.defaultShowActorTypeIds) do
        local ____self_datas__1_1 = self.datas[1]
        ____self_datas__1_1[#____self_datas__1_1 + 1] = ActorTypeUtil:getActorType(actorTypeId)
    end
    ActorTypeUtil:forAllActorTypes(function(____, actorType)
        if not __TS__ArrayIncludes(self.uiShowTypes, actorType.uiShowType) then
            return
        end
        if actorType.hide == true and actorType.uiEnable ~= true then
            return
        end
        if __TS__ArrayIncludes(self.defaultShowActorTypeIds, actorType.id) then
            return
        end
        do
            local i = 0
            while i < #self.showActorClasss do
                local showClazz = self.showActorClasss[i + 1]
                if showClazz == actorType.class then
                    local ____self_datas_index_2 = self.datas[i + 1]
                    ____self_datas_index_2[#____self_datas_index_2 + 1] = actorType
                end
                i = i + 1
            end
        end
    end)
    if IsHandle(hero) then
        local actorBuffs = ActorBuffUtil:getUnitActorBuffs(hero)
        if actorBuffs then
            for ____, actor in ipairs(actorBuffs) do
                do
                    if not __TS__ArrayIncludes(
                        self.uiShowTypes,
                        actor:get("uiShowType")
                    ) then
                        goto __continue26
                    end
                    do
                        local i = 0
                        while i < #self.showActorClasss do
                            local showClazz = self.showActorClasss[i + 1]
                            if showClazz == actor:get("class") then
                                local ____self_datas_index_3 = self.datas[i + 1]
                                ____self_datas_index_3[#____self_datas_index_3 + 1] = actor
                            end
                            i = i + 1
                        end
                    end
                end
                ::__continue26::
            end
        end
    end
    self._sl_realIndexLimits = {}
    do
        local cIndex = 0
        while cIndex < #self.showActorClasss do
            local realIndexLimit = 0
            do
                local j = 0
                while j <= cIndex do
                    local count = self.showActorClassCounts[j + 1] or -1
                    if count <= 0 then
                        count = #self.datas[j + 1]
                    end
                    realIndexLimit = realIndexLimit + count
                    j = j + 1
                end
            end
            local ____self__sl_realIndexLimits_4 = self._sl_realIndexLimits
            ____self__sl_realIndexLimits_4[#____self__sl_realIndexLimits_4 + 1] = realIndexLimit
            cIndex = cIndex + 1
        end
    end
end
IconGridPane.prototype["get每页数目"] = function(self)
    local _____6BCF_9875_6570_76EE = 0
    do
        local i = 0
        while i < self.config["行数"] do
            if i < #self.config["指定每行列数"] then
                _____6BCF_9875_6570_76EE = _____6BCF_9875_6570_76EE + self.config["指定每行列数"][i + 1]
            else
                _____6BCF_9875_6570_76EE = _____6BCF_9875_6570_76EE + self.config["列数"]
            end
            i = i + 1
        end
    end
    return _____6BCF_9875_6570_76EE
end
function IconGridPane.prototype.update(self)
    if not self._sl_inited then
        self:init()
    end
    local _____6BCF_9875_6570_76EE = self["get每页数目"](self)
    local _____5F53_524D_9875_504F_79FB = _____6BCF_9875_6570_76EE * (self._page - 1)
    self:_sl_updateData()
    do
        local i = 0
        while i < #self["按钮列表"] do
            local frameControl = self["按钮列表"][i + 1]
            local realIndex = _____5F53_524D_9875_504F_79FB + i
            local overlayText = nil
            local classIndex = -1
            local dataIndex = realIndex
            do
                local j = 0
                while j < #self._sl_realIndexLimits do
                    if realIndex < self._sl_realIndexLimits[j + 1] then
                        overlayText = self.showActorClasss[j + 1]
                        classIndex = j
                        if j > 0 then
                            dataIndex = realIndex - self._sl_realIndexLimits[j]
                        end
                        break
                    end
                    j = j + 1
                end
            end
            frameControl:setNumberOverlayText(ShortIDUtil.fullId2shortId(overlayText))
            frameControl:getBackgroundImageFrame().visible = false
            local rootVisible = true
            local iconTexture = self.config["透明"]
            local disable = false
            if classIndex >= 0 then
                local actorOrActorType = self.datas[classIndex + 1][dataIndex + 1]
                if actorOrActorType ~= nil then
                    if __TS__InstanceOf(actorOrActorType, Actor) then
                        iconTexture = actorOrActorType:getIcon()
                    else
                        iconTexture = actorOrActorType.icon
                        if actorOrActorType.uiEnable == false then
                            disable = true
                        end
                    end
                end
                frameControl:getButtonFrame().solarData.itemData = actorOrActorType
            else
                frameControl:getBackgroundImageFrame().visible = true
                rootVisible = false
            end
            frameControl:getDisableFrame().visible = disable
            frameControl.visible = rootVisible
            frameControl:getImageFrame():setTexture(iconTexture)
            i = i + 1
        end
    end
    self:setPage(self._page)
end
function IconGridPane.prototype.init(self)
    if self._sl_inited then
        return
    end
    self._sl_inited = true
    local ____temp_5 = Frame:createFrame(DzGetGameUI())
    self.root = ____temp_5
    local root = ____temp_5
    root:setAbsPoint(self.config["面板描点"], self.config["面板x"], self.config["面板y"])
    local _____5E95_677F_5BBD = self.config["列数"] * self.config["格子宽"] + (self.config["列数"] - 1) * self.config["格子间距"] + 0.03
    local _____5E95_677F_9AD8 = self.config["行数"] * self.config["格子高"] + (self.config["行数"] - 1) * self.config["格子间距"] + 0.04
    local container = root.handle
    local offsetL = 0.015
    local offsetT = -0.015
    local marginL = 0.0015
    local marginT = 0.0015
    local index = 0
    local bg = __TS__New(
        Frame,
        "BACKDROP",
        nil,
        root.handle,
        self.config["背景模版"],
        0
    )
    if self.config["背景"] then
        bg:setTexture(self.config["背景"])
    end
    bg:setAllPoints(root.handle)
    if self.config["显示标题"] then
        local title = Frame:createShadowTEXT(root.handle)
        if DzFrameSetTextFontSpacing ~= nil then
            DzFrameSetTextFontSpacing(title.handle, 1.2)
        end
        title:setFont(0.026)
        title:setPoint(
            FramePoint.top,
            root.handle,
            FramePoint.top,
            0,
            -0.01
        )
        title:setText(self.config["标题颜色"] .. self.config["标题"])
        _____5E95_677F_9AD8 = _____5E95_677F_9AD8 + 0.015
        offsetT = offsetT + -0.015
    end
    root:setSize(_____5E95_677F_5BBD, _____5E95_677F_9AD8)
    root.visible = false
    do
        local row = 0
        while row < self.config["行数"] do
            local _____5F53_524D_884C_5217_6570 = self.config["列数"]
            if row < #self.config["指定每行列数"] then
                _____5F53_524D_884C_5217_6570 = self.config["指定每行列数"][row + 1]
            end
            do
                local column = 0
                while column < _____5F53_524D_884C_5217_6570 do
                    index = index + 1
                    local x = offsetL + column * (self.config["格子宽"] + self.config["格子间距"])
                    local y = offsetT - row * (self.config["格子高"] + self.config["格子间距"])
                    local frameControl = __TS__New(FrameControl, container)
                    frameControl.rootFrame:setTexture(self.config["边框"])
                    frameControl.rootFrame:setPoint(
                        FramePoint.topLeft,
                        container,
                        FramePoint.topLeft,
                        x,
                        y
                    )
                    frameControl:setSize(self.config["格子宽"], self.config["格子高"])
                    frameControl:getTextFrame()
                    frameControl:getNumberOverlayTextFrame(true, FramePoint.topLeft)
                    frameControl._sl_numberOverlayTextFrame:setPoint(
                        FramePoint.topLeft,
                        frameControl.rootFrame.handle,
                        FramePoint.topLeft,
                        0.007,
                        -0.007
                    )
                    frameControl._sl_numberOverlayFrame:clearPoints()
                    frameControl._sl_numberOverlayFrame:setPoints(frameControl._sl_numberOverlayTextFrame.handle, 0.006, 0.006)
                    local icon = frameControl:getImageFrame()
                    icon:setTexture(self.config["透明"])
                    icon:clearPoints()
                    icon:setPoint(
                        FramePoint.topLeft,
                        frameControl.handle,
                        FramePoint.topLeft,
                        marginL,
                        -marginT
                    )
                    icon:setSize(self.config["格子宽"] - marginL * 1.8, self.config["格子高"] - marginT * 2)
                    local ____self__6309_94AE_5217_8868_8 = self["按钮列表"]
                    ____self__6309_94AE_5217_8868_8[#____self__6309_94AE_5217_8868_8 + 1] = frameControl
                    frameControl:getDisableFrame(true).visible = false
                    local btn = frameControl:getButtonFrame()
                    btn.solarData.slot_id = index
                    btn:setAllPoints(icon.handle)
                    btn:setOnClick(function()
                    end)
                    btn:setOnClick(function() return self:on_button_mouse_click() end)
                    btn:setOnMouseEnter(function() return self:on_button_mouse_enter() end)
                    btn:setOnMouseLeave(function() return self:on_button_mouse_leave() end)
                    column = column + 1
                end
            end
            row = row + 1
        end
    end
    self:init_on_button_mouse_RightClick()
    local textW = 0.01
    local arrowW = 0.018
    local arrowH = 0.018
    local arrowB = 0.005
    local fontH = 0.012
    local ____temp_9 = Frame:createBackDrop(container)
    self.pageContainer = ____temp_9
    local pageContainer = ____temp_9
    pageContainer:setAllPoints(container)
    pageContainer:setTexture2Transparent()
    local ____temp_10 = Frame:createTEXT(pageContainer.handle)
    self.pageText = ____temp_10
    local pageText = ____temp_10
    pageText:setTextAlignment(TextAlign.center)
    pageText:setFont(fontH)
    pageText:setPoint(
        FramePoint.bottom,
        pageContainer.handle,
        FramePoint.bottom,
        0,
        arrowB + (arrowH - fontH) / 2 + 0.0005
    )
    self:setPage(self._page)
    local arrowIconL = Frame:createBackDrop(pageContainer.handle)
    arrowIconL:setTexture(self.config["箭头左"])
    arrowIconL:setPoint(
        FramePoint.bottom,
        pageContainer.handle,
        FramePoint.bottom,
        -arrowW - textW / 2,
        arrowB
    )
    arrowIconL:setSize(arrowW, arrowH)
    local arrowBtnL = Frame:createBUTTON(pageContainer.handle)
    arrowBtnL:setAllPoints(arrowIconL.handle)
    arrowBtnL:setOnClick(function()
        self:setPage(self._page - 1)
        self:update()
    end)
    local arrowIconR = Frame:createBackDrop(pageContainer.handle)
    arrowIconR:setTexture(self.config["箭头右"])
    arrowIconR:setPoint(
        FramePoint.bottom,
        pageContainer.handle,
        FramePoint.bottom,
        arrowW + textW / 2,
        arrowB
    )
    arrowIconR:setSize(arrowW, arrowH)
    local arrowBtnR = Frame:createBUTTON(pageContainer.handle)
    arrowBtnR:setAllPoints(arrowIconR.handle)
    arrowBtnR:setOnClick(function()
        self:setPage(self._page + 1)
        self:update()
    end)
    se:on(
        "刷新UI",
        function()
            self:update()
        end
    )
    InputUtil:onKeyPressed(
        KeyCode.VK_ESCAPE,
        function()
            self.root.visible = false
        end
    )
end
function IconGridPane.prototype.setPage(self, page)
    local _____6BCF_9875_6570_76EE = self["get每页数目"](self)
    local allItemSize = self._sl_realIndexLimits[#self._sl_realIndexLimits]
    local total = math.ceil(allItemSize / _____6BCF_9875_6570_76EE)
    if page < 1 then
        return
    end
    if page > total then
        return
    end
    self._page = page
    self.pageText:setText((("|cffd9d919" .. tostring(page)) .. "/") .. tostring(total))
    self.pageContainer.visible = total > 1
end
function IconGridPane.prototype.init_on_button_mouse_RightClick(self)
    InputUtil:onMouseRightButtonReleased(function()
        local focusUiId = DzGetMouseFocus()
        if focusUiId == nil or focusUiId == 0 then
            return
        end
        local frame = Frame:fromHandle(focusUiId, true)
        if not frame then
            return
        end
        local slot_id = frame.solarData.slot_id
        if not slot_id then
            return
        end
        local actorOrActorType = frame.solarData.itemData
        if not actorOrActorType then
            return
        end
        if __TS__InstanceOf(actorOrActorType, Actor) then
            actorOrActorType:localClick(
                2,
                InputUtil:getMouseSceneX(),
                InputUtil:getMouseSceneY()
            )
        else
            ActorFrameUtil:localClickActorType(
                actorOrActorType,
                2,
                InputUtil:getMouseSceneX(),
                InputUtil:getMouseSceneY()
            )
        end
    end)
end
function IconGridPane.prototype.on_button_mouse_click(self)
    local frame = Frame:fromEvent()
    if not frame then
        return
    end
    local slot_id = frame.solarData.slot_id
    if not slot_id then
        return
    end
    local actorOrActorType = frame.solarData.itemData
    if not actorOrActorType then
        return
    end
    if __TS__InstanceOf(actorOrActorType, Actor) then
        actorOrActorType:localClick(
            1,
            InputUtil:getMouseSceneX(),
            InputUtil:getMouseSceneY()
        )
    else
        ActorFrameUtil:localClickActorType(
            actorOrActorType,
            1,
            InputUtil:getMouseSceneX(),
            InputUtil:getMouseSceneY()
        )
    end
end
function IconGridPane.prototype.on_button_mouse_enter(self)
    local frame = Frame:fromEvent()
    if not frame then
        return
    end
    local slot_id = frame.solarData.slot_id
    if not slot_id then
        return
    end
    local actorOrActorType = frame.solarData.itemData
    if not actorOrActorType then
        return
    end
    ActorFrameUtil:showTooltip(actorOrActorType)
    local x = InputUtil:getMouseSceneX() + 0.06 - InputUtil:getMouseSceneX() % 0.04
    local y = InputUtil:getMouseSceneY() - 0.02 - InputUtil:getMouseSceneY() % 0.04
    ActorFrameUtil._sl_tooltipFrames.describe:clearPoints()
    ActorFrameUtil._sl_tooltipFrames.describe:setAbsPoint(FramePoint.left, x, y)
end
function IconGridPane.prototype.on_button_mouse_leave(self)
    ActorFrameUtil:hideTooltip()
end
IconGridPane.lastInstance = nil
IconGridPane.instances = {}
return ____exports
