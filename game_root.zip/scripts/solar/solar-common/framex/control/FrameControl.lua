local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 13,["17"] = 13,["18"] = 13,["19"] = 13,["21"] = 13,["22"] = 41,["23"] = 13,["24"] = 44,["25"] = 45,["26"] = 46,["28"] = 48,["29"] = 44,["30"] = 56,["31"] = 56,["32"] = 56,["34"] = 65,["35"] = 56,["36"] = 69,["37"] = 70,["38"] = 70,["39"] = 70,["40"] = 70,["41"] = 70,["42"] = 70,["43"] = 71,["44"] = 72,["45"] = 73,["46"] = 74,["48"] = 76,["49"] = 76,["50"] = 77,["51"] = 69,["52"] = 81,["53"] = 82,["54"] = 82,["55"] = 82,["56"] = 82,["57"] = 82,["58"] = 82,["59"] = 83,["60"] = 84,["61"] = 85,["62"] = 86,["64"] = 88,["65"] = 88,["66"] = 89,["67"] = 81,["68"] = 93,["69"] = 94,["70"] = 94,["71"] = 94,["72"] = 94,["73"] = 94,["74"] = 94,["75"] = 95,["76"] = 96,["77"] = 97,["78"] = 98,["80"] = 100,["81"] = 100,["82"] = 101,["83"] = 93,["84"] = 105,["85"] = 106,["86"] = 106,["87"] = 106,["88"] = 106,["89"] = 106,["90"] = 106,["91"] = 107,["92"] = 108,["93"] = 109,["94"] = 110,["96"] = 112,["97"] = 112,["98"] = 113,["99"] = 105,["100"] = 117,["101"] = 117,["102"] = 117,["104"] = 118,["105"] = 119,["107"] = 121,["108"] = 117,["109"] = 125,["110"] = 125,["111"] = 125,["113"] = 126,["114"] = 127,["116"] = 129,["117"] = 125,["118"] = 133,["119"] = 133,["120"] = 133,["122"] = 134,["123"] = 135,["125"] = 137,["126"] = 133,["127"] = 141,["128"] = 141,["129"] = 141,["131"] = 142,["132"] = 143,["134"] = 145,["135"] = 141,["136"] = 149,["137"] = 149,["138"] = 149,["140"] = 150,["141"] = 151,["143"] = 153,["144"] = 149,["145"] = 157,["146"] = 157,["147"] = 157,["149"] = 158,["150"] = 159,["152"] = 161,["153"] = 157,["154"] = 166,["155"] = 167,["156"] = 166,["157"] = 171,["158"] = 172,["159"] = 173,["161"] = 171,["162"] = 179,["163"] = 179,["164"] = 179,["166"] = 180,["167"] = 181,["169"] = 183,["170"] = 179,["171"] = 187,["172"] = 187,["173"] = 187,["175"] = 187,["176"] = 187,["178"] = 188,["179"] = 189,["180"] = 189,["181"] = 189,["182"] = 189,["183"] = 189,["184"] = 189,["185"] = 189,["186"] = 191,["187"] = 192,["188"] = 193,["189"] = 194,["190"] = 194,["192"] = 196,["193"] = 187,["194"] = 200,["195"] = 201,["196"] = 200,["197"] = 205,["198"] = 206,["199"] = 207,["201"] = 205,["202"] = 212,["203"] = 212,["204"] = 212,["206"] = 213,["207"] = 214,["208"] = 215,["209"] = 216,["210"] = 217,["211"] = 218,["212"] = 219,["213"] = 219,["214"] = 219,["215"] = 219,["216"] = 219,["217"] = 219,["218"] = 219,["219"] = 221,["220"] = 222,["221"] = 223,["222"] = 224,["225"] = 227,["226"] = 212,["227"] = 231,["228"] = 232,["229"] = 231,["230"] = 236,["231"] = 237,["232"] = 238,["234"] = 236,["235"] = 243,["236"] = 243,["237"] = 243,["239"] = 244,["240"] = 245,["241"] = 246,["243"] = 248,["244"] = 243,["245"] = 252,["246"] = 252,["247"] = 252,["249"] = 252,["250"] = 252,["252"] = 253,["253"] = 255,["254"] = 255,["255"] = 255,["256"] = 255,["257"] = 255,["258"] = 255,["259"] = 256,["260"] = 258,["261"] = 258,["262"] = 258,["263"] = 258,["264"] = 258,["265"] = 258,["266"] = 259,["267"] = 260,["268"] = 261,["269"] = 261,["270"] = 261,["271"] = 261,["272"] = 261,["273"] = 261,["274"] = 261,["275"] = 262,["276"] = 263,["277"] = 263,["278"] = 263,["279"] = 263,["280"] = 263,["281"] = 263,["282"] = 263,["283"] = 264,["284"] = 265,["285"] = 265,["286"] = 265,["287"] = 265,["288"] = 265,["289"] = 265,["290"] = 265,["291"] = 266,["292"] = 267,["293"] = 267,["294"] = 267,["295"] = 267,["296"] = 267,["297"] = 267,["298"] = 267,["299"] = 268,["300"] = 269,["301"] = 269,["302"] = 269,["303"] = 269,["304"] = 269,["305"] = 269,["306"] = 269,["308"] = 271,["309"] = 271,["310"] = 271,["311"] = 271,["312"] = 271,["313"] = 271,["314"] = 271,["316"] = 274,["318"] = 276,["319"] = 252,["320"] = 281,["321"] = 282,["322"] = 283,["323"] = 284,["325"] = 286,["326"] = 287,["330"] = 291,["331"] = 292,["332"] = 293,["333"] = 281,["334"] = 297,["335"] = 298,["338"] = 301,["339"] = 302,["340"] = 303,["342"] = 305,["344"] = 307,["345"] = 297});
local ____exports = {}
local ____FrameNode = require("solar.solar-common.framex.FrameNode")
local FrameNode = ____FrameNode.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____SolarConfig = require("solar.solar-common.common.SolarConfig")
local SolarConfig = ____SolarConfig.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
____exports.default = __TS__Class()
local FrameControl = ____exports.default
FrameControl.name = "FrameControl"
__TS__ClassExtends(FrameControl, FrameNode)
function FrameControl.prototype.____constructor(self, ...)
    FrameNode.prototype.____constructor(self, ...)
    self._sl_isInitialized = false
end
function FrameControl.prototype.init(self)
    if self._sl_isInitialized then
        log.errorWithTraceBack("不要多次调用init()!")
    end
    self._sl_isInitialized = true
end
function FrameControl.prototype.getRootFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    return self.rootFrame
end
function FrameControl.prototype.addTextFrame(self, text)
    local frame = __TS__New(
        Frame,
        "TEXT",
        nil,
        self:getRootFrame().handle
    )
    frame.visible = true
    frame:setAllPoints(self:getRootFrame().handle)
    if text then
        frame:setText(text)
    end
    local ____self__sl_Frames_0 = self._sl_Frames
    ____self__sl_Frames_0[#____self__sl_Frames_0 + 1] = frame
    return frame
end
function FrameControl.prototype.addTextAreaFrame(self, text)
    local frame = __TS__New(
        Frame,
        "TEXTAREA",
        nil,
        self:getRootFrame().handle
    )
    frame.visible = true
    frame:setAllPoints(self:getRootFrame().handle)
    if text then
        frame:setText(text)
    end
    local ____self__sl_Frames_1 = self._sl_Frames
    ____self__sl_Frames_1[#____self__sl_Frames_1 + 1] = frame
    return frame
end
function FrameControl.prototype.addImageFrame(self, imagePath)
    local frame = __TS__New(
        Frame,
        "BACKDROP",
        nil,
        self:getRootFrame().handle
    )
    frame.visible = true
    frame:setAllPoints(self:getRootFrame().handle)
    if imagePath then
        frame:setTexture(imagePath)
    end
    local ____self__sl_Frames_2 = self._sl_Frames
    ____self__sl_Frames_2[#____self__sl_Frames_2 + 1] = frame
    return frame
end
function FrameControl.prototype.addModelFrame(self, modelPath)
    local frame = __TS__New(
        Frame,
        "SPRITE",
        nil,
        self:getRootFrame().handle
    )
    frame.visible = true
    frame:setAllPoints(self:getRootFrame().handle)
    if modelPath then
        frame:setModel(modelPath)
    end
    local ____self__sl_Frames_3 = self._sl_Frames
    ____self__sl_Frames_3[#____self__sl_Frames_3 + 1] = frame
    return frame
end
function FrameControl.prototype.getDisableFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_disableFrame == nil then
        self._sl_disableFrame = self:addImageFrame(SolarConfig.defaultDisablePath)
    end
    return self._sl_disableFrame
end
function FrameControl.prototype.getImageFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_imageFrame == nil then
        self._sl_imageFrame = self:addImageFrame("")
    end
    return self._sl_imageFrame
end
function FrameControl.prototype.getBackgroundImageFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_backgroundImageFrame == nil then
        self._sl_backgroundImageFrame = self:addImageFrame("")
    end
    return self._sl_backgroundImageFrame
end
function FrameControl.prototype.getTextFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_textFrame == nil then
        self._sl_textFrame = self:addTextFrame("")
    end
    return self._sl_textFrame
end
function FrameControl.prototype.getTextAreaFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_textAreaFrame == nil then
        self._sl_textAreaFrame = self:addTextAreaFrame("")
    end
    return self._sl_textAreaFrame
end
function FrameControl.prototype.getTickFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_tickFrame == nil then
        self._sl_tickFrame = self:addImageFrame(SolarConfig.defaultTickPath)
    end
    return self._sl_tickFrame
end
function FrameControl.prototype.showTickFrame(self)
    self:getTickFrame(true).visible = true
end
function FrameControl.prototype.hideTickFrame(self)
    if self._sl_tickFrame then
        self._sl_tickFrame.visible = false
    end
end
function FrameControl.prototype.getAutoCastFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_autocastFrame == nil then
        self._sl_autocastFrame = self:addModelFrame(SolarConfig.defaultAutoCastModelPath)
    end
    return self._sl_autocastFrame
end
function FrameControl.prototype.getButtonFrame(self, createDefault, hasHighlight)
    if createDefault == nil then
        createDefault = true
    end
    if hasHighlight == nil then
        hasHighlight = true
    end
    if createDefault and self._sl_buttonFrame == nil then
        local frame = __TS__New(
            Frame,
            "BUTTON",
            nil,
            self:getRootFrame().handle,
            hasHighlight and "ScoreScreenTabButtonTemplate" or ""
        )
        frame.visible = true
        frame:setAllPoints(self:getRootFrame().handle)
        self._sl_buttonFrame = frame
        local ____self__sl_Frames_4 = self._sl_Frames
        ____self__sl_Frames_4[#____self__sl_Frames_4 + 1] = frame
    end
    return self._sl_buttonFrame
end
function FrameControl.prototype.showAutoCastFrame(self)
    self:getAutoCastFrame(true).visible = true
end
function FrameControl.prototype.hideAutoCastFrame(self)
    if self._sl_autocastFrame then
        self._sl_autocastFrame.visible = false
    end
end
function FrameControl.prototype.getLampEffectFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_lampEffectFrame == nil then
        self._sl_lampEffectFrame = self:addModelFrame(SolarConfig.defaultLampEffectModelPath)
        self._sl_lampEffectFrame:clearPoints()
        self._sl_lampEffectFrame:setSize(SolarConfig.defaultLampEffectModelWidth, SolarConfig.defaultLampEffectModelHeight)
        local xScale = self.rootFrame.width / SolarConfig.defaultLampEffectModelWidth + (SolarConfig.defaultLampEffectModelScaleX - 1)
        local yScale = self.rootFrame.height / SolarConfig.defaultLampEffectModelHeight + (SolarConfig.defaultLampEffectModelScaleY - 1)
        self._sl_lampEffectFrame:setPoint(
            FramePoint.center,
            self.rootFrame.handle,
            FramePoint.center,
            SolarConfig.defaultLampEffectModelOffsetX,
            SolarConfig.defaultLampEffectModelOffsetY
        )
        if FrameSetModelScale then
            FrameSetModelScale(self._sl_lampEffectFrame.handle, xScale, yScale, 1)
        elseif DzFrameSetModelScale then
            DzFrameSetModelScale(self._sl_lampEffectFrame.handle, xScale, yScale, 1)
        end
    end
    return self._sl_lampEffectFrame
end
function FrameControl.prototype.showLampEffectFrame(self)
    self:getLampEffectFrame(true).visible = true
end
function FrameControl.prototype.hideLampEffectFrame(self)
    if self._sl_lampEffectFrame then
        self._sl_lampEffectFrame.visible = false
    end
end
function FrameControl.prototype.getCooldownFrame(self, createDefault)
    if createDefault == nil then
        createDefault = true
    end
    if createDefault and self._sl_cooldownFrame == nil then
        self._sl_cooldownFrame = self:addModelFrame()
        self._sl_cooldownFrame:setAllPoints(self:getRootFrame().handle)
    end
    return self._sl_cooldownFrame
end
function FrameControl.prototype.getNumberOverlayTextFrame(self, createDefault, point)
    if createDefault == nil then
        createDefault = true
    end
    if point == nil then
        point = FramePoint.bottomRight
    end
    if createDefault and self._sl_numberOverlayTextFrame == nil then
        self._sl_numberOverlayFrame = __TS__New(
            Frame,
            "BACKDROP",
            nil,
            self:getRootFrame().handle
        )
        self._sl_numberOverlayFrame:setTexture("UI\\Widgets\\Console\\Human\\CommandButton\\human-button-lvls-overlay.blp")
        self._sl_numberOverlayTextFrame = __TS__New(
            Frame,
            "TEXT",
            nil,
            self:getRootFrame().handle
        )
        self._sl_numberOverlayTextFrame:setFont(0.009)
        if point == FramePoint.bottomRight then
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                -0.005,
                0.002
            )
        elseif point == FramePoint.topRight then
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                -0.005,
                -0.002
            )
        elseif point == FramePoint.topLeft then
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                0.005,
                -0.002
            )
        elseif point == FramePoint.bottomLeft then
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                0.005,
                0.002
            )
        elseif point == FramePoint.center then
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                0,
                0
            )
        else
            self._sl_numberOverlayTextFrame:setPoint(
                point,
                self:getRootFrame().handle,
                point,
                0,
                0
            )
        end
        self._sl_numberOverlayFrame:setPoints(self._sl_numberOverlayTextFrame.handle, 0.003, 0.002)
    end
    return self._sl_numberOverlayTextFrame
end
function FrameControl.prototype.setNumberOverlayText(self, text)
    if text == nil or #text == 0 then
        if self._sl_numberOverlayFrame ~= nil then
            self._sl_numberOverlayFrame.visible = false
        end
        if self._sl_numberOverlayTextFrame ~= nil then
            self._sl_numberOverlayTextFrame.visible = false
        end
        return
    end
    self:getNumberOverlayTextFrame():setText(text)
    self._sl_numberOverlayFrame.visible = true
    self._sl_numberOverlayTextFrame.visible = true
end
function FrameControl.prototype.destroy(self)
    if self._sl_isDestroyed then
        return
    end
    if self._sl_Frames ~= nil then
        for ____, frame in ipairs(self._sl_Frames) do
            frame:destroy()
        end
        self._sl_Frames = nil
    end
    self._sl_isDestroyed = true
end
return ____exports
