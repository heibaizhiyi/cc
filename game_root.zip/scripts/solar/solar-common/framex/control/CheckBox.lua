local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 8,["14"] = 8,["15"] = 8,["16"] = 8,["17"] = 16,["18"] = 8,["19"] = 13,["20"] = 14,["21"] = 19,["22"] = 20,["24"] = 22,["25"] = 16,["26"] = 25,["27"] = 8,["28"] = 27,["29"] = 28,["30"] = 29,["31"] = 30,["32"] = 31,["33"] = 33,["34"] = 34,["35"] = 35,["36"] = 35,["37"] = 35,["38"] = 35,["39"] = 35,["40"] = 35,["41"] = 35,["42"] = 36,["43"] = 37,["44"] = 38,["45"] = 39,["46"] = 38,["47"] = 25,["48"] = 43,["49"] = 44,["50"] = 45,["52"] = 47,["54"] = 49,["55"] = 43,["56"] = 53,["57"] = 54,["58"] = 54,["59"] = 53,["60"] = 57,["61"] = 58,["62"] = 59,["64"] = 60,["65"] = 60,["66"] = 61,["67"] = 61,["68"] = 60,["71"] = 57,["72"] = 10,["73"] = 11,["74"] = 12});
local ____exports = {}
local ____FrameControl = require("solar.solar-common.framex.control.FrameControl")
local FrameControl = ____FrameControl.default
local ____SolarConfig = require("solar.solar-common.common.SolarConfig")
local SolarConfig = ____SolarConfig.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
____exports.default = __TS__Class()
local CheckBox = ____exports.default
CheckBox.name = "CheckBox"
__TS__ClassExtends(CheckBox, FrameControl)
function CheckBox.prototype.____constructor(self, parent, onSelectedChangeListener)
    FrameControl.prototype.____constructor(self, parent)
    self.selected = false
    self.onSelectedChangeListenerList = {}
    if onSelectedChangeListener then
        self:addSelectedChangeListener(onSelectedChangeListener)
    end
    self:init()
end
function CheckBox.prototype.init(self)
    FrameControl.prototype.init(self)
    self.rootFrame:setSize(0.025, 0.025)
    self:getBackgroundImageFrame().visible = true
    self:getBackgroundImageFrame():setTexture(____exports.default.bgPath)
    self:getTickFrame():setTexture(____exports.default.tickPath)
    self:getTickFrame().visible = false
    local textFrame = self:getTextFrame()
    textFrame:clearPoints()
    textFrame:setPoint(
        FramePoint.left,
        self.rootFrame.handle,
        FramePoint.right,
        ____exports.default.textGap,
        0
    )
    textFrame.visible = false
    textFrame:setFont(0.015)
    self:getButtonFrame(true, false):setOnClick(function()
        self:setSelected(not self.selected)
    end)
end
function CheckBox.prototype.setText(self, text)
    if text == nil or #text == 0 then
        self:getTextFrame().visible = false
    else
        self:getTextFrame().visible = true
    end
    self:getTextFrame():setText(text)
end
function CheckBox.prototype.addSelectedChangeListener(self, onSelectedChangeListener)
    local ____self_onSelectedChangeListenerList_0 = self.onSelectedChangeListenerList
    ____self_onSelectedChangeListenerList_0[#____self_onSelectedChangeListenerList_0 + 1] = onSelectedChangeListener
end
function CheckBox.prototype.setSelected(self, selected)
    self.selected = selected
    self:getTickFrame().visible = selected
    do
        local i = 0
        while i < #self.onSelectedChangeListenerList do
            local ____self_1 = self.onSelectedChangeListenerList
            ____self_1[i + 1](____self_1, selected)
            i = i + 1
        end
    end
end
CheckBox.bgPath = "UI\\Widgets\\EscMenu\\Human\\checkbox-background.blp"
CheckBox.tickPath = SolarConfig.defaultTickPath
CheckBox.textGap = 0.005
return ____exports
