local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 3,["10"] = 3,["11"] = 3,["12"] = 3});
local ____exports = {}
local ____FrameParent = require("solar.solar-common.framex.FrameParent")
local FrameParent = ____FrameParent.default
____exports.default = __TS__Class()
local Pane = ____exports.default
Pane.name = "Pane"
__TS__ClassExtends(Pane, FrameParent)
return ____exports
