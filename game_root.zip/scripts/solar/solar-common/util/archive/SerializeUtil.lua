local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 3,["9"] = 3,["10"] = 3,["12"] = 3,["13"] = 10,["14"] = 11,["15"] = 12,["16"] = 13,["17"] = 14,["19"] = 16,["20"] = 17,["21"] = 10,["22"] = 24,["23"] = 25,["24"] = 26,["26"] = 28,["27"] = 29,["28"] = 30,["29"] = 31,["30"] = 32,["32"] = 34,["33"] = 24});
local ____exports = {}
local ____ShortIDUtil = require("solar.solar-common.util.game.ShortIDUtil")
local ShortIDUtil = ____ShortIDUtil.default
____exports.default = __TS__Class()
local SerializeUtil = ____exports.default
SerializeUtil.name = "SerializeUtil"
function SerializeUtil.prototype.____constructor(self)
end
function SerializeUtil.attribute2String(self, attribute)
    local simpleAttribute = {}
    for attributeKey in pairs(attribute) do
        local simpleKey = ShortIDUtil.fullId2shortId(attributeKey, "属性key")
        simpleAttribute[simpleKey] = attribute[attributeKey]
    end
    local jsonStr = JSON:stringify(simpleAttribute)
    return jsonStr
end
function SerializeUtil.string2Attribute(self, simpleAttributeJsonStr)
    if simpleAttributeJsonStr == nil or #simpleAttributeJsonStr < 2 then
        return nil
    end
    local simpleAttribute = JSON:parse(simpleAttributeJsonStr)
    local attribute = {}
    for simpleKey in pairs(simpleAttribute) do
        local attributeKey = ShortIDUtil.shortId2fullId(simpleKey, "属性key")
        attribute[attributeKey] = simpleAttribute[simpleKey]
    end
    return attribute
end
return ____exports
