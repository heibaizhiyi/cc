local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__Delete = ____lualib.__TS__Delete
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 5,["15"] = 5,["16"] = 6,["17"] = 6,["18"] = 12,["19"] = 12,["20"] = 12,["22"] = 12,["23"] = 47,["24"] = 47,["25"] = 47,["27"] = 47,["28"] = 47,["30"] = 48,["31"] = 49,["32"] = 50,["33"] = 51,["34"] = 52,["37"] = 55,["38"] = 56,["39"] = 57,["41"] = 59,["42"] = 47,["43"] = 68,["44"] = 69,["45"] = 70,["46"] = 71,["48"] = 73,["49"] = 74,["50"] = 75,["52"] = 77,["53"] = 68,["54"] = 86,["55"] = 87,["56"] = 88,["57"] = 89,["58"] = 90,["59"] = 86,["60"] = 100,["61"] = 100,["62"] = 100,["64"] = 101,["65"] = 102,["66"] = 103,["70"] = 107,["71"] = 108,["72"] = 109,["76"] = 113,["77"] = 114,["78"] = 115,["79"] = 116,["80"] = 117,["82"] = 119,["83"] = 120,["84"] = 121,["86"] = 123,["87"] = 124,["88"] = 125,["89"] = 126,["90"] = 127,["92"] = 129,["93"] = 130,["94"] = 131,["95"] = 132,["97"] = 134,["98"] = 135,["99"] = 136,["101"] = 138,["102"] = 139,["103"] = 140,["105"] = 142,["107"] = 100,["108"] = 151,["109"] = 151,["110"] = 151,["112"] = 152,["113"] = 153,["115"] = 156,["116"] = 157,["117"] = 158,["119"] = 151,["120"] = 165,["121"] = 166,["122"] = 167,["123"] = 165,["124"] = 174,["125"] = 175,["126"] = 176,["127"] = 177,["130"] = 180,["131"] = 181,["132"] = 182,["134"] = 184,["135"] = 174,["136"] = 190,["137"] = 191,["138"] = 192,["139"] = 193,["141"] = 194,["142"] = 194,["144"] = 195,["145"] = 195,["146"] = 196,["147"] = 197,["148"] = 198,["149"] = 199,["151"] = 195,["154"] = 194,["157"] = 203,["158"] = 203,["159"] = 203,["160"] = 203,["161"] = 203,["162"] = 203,["163"] = 203,["164"] = 204,["165"] = 190,["166"] = 210,["167"] = 211,["168"] = 212,["169"] = 210,["170"] = 218,["171"] = 219,["172"] = 220,["173"] = 221,["174"] = 222,["175"] = 223,["176"] = 224,["177"] = 225,["178"] = 226,["179"] = 227,["181"] = 229,["183"] = 231,["184"] = 218,["185"] = 234,["186"] = 235,["187"] = 236,["188"] = 237,["189"] = 238,["190"] = 239,["192"] = 241,["193"] = 242,["194"] = 243,["195"] = 244,["198"] = 247,["200"] = 250,["201"] = 253,["202"] = 254,["205"] = 257,["206"] = 257,["207"] = 258,["208"] = 259,["209"] = 260,["211"] = 262,["212"] = 263,["213"] = 264,["214"] = 265,["216"] = 267,["218"] = 257,["221"] = 272,["222"] = 273,["223"] = 274,["224"] = 275,["226"] = 277,["229"] = 281,["230"] = 282,["232"] = 234,["233"] = 290,["234"] = 291,["235"] = 292,["236"] = 290,["237"] = 296,["238"] = 297,["239"] = 298,["240"] = 299,["241"] = 300,["243"] = 303,["244"] = 303,["245"] = 303,["246"] = 303,["247"] = 303,["249"] = 305,["250"] = 305,["251"] = 305,["252"] = 305,["253"] = 305,["255"] = 296,["256"] = 316,["257"] = 317,["258"] = 318,["260"] = 320,["261"] = 321,["263"] = 322,["264"] = 322,["265"] = 323,["266"] = 324,["267"] = 325,["268"] = 326,["269"] = 327,["271"] = 322,["274"] = 330,["275"] = 330,["276"] = 330,["277"] = 331,["278"] = 331,["279"] = 331,["280"] = 331,["281"] = 331,["282"] = 331,["283"] = 331,["284"] = 332,["285"] = 330,["286"] = 330,["287"] = 334,["288"] = 334,["289"] = 334,["292"] = 341,["295"] = 336,["296"] = 337,["297"] = 338,["304"] = 343,["305"] = 344,["306"] = 344,["307"] = 344,["308"] = 344,["309"] = 344,["310"] = 344,["311"] = 344,["312"] = 334,["313"] = 334,["314"] = 346,["315"] = 346,["316"] = 346,["317"] = 347,["318"] = 348,["319"] = 349,["320"] = 350,["321"] = 350,["322"] = 350,["323"] = 350,["324"] = 350,["325"] = 350,["326"] = 350,["327"] = 346,["328"] = 346,["329"] = 346,["330"] = 353,["331"] = 316,["332"] = 356,["333"] = 357,["334"] = 358,["335"] = 359,["336"] = 360,["337"] = 361,["339"] = 362,["340"] = 362,["342"] = 363,["343"] = 364,["345"] = 365,["346"] = 365,["347"] = 366,["348"] = 367,["349"] = 368,["350"] = 369,["352"] = 372,["353"] = 373,["354"] = 374,["355"] = 375,["356"] = 376,["357"] = 377,["358"] = 377,["359"] = 377,["360"] = 377,["361"] = 377,["365"] = 365,["368"] = 383,["369"] = 384,["371"] = 386,["374"] = 418,["375"] = 419,["376"] = 419,["377"] = 419,["378"] = 419,["379"] = 419,["380"] = 419,["381"] = 419,["382"] = 420,["385"] = 388,["386"] = 389,["387"] = 390,["388"] = 391,["389"] = 392,["390"] = 392,["391"] = 392,["392"] = 392,["393"] = 392,["394"] = 392,["395"] = 392,["396"] = 394,["397"] = 394,["398"] = 394,["399"] = 394,["400"] = 394,["401"] = 394,["402"] = 394,["403"] = 397,["406"] = 401,["407"] = 402,["408"] = 403,["409"] = 405,["410"] = 405,["411"] = 405,["412"] = 405,["413"] = 405,["414"] = 405,["415"] = 405,["416"] = 406,["418"] = 409,["419"] = 410,["420"] = 411,["421"] = 413,["422"] = 414,["430"] = 387,["435"] = 362,["438"] = 423,["439"] = 356,["440"] = 17,["441"] = 18,["442"] = 21,["443"] = 25,["444"] = 28,["445"] = 30,["446"] = 32,["447"] = 33,["448"] = 34,["449"] = 36,["450"] = 38,["451"] = 314});
local ____exports = {}
local ____CodecUtil = require("solar.solar-common.util.math.CodecUtil")
local CodecUtil = ____CodecUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____player = require("solar.solar-common.w3ts.handles.player")
local MapPlayer = ____player.MapPlayer
local ____PlatUtil = require("solar.solar-common.util.game.PlatUtil")
local PlatUtil = ____PlatUtil.default
local ____PlayerUtil = require("solar.solar-common.util.game.PlayerUtil")
local PlayerUtil = ____PlayerUtil.default
____exports.default = __TS__Class()
local ArchiveUtil = ____exports.default
ArchiveUtil.name = "ArchiveUtil"
function ArchiveUtil.prototype.____constructor(self)
end
function ArchiveUtil.get(self, whichPlayer, key, limitVal, limitKey)
    if limitVal == nil then
        limitVal = 0
    end
    if limitKey == nil then
        limitKey = ____exports.default.defaultLimitKey
    end
    ____exports.default:_init0()
    if limitVal > 0 then
        local sVal = limitKey and S2I(DzAPI_Map_GetServerValue(whichPlayer, limitKey)) or DzAPI_Map_GetMapLevel(whichPlayer)
        if sVal < limitVal then
            return nil
        end
    end
    local data = ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))]
    if not data then
        return nil
    end
    return data[key]
end
function ArchiveUtil.updateMaxNumber(self, whichPlayer, key, value)
    local oldVal = ____exports.default:get(whichPlayer, key) or 0
    if value == nil then
        return oldVal
    end
    if value > oldVal then
        ____exports.default:set(whichPlayer, key, value)
        return value
    end
    return oldVal
end
function ArchiveUtil.addNumber(self, whichPlayer, key, addValue)
    local oldVal = ____exports.default:get(whichPlayer, key) or 0
    local newVal = oldVal + addValue
    ____exports.default:set(whichPlayer, key, newVal)
    return newVal
end
function ArchiveUtil.set(self, whichPlayer, key, value, isSave)
    if isSave == nil then
        isSave = true
    end
    if not IsHandle(whichPlayer) then
        if isDebug then
            log.errorWithTraceBack()
        end
        return
    end
    if key == nil then
        if isDebug then
            log.errorWithTraceBack()
        end
        return
    end
    ____exports.default:_init0()
    local data = ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))]
    if not data then
        data = {}
        ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))] = data
    end
    data[key] = value
    if value == nil then
        __TS__Delete(data, key)
    end
    local bucketId = ____exports.default:_sl_getBucketId(key)
    local playerDataBucket = ____exports.default.playerDataBuckets["P" .. tostring(GetPlayerId(whichPlayer))]
    if playerDataBucket == nil then
        playerDataBucket = {}
        ____exports.default.playerDataBuckets["P" .. tostring(GetPlayerId(whichPlayer))] = playerDataBucket
    end
    local bucket = playerDataBucket[bucketId]
    if bucket == nil then
        bucket = {}
        playerDataBucket[bucketId] = bucket
    end
    bucket[key] = value
    if value == nil then
        __TS__Delete(bucket, key)
    end
    if isSave then
        if isDebug then
            print((("ArchiveUtil.set:" .. key) .. "=") .. tostring(value))
        end
        ____exports.default:_sl_saveBucket(whichPlayer, bucketId, bucket)
    end
end
function ArchiveUtil.saveAll(self, whichPlayer, ignoreWarning)
    if ignoreWarning == nil then
        ignoreWarning = false
    end
    if ignoreWarning == false then
        log.errorWithTraceBack("不推荐的用法!一次性保存所有存档可能导致崩溃丢档!")
    end
    local playerDataBucket = ____exports.default.playerDataBuckets["P" .. tostring(GetPlayerId(whichPlayer))]
    for bucketId in pairs(playerDataBucket) do
        ____exports.default:_sl_saveBucket(whichPlayer, bucketId, playerDataBucket[bucketId])
    end
end
function ArchiveUtil.getAllArchive(self, whichPlayer)
    ____exports.default:_init0()
    return ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))]
end
function ArchiveUtil.printAllArchive(self, whichPlayer)
    ____exports.default:_init0()
    local data = ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))]
    if not data then
        return
    end
    print(("========打印玩家" .. tostring(GetPlayerId(whichPlayer) + 1)) .. "的存档 开始========")
    for dataKey in pairs(data) do
        print(((dataKey .. "=[") .. tostring(data[dataKey])) .. "]")
    end
    print(("========打印玩家" .. tostring(GetPlayerId(whichPlayer) + 1)) .. "的存档 结束========")
end
function ArchiveUtil.clearAllArchive(self, whichPlayer)
    ____exports.default:_init0()
    ____exports.default.playerDatas["P" .. tostring(GetPlayerId(whichPlayer))] = {}
    ____exports.default.playerDataBuckets["P" .. tostring(GetPlayerId(whichPlayer))] = {}
    do
        local bidNo = 0
        while bidNo <= ____exports.default.bucketMax do
            do
                local i = 0
                while i < ____exports.default.bucketKeyCountMax do
                    local key = (("B_" .. tostring(bidNo)) .. "_") .. tostring(i)
                    local serverValue = DzAPI_Map_GetServerValue(whichPlayer, key)
                    if serverValue and #serverValue > 0 then
                        DzAPI_Map_FlushStoredMission(whichPlayer, key)
                    end
                    i = i + 1
                end
            end
            bidNo = bidNo + 1
        end
    end
    DisplayTimedTextToPlayer(
        whichPlayer,
        0,
        0,
        10,
        "|cffff0000已清理全部存档!请重开游戏查看效果!"
    )
    print("已清理全部存档!")
end
function ArchiveUtil.getCurrentArchiveKeyMax(self, whichPlayer)
    ____exports.default:_init0()
    return ____exports.default._sl_playerCurrentArchiveKeyMax["P" .. tostring(GetPlayerId(whichPlayer))] or 0
end
function ArchiveUtil.getCurrentArchiveKeyMaxInfo(self, whichPlayer)
    local used = ____exports.default:getCurrentArchiveKeyMax(whichPlayer)
    local p = math.ceil(used * 100 / ____exports.default.allKeyCountMax)
    local info = ("(" .. tostring(p)) .. "%)"
    if p > 90 then
        info = "|cffff0000" .. info
    elseif p > 80 then
        info = "|cffe24700" .. info
    elseif p > 70 then
        info = "|cffdb7835" .. info
    else
        info = "|cff0a8f17" .. info
    end
    return ((tostring(used) .. "/") .. tostring(____exports.default.allKeyCountMax)) .. info
end
function ArchiveUtil._sl_saveBucket(self, whichPlayer, bucketId, bucket)
    local dataJsonStr = JSON:stringify(bucket)
    local userIdTag = ____exports.default:_sl_getUserIdTag(whichPlayer)
    dataJsonStr = userIdTag .. __TS__StringSubstring(dataJsonStr, 1, #dataJsonStr - 1)
    if ____exports.default.encrypt then
        dataJsonStr = CodecUtil:saesEncode(dataJsonStr, gameName .. ____exports.default.salt)
    end
    local dataJsonStrLength = #dataJsonStr
    local keyLength = math.floor(dataJsonStrLength / 64) + 1
    if keyLength > ____exports.default.bucketKeyCountMax then
        log.errorWithTraceBack((("存档栏位大小超过" .. tostring(____exports.default.bucketKeyCountMax)) .. "！") .. tostring(keyLength))
        return
    end
    local oneData = nil
    --- 当存档位需要多个key时  使用批量保存  以保证数据完整性
    local useBatch = not isDebug
    if useBatch then
        KKApiBeginBatchSaveArchive(whichPlayer)
    end
    do
        local i = 0
        while i < keyLength do
            local endIndex = (i + 1) * 64
            if endIndex > dataJsonStrLength then
                endIndex = dataJsonStrLength
            end
            oneData = __TS__StringSubstring(dataJsonStr, i * 64, endIndex)
            local key = (bucketId .. "_") .. tostring(i)
            if useBatch then
                KKApiAddBatchSaveArchive(whichPlayer, key, oneData, true)
            else
                DzAPI_Map_SaveServerValue(whichPlayer, key, oneData)
            end
            i = i + 1
        end
    end
    if #oneData == 64 then
        local key = (bucketId .. "_") .. tostring(keyLength)
        if useBatch then
            KKApiAddBatchSaveArchive(whichPlayer, key, "", true)
        else
            DzAPI_Map_FlushStoredMission(whichPlayer, key)
        end
    end
    if useBatch then
        KKApiEndBatchSaveArchive(whichPlayer, false)
    end
end
function ArchiveUtil._sl_getBucketId(self, key)
    local index = math.abs(StringHash(key)) % ____exports.default.bucketMax
    return "B_" .. tostring(index)
end
function ArchiveUtil._sl_getUserIdTag(self, p)
    if GetUserId then
        local uid = MapPlayer:fromHandle(p).userId
        if uid == -1 then
            log.errorWithTraceBack("请等待内置userId(用户id)同步完成！(为了解决玩家名更改后靠userId判断是否是自己的存档)")
        end
        return __TS__StringSubstring(
            CodecUtil:sBase64Encode("SL" .. tostring(uid)),
            0,
            2
        )
    else
        return __TS__StringSubstring(
            CodecUtil:sBase64Encode("SL" .. GetPlayerName(p)),
            0,
            2
        )
    end
end
function ArchiveUtil._init0(self)
    if ____exports.default.isInit then
        return true
    end
    ____exports.default.isInit = true
    ____exports.default._init_time = time
    do
        local i = 0
        while i < bj_MAX_PLAYER_SLOTS do
            local tempPlayer = Player(i)
            if GetPlayerController(tempPlayer) == MAP_CONTROL_USER and GetPlayerSlotState(tempPlayer) == PLAYER_SLOT_STATE_PLAYING then
                local playerAllArchiveData = ____exports.default:_init0_onePlayer(tempPlayer)
                ____exports.default.playerDatas["P" .. tostring(i)] = playerAllArchiveData
                DataBase:getPlayerSolarData(tempPlayer, true)._tt = playerAllArchiveData._tt or 0
            end
            i = i + 1
        end
    end
    se:onPlayerChat(
        "-sl-ia",
        function(e)
            DisplayTimedTextToPlayer(
                e.triggerPlayer,
                0,
                0,
                10,
                ____exports.default:getCurrentArchiveKeyMaxInfo(e.triggerPlayer)
            )
            ____exports.default:printAllArchive(e.triggerPlayer)
        end
    )
    se:onPlayerChat(
        "-清空存档",
        function(e)
            do
                local function ____catch(e)
                    print(e)
                end
                local ____try, ____hasReturned = pcall(function()
                    for ____, allArchiveKey in ipairs(PlatUtil.allArchiveKeys) do
                        DzAPI_Map_SaveServerValue(e.triggerPlayer, allArchiveKey, "")
                        DzAPI_Map_FlushStoredMission(e.triggerPlayer, allArchiveKey)
                    end
                end)
                if not ____try then
                    ____catch(____hasReturned)
                end
            end
            ____exports.default:clearAllArchive(e.triggerPlayer)
            DisplayTimedTextToPlayer(
                e.triggerPlayer,
                0,
                0,
                10,
                "清空存档完毕!"
            )
        end
    )
    se:onPlayerChat(
        "-sla-remove-",
        function(e)
            local key = __TS__StringSubstring(e.eventPlayerChatString, 12)
            local serverValue = DzAPI_Map_GetServerValue(e.triggerPlayer, key)
            DzAPI_Map_FlushStoredMission(e.triggerPlayer, key)
            DisplayTimedTextToPlayer(
                e.triggerPlayer,
                0,
                0,
                10,
                (("|cffff0000移除存档:" .. key) .. ":") .. tostring(serverValue)
            )
        end,
        false
    )
    return true
end
function ArchiveUtil._init0_onePlayer(self, tempPlayer)
    local data = {}
    local pId = GetPlayerId(tempPlayer)
    local userIdTag = ____exports.default:_sl_getUserIdTag(tempPlayer)
    local buckets = {}
    ____exports.default.playerDataBuckets["P" .. tostring(pId)] = buckets
    do
        local bIndex = 0
        while bIndex < ____exports.default.bucketMax do
            do
                local bucketId = "B_" .. tostring(bIndex)
                local bucketDataJsonStr = ""
                do
                    local i = 0
                    while i < ____exports.default.bucketKeyCountMax do
                        local key = (bucketId .. "_") .. tostring(i)
                        local serverValue = DzAPI_Map_GetServerValue(tempPlayer, key)
                        if serverValue and #serverValue > 0 then
                            bucketDataJsonStr = bucketDataJsonStr .. serverValue
                        end
                        if serverValue == nil or #serverValue < 64 then
                            local keyMax = ____exports.default._sl_playerCurrentArchiveKeyMax["P" .. tostring(pId)] or 0
                            keyMax = keyMax + i
                            ____exports.default._sl_playerCurrentArchiveKeyMax["P" .. tostring(pId)] = keyMax
                            if keyMax > ____exports.default.allKeyCountMax then
                                PlayerUtil:message(
                                    "|cffff0000【系统错误】存储量已超过最大限制！keyCount=" .. tostring(keyMax),
                                    60,
                                    tempPlayer
                                )
                            end
                            break
                        end
                        i = i + 1
                    end
                end
                if #bucketDataJsonStr < 4 then
                    goto __continue76
                end
                local continueFlag = false
                do
                    local function ____catch(e)
                        print("存档Json格式解析出错!")
                        DisplayTimedTextToPlayer(
                            GetLocalPlayer(),
                            0,
                            0,
                            60,
                            "存档格式解析出错！请不要私自修改存档数据！"
                        )
                        print(("需要解析的Json字符串为[" .. bucketDataJsonStr) .. "]")
                    end
                    local ____try, ____hasReturned, ____returnValue = pcall(function()
                        if ____exports.default.encrypt then
                            bucketDataJsonStr = CodecUtil:saesDecode(bucketDataJsonStr, gameName .. ____exports.default.salt)
                            if bucketDataJsonStr == nil then
                                print("存档Json格式解析出错!")
                                DisplayTimedTextToPlayer(
                                    GetLocalPlayer(),
                                    0,
                                    0,
                                    60,
                                    ((("|cffff0000玩家" .. tostring(pId + 1)) .. ":") .. GetPlayerName(tempPlayer)) .. " 的存档格式解析出错！"
                                )
                                DisplayTimedTextToPlayer(
                                    tempPlayer,
                                    0,
                                    0,
                                    60,
                                    ("请不要私自修改存档数据或保存存档时终止游戏！" .. "异常的bucketId=") .. bucketId
                                )
                                continueFlag = true
                            end
                        end
                        if continueFlag == false then
                            local bucketUserIdTag = __TS__StringSubstring(bucketDataJsonStr, 0, 2)
                            if ____exports.default.verifyPlayerName and userIdTag ~= bucketUserIdTag then
                                DisplayTimedTextToPlayer(
                                    tempPlayer,
                                    0,
                                    0,
                                    20,
                                    "|cffff0000存档玩家名验证失败!请重开游戏或使用空存档继续游玩!"
                                )
                                return true, data
                            end
                            bucketDataJsonStr = ("{" .. __TS__StringSubstring(bucketDataJsonStr, 2)) .. "}"
                            local bucketData = JSON:parse(bucketDataJsonStr)
                            buckets[bucketId] = bucketData
                            for bucketDataKey in pairs(bucketData) do
                                data[bucketDataKey] = bucketData[bucketDataKey]
                            end
                        end
                    end)
                    if not ____try then
                        ____hasReturned, ____returnValue = ____catch(____hasReturned)
                    end
                    if ____hasReturned then
                        return ____returnValue
                    end
                end
            end
            ::__continue76::
            bIndex = bIndex + 1
        end
    end
    return data
end
ArchiveUtil.encrypt = true
ArchiveUtil.verifyPlayerName = not isDebug
ArchiveUtil.allKeyCountMax = 150
ArchiveUtil.bucketKeyCountMax = 50
ArchiveUtil.salt = "s_z_b_s_q_j"
ArchiveUtil.defaultLimitKey = nil
ArchiveUtil.playerDatas = {}
ArchiveUtil._sl_playerCurrentArchiveKeyMax = {}
ArchiveUtil._init_time = -1
ArchiveUtil.playerDataBuckets = {}
ArchiveUtil.bucketMax = 100
ArchiveUtil.isInit = false
return ____exports
