local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 1,["10"] = 1,["11"] = 6,["12"] = 6,["13"] = 6,["15"] = 6,["16"] = 24,["17"] = 25,["19"] = 26,["20"] = 26,["22"] = 27,["23"] = 34,["26"] = 37,["27"] = 38,["28"] = 39,["29"] = 40,["31"] = 42,["34"] = 26,["37"] = 44,["38"] = 24,["39"] = 50,["40"] = 51,["43"] = 54,["44"] = 55,["45"] = 56,["46"] = 57,["47"] = 58,["48"] = 59,["50"] = 61,["52"] = 63,["53"] = 50,["54"] = 71,["55"] = 72,["58"] = 75,["59"] = 76,["60"] = 77,["62"] = 78,["63"] = 79,["64"] = 80,["66"] = 82,["67"] = 83,["68"] = 84,["70"] = 86,["74"] = 88,["75"] = 71,["76"] = 94,["77"] = 95,["80"] = 98,["81"] = 99,["82"] = 100,["83"] = 101,["84"] = 102,["85"] = 103,["87"] = 105,["89"] = 107,["90"] = 94,["91"] = 118,["92"] = 118,["93"] = 118,["95"] = 119,["96"] = 120,["98"] = 122,["99"] = 122,["100"] = 122,["101"] = 122,["102"] = 122,["103"] = 122,["104"] = 123,["105"] = 123,["106"] = 123,["107"] = 123,["108"] = 123,["109"] = 123,["110"] = 124,["111"] = 125,["112"] = 126,["114"] = 118,["115"] = 138,["116"] = 138,["117"] = 138,["119"] = 139,["120"] = 140,["122"] = 142,["123"] = 142,["124"] = 142,["125"] = 142,["126"] = 142,["127"] = 142,["128"] = 143,["129"] = 144,["130"] = 145,["132"] = 138,["133"] = 155,["134"] = 156,["135"] = 156,["136"] = 156,["137"] = 156,["138"] = 156,["139"] = 155,["140"] = 167,["141"] = 167,["142"] = 167,["144"] = 168,["145"] = 169,["147"] = 171,["148"] = 171,["149"] = 171,["150"] = 171,["151"] = 171,["152"] = 171,["153"] = 172,["154"] = 173,["155"] = 174,["157"] = 167,["158"] = 186,["159"] = 186,["160"] = 186,["162"] = 187,["163"] = 188,["165"] = 190,["166"] = 190,["167"] = 190,["168"] = 190,["169"] = 190,["170"] = 190,["171"] = 191,["172"] = 192,["173"] = 193,["175"] = 186,["176"] = 204,["177"] = 204,["178"] = 204,["180"] = 205,["181"] = 205,["182"] = 205,["183"] = 205,["184"] = 205,["185"] = 205,["186"] = 206,["187"] = 207,["188"] = 208,["190"] = 204,["191"] = 224,["192"] = 224,["193"] = 224,["195"] = 225,["196"] = 224,["197"] = 235,["198"] = 235,["199"] = 235,["201"] = 236,["202"] = 237,["204"] = 239,["205"] = 239,["206"] = 239,["207"] = 239,["208"] = 239,["209"] = 239,["210"] = 240,["211"] = 241,["212"] = 242,["214"] = 235,["215"] = 260,["216"] = 260,["217"] = 260,["219"] = 261,["220"] = 262,["222"] = 264,["223"] = 265,["224"] = 260,["225"] = 275,["226"] = 275,["227"] = 275,["229"] = 276,["230"] = 276,["231"] = 276,["232"] = 276,["233"] = 276,["234"] = 276,["235"] = 277,["236"] = 278,["237"] = 279,["239"] = 275,["240"] = 290,["241"] = 290,["242"] = 290,["244"] = 291,["245"] = 292,["247"] = 294,["248"] = 294,["249"] = 294,["250"] = 294,["251"] = 294,["252"] = 294,["253"] = 295,["254"] = 296,["255"] = 297,["257"] = 290,["258"] = 308,["259"] = 308,["260"] = 308,["262"] = 309,["263"] = 310,["265"] = 312,["266"] = 312,["267"] = 312,["268"] = 312,["269"] = 312,["270"] = 312,["271"] = 313,["272"] = 314,["273"] = 315,["275"] = 308,["276"] = 327,["277"] = 327,["278"] = 327,["280"] = 328,["281"] = 329,["283"] = 331,["284"] = 332,["285"] = 332,["286"] = 332,["287"] = 332,["288"] = 332,["289"] = 332,["290"] = 333,["291"] = 334,["292"] = 335,["294"] = 327,["295"] = 344,["296"] = 345,["297"] = 346,["298"] = 344,["299"] = 357,["300"] = 358,["301"] = 359,["303"] = 361,["304"] = 362,["306"] = 364,["307"] = 364,["308"] = 364,["309"] = 364,["310"] = 364,["311"] = 364,["312"] = 357,["313"] = 371,["314"] = 372,["315"] = 373,["317"] = 375,["318"] = 376,["320"] = 378,["321"] = 378,["322"] = 378,["323"] = 378,["324"] = 378,["325"] = 371,["326"] = 388,["327"] = 389,["328"] = 390,["330"] = 392,["331"] = 393,["333"] = 395,["334"] = 395,["335"] = 395,["336"] = 395,["337"] = 395,["338"] = 395,["339"] = 396,["340"] = 396,["341"] = 396,["342"] = 396,["343"] = 396,["344"] = 397,["345"] = 397,["346"] = 397,["347"] = 397,["348"] = 397,["349"] = 397,["350"] = 388,["351"] = 408,["352"] = 408,["353"] = 408,["355"] = 409,["356"] = 410,["358"] = 412,["359"] = 412,["360"] = 412,["361"] = 412,["362"] = 412,["363"] = 412,["364"] = 413,["365"] = 414,["366"] = 415,["368"] = 408,["369"] = 427,["370"] = 427,["371"] = 427,["373"] = 428,["374"] = 429,["376"] = 431,["377"] = 431,["378"] = 431,["379"] = 431,["380"] = 431,["381"] = 431,["382"] = 432,["383"] = 433,["384"] = 434,["386"] = 427,["387"] = 446,["388"] = 446,["389"] = 446,["391"] = 447,["392"] = 448,["394"] = 450,["395"] = 450,["396"] = 450,["397"] = 450,["398"] = 450,["399"] = 450,["400"] = 451,["401"] = 452,["402"] = 453,["404"] = 446,["405"] = 462,["406"] = 463,["407"] = 464,["408"] = 465,["409"] = 466,["410"] = 467,["411"] = 469,["412"] = 470,["414"] = 472,["416"] = 474,["417"] = 476,["418"] = 478,["419"] = 479,["421"] = 481,["423"] = 483,["424"] = 484,["425"] = 485,["426"] = 486,["427"] = 487,["428"] = 488,["429"] = 489,["430"] = 490,["431"] = 491,["433"] = 493,["434"] = 494,["436"] = 462,["437"] = 503,["438"] = 504,["439"] = 505,["440"] = 503,["441"] = 517,["442"] = 518,["443"] = 519,["445"] = 522,["446"] = 523,["447"] = 524,["449"] = 527,["450"] = 528,["451"] = 529,["453"] = 532,["454"] = 533,["455"] = 534,["457"] = 537,["458"] = 539,["459"] = 540,["460"] = 541,["462"] = 544,["463"] = 545,["464"] = 546,["467"] = 549,["468"] = 517,["469"] = 557,["470"] = 558,["471"] = 558,["472"] = 558,["473"] = 558,["474"] = 558,["475"] = 557,["476"] = 566,["477"] = 567,["478"] = 567,["479"] = 567,["480"] = 567,["481"] = 566,["482"] = 576,["483"] = 576,["484"] = 576,["486"] = 577,["487"] = 578,["488"] = 579,["489"] = 580,["490"] = 581,["492"] = 582,["493"] = 582,["494"] = 583,["495"] = 583,["496"] = 583,["497"] = 583,["498"] = 582,["503"] = 587,["504"] = 576,["505"] = 594,["506"] = 595,["507"] = 596,["508"] = 594,["509"] = 602,["510"] = 603,["511"] = 604,["512"] = 602,["513"] = 8,["514"] = 9,["515"] = 9,["516"] = 9,["517"] = 9,["518"] = 9,["519"] = 9,["520"] = 9,["521"] = 8});
local ____exports = {}
local ____TargetType = require("solar.solar-common.constant.TargetType")
local TargetType = ____TargetType.default
local OptionType = ____TargetType.OptionType
local TargetCnType = ____TargetType.TargetCnType
____exports.default = __TS__Class()
local AbilityUtil = ____exports.default
AbilityUtil.name = "AbilityUtil"
function AbilityUtil.prototype.____constructor(self)
end
function AbilityUtil.getUnitAbilityIds(self, unit)
    local abilityIdStrs = {}
    do
        local i = 0
        while i < 100 do
            do
                local ar = EXGetUnitAbilityByIndex(unit, i)
                if not IsHandle(ar) then
                    break
                end
                local aId = EXGetAbilityId(ar)
                local aIdStr = id2string(aId)
                if ____exports.default.config.ignoreAbilityIds[aIdStr] then
                    goto __continue5
                end
                abilityIdStrs[#abilityIdStrs + 1] = aIdStr
            end
            ::__continue5::
            i = i + 1
        end
    end
    return abilityIdStrs
end
function AbilityUtil.targets2Num(self, str)
    if not str then
        return
    end
    local result = 0
    local data = __TS__StringSplit(str, ",")
    for ____, name in ipairs(data) do
        local flag = TargetType[name]
        if not flag then
            print("错误的目标允许类型: " .. name)
        end
        result = result + flag
    end
    return result
end
function AbilityUtil.targetAllow2Num(self, str)
    if not str then
        return
    end
    local result = 0
    local data = __TS__StringSplit(str, ",")
    for ____, name in ipairs(data) do
        do
            local flag = TargetCnType[name]
            if flag == nil then
                flag = TargetType[name]
            end
            if flag == nil then
                print("错误的目标允许类型: " .. name)
                goto __continue15
            end
            result = result + flag
        end
        ::__continue15::
    end
    return result
end
function AbilityUtil.option2Num(self, str)
    if not str then
        return
    end
    local result = 0
    local data = __TS__StringSplit(str, ",")
    for ____, name in ipairs(data) do
        local flag = OptionType[name]
        if not flag then
            print("错误的图标选项类型: " .. name)
        end
        result = result + flag
    end
    return result
end
function AbilityUtil.setUnitAbilityName(self, udw, abilityId, name, isref)
    if isref == nil then
        isref = false
    end
    if not name then
        print("不存在技能名字")
    end
    EXSetAbilityDataString(
        EXGetUnitAbility(udw, abilityId),
        1,
        ABILITY_DATA_NAME,
        name
    )
    EXSetAbilityDataString(
        EXGetUnitAbility(udw, abilityId),
        1,
        ABILITY_DATA_TIP,
        name
    )
    if isref then
        IncUnitAbilityLevel(udw, abilityId)
        DecUnitAbilityLevel(udw, abilityId)
    end
end
function AbilityUtil.setUnitAbilityHotkey(self, udw, abilityId, hotKey, isref)
    if isref == nil then
        isref = false
    end
    if not hotKey then
        print("不存在hotKey")
    end
    EXSetAbilityDataInteger(
        EXGetUnitAbility(udw, abilityId),
        1,
        ABILITY_DATA_HOTKET,
        hotKey
    )
    if isref then
        IncUnitAbilityLevel(udw, abilityId)
        DecUnitAbilityLevel(udw, abilityId)
    end
end
function AbilityUtil.getUnitAbilityArt(self, udw, abilityId)
    return EXGetAbilityDataString(
        EXGetUnitAbility(udw, abilityId),
        1,
        ABILITY_DATA_ART
    )
end
function AbilityUtil.setUnitAbilityArt(self, udw, abilityId, art, isref)
    if isref == nil then
        isref = false
    end
    if not art then
        print("不存在技能图标路径")
    end
    EXSetAbilityDataString(
        EXGetUnitAbility(udw, abilityId),
        1,
        ABILITY_DATA_ART,
        art
    )
    if isref then
        IncUnitAbilityLevel(udw, abilityId)
        DecUnitAbilityLevel(udw, abilityId)
    end
end
function AbilityUtil.setUnitAbilityUbertip(self, udw, skid, Ubertip, isref)
    if isref == nil then
        isref = false
    end
    if not Ubertip then
        print("不存在技能提示拓展")
    end
    EXSetAbilityDataString(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_UBERTIP,
        Ubertip
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityDataA(self, udw, skid, data, isref)
    if isref == nil then
        isref = false
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_DATA_A,
        data
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitANclAbilityTarget(self, udw, skid, target_type, isref)
    if isref == nil then
        isref = false
    end
    ____exports.default:setUnitAbilityDataB(udw, skid, target_type, isref)
end
function AbilityUtil.setUnitAbilityDataB(self, udw, skid, DataB, isref)
    if isref == nil then
        isref = false
    end
    if not DataB then
        print("不存在技能图标路径")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_DATA_B,
        DataB
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitANclAbilityOption(self, udw, skid, options, isref)
    if isref == nil then
        isref = false
    end
    if not options then
        print("不存在技能选项")
    end
    local data = ____exports.default:option2Num(options)
    ____exports.default:setUnitAbilityDataC(udw, skid, data, isref)
end
function AbilityUtil.setUnitAbilityDataC(self, udw, skid, data, isref)
    if isref == nil then
        isref = false
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_DATA_C,
        data
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityDataD(self, udw, skid, data, isref)
    if isref == nil then
        isref = false
    end
    if not data then
        print("不存在技能选项")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_DATA_D,
        data
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityUnitId(self, udw, skid, data, isref)
    if isref == nil then
        isref = false
    end
    if not data then
        print("不存在技能选项")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_UNITID,
        data
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityTargs(self, udw, skid, Targs, isref)
    if isref == nil then
        isref = false
    end
    if not Targs then
        print("不存在技能目标允许")
    end
    local data = ____exports.default:targets2Num(Targs)
    EXSetAbilityDataInteger(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_TARGS,
        R2I(data)
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.refreshAbility(self, udw, skid)
    IncUnitAbilityLevel(udw, skid)
    DecUnitAbilityLevel(udw, skid)
end
function AbilityUtil.setUnitAbilityCool(self, udw, skid, cool)
    if type(skid) == "string" then
        skid = FourCC(skid)
    end
    if not cool then
        print("不存在技能释放间隔")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_COOL,
        cool
    )
end
function AbilityUtil.setUnitAbilityStateCooldown(self, udw, skid, state_cooldown)
    if type(skid) == "string" then
        skid = FourCC(skid)
    end
    if not state_cooldown then
        print("不存在技能释放间隔")
    end
    EXSetAbilityState(
        EXGetUnitAbility(udw, skid),
        ABILITY_STATE_COOLDOWN,
        state_cooldown
    )
end
function AbilityUtil.refreshUnitAbilityStateCooldown(self, udw, skid, state_cooldown)
    if type(skid) == "string" then
        skid = FourCC(skid)
    end
    if not state_cooldown then
        print("不存在技能释放间隔")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_COOL,
        state_cooldown
    )
    EXSetAbilityState(
        EXGetUnitAbility(udw, skid),
        ABILITY_STATE_COOLDOWN,
        state_cooldown
    )
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_COOL,
        0
    )
end
function AbilityUtil.setUnitAbilityCost(self, udw, skid, Cost, isref)
    if isref == nil then
        isref = false
    end
    if not Cost then
        print("不存在技能魔法消耗")
    end
    EXSetAbilityDataInteger(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_COST,
        Cost
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityRng(self, udw, skid, Rng, isref)
    if isref == nil then
        isref = false
    end
    if not Rng then
        print("不存在技能施法距离")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_RNG,
        Rng
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setUnitAbilityArea(self, udw, skid, Area, isref)
    if isref == nil then
        isref = false
    end
    if not Area then
        print("不存在技能影响区域")
    end
    EXSetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        1,
        ABILITY_DATA_AREA,
        Area
    )
    if isref then
        IncUnitAbilityLevel(udw, skid)
        DecUnitAbilityLevel(udw, skid)
    end
end
function AbilityUtil.setTargetType(self, ability, targetType)
    if targetType == "单位" then
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 1)
        EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_TARGS, 0)
    elseif targetType == "点" then
        if EXGetAbilityDataReal(ability, 1, ABILITY_DATA_AREA) < 100 then
            EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        else
            EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 3)
        end
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 2)
    elseif targetType == "单位或点" then
        if EXGetAbilityDataReal(ability, 1, ABILITY_DATA_AREA) < 100 then
            EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        else
            EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 3)
        end
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 3)
        EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_TARGS, 0)
    elseif targetType == "物品" then
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 1)
        EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_TARGS, 32)
    elseif targetType == "无目标" then
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 0)
    else
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 1)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 0)
    end
end
function AbilityUtil.setTargetAllow(self, ability, targetAllow)
    local allow2Num = ____exports.default:targetAllow2Num(targetAllow)
    EXSetAbilityDataInteger(ability, 1, ABILITY_DATA_TARGS, allow2Num)
end
function AbilityUtil.getSpellXY(self, attype, store)
    if not store then
        store = {}
    end
    if attype == 0 then
        store.x = GetUnitX(GetTriggerUnit())
        store.y = GetUnitY(GetTriggerUnit())
    end
    if attype == 1 then
        store.x = GetUnitX(GetSpellTargetUnit())
        store.y = GetUnitY(GetSpellTargetUnit())
    end
    if attype == 2 then
        store.x = GetSpellTargetX()
        store.y = GetSpellTargetY()
    end
    if attype == 2 then
        if GetSpellTargetX() ~= 0 and GetSpellTargetY() ~= 0 then
            store.x = GetSpellTargetX()
            store.y = GetSpellTargetY()
        end
        if GetUnitX(GetSpellTargetUnit()) ~= 0 and GetUnitY(GetSpellTargetUnit()) ~= 0 then
            store.x = GetUnitX(GetSpellTargetUnit())
            store.y = GetUnitY(GetSpellTargetUnit())
        end
    end
    return store
end
function AbilityUtil.getUnitAbilityCool(self, udw, skid)
    return EXGetAbilityDataReal(
        EXGetUnitAbility(udw, skid),
        GetUnitAbilityLevel(udw, skid),
        ABILITY_DATA_COOL
    )
end
function AbilityUtil.getUnitAbilityStateCooldown(self, udw, skid)
    return EXGetAbilityState(
        EXGetUnitAbility(udw, skid),
        ABILITY_STATE_COOLDOWN
    )
end
function AbilityUtil.studyHeroAbilLists(self, hero, maxLevel)
    if maxLevel == nil then
        maxLevel = 50
    end
    local uobj = _g_objs.unit[id2string(GetUnitTypeId(hero))]
    local heroAbilList = uobj.heroAbilList or ""
    local heroAbilLists = __TS__StringSplit(heroAbilList, ",")
    for ____, abilityId in ipairs(heroAbilLists) do
        if abilityId and #abilityId == 4 then
            do
                local i = 0
                while i < maxLevel do
                    SelectHeroSkill(
                        hero,
                        FourCC(abilityId)
                    )
                    i = i + 1
                end
            end
        end
    end
    return heroAbilLists
end
function AbilityUtil.isSelectUi(self)
    local ability, order = button(3, 2)
    return order == 851979
end
function AbilityUtil.isBookUi(self)
    local ability, order = button(3, 2)
    return order == 851975
end
AbilityUtil.config = {ignoreAbilityIds = {
    Ahrp = true,
    Amil = true,
    Ahar = true,
    Aatk = true,
    Amov = true,
    Afih = true,
    Aalr = true
}}
return ____exports
