local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["9"] = 1,["10"] = 1,["11"] = 4,["12"] = 4,["13"] = 4,["15"] = 4,["16"] = 12,["17"] = 13,["18"] = 12,["19"] = 21,["20"] = 22,["21"] = 21,["22"] = 31,["23"] = 32,["24"] = 31,["25"] = 40,["26"] = 41,["27"] = 40,["28"] = 52,["29"] = 53,["31"] = 54,["32"] = 54,["33"] = 55,["35"] = 55,["37"] = 55,["38"] = 55,["39"] = 55,["41"] = 55,["42"] = 56,["43"] = 54,["46"] = 58,["47"] = 59,["48"] = 60,["49"] = 61,["51"] = 63,["52"] = 64,["53"] = 65,["55"] = 67,["56"] = 52,["57"] = 77,["58"] = 77,["59"] = 80,["60"] = 81,["61"] = 83,["63"] = 84,["64"] = 84,["65"] = 85,["66"] = 86,["67"] = 87,["68"] = 88,["70"] = 84,["73"] = 92,["74"] = 93,["77"] = 96,["78"] = 96,["79"] = 97,["80"] = 98,["83"] = 101,["84"] = 102,["86"] = 104,["87"] = 105,["90"] = 96,["93"] = 109,["94"] = 110,["95"] = 111,["97"] = 113,["98"] = 77,["99"] = 122,["100"] = 122,["101"] = 123,["102"] = 124,["103"] = 125,["104"] = 126,["107"] = 129,["108"] = 130,["109"] = 131,["110"] = 132,["111"] = 133,["112"] = 134,["116"] = 138,["117"] = 122,["118"] = 148,["119"] = 149,["120"] = 148,["121"] = 155,["122"] = 156,["123"] = 155,["124"] = 163,["125"] = 164,["126"] = 163,["127"] = 171,["128"] = 172,["129"] = 171,["130"] = 5});
local ____exports = {}
local ____Random = require("solar.solar-common.tool.Random")
local Random = ____Random.default
____exports.default = __TS__Class()
local RandomUtil = ____exports.default
RandomUtil.name = "RandomUtil"
function RandomUtil.prototype.____constructor(self)
end
function RandomUtil.nextInt(min, max)
    return GetRandomInt(min, max)
end
function RandomUtil.nextReal(min, max)
    return GetRandomReal(min, max)
end
function RandomUtil.nextLocalInt(min, max)
    return math.floor(____exports.default.nextLocalReal(min, max) + 0.5)
end
function RandomUtil.nextLocalReal(min, max)
    return ____exports.default._SL_Random:nextReal(min, max)
end
function RandomUtil.getRandomElementByObjArrays(needkeyCount, weightKey, objArray)
    local indexAndWeight = {}
    do
        local i = 0
        while i < #objArray do
            local ____opt_0 = objArray[i + 1]
            if ____opt_0 ~= nil then
                ____opt_0 = ____opt_0[weightKey]
            end
            local ____opt_0_2 = ____opt_0
            if ____opt_0_2 == nil then
                ____opt_0_2 = 0
            end
            local weight = ____opt_0_2
            indexAndWeight[i] = weight
            i = i + 1
        end
    end
    local keys = ____exports.default.getRandomKeysByWeight(needkeyCount, indexAndWeight)
    local result = {}
    for ____, key in ipairs(keys) do
        result[#result + 1] = objArray[key + 1]
    end
    if #result < needkeyCount then
        print("getRandomElementByObjArrays: 没有找到足够的元素")
        return result
    end
    return result
end
function RandomUtil.getRandomKeysByWeight(needkeyCount, ...)
    local objAndWeights = {...}
    local result = {}
    local poolKeyCount = 0
    local allObjAndWeights = {}
    do
        local i = 0
        while i < #objAndWeights do
            local objAndWeight = objAndWeights[i + 1]
            for objAndWeightKey in pairs(objAndWeight) do
                allObjAndWeights[objAndWeightKey] = objAndWeight[objAndWeightKey]
                poolKeyCount = poolKeyCount + 1
            end
            i = i + 1
        end
    end
    if poolKeyCount <= needkeyCount then
        return __TS__ObjectKeys(allObjAndWeights)
    end
    do
        local i = 0
        while i < 1000000 do
            local one = ____exports.default.getRandomKeyByWeight(allObjAndWeights)
            if one == nil then
                break
            end
            if not __TS__ArrayIncludes(result, one) then
                result[#result + 1] = one
            end
            allObjAndWeights[one] = nil
            if #result >= needkeyCount then
                break
            end
            i = i + 1
        end
    end
    if #result < needkeyCount then
        print("getRandomKeysByWeight: 没有找到足够的元素")
        return result
    end
    return result
end
function RandomUtil.getRandomKeyByWeight(...)
    local objAndWeights = {...}
    local max = 0
    for ____, objAndWeight in ipairs(objAndWeights) do
        for objAndWeightKey in pairs(objAndWeight) do
            max = max + objAndWeight[objAndWeightKey]
        end
    end
    local ri = ____exports.default.nextReal(0, max)
    for ____, objAndWeight in ipairs(objAndWeights) do
        for objAndWeightKey in pairs(objAndWeight) do
            ri = ri - objAndWeight[objAndWeightKey]
            if ri <= 0 then
                return objAndWeightKey
            end
        end
    end
    return nil
end
function RandomUtil.isInChance(chance)
    return GetRandomReal(0, 1) < chance
end
function RandomUtil.randomAngle()
    return GetRandomReal(0, 360)
end
function RandomUtil.randomPercent()
    return GetRandomReal(0, 1)
end
function RandomUtil.randomBool()
    return GetRandomInt(0, 100) < 50
end
RandomUtil._SL_Random = __TS__New(Random)
return ____exports
