local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["9"] = 1,["10"] = 1,["11"] = 2,["12"] = 2,["13"] = 7,["14"] = 7,["15"] = 7,["17"] = 7,["18"] = 16,["19"] = 17,["20"] = 18,["21"] = 19,["22"] = 20,["23"] = 21,["25"] = 23,["26"] = 16,["27"] = 31,["28"] = 32,["29"] = 33,["30"] = 34,["31"] = 35,["32"] = 36,["34"] = 38,["35"] = 31,["36"] = 46,["37"] = 47,["38"] = 48,["39"] = 49,["40"] = 50,["41"] = 51,["43"] = 53,["44"] = 46,["45"] = 61,["46"] = 62,["47"] = 63,["48"] = 64,["49"] = 65,["50"] = 66,["52"] = 68,["53"] = 61,["54"] = 76,["55"] = 77,["56"] = 78,["57"] = 79,["58"] = 76,["59"] = 87,["60"] = 88,["61"] = 89,["63"] = 92,["64"] = 93,["65"] = 94,["66"] = 95,["68"] = 97,["69"] = 98,["70"] = 99,["71"] = 100,["72"] = 101,["74"] = 103,["75"] = 104,["78"] = 118,["79"] = 119,["82"] = 106,["83"] = 107,["84"] = 108,["85"] = 109,["86"] = 110,["87"] = 111,["88"] = 112,["90"] = 114,["91"] = 115,["92"] = 116,["98"] = 105,["101"] = 121,["102"] = 122,["104"] = 125,["105"] = 87,["106"] = 9});
local ____exports = {}
local ____LangUtil = require("solar.solar-common.util.lang.LangUtil")
local LangUtil = ____LangUtil.default
local ____Cache = require("solar.solar-common.tool.Cache")
local Cache = ____Cache.default
____exports.default = __TS__Class()
local VectorUtil = ____exports.default
VectorUtil.name = "VectorUtil"
function VectorUtil.prototype.____constructor(self)
end
function VectorUtil.add(self, v1, v2)
    local x = v1.x + v2.x
    local y = v1.y + v2.y
    if v1.z then
        local z = v1.z + (v2.z and v2.z or 0)
        return {x = x, y = y, z = z}
    end
    return {x = x, y = y}
end
function VectorUtil.subtract(self, v1, v2)
    local x = v1.x - v2.x
    local y = v1.y - v2.y
    if v1.z then
        local z = v1.z - (v2.z and v2.z or 0)
        return {x = x, y = y, z = z}
    end
    return {x = x, y = y}
end
function VectorUtil.mult(self, v1, v2)
    local x = v1.x * v2.x
    local y = v1.y * v2.y
    if v1.z then
        local z = v1.z * (v2.z and v2.z or 0)
        return {x = x, y = y, z = z}
    end
    return {x = x, y = y}
end
function VectorUtil.multScalar(self, v1, scalar)
    local x = v1.x * scalar
    local y = v1.y * scalar
    if v1.z then
        local z = v1.z * scalar
        return {x = x, y = y, z = z}
    end
    return {x = x, y = y}
end
function VectorUtil.getRandomXY(self, v1, bound)
    local x = v1.x + GetRandomInt(-bound, bound)
    local y = v1.y + GetRandomInt(-bound, bound)
    return {x = x, y = y}
end
function VectorUtil.getVector(self, data)
    if data == nil then
        return nil
    end
    if LangUtil:isString(data) and __TS__StringEndsWith(data, "]") then
        local lineLoc = ____exports.default.cache:get(data)
        if lineLoc then
            return lineLoc
        end
        local solarLineInfo = data
        local indexOf = (string.find(solarLineInfo, "[", nil, true) or 0) - 1
        if indexOf <= 0 then
            print(("线变量不存在:<" .. tostring(data)) .. ">...可在太阳rpg编辑器中双击地形画此变量名对应的线!")
            return nil
        end
        local solarLineName = __TS__StringSubstring(solarLineInfo, 0, indexOf)
        local solarLineIndex = tonumber(__TS__StringSubstring(solarLineInfo, indexOf + 1, #solarLineInfo - 1))
        do
            local function ____catch(e)
                print(e)
                print(("E:线变量不存在:<" .. tostring(data)) .. ">...可在太阳rpg编辑器中双击地形画此变量名对应的线!")
            end
            local ____try, ____hasReturned, ____returnValue = pcall(function()
                local _require = require
                local t2LExports = _require(solarLineName)
                local key, lineVals = next(t2LExports)
                local vectors = lineVals
                if solarLineIndex >= #vectors then
                    log.errorWithTraceBack((("线变量长度不足![" .. tostring(data)) .. "]当前线变量最大索引为:") .. tostring(#vectors - 1))
                    return true, nil
                end
                lineLoc = vectors[solarLineIndex + 1]
                ____exports.default.cache:put(data, lineLoc)
                return true, lineLoc
            end)
            if not ____try then
                ____hasReturned, ____returnValue = ____catch(____hasReturned)
            end
            if ____hasReturned then
                return ____returnValue
            end
        end
    elseif data.x and data.y then
        return data
    end
    return nil
end
VectorUtil.cache = __TS__New(Cache)
return ____exports
