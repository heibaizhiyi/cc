local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 1,["8"] = 1,["9"] = 2,["10"] = 2,["11"] = 3,["12"] = 3,["13"] = 4,["14"] = 4,["15"] = 5,["16"] = 5,["17"] = 6,["18"] = 6,["19"] = 7,["20"] = 7,["21"] = 8,["22"] = 8,["23"] = 30,["24"] = 30,["25"] = 30,["27"] = 30,["28"] = 48,["29"] = 51,["30"] = 52,["32"] = 53,["33"] = 53,["34"] = 54,["35"] = 55,["36"] = 55,["37"] = 55,["38"] = 55,["39"] = 55,["40"] = 55,["41"] = 55,["42"] = 55,["43"] = 56,["44"] = 57,["45"] = 62,["46"] = 63,["47"] = 64,["48"] = 64,["49"] = 64,["50"] = 64,["51"] = 64,["52"] = 64,["53"] = 64,["54"] = 65,["55"] = 67,["56"] = 68,["57"] = 69,["58"] = 70,["59"] = 70,["60"] = 70,["61"] = 70,["62"] = 70,["63"] = 70,["64"] = 70,["65"] = 71,["66"] = 73,["67"] = 74,["68"] = 75,["69"] = 75,["70"] = 75,["71"] = 75,["72"] = 75,["73"] = 75,["74"] = 75,["75"] = 76,["76"] = 77,["77"] = 79,["78"] = 80,["79"] = 81,["80"] = 82,["81"] = 82,["82"] = 83,["83"] = 84,["84"] = 85,["85"] = 82,["86"] = 82,["87"] = 82,["88"] = 53,["91"] = 89,["92"] = 89,["93"] = 89,["94"] = 89,["95"] = 90,["96"] = 91,["97"] = 92,["98"] = 93,["99"] = 94,["100"] = 95,["103"] = 98,["104"] = 99,["106"] = 101,["108"] = 103,["109"] = 106,["110"] = 107,["111"] = 107,["112"] = 108,["113"] = 109,["114"] = 110,["115"] = 111,["116"] = 112,["117"] = 113,["118"] = 107,["119"] = 107,["120"] = 107,["122"] = 48,["123"] = 126,["124"] = 129,["125"] = 130,["126"] = 131,["127"] = 132,["128"] = 134,["129"] = 135,["130"] = 137,["132"] = 139,["133"] = 139,["134"] = 140,["135"] = 143,["136"] = 144,["137"] = 146,["138"] = 146,["139"] = 146,["140"] = 146,["141"] = 146,["142"] = 146,["143"] = 146,["144"] = 147,["145"] = 148,["146"] = 149,["148"] = 153,["149"] = 154,["150"] = 155,["151"] = 156,["152"] = 157,["153"] = 158,["154"] = 159,["155"] = 159,["156"] = 160,["157"] = 161,["158"] = 162,["159"] = 163,["160"] = 164,["161"] = 165,["162"] = 159,["163"] = 159,["164"] = 159,["165"] = 139,["168"] = 168,["169"] = 168,["170"] = 168,["171"] = 168,["172"] = 169,["173"] = 170,["174"] = 171,["175"] = 172,["176"] = 173,["177"] = 174,["178"] = 175,["181"] = 178,["182"] = 179,["184"] = 181,["186"] = 183,["187"] = 185,["188"] = 186,["189"] = 186,["190"] = 187,["191"] = 188,["192"] = 189,["193"] = 191,["194"] = 191,["195"] = 191,["196"] = 191,["197"] = 191,["198"] = 191,["199"] = 191,["200"] = 192,["201"] = 186,["202"] = 186,["203"] = 186,["205"] = 126,["206"] = 198,["207"] = 199,["208"] = 200,["211"] = 201,["212"] = 202,["215"] = 203,["216"] = 198,["217"] = 207,["218"] = 208,["219"] = 207,["220"] = 31,["221"] = 32,["222"] = 33,["223"] = 34,["224"] = 38});
local ____exports = {}
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____TextAlign = require("solar.solar-common.constant.TextAlign")
local TextAlign = ____TextAlign.default
local ____AsyncUtil = require("solar.solar-common.util.net.AsyncUtil")
local AsyncUtil = ____AsyncUtil.default
local ____FrameControl = require("solar.solar-common.framex.control.FrameControl")
local FrameControl = ____FrameControl.default
local ____ActorFrameUtil = require("solar.solar-common.actor.util.ActorFrameUtil")
local ActorFrameUtil = ____ActorFrameUtil.default
local ____SolarConfig = require("solar.solar-common.common.SolarConfig")
local SolarConfig = ____SolarConfig.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
____exports.default = __TS__Class()
local IconChooserUtil = ____exports.default
IconChooserUtil.name = "IconChooserUtil"
function IconChooserUtil.prototype.____constructor(self)
end
function IconChooserUtil.show(self, playerId, iconOptions, onClickCallBack, title)
    local startX = (0.8 - (____exports.default.bgWidth * #iconOptions + ____exports.default.optionGap * (#iconOptions - 1))) / 2
    local rootFrame = __TS__New(Frame, "FRAME")
    do
        local i = 0
        while i < #iconOptions do
            local iconOption = iconOptions[i + 1]
            local backDropFrame = __TS__New(
                Frame,
                "BACKDROP",
                nil,
                rootFrame.current,
                "_sl_border_backdrop",
                0
            )
            backDropFrame:setSize(____exports.default.bgWidth, ____exports.default.bgHeight)
            backDropFrame:setAbsPoint(FramePoint.left, startX + (____exports.default.bgWidth + 0.04) * i, ____exports.default.centerY)
            local iconFrame = Frame:createBackDrop(backDropFrame.current)
            iconFrame:setSize(0.03, 0.04)
            iconFrame:setPoint(
                FramePoint.top,
                backDropFrame.current,
                FramePoint.top,
                0,
                -0.01
            )
            iconFrame:setTexture(iconOption.icon or "UI\\Widgets\\EscMenu\\Human\\blank-background.blp")
            local nameFrame = Frame:createShadowTEXT(backDropFrame.current)
            nameFrame:setText(iconOption.name)
            nameFrame:setSize(____exports.default.bgWidth - 0.02, -1)
            nameFrame:setPoint(
                FramePoint.top,
                iconFrame.current,
                FramePoint.bottom,
                0,
                -0.01
            )
            nameFrame:setTextAlignment(TextAlign.center)
            local infoFrame = Frame:createTEXT(backDropFrame.current)
            infoFrame:setText(iconOption.describe)
            infoFrame:setPoint(
                FramePoint.top,
                nameFrame.current,
                FramePoint.bottom,
                0,
                -0.02
            )
            infoFrame:setTextAlignment(TextAlign.center)
            infoFrame:setSize(____exports.default.bgWidth - 0.02, -1)
            local btn = Frame:createGLUEBUTTON(backDropFrame.current)
            btn:setAllPoints(backDropFrame.current)
            local index = i
            btn:setOnClick(
                function()
                    rootFrame:setVisible(false)
                    DzDestroyFrame(rootFrame.current)
                    onClickCallBack(nil, index, iconOption)
                end,
                true
            )
            i = i + 1
        end
    end
    local playerSolarData = DataBase:getPlayerSolarData(
        Player(playerId),
        true
    )
    if GetPlayerId(GetLocalPlayer()) == playerId then
        if ____exports.default.removeLastChooser and playerSolarData._sl_lastShow then
            local rootFrame = playerSolarData._sl_lastShow
            if rootFrame.visible then
                rootFrame:setVisible(false)
                rootFrame:destroy()
            end
        end
        rootFrame:setVisible(true)
        ActorFrameUtil:hideTooltip()
    else
        rootFrame:setVisible(false)
    end
    playerSolarData._sl_lastShow = rootFrame
    if title then
        AsyncUtil:run(
            function()
                local titleFrame = Frame:createTEXTWithBorderBackDrop(rootFrame.current)
                titleFrame:setSize(____exports.default.bgWidth - ____exports.default.optionGap - 0.02, 0.015)
                titleFrame:setText(title)
                titleFrame:setFont(0.026)
                titleFrame:setAbsPoint(FramePoint.top, 0.4, ____exports.default.centerY + ____exports.default.bgHeight / 2 + ____exports.default.optionGap)
                titleFrame:setTextAlignment(TextAlign.center)
            end,
            Player(playerId)
        )
    end
end
function IconChooserUtil.showSimple(self, playerId, iconOptions, onClickCallBack, title)
    local iconListRootFrame = Frame:createBackDrop()
    local iconW = 0.03
    local iconGap = 0.004
    iconListRootFrame:setTexture("UI\\Glues\\BattleNet\\BattleNetTeamLevelBar\\Loading-BarBackground.blp")
    iconListRootFrame:setSize((iconW + iconGap) * #iconOptions + 0.008, 0.044)
    iconListRootFrame:setAbsPoint(FramePoint.bottomRight, 0.785, 0.166)
    local old_defaultTooltipFrameAbsY = SolarConfig.defaultTooltipFrameAbsY
    do
        local i = 0
        while i < #iconOptions do
            local iconOption = iconOptions[i + 1]
            local frameControl = __TS__New(FrameControl, iconListRootFrame.current)
            frameControl:setSize(iconW, 0.04)
            frameControl.rootFrame:setPoint(
                FramePoint.bottomRight,
                iconListRootFrame.handle,
                FramePoint.bottomRight,
                -(iconW + iconGap) * i - 0.005,
                0.002
            )
            frameControl:getBackgroundImageFrame():setTexture(iconOption.icon or "UI\\Widgets\\EscMenu\\Human\\blank-background.blp")
            if iconOption.showLampEffect == true then
                frameControl:getLampEffectFrame().visible = true
            end
            local btn = frameControl:getButtonFrame()
            btn:setSize(iconW, 0.04)
            local index = i
            btn.solarData.itemData = iconOption
            btn:setOnMouseEnter(____exports.default._sl_on_button_mouse_enter)
            btn:setOnMouseLeave(____exports.default._sl_on_button_mouse_leave)
            btn:setOnClick(
                function()
                    iconListRootFrame:setVisible(false)
                    ActorFrameUtil:hideTooltip()
                    btn:destroy()
                    DzDestroyFrame(iconListRootFrame.current)
                    onClickCallBack(nil, index, iconOption)
                    SolarConfig.defaultTooltipFrameAbsY = old_defaultTooltipFrameAbsY
                end,
                true
            )
            i = i + 1
        end
    end
    local playerSolarData = DataBase:getPlayerSolarData(
        Player(playerId),
        true
    )
    if GetPlayerId(GetLocalPlayer()) == playerId then
        SolarConfig.defaultTooltipFrameAbsY = 0.22
        if ____exports.default.removeLastChooser and playerSolarData._sl_lastShowSimpleRootFrame then
            local _sl_lastShowSimpleRootFrame = playerSolarData._sl_lastShowSimpleRootFrame
            if _sl_lastShowSimpleRootFrame.visible then
                _sl_lastShowSimpleRootFrame:setVisible(false)
                _sl_lastShowSimpleRootFrame:destroy()
            end
        end
        iconListRootFrame:setVisible(true)
        ActorFrameUtil:hideTooltip()
    else
        iconListRootFrame:setVisible(false)
    end
    playerSolarData._sl_lastShowSimpleRootFrame = iconListRootFrame
    if title then
        AsyncUtil:run(
            function()
                local titleFrame = Frame:createTEXTWithBorderBackDrop(iconListRootFrame.current)
                titleFrame.backdropFrame:setTexture("UI\\Glues\\BattleNet\\BattleNetTeamLevelBar\\Loading-BarBackground.blp")
                titleFrame:setText(title)
                titleFrame:setPoint(
                    FramePoint.right,
                    iconListRootFrame.current,
                    FramePoint.left,
                    -0.006,
                    0
                )
                titleFrame:setTextAlignment(TextAlign.center)
            end,
            Player(playerId)
        )
    end
end
function IconChooserUtil._sl_on_button_mouse_enter(self)
    local frame = Frame:fromEvent()
    if not frame then
        return
    end
    local actorOrActorType = frame.solarData.itemData
    if not actorOrActorType then
        return
    end
    ActorFrameUtil:showTooltip(actorOrActorType)
end
function IconChooserUtil._sl_on_button_mouse_leave(self)
    ActorFrameUtil:hideTooltip()
end
IconChooserUtil.bgWidth = 0.12
IconChooserUtil.bgHeight = 0.26
IconChooserUtil.optionGap = 0.04
IconChooserUtil.centerY = 0.35
IconChooserUtil.removeLastChooser = true
return ____exports
