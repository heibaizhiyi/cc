local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 5,["7"] = 5,["8"] = 6,["9"] = 6,["10"] = 8,["11"] = 8,["12"] = 26,["13"] = 26,["14"] = 26,["16"] = 26,["17"] = 36,["18"] = 37,["19"] = 38,["20"] = 38,["21"] = 39,["22"] = 39,["23"] = 40,["24"] = 40,["25"] = 41,["26"] = 42,["27"] = 43,["28"] = 44,["29"] = 44,["30"] = 44,["31"] = 45,["32"] = 46,["33"] = 47,["34"] = 48,["35"] = 49,["36"] = 50,["37"] = 51,["39"] = 53,["41"] = 55,["42"] = 44,["43"] = 44,["44"] = 36,["45"] = 67,["46"] = 68,["47"] = 69,["48"] = 69,["49"] = 70,["50"] = 70,["51"] = 71,["52"] = 71,["53"] = 72,["54"] = 73,["55"] = 74,["56"] = 75,["57"] = 76,["58"] = 77,["59"] = 77,["60"] = 77,["61"] = 78,["62"] = 79,["63"] = 80,["64"] = 81,["65"] = 82,["66"] = 83,["67"] = 84,["69"] = 86,["71"] = 88,["72"] = 77,["73"] = 77,["74"] = 67,["75"] = 100,["76"] = 101,["77"] = 102,["78"] = 103,["79"] = 104,["80"] = 105,["81"] = 106,["82"] = 107,["83"] = 107,["84"] = 107,["85"] = 108,["86"] = 109,["87"] = 110,["88"] = 111,["89"] = 112,["90"] = 113,["92"] = 115,["94"] = 117,["95"] = 107,["96"] = 107,["97"] = 100,["98"] = 129,["99"] = 130,["100"] = 131,["101"] = 132,["102"] = 133,["103"] = 134,["104"] = 135,["105"] = 136,["106"] = 136,["107"] = 136,["108"] = 137,["109"] = 138,["110"] = 139,["111"] = 140,["112"] = 141,["113"] = 142,["115"] = 144,["117"] = 146,["118"] = 136,["119"] = 136,["120"] = 129,["121"] = 157,["122"] = 158,["123"] = 159,["124"] = 160,["125"] = 161,["126"] = 162,["127"] = 162,["128"] = 162,["129"] = 163,["130"] = 164,["131"] = 165,["132"] = 166,["133"] = 167,["135"] = 169,["137"] = 171,["138"] = 162,["139"] = 162,["140"] = 157,["141"] = 182,["142"] = 183,["143"] = 184,["144"] = 185,["145"] = 186,["146"] = 187,["147"] = 187,["148"] = 187,["149"] = 188,["150"] = 189,["151"] = 190,["152"] = 191,["153"] = 192,["155"] = 194,["157"] = 196,["158"] = 187,["159"] = 187,["160"] = 182,["161"] = 207,["162"] = 208,["163"] = 209,["164"] = 210,["165"] = 210,["166"] = 210,["167"] = 211,["168"] = 212,["169"] = 213,["170"] = 213,["171"] = 213,["172"] = 213,["173"] = 213,["175"] = 213,["177"] = 213,["178"] = 214,["179"] = 215,["180"] = 216,["181"] = 217,["183"] = 219,["185"] = 221,["186"] = 210,["187"] = 210,["188"] = 207,["189"] = 232,["190"] = 233,["191"] = 234,["192"] = 235,["193"] = 236,["194"] = 237,["195"] = 237,["196"] = 237,["197"] = 238,["198"] = 239,["199"] = 240,["200"] = 241,["201"] = 242,["203"] = 244,["205"] = 246,["206"] = 237,["207"] = 237,["208"] = 232,["209"] = 256,["210"] = 257,["211"] = 256,["212"] = 266,["213"] = 267,["214"] = 266,["215"] = 279,["216"] = 279,["217"] = 279,["219"] = 279,["220"] = 279,["222"] = 280,["225"] = 281,["226"] = 282,["227"] = 283,["228"] = 284,["229"] = 284,["230"] = 284,["231"] = 285,["232"] = 286,["233"] = 287,["234"] = 288,["235"] = 289,["236"] = 290,["237"] = 291,["240"] = 294,["241"] = 295,["242"] = 296,["244"] = 298,["245"] = 299,["247"] = 301,["249"] = 303,["250"] = 284,["251"] = 284,["252"] = 279,["253"] = 317,["254"] = 318,["255"] = 319,["256"] = 320,["257"] = 320,["258"] = 321,["259"] = 321,["260"] = 322,["261"] = 322,["262"] = 323,["263"] = 323,["264"] = 323,["265"] = 324,["266"] = 325,["267"] = 326,["268"] = 327,["269"] = 328,["270"] = 329,["271"] = 330,["272"] = 331,["273"] = 332,["274"] = 333,["276"] = 335,["278"] = 337,["279"] = 323,["280"] = 323,["281"] = 317,["282"] = 351,["283"] = 352,["284"] = 353,["285"] = 354,["286"] = 354,["287"] = 355,["288"] = 355,["289"] = 356,["290"] = 357,["291"] = 358,["292"] = 358,["293"] = 358,["294"] = 358,["295"] = 358,["296"] = 358,["297"] = 358,["298"] = 358,["299"] = 358,["300"] = 351,["301"] = 368,["302"] = 369,["303"] = 370,["304"] = 370,["305"] = 371,["306"] = 371,["307"] = 372,["308"] = 372,["309"] = 373,["310"] = 373,["311"] = 373,["312"] = 374,["313"] = 375,["314"] = 376,["315"] = 377,["316"] = 378,["317"] = 379,["318"] = 380,["319"] = 381,["320"] = 382,["321"] = 383,["322"] = 383,["323"] = 383,["324"] = 383,["325"] = 383,["326"] = 383,["327"] = 383,["328"] = 384,["329"] = 384,["330"] = 384,["331"] = 384,["332"] = 384,["333"] = 384,["334"] = 384,["335"] = 385,["336"] = 386,["337"] = 387,["338"] = 388,["339"] = 389,["341"] = 391,["343"] = 393,["344"] = 373,["345"] = 373,["346"] = 368,["347"] = 404,["348"] = 405,["349"] = 406,["350"] = 406,["351"] = 407,["352"] = 407,["353"] = 408,["354"] = 422,["355"] = 404,["356"] = 426,["357"] = 427,["358"] = 426,["359"] = 439,["360"] = 440,["361"] = 441,["362"] = 441,["363"] = 441,["364"] = 441,["365"] = 441,["366"] = 442,["367"] = 442,["368"] = 442,["370"] = 442,["371"] = 443,["372"] = 443,["373"] = 443,["375"] = 443,["376"] = 444,["377"] = 444,["378"] = 444,["380"] = 444,["381"] = 445,["382"] = 446,["383"] = 446,["384"] = 446,["385"] = 447,["386"] = 448,["387"] = 449,["388"] = 450,["389"] = 451,["390"] = 452,["391"] = 453,["392"] = 454,["393"] = 455,["394"] = 456,["395"] = 457,["396"] = 458,["398"] = 460,["400"] = 462,["401"] = 446,["402"] = 446,["403"] = 439,["404"] = 475,["405"] = 476,["406"] = 477,["407"] = 477,["408"] = 477,["409"] = 477,["410"] = 477,["411"] = 478,["412"] = 478,["413"] = 478,["415"] = 478,["416"] = 479,["417"] = 479,["418"] = 479,["420"] = 479,["421"] = 480,["422"] = 480,["423"] = 480,["425"] = 480,["426"] = 481,["427"] = 482,["428"] = 483,["429"] = 484,["430"] = 484,["431"] = 484,["432"] = 484,["433"] = 484,["434"] = 484,["435"] = 484,["436"] = 484,["437"] = 475});
local ____exports = {}
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____MathUtil = require("solar.solar-common.util.math.MathUtil")
local MathUtil = ____MathUtil.default
____exports.default = __TS__Class()
local FrameActionUtil = ____exports.default
FrameActionUtil.name = "FrameActionUtil"
function FrameActionUtil.prototype.____constructor(self)
end
function FrameActionUtil.moveBy(self, frame, duration, x, y, callback)
    assert(duration >= 0.01, "moveBy持续时间不能小于0.01秒")
    local ____opt_0 = frame:getPoint()
    local frameX = ____opt_0 and ____opt_0.x or 0
    local ____opt_2 = frame:getPoint()
    local frameY = ____opt_2 and ____opt_2.y or 0
    local ____opt_4 = frame:getPoint()
    local point = ____opt_4 and ____opt_4.point or 4
    local loopCount = R2I(duration / 0.01)
    local deltaX = 1 * x / loopCount
    local deltaY = 1 * y / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameX = frameX + deltaX
            frameY = frameY + deltaY
            frame:clearPoints()
            frame:setAbsPoint(point, frameX, frameY)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.moveTo(self, frame, duration, x, y, callback)
    assert(duration >= 0.01, "moveTo持续时间不能小于0.01秒")
    local ____opt_6 = frame:getPoint()
    local frameX = ____opt_6 and ____opt_6.x or 0
    local ____opt_8 = frame:getPoint()
    local frameY = ____opt_8 and ____opt_8.y or 0
    local ____opt_10 = frame:getPoint()
    local point = ____opt_10 and ____opt_10.point or 4
    local distance = MathUtil.distanceBetweenPoints(frameX, frameY, x, y)
    local angle = MathUtil.angleBetweenCoords(frameX, frameY, x, y)
    local loopCount = R2I(duration / 0.01)
    local deltaX = distance * CosBJ(angle) / loopCount
    local deltaY = distance * SinBJ(angle) / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameX = frameX + deltaX
            frameY = frameY + deltaY
            frame:clearPoints()
            frame:setAbsPoint(point, frameX, frameY)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.resizeBy(self, frame, duration, w, h, callback)
    assert(duration >= 0.01, "resizeBy持续时间不能小于0.01秒")
    local width = frame.width or 0
    local height = frame.height or 0
    local loopCount = R2I(duration / 0.01)
    local deltaW = 1 * w / loopCount
    local deltaH = 1 * h / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            width = width + deltaW
            height = height + deltaH
            frame:setSize(width, height)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.resizeTo(self, frame, duration, width, height, callback)
    assert(duration >= 0.01, "resizeTo持续时间不能小于0.01秒")
    local frameWidth = frame.width or 0
    local frameHeight = frame.height or 0
    local loopCount = R2I(duration / 0.01)
    local deltaW = 1 * (width - frameWidth) / loopCount
    local deltaH = 1 * (height - frameHeight) / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameWidth = frameWidth + deltaW
            frameHeight = frameHeight + deltaH
            frame:setSize(frameWidth, frameHeight)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.scaleBy(self, frame, duration, scale, callback)
    assert(duration >= 0.01, "scaleBy持续时间不能小于0.01秒")
    local frameScale = frame:getScale() or 1
    local loopCount = R2I(duration / 0.01)
    local deltaScale = 1 * scale / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameScale = frameScale + deltaScale
            frame:setScale(frameScale)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.scaleTo(self, frame, duration, scale, callback)
    assert(duration >= 0.01, "scaleTo持续时间不能小于0.01秒")
    local frameScale = frame:getScale() or 1
    local loopCount = R2I(duration / 0.01)
    local deltaScale = 1 * (scale - frameScale) / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameScale = frameScale + deltaScale
            frame:setScale(frameScale)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.blink(self, frame, duration, times, callback)
    assert(duration >= 0.01, "blink持续时间不能小于0.01秒")
    local frameVisible = frame.visible
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            local slice = 1 / times
            local m = ModuloReal(0.01 * count, slice)
            local ____frame_13 = frame
            local ____frame_setVisible_14 = frame.setVisible
            local ____temp_12
            if m > slice / 2 then
                ____temp_12 = true
            else
                ____temp_12 = false
            end
            ____frame_setVisible_14(____frame_13, ____temp_12)
            if 0.01 * count >= duration then
                frame:setVisible(frameVisible)
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.fadeTo(self, frame, duration, alpha, callback)
    assert(duration >= 0.01, "fadeTo持续时间不能小于0.01秒")
    local frameAlpha = frame.alpha
    local loopCount = R2I(duration / 0.01)
    local deltaAlpha = 1 * (alpha - frameAlpha) / loopCount
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            frameAlpha = frameAlpha + deltaAlpha
            frame:setAlpha(frameAlpha)
            if count >= loopCount then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.fadeIn(self, frame, duration, callback)
    self:fadeTo(frame, duration, 255, callback)
end
function FrameActionUtil.fadeOut(self, frame, duration, callback)
    self:fadeTo(frame, duration, 0, callback)
end
function FrameActionUtil.animate(self, frame, textures, interval, loopCount, isRestore, callback)
    if loopCount == nil then
        loopCount = -1
    end
    if isRestore == nil then
        isRestore = true
    end
    if #textures <= 0 then
        return
    end
    local frameTexture = frame:getTexture()
    local index = 0
    local execCount = 0
    BaseUtil.onTimer(
        interval,
        function()
            index = index + 1
            if index < #textures then
                local texture = textures[index + 1]
                frame:setTexture(texture)
                if index == #textures - 1 then
                    execCount = execCount + 1
                    index = 0
                end
            end
            if execCount == loopCount then
                if isRestore then
                    frame:setTexture(frameTexture)
                end
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.jumpBy(self, frame, duration, x, y, height, jumps, callback)
    assert(duration >= 0.01, "jumpBy持续时间不能小于0.01秒")
    assert(jumps >= 0, "jumpBy跳跃次数不能小于0")
    local ____opt_15 = frame:getPoint()
    local frameX = ____opt_15 and ____opt_15.x or 0
    local ____opt_17 = frame:getPoint()
    local frameY = ____opt_17 and ____opt_17.y or 0
    local ____opt_19 = frame:getPoint()
    local point = ____opt_19 and ____opt_19.point or 4
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            local escapedTime = 0.01 * count
            local xx = x * escapedTime * (1 / duration)
            local frac = ModuloReal(escapedTime * jumps, 1)
            local yy = height * 4 * frac * (1 - frac)
            yy = yy + y * escapedTime * (1 / duration)
            frame:clearPoints()
            frame:setAbsPoint(point, frameX + xx, frameY + yy)
            if escapedTime >= duration then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.jumpTo(self, frame, duration, x, y, height, jumps, callback)
    assert(duration >= 0.01, "jumpTo持续时间不能小于0.01秒")
    assert(jumps >= 0, "jumpTo跳跃次数不能小于0")
    local ____opt_21 = frame:getPoint()
    local frameX = ____opt_21 and ____opt_21.x or 0
    local ____opt_23 = frame:getPoint()
    local frameY = ____opt_23 and ____opt_23.y or 0
    local deltaX = x - frameX
    local deltaY = y - frameY
    self:jumpBy(
        frame,
        duration,
        deltaX,
        deltaY,
        height,
        jumps,
        callback
    )
end
function FrameActionUtil.bezierBy(self, frame, duration, bezierConfig, callback)
    assert(duration >= 0.01, "bezierBy持续时间不能小于0.01秒")
    local ____opt_25 = frame:getPoint()
    local frameX = ____opt_25 and ____opt_25.x or 0
    local ____opt_27 = frame:getPoint()
    local frameY = ____opt_27 and ____opt_27.y or 0
    local ____opt_29 = frame:getPoint()
    local point = ____opt_29 and ____opt_29.point or 4
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            local escapedTime = 0.01 * count
            local xa = 0
            local xb = bezierConfig.controlPoint_1.x
            local xc = bezierConfig.controlPoint_2.x
            local xd = bezierConfig.endPosition.x
            local ya = 0
            local yb = bezierConfig.controlPoint_1.y
            local yc = bezierConfig.controlPoint_2.y
            local yd = bezierConfig.endPosition.y
            local x = self:bezierAt(
                xa,
                xb,
                xc,
                xd,
                escapedTime
            )
            local y = self:bezierAt(
                ya,
                yb,
                yc,
                yd,
                escapedTime
            )
            frame:clearPoints()
            frame:setAbsPoint(point, frameX + x, frameY + y)
            if escapedTime >= duration then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.bezierTo(self, frame, duration, bezierConfig, callback)
    assert(duration >= 0.01, "bezierTo持续时间不能小于0.01秒")
    local ____opt_31 = frame:getPoint()
    local frameX = ____opt_31 and ____opt_31.x or 0
    local ____opt_33 = frame:getPoint()
    local frameY = ____opt_33 and ____opt_33.y or 0
    local bc = {controlPoint_1 = {x = bezierConfig.controlPoint_1.x - frameX, y = bezierConfig.controlPoint_1.y - frameY}, controlPoint_2 = {x = bezierConfig.controlPoint_2.x - frameX, y = bezierConfig.controlPoint_2.y - frameY}, endPosition = {x = bezierConfig.endPosition.x - frameX, y = bezierConfig.endPosition.y - frameY}}
    self:bezierBy(frame, duration, bc, callback)
end
function FrameActionUtil.bezierAt(self, a, b, c, d, t)
    return math.pow(1 - t, 3) * a + 3 * t * math.pow(1 - t, 2) * b + 3 * math.pow(t, 2) * (1 - t) * c + math.pow(t, 3) * d
end
function FrameActionUtil.tintBy(self, frame, duration, r, g, b, callback)
    assert(duration >= 0.01, "tintBy持续时间不能小于0.01秒")
    local frameData = DataBase:getDataByTypeId(
        "Frame",
        tostring(frame.current),
        true
    )
    local ____temp_37 = frameData and frameData.r
    if ____temp_37 == nil then
        ____temp_37 = 0
    end
    local frameR = ____temp_37
    local ____temp_40 = frameData and frameData.g
    if ____temp_40 == nil then
        ____temp_40 = 0
    end
    local frameG = ____temp_40
    local ____temp_43 = frameData and frameData.b
    if ____temp_43 == nil then
        ____temp_43 = 0
    end
    local frameB = ____temp_43
    local frameAlpha = frame.alpha
    BaseUtil.onTimer(
        0.01,
        function(____, count)
            local escapedTime = 0.01 * count
            local rr = frameR + r * escapedTime
            local gg = frameG + g * escapedTime
            local bb = frameB + b * escapedTime
            frameData.r = rr
            frameData.g = gg
            frameData.b = bb
            local color = DzGetColor(rr, gg, bb, frameAlpha)
            frame:setVertexColor(color)
            if escapedTime >= duration then
                if callback then
                    callback(nil)
                end
                return false
            end
            return true
        end
    )
end
function FrameActionUtil.tintTo(self, frame, duration, r, g, b, callback)
    assert(duration >= 0.01, "tintTo持续时间不能小于0.01秒")
    local frameData = DataBase:getDataByTypeId(
        "Frame",
        tostring(frame.current),
        true
    )
    local ____temp_46 = frameData and frameData.r
    if ____temp_46 == nil then
        ____temp_46 = 0
    end
    local frameR = ____temp_46
    local ____temp_49 = frameData and frameData.g
    if ____temp_49 == nil then
        ____temp_49 = 0
    end
    local frameG = ____temp_49
    local ____temp_52 = frameData and frameData.b
    if ____temp_52 == nil then
        ____temp_52 = 0
    end
    local frameB = ____temp_52
    local deltaR = r - frameR
    local deltaG = g - frameG
    local deltaB = b - frameB
    self:tintBy(
        frame,
        duration,
        deltaR,
        deltaG,
        deltaB,
        callback
    )
end
return ____exports
