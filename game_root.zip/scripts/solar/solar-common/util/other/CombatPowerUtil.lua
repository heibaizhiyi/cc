local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 9,["15"] = 9,["16"] = 9,["18"] = 9,["19"] = 20,["20"] = 21,["21"] = 22,["22"] = 23,["23"] = 23,["24"] = 23,["25"] = 23,["26"] = 23,["27"] = 24,["28"] = 25,["29"] = 25,["30"] = 25,["31"] = 25,["32"] = 26,["35"] = 29,["38"] = 32,["39"] = 25,["40"] = 25,["41"] = 34,["42"] = 20,["43"] = 40,["44"] = 41,["45"] = 43,["46"] = 46,["47"] = 47,["48"] = 48,["49"] = 49,["50"] = 50,["51"] = 51,["52"] = 52,["53"] = 53,["54"] = 54,["55"] = 55,["56"] = 56,["57"] = 57,["58"] = 58,["59"] = 59,["60"] = 60,["62"] = 62,["64"] = 64,["65"] = 65,["66"] = 66,["68"] = 68,["69"] = 40,["70"] = 11,["71"] = 12,["72"] = 13,["73"] = 14});
local ____exports = {}
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____GroupUtil = require("solar.solar-common.util.unit.GroupUtil")
local GroupUtil = ____GroupUtil.default
local ____AttributeUtil = require("solar.solar-common.util.system.AttributeUtil")
local AttributeUtil = ____AttributeUtil.default
local ____HeroUtil = require("solar.solar-common.util.unit.HeroUtil")
local HeroUtil = ____HeroUtil.default
____exports.default = __TS__Class()
local CombatPowerUtil = ____exports.default
CombatPowerUtil.name = "CombatPowerUtil"
function CombatPowerUtil.prototype.____constructor(self)
end
function CombatPowerUtil.getPlayerCombatPower(self, playerIndex)
    local cp = 0
    GroupClear(_tempGroup)
    GroupEnumUnitsOfPlayer(
        _tempGroup,
        Player(playerIndex),
        nil
    )
    local assistant = db:getPlayerSolarData(Player(playerIndex)).assistant
    GroupUtil["for"](
        GroupUtil,
        _tempGroup,
        function(____, u)
            if assistant == u then
                return
            end
            if UnitStateUtil:getDamageMax(u) <= 1 then
                return
            end
            cp = cp + ____exports.default:getUnitCombatPower(u)
        end
    )
    return cp
end
function CombatPowerUtil.getUnitCombatPower(self, u)
    local combat = 0
    combat = combat + UnitStateUtil:getMaxLife(u) * ____exports.default.factor_MaxLife
    local aspd = UnitStateUtil:getAttackSpeed(u)
    local dc = UnitStateUtil:getDamageCool(u)
    local dmgMax = UnitStateUtil:getDamageMax(u)
    if aspd > 0 and dc > 0 and dmgMax > 0 then
        local realSh = 1
        local attribute = AttributeUtil:getUnitAttribute(u, false)
        if attribute then
            realSh = realSh + (attribute.damage_increased or 0)
            realSh = realSh + (attribute.physical_damage_increased or 0)
            realSh = realSh + (attribute.magic_damage_increased or 0)
            realSh = realSh + (attribute.physical_damage_pierce or 0)
            realSh = realSh + (attribute.magic_damage_pierce or 0)
            realSh = realSh + (attribute.magic_damage_increased or 0)
            realSh = realSh + (attribute.physical_critical_chance or 0) * (attribute.physical_critical_damage or 0)
            realSh = realSh + (attribute.magic_critical_chance or 0) * (attribute.magic_critical_damage or 0)
        end
        combat = combat + dmgMax * realSh * (aspd / dc)
    end
    combat = combat + UnitStateUtil:getArmor(u) * ____exports.default.factor_def
    if IsUnitType(u, UNIT_TYPE_HERO) then
        combat = combat + HeroUtil:getFullProperty(u, true) * ____exports.default.factor_FullProperty
    end
    return math.floor(combat * ____exports.default.combatScale)
end
CombatPowerUtil.factor_def = 10
CombatPowerUtil.factor_FullProperty = 5
CombatPowerUtil.factor_MaxLife = 0.1
CombatPowerUtil.combatScale = 1
return ____exports
