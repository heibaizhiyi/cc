local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 3,["8"] = 3,["9"] = 4,["10"] = 4,["11"] = 5,["12"] = 5,["13"] = 6,["14"] = 6,["15"] = 7,["16"] = 7,["17"] = 9,["18"] = 9,["19"] = 9,["21"] = 9,["22"] = 19,["23"] = 19,["24"] = 19,["26"] = 20,["27"] = 20,["28"] = 20,["29"] = 21,["30"] = 22,["31"] = 23,["32"] = 24,["35"] = 27,["36"] = 28,["37"] = 28,["38"] = 28,["39"] = 28,["40"] = 28,["41"] = 28,["42"] = 28,["43"] = 29,["44"] = 29,["45"] = 29,["47"] = 30,["48"] = 30,["49"] = 31,["50"] = 30,["53"] = 29,["54"] = 29,["56"] = 35,["57"] = 35,["58"] = 35,["59"] = 35,["60"] = 35,["61"] = 35,["62"] = 36,["64"] = 37,["65"] = 37,["66"] = 38,["67"] = 37,["70"] = 40,["71"] = 35,["72"] = 35,["74"] = 43,["75"] = 20,["76"] = 20,["77"] = 45,["78"] = 45,["79"] = 45,["80"] = 46,["81"] = 45,["82"] = 45,["83"] = 45,["84"] = 19,["85"] = 56,["86"] = 56,["87"] = 56,["89"] = 57,["90"] = 57,["91"] = 57,["92"] = 58,["93"] = 59,["94"] = 60,["95"] = 61,["98"] = 64,["99"] = 65,["100"] = 65,["101"] = 65,["102"] = 65,["103"] = 65,["104"] = 65,["105"] = 65,["106"] = 66,["107"] = 66,["108"] = 66,["110"] = 67,["111"] = 67,["112"] = 68,["113"] = 67,["116"] = 66,["117"] = 66,["119"] = 72,["120"] = 72,["121"] = 72,["122"] = 72,["123"] = 72,["124"] = 72,["125"] = 73,["127"] = 74,["128"] = 74,["129"] = 75,["130"] = 74,["133"] = 77,["134"] = 72,["135"] = 72,["137"] = 80,["138"] = 57,["139"] = 57,["140"] = 82,["141"] = 82,["142"] = 82,["143"] = 83,["144"] = 82,["145"] = 82,["146"] = 82,["147"] = 56,["148"] = 92,["149"] = 93,["150"] = 93,["151"] = 93,["152"] = 94,["153"] = 95,["154"] = 95,["155"] = 95,["156"] = 95,["157"] = 95,["158"] = 95,["159"] = 96,["161"] = 97,["162"] = 97,["163"] = 98,["164"] = 97,["167"] = 100,["168"] = 95,["169"] = 95,["170"] = 102,["171"] = 93,["172"] = 93,["173"] = 104,["174"] = 104,["175"] = 104,["176"] = 105,["177"] = 104,["178"] = 104,["179"] = 104,["180"] = 92,["181"] = 114,["182"] = 115,["183"] = 115,["184"] = 115,["185"] = 116,["186"] = 117,["187"] = 117,["188"] = 117,["189"] = 117,["190"] = 117,["191"] = 117,["192"] = 118,["194"] = 119,["195"] = 119,["196"] = 120,["197"] = 119,["200"] = 122,["201"] = 117,["202"] = 117,["203"] = 124,["204"] = 115,["205"] = 115,["206"] = 126,["207"] = 126,["208"] = 126,["209"] = 127,["210"] = 126,["211"] = 126,["212"] = 126,["213"] = 114,["214"] = 135,["215"] = 136,["216"] = 136,["217"] = 136,["218"] = 137,["219"] = 138,["220"] = 138,["221"] = 138,["222"] = 138,["223"] = 138,["224"] = 138,["225"] = 139,["227"] = 140,["228"] = 140,["229"] = 141,["230"] = 140,["233"] = 143,["234"] = 138,["235"] = 138,["236"] = 145,["237"] = 136,["238"] = 136,["239"] = 147,["240"] = 147,["241"] = 147,["242"] = 148,["243"] = 147,["244"] = 147,["245"] = 147,["246"] = 135,["247"] = 156,["248"] = 157,["249"] = 157,["250"] = 157,["251"] = 158,["252"] = 159,["253"] = 159,["254"] = 159,["255"] = 159,["256"] = 159,["257"] = 159,["258"] = 160,["260"] = 161,["261"] = 161,["262"] = 162,["263"] = 161,["266"] = 164,["267"] = 159,["268"] = 159,["269"] = 166,["270"] = 157,["271"] = 157,["272"] = 168,["273"] = 168,["274"] = 168,["275"] = 169,["276"] = 168,["277"] = 168,["278"] = 168,["279"] = 156,["280"] = 180,["281"] = 180,["282"] = 180,["284"] = 180,["285"] = 180,["287"] = 181,["288"] = 181,["289"] = 181,["290"] = 182,["291"] = 182,["292"] = 182,["293"] = 183,["294"] = 184,["295"] = 184,["296"] = 184,["297"] = 184,["298"] = 185,["299"] = 186,["301"] = 187,["302"] = 187,["304"] = 187,["307"] = 189,["308"] = 184,["309"] = 184,["310"] = 191,["311"] = 182,["312"] = 182,["313"] = 193,["314"] = 181,["315"] = 181,["316"] = 195,["317"] = 180,["318"] = 202,["319"] = 203,["320"] = 204,["321"] = 205,["323"] = 202,["324"] = 213,["325"] = 214,["326"] = 215,["327"] = 213,["328"] = 221,["329"] = 222,["330"] = 223,["331"] = 221,["332"] = 229,["333"] = 230,["334"] = 231,["335"] = 229,["336"] = 242,["337"] = 243,["338"] = 244,["339"] = 245,["342"] = 248,["343"] = 249,["344"] = 250,["347"] = 253,["348"] = 254,["350"] = 256,["351"] = 257,["352"] = 243,["353"] = 242,["354"] = 266,["355"] = 267,["358"] = 271,["359"] = 272,["360"] = 271,["361"] = 274,["362"] = 275,["363"] = 274,["364"] = 277,["365"] = 266,["366"] = 10,["367"] = 11,["368"] = 237,["369"] = 264});
local ____exports = {}
local ____Cache = require("solar.solar-common.tool.Cache")
local Cache = ____Cache.default
local ____AsyncUtil = require("solar.solar-common.util.net.AsyncUtil")
local AsyncUtil = ____AsyncUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____SolarTrigger = require("solar.solar-common.common.SolarTrigger")
local SolarTrigger = ____SolarTrigger.default
local ____InputEvent = require("solar.solar-common.tool.event.InputEvent")
local InputEvent = ____InputEvent.default
____exports.default = __TS__Class()
local InputUtil = ____exports.default
InputUtil.name = "InputUtil"
function InputUtil.prototype.____constructor(self)
end
function InputUtil.onKeyPressed(self, key, callback, isSync)
    if isSync == nil then
        isSync = false
    end
    local solarTriggerSet = ____exports.default.cache:get(
        (("onKeyPressed:" .. tostring(key)) .. ":") .. tostring(isSync),
        function()
            local stSet = {}
            if isSync then
                if isAsync then
                    log.errorWithTraceBack("不能在异步环境注册同步事件!")
                    return
                end
                local t = CreateTrigger()
                DzTriggerRegisterKeyEventByCode(
                    t,
                    key,
                    1,
                    true,
                    nil
                )
                TriggerAddAction(
                    t,
                    function()
                        do
                            local i = #stSet - 1
                            while i >= 0 do
                                stSet[i + 1]:exec()
                                i = i - 1
                            end
                        end
                    end
                )
            else
                DzTriggerRegisterKeyEventByCode(
                    nil,
                    key,
                    1,
                    false,
                    function()
                        isAsync = true
                        do
                            local i = #stSet - 1
                            while i >= 0 do
                                stSet[i + 1]:exec()
                                i = i - 1
                            end
                        end
                        isAsync = false
                    end
                )
            end
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onKeyReleased(self, key, callback, isSync)
    if isSync == nil then
        isSync = false
    end
    local solarTriggerSet = ____exports.default.cache:get(
        (("onKeyReleased:" .. tostring(key)) .. ":") .. tostring(isSync),
        function()
            local stSet = {}
            if isSync then
                if isAsync then
                    log.errorWithTraceBack("不能在异步环境注册同步事件!")
                    return
                end
                local t = CreateTrigger()
                DzTriggerRegisterKeyEventByCode(
                    t,
                    key,
                    0,
                    true,
                    nil
                )
                TriggerAddAction(
                    t,
                    function()
                        do
                            local i = #stSet - 1
                            while i >= 0 do
                                stSet[i + 1]:exec()
                                i = i - 1
                            end
                        end
                    end
                )
            else
                DzTriggerRegisterKeyEventByCode(
                    nil,
                    key,
                    0,
                    false,
                    function()
                        isAsync = true
                        do
                            local i = #stSet - 1
                            while i >= 0 do
                                stSet[i + 1]:exec()
                                i = i - 1
                            end
                        end
                        isAsync = false
                    end
                )
            end
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onMouseLeftButtonPressed(self, callback)
    local solarTriggerSet = ____exports.default.cache:get(
        "onMouseLeftButtonPressed",
        function()
            local stSet = {}
            DzTriggerRegisterMouseEventByCode(
                nil,
                1,
                1,
                false,
                function()
                    isAsync = true
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    isAsync = false
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onMouseLeftButtonReleased(self, callback)
    local solarTriggerSet = ____exports.default.cache:get(
        "onMouseLeftButtonReleased",
        function()
            local stSet = {}
            DzTriggerRegisterMouseEventByCode(
                nil,
                1,
                0,
                false,
                function()
                    isAsync = true
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    isAsync = false
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onMouseRightButtonPressed(self, callback)
    local solarTriggerSet = ____exports.default.cache:get(
        "onMouseRightButtonPressed",
        function()
            local stSet = {}
            DzTriggerRegisterMouseEventByCode(
                nil,
                2,
                1,
                false,
                function()
                    isAsync = true
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    isAsync = false
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onMouseRightButtonReleased(self, callback)
    local solarTriggerSet = ____exports.default.cache:get(
        "onMouseRightButtonReleased",
        function()
            local stSet = {}
            DzTriggerRegisterMouseEventByCode(
                nil,
                2,
                0,
                false,
                function()
                    isAsync = true
                    do
                        local i = #stSet - 1
                        while i >= 0 do
                            stSet[i + 1]:exec()
                            i = i - 1
                        end
                    end
                    isAsync = false
                end
            )
            return stSet
        end
    )
    return __TS__New(
        SolarTrigger,
        function(solarTrigger)
            callback(InputEvent.instance, solarTrigger)
        end,
        solarTriggerSet
    )
end
function InputUtil.onMouseMoveEvent(self, actionFunc, key, delay)
    if key == nil then
        key = "slmm" .. tostring(AsyncUtil:getUUIDAsync())
    end
    if delay == nil then
        delay = 0.1
    end
    BaseUtil.runLater(
        delay,
        function()
            local callbacks = ____exports.default.cache:get(
                "onMouseMoveEvent",
                function()
                    local cbs = {}
                    DzTriggerRegisterMouseMoveEventByCode(
                        nil,
                        false,
                        function()
                            isAsync = true
                            for key in pairs(cbs) do
                                local ____this_1
                                ____this_1 = cbs
                                local ____opt_0 = ____this_1[key]
                                if ____opt_0 ~= nil then
                                    ____opt_0(____this_1)
                                end
                            end
                            isAsync = false
                        end
                    )
                    return cbs
                end
            )
            callbacks[key] = actionFunc
        end
    )
    return key
end
function InputUtil.removeMouseMoveEvent(self, key)
    local callbacks = ____exports.default.cache:get("onMouseMoveEvent")
    if callbacks then
        callbacks[key] = nil
    end
end
function InputUtil.isMouseRightButtonDown(self)
    ____exports.default:_sl_init_isMouseLeftButtonDown()
    return ____exports.default._sl_isMouseLeftButtonDown
end
function InputUtil.getMouseSceneX(self)
    local sceneX = DzGetMouseXRelative() / DzGetClientWidth() * 0.8
    return sceneX
end
function InputUtil.getMouseSceneY(self)
    local sceneY = DzGetMouseYRelative() / DzGetClientHeight() * 0.6
    return 0.6 - sceneY
end
function InputUtil.onUnitMouseDoubleClicked(self, callback)
    ____exports.default:onMouseLeftButtonReleased(function(event, solarTrigger)
        local tu = DzGetUnitUnderMouse()
        if not IsHandle(tu) then
            return
        end
        local lastSelectInfo = ____exports.default._sl_last_click_unit_info
        if lastSelectInfo == nil then
            ____exports.default._sl_last_click_unit_info = {unit = tu, time = _g_time}
            return
        end
        if lastSelectInfo.unit == tu and _g_time - lastSelectInfo.time < 1000 then
            callback(InputEvent.instance, solarTrigger, tu)
        end
        lastSelectInfo.unit = tu
        lastSelectInfo.time = _g_time
    end)
end
function InputUtil._sl_init_isMouseLeftButtonDown(self)
    if ____exports.default._sl_init_isMouseLeftButtonDown_flag then
        return
    end
    ____exports.default:onMouseLeftButtonPressed(function()
        ____exports.default._sl_isMouseLeftButtonDown = true
    end)
    ____exports.default:onMouseLeftButtonReleased(function()
        ____exports.default._sl_isMouseLeftButtonDown = false
    end)
    ____exports.default._sl_init_isMouseLeftButtonDown_flag = true
end
InputUtil.cache = __TS__New(Cache)
InputUtil._sl_isMouseLeftButtonDown = false
InputUtil._sl_last_click_unit_info = nil
InputUtil._sl_init_isMouseLeftButtonDown_flag = false
return ____exports
