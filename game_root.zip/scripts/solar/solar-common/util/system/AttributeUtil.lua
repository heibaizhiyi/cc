local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 14,["19"] = 14,["20"] = 14,["22"] = 14,["23"] = 69,["24"] = 69,["25"] = 69,["27"] = 70,["28"] = 71,["29"] = 72,["31"] = 74,["32"] = 76,["34"] = 77,["35"] = 78,["37"] = 80,["41"] = 83,["42"] = 83,["43"] = 83,["44"] = 84,["45"] = 84,["46"] = 85,["47"] = 85,["48"] = 86,["49"] = 83,["50"] = 83,["51"] = 89,["52"] = 90,["53"] = 91,["54"] = 92,["55"] = 93,["56"] = 95,["57"] = 96,["58"] = 97,["59"] = 98,["60"] = 99,["61"] = 100,["64"] = 103,["65"] = 104,["67"] = 107,["70"] = 111,["71"] = 69,["72"] = 121,["73"] = 121,["74"] = 121,["76"] = 122,["77"] = 123,["78"] = 124,["81"] = 127,["82"] = 128,["83"] = 129,["85"] = 131,["86"] = 121,["87"] = 141,["88"] = 141,["89"] = 141,["91"] = 142,["92"] = 143,["93"] = 144,["95"] = 146,["96"] = 141,["97"] = 154,["98"] = 155,["101"] = 158,["102"] = 159,["103"] = 160,["104"] = 161,["105"] = 162,["106"] = 163,["108"] = 165,["111"] = 154,["112"] = 175,["113"] = 175,["114"] = 175,["116"] = 176,["117"] = 177,["118"] = 178,["120"] = 180,["121"] = 175,["122"] = 188,["123"] = 188,["124"] = 188,["126"] = 189,["127"] = 190,["128"] = 191,["130"] = 193,["131"] = 188,["132"] = 202,["133"] = 202,["134"] = 202,["136"] = 203,["137"] = 204,["138"] = 205,["139"] = 206,["140"] = 207,["142"] = 209,["143"] = 210,["144"] = 202,["145"] = 218,["146"] = 218,["147"] = 218,["149"] = 219,["150"] = 220,["151"] = 221,["153"] = 223,["154"] = 218,["155"] = 231,["156"] = 232,["159"] = 235,["160"] = 236,["161"] = 237,["162"] = 238,["163"] = 239,["164"] = 240,["166"] = 242,["169"] = 231,["170"] = 254,["171"] = 254,["172"] = 254,["174"] = 255,["175"] = 256,["176"] = 257,["177"] = 258,["178"] = 259,["180"] = 261,["181"] = 262,["182"] = 254,["183"] = 271,["184"] = 271,["185"] = 271,["187"] = 272,["188"] = 273,["189"] = 274,["190"] = 275,["191"] = 276,["193"] = 278,["194"] = 279,["195"] = 271,["196"] = 288,["197"] = 288,["198"] = 288,["200"] = 289,["201"] = 290,["202"] = 291,["203"] = 292,["204"] = 293,["206"] = 295,["207"] = 296,["208"] = 288,["209"] = 305,["210"] = 305,["211"] = 305,["213"] = 306,["214"] = 307,["215"] = 308,["216"] = 309,["217"] = 310,["219"] = 312,["220"] = 313,["221"] = 305,["222"] = 319,["223"] = 320,["224"] = 321,["225"] = 322,["226"] = 323,["228"] = 320,["229"] = 319,["230"] = 331,["231"] = 331,["232"] = 331,["234"] = 332,["235"] = 333,["236"] = 334,["237"] = 335,["239"] = 332,["240"] = 331,["241"] = 344,["242"] = 345,["243"] = 346,["244"] = 347,["246"] = 349,["247"] = 350,["249"] = 351,["250"] = 352,["252"] = 354,["253"] = 355,["255"] = 357,["260"] = 361,["261"] = 344,["262"] = 368,["263"] = 369,["266"] = 372,["267"] = 373,["268"] = 374,["271"] = 368,["272"] = 383,["273"] = 384,["276"] = 387,["277"] = 388,["278"] = 389,["281"] = 383,["282"] = 398,["283"] = 399,["286"] = 402,["287"] = 403,["289"] = 405,["290"] = 406,["292"] = 408,["293"] = 409,["294"] = 410,["297"] = 413,["298"] = 398,["299"] = 419,["300"] = 420,["301"] = 421,["303"] = 423,["304"] = 424,["306"] = 426,["307"] = 427,["308"] = 428,["309"] = 429,["311"] = 431,["312"] = 432,["313"] = 433,["316"] = 436,["317"] = 419,["318"] = 450,["319"] = 451,["320"] = 452,["321"] = 450,["322"] = 461,["323"] = 462,["324"] = 463,["325"] = 461,["326"] = 472,["327"] = 473,["328"] = 474,["329"] = 475,["330"] = 472,["331"] = 484,["332"] = 485,["333"] = 486,["334"] = 484,["335"] = 495,["336"] = 496,["337"] = 497,["338"] = 495,["339"] = 506,["340"] = 507,["341"] = 508,["342"] = 509,["343"] = 506,["344"] = 19,["345"] = 19,["346"] = 19,["347"] = 19,["348"] = 19,["349"] = 19,["350"] = 19,["351"] = 19,["352"] = 19,["353"] = 19,["354"] = 19,["355"] = 19,["356"] = 19,["357"] = 19,["358"] = 19,["359"] = 19,["360"] = 19,["361"] = 19,["362"] = 19,["363"] = 19,["364"] = 19,["365"] = 19,["366"] = 19,["367"] = 19,["368"] = 19,["369"] = 19,["370"] = 19,["371"] = 19,["372"] = 19,["373"] = 19,["374"] = 19,["375"] = 19,["376"] = 19,["377"] = 19,["378"] = 19,["379"] = 19,["380"] = 19,["381"] = 19,["382"] = 19,["383"] = 19,["384"] = 19,["385"] = 19});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____HandleUtil = require("solar.solar-common.util.lang.HandleUtil")
local HandleUtil = ____HandleUtil.default
local ____UnitUtil = require("solar.solar-common.util.unit.UnitUtil")
local UnitUtil = ____UnitUtil.default
local ____PlayerUtil = require("solar.solar-common.util.game.PlayerUtil")
local PlayerUtil = ____PlayerUtil.default
local ____TextUtil = require("solar.solar-common.util.text.TextUtil")
local TextUtil = ____TextUtil.default
____exports.default = __TS__Class()
local AttributeUtil = ____exports.default
AttributeUtil.name = "AttributeUtil"
function AttributeUtil.prototype.____constructor(self)
end
function AttributeUtil.getAttributeInfo(self, attribute, prefx)
    if prefx == nil then
        prefx = ""
    end
    local info = ""
    if attribute == nil then
        return info
    end
    local keys = {}
    for key in pairs(attribute) do
        do
            if type(attribute[key]) ~= "number" then
                goto __continue5
            end
            keys[#keys + 1] = key
        end
        ::__continue5::
    end
    __TS__ArraySort(
        keys,
        function(____, k1, k2)
            local ____opt_0 = ____exports.default.keyInfos[k1]
            local k1i = ____opt_0 and ____opt_0.index or 1000000
            local ____opt_2 = ____exports.default.keyInfos[k2]
            local k2i = ____opt_2 and ____opt_2.index or 1000000
            return k1i - k2i
        end
    )
    for ____, key in ipairs(keys) do
        local name = key
        local val = attribute[key]
        local valStr = val
        local keyInfo = ____exports.default.keyInfos[key]
        if keyInfo then
            name = keyInfo.name
            if keyInfo.isPercentage then
                valStr = TextUtil:toPercentage(val)
            elseif val > 10000 then
                valStr = TextUtil:toCnUnit(val)
            end
        end
        if val >= 0 then
            info = info .. (((prefx .. name) .. " + ") .. tostring(valStr)) .. "|n"
        else
            info = info .. (((prefx .. name) .. " ") .. tostring(valStr)) .. "|n"
        end
    end
    return info
end
function AttributeUtil.getUnitAttribute(self, unitHandle, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    if isDebug and createDefault and not UnitUtil.isHero(unitHandle) then
        if not UnitAlive(unitHandle) or not HandleUtil:isUnitHandle(unitHandle) then
            log.errorWithTraceBack(("警告：你正在给一个死亡的单位创建属性: " .. GetUnitName(unitHandle)) .. " 如果只是查询数据请将createDefault参数传false")
        end
    end
    local solarData = db:getUnitSolarData(unitHandle, createDefault)
    if createDefault and not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    return solarData and solarData._SL_solarAttribute
end
function AttributeUtil.getUnitTypeAttribute(self, unitTypeId, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    local solarData = db:getUnitTypeSolarData(unitTypeId, createDefault)
    if createDefault and not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    return solarData and solarData._SL_solarAttribute
end
function AttributeUtil.addUnitAttribute(self, unitHandle, addAttribute)
    if not addAttribute then
        return
    end
    local baseAttribute = ____exports.default:getUnitAttribute(unitHandle, true)
    for key in pairs(addAttribute) do
        if type(addAttribute[key]) == "number" then
            baseAttribute[key] = (baseAttribute[key] or 0) + addAttribute[key]
        elseif baseAttribute[key] == nil then
            baseAttribute[key] = addAttribute[key]
        else
            print("未覆盖单位旧属性值:" .. key)
        end
    end
end
function AttributeUtil.getItemAttribute(self, itemHandle, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    local solarData = db:getItemSolarData(itemHandle, createDefault)
    if createDefault and not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    return solarData and solarData._SL_solarAttribute
end
function AttributeUtil.getItemTypeAttribute(self, itemTypeId, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    local solarData = db:getItemTypeSolarData(itemTypeId, createDefault)
    if createDefault and not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    return solarData and solarData._SL_solarAttribute
end
function AttributeUtil.setItemTypeAttribute(self, itemTypeId, attribute, allowCover)
    if allowCover == nil then
        allowCover = false
    end
    local solarData = db:getItemTypeSolarData(itemTypeId)
    local oldAttribute = solarData._SL_solarAttribute
    if oldAttribute and not allowCover then
        log.errorWithTraceBack("此物品类型已有属性了，无法覆盖所有属性!可直接修改已有属性的对应词条!" .. itemTypeId)
        return oldAttribute
    end
    solarData._SL_solarAttribute = attribute
    return oldAttribute
end
function AttributeUtil.getPlayerAttribute(self, playerHandle, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    local solarData = db:getPlayerSolarData(playerHandle, createDefault)
    if createDefault and not solarData._SL_solarAttribute then
        solarData._SL_solarAttribute = {}
    end
    return solarData and solarData._SL_solarAttribute
end
function AttributeUtil.addPlayerAttribute(self, playerHandle, addAttribute)
    if not addAttribute then
        return
    end
    local basePlayerAttribute = ____exports.default:getPlayerAttribute(playerHandle, true)
    for key in pairs(addAttribute) do
        if type(addAttribute[key]) == "number" then
            basePlayerAttribute[key] = (basePlayerAttribute[key] or 0) + addAttribute[key]
        elseif basePlayerAttribute[key] == nil then
            basePlayerAttribute[key] = addAttribute[key]
        else
            print("未覆盖玩家旧属性值:" .. key)
        end
    end
end
function AttributeUtil.setPlayerAttribute(self, playerHandle, attribute, allowCover)
    if allowCover == nil then
        allowCover = false
    end
    local solarData = db:getPlayerSolarData(playerHandle)
    local oldAttribute = solarData._SL_solarAttribute
    if oldAttribute and not allowCover then
        log.errorWithTraceBack("此玩家已有属性了，无法覆盖所有属性!可直接修改已有属性的对应词条!" .. tostring(GetPlayerId(playerHandle)))
        return oldAttribute
    end
    solarData._SL_solarAttribute = attribute
    return oldAttribute
end
function AttributeUtil.setUnitAttribute(self, unitHandle, attribute, allowCover)
    if allowCover == nil then
        allowCover = false
    end
    local unitSolarData = db:getUnitSolarData(unitHandle)
    local oldAttribute = unitSolarData._SL_solarAttribute
    if oldAttribute and not allowCover then
        log.errorWithTraceBack("此单位已有属性了，无法覆盖所有属性!可直接修改已有属性的对应词条!" .. GetUnitName(unitHandle))
        return oldAttribute
    end
    unitSolarData._SL_solarAttribute = attribute
    return oldAttribute
end
function AttributeUtil.setUnitTypeAttribute(self, unitTypeId, attribute, allowCover)
    if allowCover == nil then
        allowCover = false
    end
    local solarData = db:getUnitTypeSolarData(unitTypeId, true)
    local oldAttribute = solarData._SL_solarAttribute
    if oldAttribute and not allowCover then
        log.errorWithTraceBack("此单位已有属性了，无法覆盖所有属性!可直接修改已有属性的对应词条!" .. unitTypeId)
        return oldAttribute
    end
    solarData._SL_solarAttribute = attribute
    return oldAttribute
end
function AttributeUtil.setItemAttribute(self, itemHandle, attribute, allowCover)
    if allowCover == nil then
        allowCover = false
    end
    local solarData = db:getItemSolarData(itemHandle)
    local oldAttribute = solarData._SL_solarAttribute
    if oldAttribute and not allowCover then
        log.errorWithTraceBack("此物品已有属性了，无法覆盖所有属性!可直接修改已有属性的对应词条!" .. GetItemName(itemHandle))
        return oldAttribute
    end
    solarData._SL_solarAttribute = attribute
    return oldAttribute
end
function AttributeUtil.forAllUnitsAttribute(self, callback)
    DataBase:forUnitSolarDatas(function(____, u, solarData)
        local solarAttribute = solarData and solarData._SL_solarAttribute
        if solarAttribute then
            callback(nil, u, solarAttribute)
        end
    end)
end
function AttributeUtil.forAllPlayerAttribute(self, callback, createDefault)
    if createDefault == nil then
        createDefault = false
    end
    PlayerUtil:forPlayingPlayers(function(____, player)
        local playerAttribute = ____exports.default:getPlayerAttribute(player, createDefault)
        if playerAttribute then
            callback(nil, player, playerAttribute)
        end
    end)
end
function AttributeUtil.sumAttributes(self, attributes)
    local result = {}
    if attributes == nil then
        return result
    end
    for ____, attribute in ipairs(attributes) do
        for key in pairs(attribute) do
            do
                if type(attribute[key]) ~= "number" then
                    goto __continue61
                end
                if not result[key] then
                    result[key] = 0
                end
                result[key] = result[key] + attribute[key]
            end
            ::__continue61::
        end
    end
    return result
end
function AttributeUtil.add(self, attribute, _attribute)
    if not _attribute then
        return
    end
    for key in pairs(_attribute) do
        if type(_attribute[key]) == "number" then
            attribute[key] = (attribute[key] or 0) + _attribute[key]
        end
    end
end
function AttributeUtil.subtract(self, attribute, _attribute)
    if not _attribute then
        return
    end
    for key in pairs(_attribute) do
        if type(_attribute[key]) == "number" then
            attribute[key] = (attribute[key] or 0) - _attribute[key]
        end
    end
end
function AttributeUtil.multiply(self, attribute, scale, store)
    if not attribute then
        return
    end
    if scale == 0 then
        return {}
    end
    if store == nil then
        store = {}
    end
    for key in pairs(attribute) do
        if type(attribute[key]) == "number" then
            store[key] = (attribute[key] or 0) * scale
        end
    end
    return store
end
function AttributeUtil.isEquals(self, attribute, otherAttribute)
    if attribute == otherAttribute then
        return true
    end
    if attribute == nil or otherAttribute == nil then
        return false
    end
    local keys1 = __TS__ObjectKeys(attribute)
    local keys2 = __TS__ObjectKeys(otherAttribute)
    if #keys1 ~= #keys2 then
        return false
    end
    for ____, key in ipairs(keys1) do
        if attribute[key] ~= otherAttribute[key] then
            return false
        end
    end
    return true
end
function AttributeUtil.getAbilityCDP(self, unitHandle, abilityIdStr)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, false)
    return attribute and attribute["ability_cd_p_" .. abilityIdStr] or 0
end
function AttributeUtil.setAbilityCDP(self, unitHandle, abilityIdStr, val)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, true)
    attribute["ability_cd_p_" .. abilityIdStr] = val
end
function AttributeUtil.addAbilityCDP(self, unitHandle, abilityIdStr, val)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, true)
    local key = "ability_cd_p_" .. abilityIdStr
    attribute[key] = (attribute[key] or 0) + val
end
function AttributeUtil.getAbilityCD(self, unitHandle, abilityIdStr)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, false)
    return attribute and attribute["ability_cd_" .. abilityIdStr] or 0
end
function AttributeUtil.setAbilityCD(self, unitHandle, abilityIdStr, val)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, true)
    attribute["ability_cd_" .. abilityIdStr] = val
end
function AttributeUtil.addAbilityCD(self, unitHandle, abilityIdStr, val)
    local attribute = ____exports.default:getUnitAttribute(unitHandle, true)
    local key = "ability_cd_" .. abilityIdStr
    attribute[key] = (attribute[key] or 0) + val
end
AttributeUtil.keyInfos = {
    attack = {name = "攻击", index = 1, isPercentage = false},
    attack_p = {name = "攻击增幅", index = 2, isPercentage = true},
    life = {name = "生命", index = 3, isPercentage = false},
    life_p = {name = "生命增幅", index = 4, isPercentage = true},
    mana = {name = "魔法", index = 5, isPercentage = false},
    mana_p = {name = "魔法增幅", index = 6, isPercentage = true},
    miss_p = {name = "闪避几率", index = 7, isPercentage = true},
    def = {name = "护甲", index = 8, isPercentage = false},
    def_p = {name = "护甲增幅", index = 9, isPercentage = true},
    def_pierce = {name = "护甲穿透", index = 10, isPercentage = false},
    def_pierce_p = {name = "护甲穿透比例", index = 11, isPercentage = true},
    full_property = {name = "全属性", index = 12, isPercentage = false},
    full_property_p = {name = "全属性增幅", index = 13, isPercentage = true},
    strength = {name = "力量", index = 14, isPercentage = false},
    strength_p = {name = "力量增幅", index = 15, isPercentage = true},
    agility = {name = "敏捷", index = 16, isPercentage = false},
    agility_p = {name = "敏捷增幅", index = 17, isPercentage = true},
    intelligence = {name = "智力", index = 18, isPercentage = false},
    intelligence_p = {name = "智力增幅", index = 19, isPercentage = true},
    attackSpd_p = {name = "攻击速度", index = 20, isPercentage = true},
    move_speed = {name = "移动速度", index = 21, isPercentage = false},
    damage_cool = {name = "攻击间隔", index = 22, isPercentage = false},
    damage_range = {name = "攻击范围", index = 23, isPercentage = false},
    attack_damage_increased = {name = "攻击增伤", index = 24, isPercentage = true},
    physical_damage_increased = {name = "物理增伤", index = 25, isPercentage = true},
    physical_damage_reduction = {name = "物理抗性", index = 26, isPercentage = true},
    magic_damage_increased = {name = "法术增伤", index = 27, isPercentage = true},
    physical_critical_chance = {name = "物理暴击几率", index = 28, isPercentage = true},
    physical_critical_damage = {name = "物理暴击伤害", index = 29, isPercentage = true},
    magic_power = {name = "法术强度", index = 30, isPercentage = false},
    magic_damage_reduction = {name = "法术抗性", index = 31, isPercentage = true},
    magic_critical_chance = {name = "法术暴击几率", index = 32, isPercentage = true},
    magic_critical_damage = {name = "法术暴击伤害", index = 33, isPercentage = true},
    damage_increased = {name = "全伤害增幅", index = 34, isPercentage = true},
    damage_reduction = {name = "|cff00ff00伤害减免|r", index = 35, isPercentage = true},
    blood_sucking = {name = "|cffff0000伤害吸血|r", index = 36, isPercentage = true},
    split_damage_range = {name = "分裂范围", index = 37, isPercentage = false},
    split_damage = {name = "分裂伤害", index = 38, isPercentage = true},
    primary_property = {name = "主属性", index = 39, isPercentage = false},
    primary_property_p = {name = "主属性百分比", index = 40, isPercentage = true}
}
return ____exports
