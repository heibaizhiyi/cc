local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 5,["15"] = 5,["16"] = 6,["17"] = 6,["18"] = 8,["19"] = 8,["20"] = 8,["22"] = 8,["23"] = 26,["24"] = 26,["25"] = 26,["27"] = 27,["28"] = 27,["30"] = 27,["31"] = 27,["33"] = 28,["34"] = 28,["36"] = 28,["37"] = 28,["39"] = 29,["40"] = 30,["41"] = 31,["42"] = 32,["43"] = 33,["45"] = 35,["47"] = 37,["48"] = 37,["49"] = 37,["50"] = 37,["51"] = 37,["52"] = 37,["53"] = 37,["54"] = 37,["55"] = 37,["56"] = 37,["57"] = 38,["58"] = 26,["59"] = 53,["60"] = 53,["61"] = 53,["63"] = 54,["64"] = 54,["66"] = 54,["67"] = 54,["69"] = 55,["70"] = 55,["72"] = 55,["73"] = 55,["75"] = 56,["76"] = 57,["77"] = 58,["78"] = 59,["79"] = 60,["80"] = 61,["81"] = 62,["83"] = 64,["85"] = 66,["86"] = 66,["87"] = 66,["88"] = 66,["89"] = 66,["90"] = 66,["91"] = 66,["92"] = 66,["93"] = 66,["94"] = 66,["95"] = 67,["96"] = 68,["97"] = 53,["98"] = 84,["99"] = 84,["100"] = 84,["102"] = 85,["103"] = 85,["105"] = 85,["106"] = 85,["108"] = 86,["109"] = 86,["111"] = 87,["112"] = 87,["114"] = 87,["115"] = 87,["117"] = 87,["118"] = 87,["120"] = 88,["121"] = 89,["122"] = 90,["123"] = 91,["124"] = 91,["125"] = 91,["126"] = 91,["127"] = 92,["128"] = 93,["130"] = 95,["132"] = 97,["133"] = 97,["134"] = 97,["135"] = 97,["136"] = 97,["137"] = 97,["138"] = 97,["139"] = 97,["140"] = 97,["141"] = 97,["142"] = 91,["143"] = 91,["144"] = 91,["145"] = 91,["146"] = 99,["147"] = 84,["148"] = 115,["149"] = 115,["150"] = 115,["152"] = 116,["153"] = 116,["155"] = 116,["156"] = 116,["158"] = 117,["159"] = 117,["161"] = 118,["162"] = 118,["164"] = 118,["165"] = 118,["167"] = 118,["168"] = 118,["170"] = 119,["171"] = 120,["172"] = 121,["173"] = 122,["174"] = 123,["175"] = 124,["176"] = 124,["177"] = 124,["178"] = 124,["179"] = 125,["180"] = 126,["182"] = 128,["184"] = 130,["185"] = 130,["186"] = 130,["187"] = 130,["188"] = 130,["189"] = 130,["190"] = 130,["191"] = 130,["192"] = 130,["193"] = 130,["194"] = 124,["195"] = 124,["196"] = 124,["197"] = 124,["198"] = 132,["199"] = 133,["200"] = 115,["201"] = 150,["202"] = 151,["203"] = 151,["205"] = 151,["206"] = 151,["208"] = 152,["209"] = 152,["211"] = 152,["212"] = 152,["214"] = 152,["215"] = 152,["217"] = 153,["218"] = 154,["219"] = 155,["220"] = 155,["221"] = 155,["222"] = 155,["223"] = 155,["224"] = 155,["225"] = 156,["226"] = 157,["227"] = 158,["228"] = 159,["229"] = 160,["230"] = 160,["231"] = 160,["232"] = 160,["233"] = 161,["234"] = 161,["235"] = 161,["236"] = 161,["237"] = 161,["238"] = 161,["239"] = 162,["240"] = 162,["241"] = 162,["242"] = 162,["243"] = 162,["244"] = 162,["245"] = 163,["246"] = 163,["247"] = 163,["248"] = 163,["249"] = 163,["250"] = 163,["251"] = 164,["252"] = 165,["253"] = 166,["255"] = 168,["257"] = 170,["258"] = 170,["259"] = 170,["260"] = 170,["261"] = 170,["262"] = 170,["263"] = 170,["264"] = 170,["265"] = 170,["266"] = 170,["268"] = 160,["269"] = 160,["270"] = 160,["271"] = 160,["272"] = 173,["273"] = 150,["274"] = 190,["275"] = 191,["276"] = 191,["278"] = 191,["279"] = 191,["281"] = 192,["282"] = 192,["284"] = 192,["285"] = 192,["287"] = 192,["288"] = 192,["290"] = 193,["291"] = 194,["292"] = 195,["293"] = 195,["294"] = 195,["295"] = 195,["296"] = 195,["297"] = 195,["298"] = 195,["299"] = 195,["300"] = 195,["301"] = 195,["302"] = 195,["303"] = 195,["304"] = 195,["305"] = 197,["306"] = 198,["307"] = 190,["308"] = 205,["309"] = 206,["310"] = 205,["311"] = 219,["312"] = 220,["314"] = 221,["315"] = 221,["316"] = 222,["317"] = 223,["319"] = 221,["322"] = 226,["323"] = 219,["324"] = 232,["325"] = 233,["326"] = 232,["327"] = 239,["328"] = 240,["329"] = 239,["330"] = 247,["331"] = 248,["332"] = 247,["333"] = 255,["334"] = 256,["335"] = 255,["336"] = 263,["337"] = 264,["338"] = 263,["339"] = 271,["340"] = 272,["342"] = 273,["343"] = 273,["344"] = 274,["345"] = 273,["348"] = 276,["349"] = 271,["350"] = 282,["351"] = 283,["353"] = 284,["354"] = 284,["355"] = 285,["356"] = 284,["359"] = 287,["360"] = 282,["361"] = 10,["362"] = 11,["363"] = 12,["364"] = 12,["365"] = 12,["366"] = 12,["367"] = 12,["368"] = 12,["369"] = 12});
local ____exports = {}
local ____DamageType = require("solar.solar-common.constant.DamageType")
local DamageType = ____DamageType.default
local ____MathUtil = require("solar.solar-common.util.math.MathUtil")
local MathUtil = ____MathUtil.default
local ____SelectUtil = require("solar.solar-common.util.unit.SelectUtil")
local SelectUtil = ____SelectUtil.default
local ____WeaponType = require("solar.solar-common.constant.WeaponType")
local WeaponType = ____WeaponType.default
local ____LangUtil = require("solar.solar-common.util.lang.LangUtil")
local LangUtil = ____LangUtil.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
____exports.default = __TS__Class()
local DamageUtil = ____exports.default
DamageUtil.name = "DamageUtil"
function DamageUtil.prototype.____constructor(self)
end
function DamageUtil.damage(self, whichUnit, target, damageOrFormula, damageTypeId, weaponTypeID, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if weaponTypeID == nil then
        weaponTypeID = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local dt = ____exports.default.damageTypes[damageTypeId + 1]
    local wt = ____exports.default.weaponTypes[weaponTypeID + 1]
    local damage
    if LangUtil:isNumber(damageOrFormula) then
        damage = damageOrFormula
    else
        damage = UnitStateUtil:calculateStateFormula(damageOrFormula, whichUnit, target)
    end
    UnitDamageTarget(
        whichUnit,
        target,
        damage,
        attack,
        ranged,
        attackType,
        dt,
        wt
    )
    return damage
end
function DamageUtil.damageSL(self, whichUnit, target, damageOrFormula, damageTypeId, weaponTypeID, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if weaponTypeID == nil then
        weaponTypeID = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local oldFlag = isSolarDamageEnable
    isSolarDamageEnable = true
    local dt = ____exports.default.damageTypes[damageTypeId + 1]
    local wt = ____exports.default.weaponTypes[weaponTypeID + 1]
    local damage
    if LangUtil:isNumber(damageOrFormula) then
        damage = damageOrFormula
    else
        damage = UnitStateUtil:calculateStateFormula(damageOrFormula, whichUnit, target)
    end
    UnitDamageTarget(
        whichUnit,
        target,
        damage,
        attack,
        ranged,
        attackType,
        dt,
        wt
    )
    isSolarDamageEnable = oldFlag
    return damage
end
function DamageUtil.damageEnemyUnitsInRange(self, whichUnit, radius, damageOrFormula, damageTypeId, x, y, weaponTypeId, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if x == nil then
        x = GetUnitX(whichUnit)
    end
    if y == nil then
        y = GetUnitY(whichUnit)
    end
    if weaponTypeId == nil then
        weaponTypeId = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local dt = ____exports.default.damageTypes[damageTypeId + 1]
    local wt = ____exports.default.weaponTypes[weaponTypeId + 1]
    local damage
    SelectUtil.forEnemyUnitsInRange(
        whichUnit,
        radius,
        function(____, enemy)
            if LangUtil:isNumber(damageOrFormula) then
                damage = damageOrFormula
            else
                damage = UnitStateUtil:calculateStateFormula(damageOrFormula, whichUnit, enemy)
            end
            UnitDamageTarget(
                whichUnit,
                enemy,
                damage,
                attack,
                ranged,
                attackType,
                dt,
                wt
            )
        end,
        x,
        y
    )
    return damage
end
function DamageUtil.damageEnemyUnitsInRangeSL(self, whichUnit, radius, damageOrFormula, damageTypeId, x, y, weaponTypeId, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if x == nil then
        x = GetUnitX(whichUnit)
    end
    if y == nil then
        y = GetUnitY(whichUnit)
    end
    if weaponTypeId == nil then
        weaponTypeId = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local dt = ____exports.default.damageTypes[damageTypeId + 1]
    local wt = ____exports.default.weaponTypes[weaponTypeId + 1]
    local oldFlag = isSolarDamageEnable
    isSolarDamageEnable = true
    local damage
    SelectUtil.forEnemyUnitsInRange(
        whichUnit,
        radius,
        function(____, enemy)
            if LangUtil:isNumber(damageOrFormula) then
                damage = damageOrFormula
            else
                damage = UnitStateUtil:calculateStateFormula(damageOrFormula, whichUnit, enemy)
            end
            UnitDamageTarget(
                whichUnit,
                enemy,
                damage,
                attack,
                ranged,
                attackType,
                dt,
                wt
            )
        end,
        x,
        y
    )
    isSolarDamageEnable = oldFlag
    return damage
end
function DamageUtil.damageEnemyUnitsInSector(self, whichUnit, radius, damageOrFormula, angle, targetX, targetY, damageTypeId, weaponTypeId, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if weaponTypeId == nil then
        weaponTypeId = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local dt = ____exports.default.damageTypes[damageTypeId + 1]
    local wt = ____exports.default.weaponTypes[weaponTypeId + 1]
    local degree = MathUtil.angleBetweenCoords(
        GetUnitX(whichUnit),
        GetUnitY(whichUnit),
        targetX,
        targetY
    )
    SetUnitFacing(whichUnit, degree)
    local x = GetUnitX(whichUnit) + radius * CosBJ(degree)
    local y = GetUnitY(whichUnit) + radius * SinBJ(degree)
    local damage
    SelectUtil.forEnemyUnitsInRange(
        whichUnit,
        radius,
        function(____, unitHandle)
            local angle0 = MathUtil.angleBetweenCoords(
                GetUnitX(whichUnit),
                GetUnitY(whichUnit),
                GetUnitX(unitHandle),
                GetUnitY(unitHandle)
            )
            local angle1 = MathUtil.angleBetweenCoords(
                GetUnitX(whichUnit),
                GetUnitY(whichUnit),
                targetX,
                targetY
            ) - angle / 2
            local angle2 = MathUtil.angleBetweenCoords(
                GetUnitX(whichUnit),
                GetUnitY(whichUnit),
                targetX,
                targetY
            ) + angle / 2
            if angle0 >= angle1 and angle0 <= angle2 then
                if LangUtil:isNumber(damageOrFormula) then
                    damage = damageOrFormula
                else
                    damage = UnitStateUtil:calculateStateFormula(damageOrFormula, whichUnit, unitHandle)
                end
                UnitDamageTarget(
                    whichUnit,
                    unitHandle,
                    damage,
                    attack,
                    ranged,
                    attackType,
                    dt,
                    wt
                )
            end
        end,
        x,
        y
    )
    return damage
end
function DamageUtil.damageEnemyUnitsInSectorSL(self, whichUnit, radius, damageOrFormula, angle, targetX, targetY, damageTypeId, weaponTypeId, ranged, attack, attackType)
    if damageTypeId == nil then
        damageTypeId = DamageType.T4_NORMAL
    end
    if weaponTypeId == nil then
        weaponTypeId = WeaponType.T0_WHOKNOWS
    end
    if ranged == nil then
        ranged = true
    end
    if attack == nil then
        attack = false
    end
    if attackType == nil then
        attackType = ATTACK_TYPE_CHAOS
    end
    local oldFlag = isSolarDamageEnable
    isSolarDamageEnable = true
    local damage = ____exports.default:damageEnemyUnitsInSector(
        whichUnit,
        radius,
        damageOrFormula,
        angle,
        targetX,
        targetY,
        damageTypeId,
        weaponTypeId,
        ranged,
        attack,
        attackType
    )
    isSolarDamageEnable = oldFlag
    return damage
end
function DamageUtil.isEventPhysicalDamage(self)
    return 0 ~= EXGetEventDamageData(EVENT_DAMAGE_DATA_IS_PHYSICAL)
end
function DamageUtil.isEventPhysicalDamageType(self)
    local damageTypeData = EXGetEventDamageData(EVENT_DAMAGE_DATA_DAMAGE_TYPE)
    do
        local i = 0
        while i < #____exports.default.physicalDamageType do
            if damageTypeData == ____exports.default.physicalDamageType[i + 1] then
                return true
            end
            i = i + 1
        end
    end
    return false
end
function DamageUtil.isEventAttackDamage(self)
    return 0 ~= EXGetEventDamageData(EVENT_DAMAGE_DATA_IS_ATTACK)
end
function DamageUtil.isEventRangedDamage(self)
    return 0 ~= EXGetEventDamageData(EVENT_DAMAGE_DATA_IS_RANGED)
end
function DamageUtil.isEventDamageType(self, damageType)
    return damageType == ConvertDamageType(EXGetEventDamageData(EVENT_DAMAGE_DATA_DAMAGE_TYPE))
end
function DamageUtil.isEventWeaponType(self, weaponType)
    return weaponType == ConvertWeaponType(EXGetEventDamageData(EVENT_DAMAGE_DATA_WEAPON_TYPE))
end
function DamageUtil.isEventAttackType(self, attackType)
    return attackType == ConvertAttackType(EXGetEventDamageData(EVENT_DAMAGE_DATA_ATTACK_TYPE))
end
function DamageUtil._sl_createDamageTypes(self)
    local ds = {}
    do
        local i = 0
        while i < 32 do
            ds[i + 1] = ConvertDamageType(i)
            i = i + 1
        end
    end
    return ds
end
function DamageUtil._sl_createWeaponTypes(self)
    local ws = {}
    do
        local i = 0
        while i < 24 do
            ws[i + 1] = ConvertWeaponType(i)
            i = i + 1
        end
    end
    return ws
end
DamageUtil.damageTypes = ____exports.default:_sl_createDamageTypes()
DamageUtil.weaponTypes = ____exports.default:_sl_createWeaponTypes()
DamageUtil.physicalDamageType = {
    DamageType.T4_NORMAL,
    DamageType.T5_ENHANCED,
    DamageType.T17_FORCE,
    DamageType.T21_DEFENSIVE,
    DamageType.T26_UNIVERSAL
}
return ____exports
