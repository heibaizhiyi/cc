local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 2,["8"] = 3,["9"] = 3,["10"] = 4,["11"] = 4,["12"] = 5,["13"] = 5,["14"] = 6,["15"] = 6,["16"] = 7,["17"] = 7,["18"] = 8,["19"] = 8,["20"] = 10,["21"] = 12,["22"] = 12,["23"] = 12,["25"] = 12,["26"] = 20,["27"] = 27,["28"] = 28,["29"] = 29,["31"] = 31,["32"] = 32,["34"] = 34,["35"] = 35,["37"] = 37,["38"] = 38,["40"] = 40,["41"] = 41,["43"] = 43,["44"] = 20,["45"] = 53,["46"] = 54,["48"] = 56,["49"] = 56,["50"] = 57,["51"] = 58,["52"] = 59,["54"] = 56,["57"] = 62,["58"] = 53,["59"] = 71,["61"] = 72,["62"] = 72,["63"] = 73,["64"] = 74,["65"] = 75,["67"] = 72,["70"] = 78,["71"] = 71,["72"] = 89,["73"] = 90,["76"] = 94,["77"] = 95,["78"] = 96,["80"] = 98,["81"] = 99,["82"] = 101,["83"] = 102,["84"] = 103,["86"] = 105,["87"] = 106,["88"] = 108,["89"] = 109,["90"] = 110,["92"] = 112,["93"] = 113,["94"] = 89,["95"] = 124,["96"] = 125,["99"] = 128,["100"] = 130,["101"] = 131,["102"] = 132,["104"] = 134,["105"] = 135,["106"] = 136,["107"] = 138,["108"] = 139,["109"] = 140,["111"] = 142,["112"] = 143,["113"] = 144,["114"] = 146,["115"] = 147,["116"] = 148,["118"] = 150,["119"] = 151,["120"] = 152,["121"] = 124,["122"] = 163,["123"] = 163,["124"] = 163,["126"] = 163,["127"] = 163,["129"] = 164,["130"] = 164,["131"] = 164,["132"] = 164,["133"] = 164,["134"] = 164,["135"] = 164,["136"] = 163,["137"] = 175,["138"] = 175,["139"] = 175,["141"] = 175,["142"] = 175,["144"] = 177,["145"] = 177,["146"] = 177,["147"] = 179,["148"] = 180,["149"] = 180,["150"] = 180,["151"] = 180,["152"] = 180,["153"] = 180,["154"] = 181,["155"] = 182,["156"] = 183,["158"] = 177,["159"] = 177,["160"] = 175,["161"] = 192,["162"] = 192,["163"] = 192,["165"] = 193,["166"] = 194,["167"] = 195,["169"] = 197,["170"] = 197,["171"] = 197,["172"] = 197,["173"] = 197,["174"] = 197,["175"] = 198,["176"] = 199,["177"] = 192,["178"] = 207,["179"] = 208,["180"] = 207,["181"] = 215,["182"] = 216,["183"] = 215,["184"] = 222,["185"] = 223,["186"] = 222,["187"] = 229,["188"] = 230,["189"] = 229,["190"] = 236,["191"] = 237,["192"] = 236,["193"] = 243,["194"] = 244,["195"] = 243,["196"] = 250,["197"] = 251,["198"] = 250,["199"] = 264,["200"] = 264,["201"] = 264,["203"] = 264,["204"] = 264,["206"] = 265,["208"] = 266,["209"] = 266,["210"] = 267,["211"] = 267,["212"] = 267,["213"] = 267,["214"] = 267,["215"] = 267,["216"] = 267,["217"] = 266,["220"] = 269,["221"] = 264,["222"] = 278,["223"] = 279,["224"] = 280,["225"] = 281,["226"] = 282,["227"] = 283,["228"] = 284,["229"] = 285,["230"] = 286,["232"] = 288,["233"] = 289,["235"] = 291,["236"] = 292,["238"] = 294,["241"] = 278,["242"] = 302,["243"] = 302,["244"] = 302,["246"] = 303,["247"] = 304,["248"] = 305,["249"] = 306,["250"] = 307,["252"] = 309,["253"] = 310,["254"] = 311,["255"] = 312,["256"] = 313,["257"] = 314,["258"] = 315,["259"] = 302,["260"] = 318,["261"] = 319,["262"] = 318,["263"] = 325,["264"] = 325,["265"] = 325,["267"] = 326,["268"] = 327,["269"] = 328,["270"] = 329,["271"] = 330,["272"] = 331,["273"] = 332,["274"] = 333,["275"] = 334,["276"] = 335,["277"] = 325,["278"] = 338,["279"] = 339,["280"] = 338,["281"] = 345,["282"] = 345,["283"] = 345,["285"] = 346,["286"] = 347,["287"] = 348,["288"] = 349,["289"] = 345,["290"] = 355,["291"] = 355,["292"] = 355,["294"] = 356,["295"] = 357,["296"] = 358,["297"] = 359,["298"] = 355,["299"] = 365,["300"] = 365,["301"] = 365,["303"] = 366,["304"] = 367,["305"] = 368,["306"] = 369,["307"] = 370,["308"] = 371,["309"] = 372,["310"] = 365,["311"] = 378,["312"] = 378,["313"] = 378,["315"] = 380,["316"] = 381,["317"] = 382,["318"] = 382,["319"] = 382,["320"] = 382,["322"] = 384,["323"] = 384,["324"] = 384,["325"] = 384,["326"] = 384,["327"] = 384,["329"] = 378,["330"] = 393,["331"] = 394,["332"] = 393,["333"] = 400,["334"] = 400,["335"] = 400,["337"] = 402,["338"] = 403,["339"] = 404,["341"] = 406,["343"] = 408,["344"] = 408,["345"] = 408,["346"] = 408,["347"] = 408,["348"] = 408,["349"] = 400,["350"] = 415,["351"] = 416,["352"] = 415,["353"] = 422,["354"] = 422,["355"] = 422,["357"] = 424,["358"] = 425,["359"] = 427,["361"] = 429,["363"] = 431,["364"] = 432,["365"] = 432,["366"] = 432,["367"] = 432,["369"] = 434,["370"] = 434,["371"] = 434,["372"] = 434,["373"] = 434,["374"] = 434,["376"] = 422,["377"] = 442,["378"] = 443,["379"] = 442,["380"] = 452,["381"] = 453,["382"] = 454,["383"] = 455,["384"] = 456,["385"] = 452,["386"] = 462,["387"] = 462,["388"] = 462,["390"] = 463,["391"] = 464,["392"] = 465,["393"] = 466,["394"] = 462,["395"] = 473,["396"] = 474,["397"] = 475,["399"] = 477,["400"] = 473,["401"] = 483,["402"] = 483,["403"] = 483,["405"] = 484,["406"] = 485,["407"] = 486,["408"] = 487,["409"] = 483,["410"] = 494,["411"] = 495,["412"] = 496,["414"] = 498,["415"] = 494,["416"] = 504,["417"] = 504,["418"] = 504,["420"] = 505,["421"] = 506,["422"] = 507,["423"] = 508,["424"] = 504,["425"] = 515,["426"] = 516,["427"] = 517,["429"] = 519,["430"] = 515,["431"] = 532,["432"] = 532,["433"] = 532,["435"] = 533,["436"] = 534,["437"] = 535,["438"] = 536,["439"] = 537,["440"] = 538,["442"] = 540,["444"] = 542,["445"] = 543,["446"] = 532,["447"] = 552,["448"] = 553,["449"] = 554,["450"] = 555,["452"] = 557,["453"] = 558,["454"] = 559,["456"] = 561,["457"] = 552,["458"] = 573,["459"] = 575,["460"] = 576,["461"] = 577,["464"] = 581,["465"] = 582,["467"] = 584,["468"] = 585,["469"] = 586,["470"] = 587,["471"] = 573,["472"] = 598,["473"] = 599,["476"] = 602,["479"] = 605,["482"] = 608,["483"] = 609,["484"] = 610,["485"] = 611,["486"] = 612,["487"] = 613,["488"] = 614,["489"] = 615,["491"] = 617,["492"] = 618,["493"] = 620,["494"] = 622,["495"] = 622,["496"] = 622,["497"] = 622,["498"] = 622,["499"] = 622,["500"] = 623,["501"] = 623,["502"] = 623,["503"] = 623,["504"] = 623,["505"] = 623,["506"] = 624,["507"] = 624,["508"] = 624,["509"] = 624,["510"] = 624,["511"] = 624,["512"] = 626,["513"] = 627,["515"] = 631,["516"] = 632,["519"] = 635,["520"] = 635,["521"] = 635,["522"] = 635,["523"] = 635,["524"] = 635,["525"] = 636,["526"] = 636,["527"] = 636,["528"] = 636,["529"] = 636,["530"] = 636,["531"] = 637,["532"] = 637,["533"] = 637,["534"] = 637,["535"] = 637,["536"] = 637,["538"] = 639,["539"] = 598});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____MathUtil = require("solar.solar-common.util.math.MathUtil")
local MathUtil = ____MathUtil.default
local ____UnitStateUtil = require("solar.solar-common.util.unit.UnitStateUtil")
local UnitStateUtil = ____UnitStateUtil.default
local ____HandleUtil = require("solar.solar-common.util.lang.HandleUtil")
local HandleUtil = ____HandleUtil.default
local ____LangUtil = require("solar.solar-common.util.lang.LangUtil")
local LangUtil = ____LangUtil.default
local ____SelectUtil = require("solar.solar-common.util.unit.SelectUtil")
local SelectUtil = ____SelectUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local BaseAttributeMax = 10000000
____exports.default = __TS__Class()
local UnitUtil = ____exports.default
UnitUtil.name = "UnitUtil"
function UnitUtil.prototype.____constructor(self)
end
function UnitUtil.calculateDamageByPropertySet(unitHandle, dmgPropertySet)
    local damage = 0
    if dmgPropertySet.strDamageRate then
        damage = GetHeroStr(unitHandle, true) * dmgPropertySet.strDamageRate + damage
    end
    if dmgPropertySet.agiDamageRate then
        damage = GetHeroAgi(unitHandle, true) * dmgPropertySet.agiDamageRate + damage
    end
    if dmgPropertySet.intDamageRate then
        damage = GetHeroInt(unitHandle, true) * dmgPropertySet.intDamageRate + damage
    end
    if dmgPropertySet.hpDamageRate then
        damage = GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE) * dmgPropertySet.hpDamageRate + damage
    end
    if dmgPropertySet.manaDamageRate then
        damage = GetUnitState(unitHandle, UNIT_STATE_MAX_MANA) * dmgPropertySet.manaDamageRate + damage
    end
    return damage
end
function UnitUtil.GetInventoryIndexOfItemType(unitHandle, id)
    local idint = FourCC(id)
    do
        local i = 0
        while i < 6 do
            local indexItem = UnitItemInSlot(unitHandle, i)
            if IsHandle(indexItem) and GetItemTypeId(indexItem) == idint then
                return i + 1
            end
            i = i + 1
        end
    end
    return 0
end
function UnitUtil.GetInventoryOfItemType(unitHandle, idint)
    do
        local i = 0
        while i < 6 do
            local indexItem = UnitItemInSlot(unitHandle, i)
            if IsHandle(indexItem) and GetItemTypeId(indexItem) == idint then
                return indexItem
            end
            i = i + 1
        end
    end
    return nil
end
function UnitUtil.addHeroProperty(unit, key, addNum)
    if not unit:isHero() then
        return
    end
    local baseStr = unit.strength
    if unit.solarData["UnitUtil_addHeroProperty_strength_" .. key] then
        baseStr = baseStr - unit.solarData["UnitUtil_addHeroProperty_strength_" .. key]
    end
    unit.solarData["UnitUtil_addHeroProperty_strength_" .. key] = addNum
    unit.strength = baseStr + addNum
    local baseAgi = unit.agility
    if unit.solarData["UnitUtil_addHeroProperty_agility_" .. key] then
        baseAgi = baseAgi - unit.solarData["UnitUtil_addHeroProperty_agility_" .. key]
    end
    unit.solarData["UnitUtil_addHeroProperty_agility_" .. key] = addNum
    unit.agility = baseAgi + addNum
    local baseInt = unit.intelligence
    if unit.solarData["UnitUtil_addHeroProperty_intelligence_" .. key] then
        baseInt = baseInt - unit.solarData["UnitUtil_addHeroProperty_intelligence_" .. key]
    end
    unit.solarData["UnitUtil_addHeroProperty_intelligence_" .. key] = addNum
    unit.intelligence = baseInt + addNum
end
function UnitUtil.addHeroPropertyByRate(unit, key, addRate)
    if not unit:isHero() then
        return
    end
    local addNum = 0
    local baseStr = unit.strength
    if unit.solarData["UnitUtil_addHeroPropertyByRate_strength_" .. key] then
        baseStr = baseStr - unit.solarData["UnitUtil_addHeroPropertyByRate_strength_" .. key]
    end
    addNum = baseStr * addRate
    unit.solarData["UnitUtil_addHeroPropertyByRate_strength_" .. key] = addNum
    unit.strength = baseStr + addNum
    local baseAgi = unit.agility
    if unit.solarData["UnitUtil_addHeroPropertyByRate_agility_" .. key] then
        baseAgi = baseAgi - unit.solarData["UnitUtil_addHeroPropertyByRate_agility_" .. key]
    end
    addNum = baseAgi * addRate
    unit.solarData["UnitUtil_addHeroPropertyByRate_agility_" .. key] = addNum
    unit.agility = baseAgi + addNum
    local baseInt = unit.intelligence
    if unit.solarData["UnitUtil_addHeroPropertyByRate_intelligence_" .. key] then
        baseInt = baseInt - unit.solarData["UnitUtil_addHeroPropertyByRate_intelligence_" .. key]
    end
    addNum = baseInt * addRate
    unit.solarData["UnitUtil_addHeroPropertyByRate_intelligence_" .. key] = addNum
    unit.intelligence = baseInt + addNum
end
function UnitUtil.transfer2Rect(unitHandle, rect, faceNearestEnemy, effectPath)
    if faceNearestEnemy == nil then
        faceNearestEnemy = true
    end
    if effectPath == nil then
        effectPath = "Abilities\\Spells\\Human\\MassTeleport\\MassTeleportCaster.mdx"
    end
    ____exports.default.transfer(
        unitHandle,
        GetRectCenterX(rect),
        GetRectCenterY(rect),
        faceNearestEnemy,
        effectPath
    )
end
function UnitUtil.transfer(unitHandle, x, y, faceNearestEnemy, effectPath)
    if faceNearestEnemy == nil then
        faceNearestEnemy = true
    end
    if effectPath == nil then
        effectPath = "Abilities\\Spells\\Human\\MassTeleport\\MassTeleportCaster.mdx"
    end
    BaseUtil.runLater(
        0.01,
        function()
            SetUnitPosition(unitHandle, x, y)
            PanCameraToTimedForPlayer(
                GetOwningPlayer(unitHandle),
                x,
                y,
                0.1
            )
            DestroyEffect(AddSpecialEffect(effectPath, x, y))
            if faceNearestEnemy then
                ____exports.default.faceNearestEnemy(unitHandle)
            end
        end
    )
end
function UnitUtil.faceNearestEnemy(unitHandle, maxRange)
    if maxRange == nil then
        maxRange = 2000
    end
    local nearestEnemy = SelectUtil.getNearestEnemyInRange(unitHandle, maxRange)
    if not IsHandle(nearestEnemy) then
        return nearestEnemy
    end
    local angle = MathUtil.angleBetweenCoords(
        GetUnitX(unitHandle),
        GetUnitY(unitHandle),
        GetUnitX(nearestEnemy),
        GetUnitY(nearestEnemy)
    )
    SetUnitFacing(unitHandle, angle)
    return nearestEnemy
end
function UnitUtil.order_stop(unitHandle)
    IssueImmediateOrder(unitHandle, "stop")
end
function UnitUtil.isHero(unitHandle)
    return IsHeroUnitId(GetUnitTypeId(unitHandle))
end
function UnitUtil.isType(unitType, unitHandle)
    return GetUnitTypeId(unitHandle) == LangUtil:getIntId(unitType)
end
function UnitUtil.isStructure(unitHandle)
    return IsUnitType(unitHandle, UNIT_TYPE_STRUCTURE)
end
function UnitUtil.isSummoned(unitHandle)
    return IsUnitType(unitHandle, UNIT_TYPE_SUMMONED)
end
function UnitUtil.isNeutralAggressive(unitHandle)
    return GetPlayerId(GetOwningPlayer(unitHandle)) == PLAYER_NEUTRAL_AGGRESSIVE
end
function UnitUtil.isNeutralPassive(unitHandle)
    return GetPlayerId(GetOwningPlayer(unitHandle)) == PLAYER_NEUTRAL_PASSIVE
end
function UnitUtil.createUnit(player, unitTypeId, x, y, face, count)
    if face == nil then
        face = 0
    end
    if count == nil then
        count = 1
    end
    local unit = nil
    do
        local i = 0
        while i < count do
            unit = CreateUnit(
                player,
                unitTypeId,
                x,
                y,
                face
            )
            i = i + 1
        end
    end
    return unit
end
function UnitUtil.isBack(attackedUnit, attacker)
    local targetLoc = GetUnitLoc(attackedUnit)
    local triggerLoc = GetUnitLoc(attacker)
    local angle = AngleBetweenPoints(triggerLoc, targetLoc)
    local facing = GetUnitFacing(attackedUnit)
    RemoveLocation(targetLoc)
    RemoveLocation(triggerLoc)
    if angle <= 0 then
        angle = angle + 360
    end
    if facing < 90 then
        return angle >= 360 - (facing - 90) and angle <= 360 or angle >= 0 and angle <= facing + 90
    else
        if facing > 270 then
            return angle >= facing - 90 and angle <= 360 or angle >= 0 and angle <= facing + 90 - 360
        else
            return angle >= facing - 90 and angle <= facing + 90
        end
    end
end
function UnitUtil.setExtraMana(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local nowValue = GetUnitState(unitHandle, UNIT_STATE_MANA)
    local maxValue = GetUnitState(unitHandle, UNIT_STATE_MAX_MANA)
    local bfp = 1
    if maxValue > 0 then
        bfp = nowValue / maxValue
    end
    local oldExtra = ____exports.default.getExtraMana(unitHandle)
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Mana", val, key)
    local add = val - oldExtra
    maxValue = maxValue + add
    nowValue = bfp * maxValue
    SetUnitState(unitHandle, UNIT_STATE_MAX_MANA, maxValue)
    SetUnitState(unitHandle, UNIT_STATE_MANA, nowValue)
end
function UnitUtil.getExtraMana(unitHandle, key)
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Mana", key)
end
function UnitUtil.setExtraHp(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local nowValue = GetUnitState(unitHandle, UNIT_STATE_LIFE)
    local maxValue = GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE)
    local bfp = nowValue / maxValue
    local oldExtra = ____exports.default.getExtraHp(unitHandle)
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Hp", val, key)
    local add = val - oldExtra
    maxValue = maxValue + add
    nowValue = bfp * maxValue
    SetUnitState(unitHandle, UNIT_STATE_MAX_LIFE, maxValue)
    SetUnitState(unitHandle, UNIT_STATE_LIFE, nowValue)
end
function UnitUtil.getExtraHp(unitHandle, key)
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Hp", key)
end
function UnitUtil.setExtraDamageCool(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local oldExtra = ____exports.default.getExtraValue(unitHandle, "_SLExt_DamageCool")
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_DamageCool", val, key)
    local add = val - oldExtra
    UnitStateUtil:addDamageCool(unitHandle, add)
end
function UnitUtil.setExtraDamageRange(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local oldExtra = ____exports.default.getExtraValue(unitHandle, "_SLExt_DamageRange")
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_DamageRange", val, key)
    local add = val - oldExtra
    UnitStateUtil:addDamageRange(unitHandle, add)
end
function UnitUtil.setExtraMoveSpeed(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local oldExtra = ____exports.default.getExtraValue(unitHandle, "_SLExt_MoveSpeed")
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_MoveSpeed", val, key)
    local add = val - oldExtra
    local solarData = DataBase:getUnitSolarData(unitHandle)
    local _sl_logical_MoveSpeed = (solarData._sl_logical_MoveSpeed or UnitStateUtil:getMoveSpeed(unitHandle)) + add
    SetUnitMoveSpeed(unitHandle, _sl_logical_MoveSpeed)
    solarData._sl_logical_MoveSpeed = _sl_logical_MoveSpeed
end
function UnitUtil.setExtraAttackSpd(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_AttackSpd", val, key)
    if val == 0 then
        UnitRemoveAbility(
            unitHandle,
            FourCC("AIs2")
        )
    else
        ____exports.default.refreshUnitAbilityData(
            unitHandle,
            FourCC("AIs2"),
            ABILITY_DATA_DATA_A,
            val
        )
    end
end
function UnitUtil.getExtraAttackSpd(unitHandle)
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_AttackSpd")
end
function UnitUtil.setExtraAttack(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Attack", val, key)
    if isBigAttributeMode then
        val = MathUtil.clamp(val, -BaseAttributeMax, BaseAttributeMax)
    else
        val = math.min(val, 2100000000)
    end
    ____exports.default.refreshUnitAbilityData(
        unitHandle,
        FourCC("AItg"),
        108,
        val
    )
end
function UnitUtil.getExtraAttack(unitHandle)
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Attack")
end
function UnitUtil.setExtraDef(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Def", val, key)
    if isBigAttributeMode then
        val = MathUtil.clamp(val, -BaseAttributeMax, BaseAttributeMax)
    else
        val = math.min(val, 2100000000)
    end
    if val == 0 then
        UnitRemoveAbility(
            unitHandle,
            FourCC("AId1")
        )
    else
        ____exports.default.refreshUnitAbilityData(
            unitHandle,
            FourCC("AId1"),
            108,
            val
        )
    end
end
function UnitUtil.getExtraDef(unitHandle, key)
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Def", key)
end
function UnitUtil.setExtraStrAgiInt(unitHandle, key, str, agi, int)
    local str_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Str", str, key)
    local agi_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Agi", agi, key)
    local int_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Int", int, key)
    ____exports.default.refreshUnitAamkData(unitHandle, str_val, agi_val, int_val)
end
function UnitUtil.setExtraStr(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local str_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Str", val, key)
    local agi_val = ____exports.default.getExtraAgi(unitHandle)
    local int_val = ____exports.default.getExtraInt(unitHandle)
    ____exports.default.refreshUnitAamkData(unitHandle, str_val, agi_val, int_val)
end
function UnitUtil.getExtraStr(unitHandle, key)
    if key then
        return ____exports.default.getExtraValue(unitHandle, "_SLExt_Str", key)
    end
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Str")
end
function UnitUtil.setExtraAgi(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local str_val = ____exports.default.getExtraStr(unitHandle)
    local agi_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Agi", val, key)
    local int_val = ____exports.default.getExtraInt(unitHandle)
    ____exports.default.refreshUnitAamkData(unitHandle, str_val, agi_val, int_val)
end
function UnitUtil.getExtraAgi(unitHandle, key)
    if key then
        return ____exports.default.getExtraValue(unitHandle, "_SLExt_Agi", key)
    end
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Agi")
end
function UnitUtil.setExtraInt(unitHandle, val, key)
    if key == nil then
        key = "base"
    end
    local str_val = ____exports.default.getExtraStr(unitHandle)
    local agi_val = ____exports.default.getExtraAgi(unitHandle)
    local int_val = ____exports.default.extraValueSum(unitHandle, "_SLExt_Int", val, key)
    ____exports.default.refreshUnitAamkData(unitHandle, str_val, agi_val, int_val)
end
function UnitUtil.getExtraInt(unitHandle, key)
    if key then
        return ____exports.default.getExtraValue(unitHandle, "_SLExt_Int", key)
    end
    return ____exports.default.getExtraValue(unitHandle, "_SLExt_Int")
end
function UnitUtil.extraValueSum(unitHandle, ____type, val, key)
    if key == nil then
        key = "base"
    end
    local solarData = DataBase:getUnitSolarData(unitHandle)
    local extraData = solarData[____type]
    if val then
        if not extraData then
            extraData = {}
            solarData[____type] = extraData
        end
        extraData[key] = val
    end
    local count = MathUtil.sum(extraData)
    return count
end
function UnitUtil.getExtraValue(unitHandle, ____type, key)
    local solarData = DataBase:getUnitSolarData(unitHandle, false)
    if not solarData then
        return 0
    end
    local extraData = solarData[____type]
    if key then
        return extraData and extraData[key] or 0
    end
    return MathUtil.sum(extraData)
end
function UnitUtil.refreshUnitAbilityData(unitHandle, abilcode, data_type, value)
    if isDebug and not HandleUtil:isUnitHandle(unitHandle) then
        print_r(handledef(unitHandle))
        log.errorWithTraceBack("你传的单位handle 有误。可能已被其它类型的handle对象重用")
        return
    end
    if GetUnitAbilityLevel(unitHandle, abilcode) <= 0 then
        UnitAddAbility(unitHandle, abilcode)
    end
    local ability = EXGetUnitAbility(unitHandle, abilcode)
    IncUnitAbilityLevel(unitHandle, abilcode)
    EXSetAbilityDataReal(ability, 1, data_type, value)
    DecUnitAbilityLevel(unitHandle, abilcode)
end
function UnitUtil.refreshUnitAamkData(unitHandle, str, agi, int)
    if not IsHandle(unitHandle) then
        return
    end
    if GetWidgetLife(unitHandle) < 0.4 then
        return
    end
    if not IsHeroUnitId(GetUnitTypeId(unitHandle)) then
        return
    end
    local abilcode = FourCC("Aamk")
    if GetUnitAbilityLevel(unitHandle, abilcode) <= 0 then
        UnitAddAbility(unitHandle, abilcode)
        local ability = EXGetUnitAbility(unitHandle, abilcode)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_D, 1)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_A, 0)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_B, 0)
        EXSetAbilityDataReal(ability, 1, ABILITY_DATA_DATA_C, 0)
    end
    local ability = EXGetUnitAbility(unitHandle, abilcode)
    IncUnitAbilityLevel(unitHandle, abilcode)
    if isBigAttributeMode then
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_A,
            MathUtil.clamp(agi, -BaseAttributeMax, BaseAttributeMax)
        )
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_B,
            MathUtil.clamp(int, -BaseAttributeMax, BaseAttributeMax)
        )
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_C,
            MathUtil.clamp(str, -BaseAttributeMax, BaseAttributeMax)
        )
        if StrHpBonus > 0 and str > BaseAttributeMax then
            ____exports.default.setExtraHp(unitHandle, (str - BaseAttributeMax) * StrHpBonus, "_SL_refreshUnitAamkData")
        end
        if IntManaBonus > 0 and int > BaseAttributeMax then
            ____exports.default.setExtraMana(unitHandle, (int - BaseAttributeMax) * IntManaBonus, "_SL_refreshUnitAamkData")
        end
    else
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_A,
            math.min(agi, 2100000000)
        )
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_B,
            math.min(int, 2100000000)
        )
        EXSetAbilityDataReal(
            ability,
            1,
            ABILITY_DATA_DATA_C,
            math.min(str, 2100000000)
        )
    end
    DecUnitAbilityLevel(unitHandle, abilcode)
end
return ____exports
