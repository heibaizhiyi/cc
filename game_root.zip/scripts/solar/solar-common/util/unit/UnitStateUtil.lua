local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 5,["15"] = 5,["16"] = 6,["17"] = 6,["18"] = 11,["19"] = 11,["20"] = 11,["22"] = 11,["23"] = 18,["24"] = 19,["25"] = 18,["26"] = 27,["27"] = 28,["28"] = 27,["29"] = 36,["30"] = 37,["31"] = 36,["32"] = 44,["33"] = 45,["34"] = 46,["35"] = 44,["36"] = 53,["37"] = 54,["38"] = 53,["39"] = 61,["40"] = 62,["41"] = 61,["42"] = 70,["43"] = 71,["44"] = 70,["45"] = 79,["46"] = 80,["47"] = 79,["48"] = 89,["49"] = 90,["50"] = 90,["51"] = 90,["52"] = 90,["53"] = 90,["54"] = 89,["55"] = 97,["56"] = 98,["57"] = 97,["58"] = 106,["59"] = 107,["60"] = 106,["61"] = 115,["62"] = 116,["63"] = 115,["64"] = 123,["65"] = 124,["66"] = 125,["67"] = 123,["68"] = 132,["69"] = 133,["70"] = 132,["71"] = 141,["72"] = 142,["73"] = 141,["74"] = 150,["75"] = 151,["76"] = 150,["77"] = 160,["78"] = 161,["79"] = 161,["80"] = 161,["81"] = 161,["82"] = 161,["83"] = 160,["84"] = 167,["85"] = 168,["86"] = 167,["87"] = 177,["88"] = 178,["89"] = 177,["90"] = 185,["91"] = 186,["92"] = 187,["94"] = 189,["95"] = 185,["96"] = 197,["97"] = 198,["98"] = 199,["99"] = 200,["101"] = 202,["102"] = 197,["103"] = 208,["104"] = 209,["105"] = 208,["106"] = 218,["107"] = 218,["108"] = 218,["110"] = 219,["111"] = 220,["112"] = 221,["113"] = 222,["114"] = 224,["116"] = 218,["117"] = 233,["118"] = 234,["119"] = 234,["120"] = 234,["121"] = 234,["122"] = 233,["123"] = 240,["124"] = 241,["125"] = 240,["126"] = 249,["127"] = 250,["128"] = 251,["130"] = 253,["131"] = 249,["132"] = 259,["133"] = 260,["134"] = 261,["135"] = 262,["137"] = 264,["138"] = 259,["139"] = 271,["140"] = 272,["141"] = 271,["142"] = 280,["143"] = 281,["144"] = 280,["145"] = 291,["146"] = 291,["147"] = 291,["149"] = 292,["150"] = 293,["151"] = 294,["154"] = 297,["155"] = 298,["156"] = 300,["157"] = 301,["158"] = 302,["162"] = 306,["163"] = 307,["165"] = 310,["166"] = 311,["167"] = 312,["168"] = 313,["169"] = 313,["170"] = 313,["171"] = 313,["172"] = 313,["173"] = 313,["175"] = 315,["178"] = 319,["179"] = 319,["180"] = 319,["181"] = 319,["182"] = 319,["183"] = 319,["184"] = 320,["185"] = 322,["186"] = 291,["187"] = 330,["188"] = 331,["189"] = 330,["190"] = 337,["191"] = 338,["192"] = 337,["193"] = 346,["194"] = 347,["195"] = 348,["197"] = 350,["198"] = 346,["199"] = 358,["200"] = 359,["201"] = 360,["202"] = 361,["204"] = 363,["205"] = 358,["206"] = 372,["207"] = 373,["208"] = 374,["209"] = 375,["210"] = 372,["211"] = 381,["212"] = 382,["213"] = 381,["214"] = 391,["215"] = 392,["216"] = 391,["217"] = 401,["218"] = 402,["219"] = 403,["220"] = 404,["221"] = 401,["222"] = 412,["223"] = 413,["224"] = 414,["225"] = 415,["228"] = 418,["229"] = 419,["230"] = 420,["231"] = 421,["232"] = 422,["233"] = 423,["234"] = 424,["235"] = 425,["236"] = 426,["237"] = 427,["238"] = 428,["239"] = 429,["240"] = 430,["241"] = 431,["242"] = 432,["243"] = 433,["245"] = 412,["246"] = 442,["247"] = 443,["248"] = 444,["249"] = 445,["250"] = 445,["251"] = 445,["252"] = 446,["253"] = 447,["254"] = 445,["255"] = 445,["256"] = 445,["257"] = 445,["258"] = 442,["259"] = 456,["260"] = 457,["261"] = 456,["262"] = 466,["263"] = 467,["264"] = 467,["265"] = 467,["266"] = 467,["267"] = 467,["268"] = 466,["269"] = 475,["270"] = 476,["271"] = 475,["272"] = 485,["273"] = 486,["274"] = 486,["275"] = 486,["276"] = 486,["277"] = 486,["278"] = 485,["279"] = 498,["280"] = 498,["281"] = 498,["283"] = 498,["284"] = 498,["286"] = 498,["287"] = 498,["289"] = 499,["290"] = 499,["291"] = 499,["292"] = 499,["293"] = 499,["294"] = 499,["295"] = 499,["296"] = 498,["297"] = 506,["298"] = 507,["299"] = 508,["301"] = 510,["302"] = 506,["303"] = 516,["304"] = 518,["305"] = 516,["306"] = 526,["307"] = 527,["308"] = 528,["309"] = 530,["310"] = 531,["312"] = 533,["313"] = 535,["314"] = 536,["316"] = 538,["317"] = 540,["318"] = 541,["319"] = 541,["320"] = 541,["321"] = 543,["322"] = 544,["323"] = 545,["324"] = 546,["325"] = 547,["328"] = 541,["329"] = 541,["330"] = 526,["331"] = 560,["332"] = 560,["333"] = 560,["335"] = 561,["336"] = 560,["337"] = 568,["338"] = 574,["339"] = 568,["340"] = 580,["341"] = 581,["342"] = 582,["343"] = 583,["345"] = 585,["347"] = 580,["348"] = 592,["349"] = 593,["350"] = 592,["351"] = 599,["352"] = 600,["353"] = 599,["354"] = 606,["355"] = 607,["356"] = 606,["357"] = 613,["358"] = 614,["359"] = 613,["360"] = 620,["361"] = 620,["362"] = 620,["364"] = 621,["365"] = 622,["366"] = 623,["367"] = 623,["368"] = 623,["369"] = 624,["370"] = 625,["371"] = 623,["372"] = 623,["373"] = 620,["374"] = 633,["375"] = 634,["376"] = 634,["377"] = 634,["378"] = 634,["379"] = 635,["380"] = 635,["381"] = 635,["382"] = 635,["383"] = 633,["384"] = 642,["385"] = 643,["386"] = 644,["388"] = 647,["389"] = 648,["391"] = 650,["392"] = 652,["393"] = 653,["394"] = 654,["396"] = 656,["397"] = 657,["399"] = 659,["400"] = 660,["402"] = 663,["403"] = 664,["405"] = 666,["406"] = 667,["408"] = 669,["409"] = 670,["411"] = 672,["412"] = 673,["414"] = 675,["415"] = 676,["417"] = 678,["418"] = 679,["420"] = 681,["421"] = 682,["423"] = 684,["424"] = 685,["426"] = 687,["427"] = 688,["429"] = 690,["430"] = 691,["433"] = 696,["434"] = 697,["435"] = 698,["437"] = 700,["438"] = 701,["440"] = 703,["441"] = 704,["443"] = 707,["444"] = 708,["446"] = 710,["447"] = 711,["449"] = 713,["450"] = 714,["452"] = 716,["453"] = 717,["455"] = 719,["456"] = 720,["458"] = 722,["459"] = 723,["461"] = 725,["462"] = 726,["464"] = 728,["465"] = 729,["467"] = 731,["468"] = 732,["470"] = 734,["471"] = 735,["474"] = 740,["475"] = 741,["476"] = 742,["477"] = 743,["479"] = 745,["480"] = 746,["482"] = 748,["483"] = 749,["485"] = 751,["486"] = 752,["487"] = 752,["490"] = 756,["491"] = 757,["493"] = 760,["494"] = 642});
local ____exports = {}
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____MoveType = require("solar.solar-common.constant.MoveType")
local MoveType = ____MoveType.default
local ____AbilityUtil = require("solar.solar-common.util.ability.AbilityUtil")
local AbilityUtil = ____AbilityUtil.default
local ____ObjectDataUtil = require("solar.solar-common.util.object.ObjectDataUtil")
local ObjectDataUtil = ____ObjectDataUtil.default
local ____HeroUtil = require("solar.solar-common.util.unit.HeroUtil")
local HeroUtil = ____HeroUtil.default
____exports.default = __TS__Class()
local UnitStateUtil = ____exports.default
UnitStateUtil.name = "UnitStateUtil"
function UnitStateUtil.prototype.____constructor(self)
end
function UnitStateUtil.getMaxLife(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE)
end
function UnitStateUtil.setMaxLife(self, unitHandle, newVal)
    SetUnitState(unitHandle, UNIT_STATE_MAX_LIFE, newVal)
end
function UnitStateUtil.addMaxLife(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MAX_LIFE, addVal)
end
function UnitStateUtil.addMaxLifeAndLife(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MAX_LIFE, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_LIFE, addVal)
end
function UnitStateUtil.isAlive(self, unitHandle)
    return UnitAlive(unitHandle)
end
function UnitStateUtil.getLife(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_LIFE)
end
function UnitStateUtil.setLife(self, unitHandle, newVal)
    SetUnitState(unitHandle, UNIT_STATE_LIFE, newVal)
end
function UnitStateUtil.addLife(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_LIFE, addVal)
end
function UnitStateUtil.addUnitLifeByMaxLifeP(self, unitHandle, proportion)
    ____exports.default:addUnitState(
        unitHandle,
        UNIT_STATE_LIFE,
        GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE) * proportion
    )
end
function UnitStateUtil.getMaxMana(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_MAX_MANA)
end
function UnitStateUtil.setMaxMana(self, unitHandle, newVal)
    SetUnitState(unitHandle, UNIT_STATE_MAX_MANA, newVal)
end
function UnitStateUtil.addMaxMana(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MAX_MANA, addVal)
end
function UnitStateUtil.addMaxManaAndMana(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MAX_MANA, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MANA, addVal)
end
function UnitStateUtil.getMana(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_MANA)
end
function UnitStateUtil.setMana(self, unitHandle, newVal)
    SetUnitState(unitHandle, UNIT_STATE_MANA, newVal)
end
function UnitStateUtil.addMana(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UNIT_STATE_MANA, addVal)
end
function UnitStateUtil.addUnitManaByMaxManaP(self, unitHandle, proportion)
    ____exports.default:addUnitState(
        unitHandle,
        UNIT_STATE_MANA,
        GetUnitState(unitHandle, UNIT_STATE_MAX_MANA) * proportion
    )
end
function UnitStateUtil.getDamageMax(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateDamageMax)
end
function UnitStateUtil.getDamageBase(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateDamageBase)
end
function UnitStateUtil.setDamageBase(self, unitHandle, damageBase)
    if not isBigAttributeMode then
        damageBase = math.min(damageBase, 2100000000)
    end
    SetUnitState(unitHandle, UnitStateDamageBase, damageBase)
end
function UnitStateUtil.addDamageBase(self, unitHandle, addVal)
    local newVal = GetUnitState(unitHandle, UnitStateDamageBase) + addVal
    if not isBigAttributeMode then
        newVal = math.min(newVal, 2100000000)
    end
    SetUnitState(unitHandle, UnitStateDamageBase, newVal)
end
function UnitStateUtil.getDamageRange(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateDamageRange)
end
function UnitStateUtil.setDamageRange(self, unitHandle, newVal, syncAcquire)
    if syncAcquire == nil then
        syncAcquire = false
    end
    SetUnitState(unitHandle, UnitStateDamageRange, newVal)
    if syncAcquire then
        SetUnitAcquireRange(unitHandle, newVal)
    elseif GetUnitAcquireRange(unitHandle) < newVal then
        SetUnitAcquireRange(unitHandle, newVal)
    end
end
function UnitStateUtil.addDamageRange(self, unitHandle, addVal)
    ____exports.default:setDamageRange(
        unitHandle,
        GetUnitState(unitHandle, UnitStateDamageRange) + addVal
    )
end
function UnitStateUtil.getDamageCool(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateDamageCool)
end
function UnitStateUtil.setDamageCool(self, unitHandle, newVal)
    if newVal < 0.001 then
        newVal = 0.001
    end
    SetUnitState(unitHandle, UnitStateDamageCool, newVal)
end
function UnitStateUtil.addDamageCool(self, unitHandle, addVal)
    local newVal = GetUnitState(unitHandle, UnitStateDamageCool) + addVal
    if newVal < 0.001 then
        newVal = 0.001
    end
    SetUnitState(unitHandle, UnitStateDamageCool, newVal)
end
function UnitStateUtil.getAttackSpeed(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateAttackSpeed)
end
function UnitStateUtil.setAttackSpeed(self, unitHandle, newVal)
    SetUnitState(unitHandle, UnitStateAttackSpeed, newVal)
end
function UnitStateUtil.setAttackTargetCount(self, unitHandle, targetCount, range, missileart)
    if range == nil then
        range = ____exports.default:getDamageRange(unitHandle) + 200
    end
    local templateId = _sl_funs:borrowTemplate("攻击目标数量辅助")
    if templateId == nil then
        log.errorWithTraceBack("请使用太阳RPG编辑器添加基础物编!")
        return
    end
    _sl_funs:returnTemplate("攻击目标数量辅助", templateId)
    local tempAbilityId = FourCC(templateId)
    if targetCount == 0 then
        if GetUnitAbilityLevel(unitHandle, tempAbilityId) > 0 then
            UnitRemoveAbility(unitHandle, tempAbilityId)
        end
        return
    end
    if GetUnitAbilityLevel(unitHandle, tempAbilityId) == 0 then
        UnitAddAbility(unitHandle, tempAbilityId)
    end
    if missileart == nil then
        missileart = ObjectDataUtil:getUnitMissileart(id2string(GetUnitTypeId(unitHandle)))
        if missileart ~= nil and #missileart > 3 then
            EXSetAbilityDataString(
                EXGetUnitAbility(unitHandle, tempAbilityId),
                1,
                ABILITY_DATA_MISSILE_ART,
                missileart
            )
        else
            missileart = "Abilities\\Weapons\\Arrow\\ArrowMissile.mdx"
        end
    end
    EXSetAbilityDataString(
        EXGetUnitAbility(unitHandle, tempAbilityId),
        1,
        ABILITY_DATA_MISSILE_ART,
        missileart
    )
    AbilityUtil:setUnitAbilityArea(unitHandle, tempAbilityId, range, false)
    AbilityUtil:setUnitAbilityDataC(unitHandle, tempAbilityId, targetCount, true)
end
function UnitStateUtil.addAttackSpeed(self, unitHandle, addVal)
    ____exports.default:addUnitState(unitHandle, UnitStateAttackSpeed, addVal)
end
function UnitStateUtil.getArmor(self, unitHandle)
    return GetUnitState(unitHandle, UnitStateArmor)
end
function UnitStateUtil.setArmor(self, unitHandle, newVal)
    if not isBigAttributeMode then
        newVal = math.min(newVal, 2100000000)
    end
    SetUnitState(unitHandle, UnitStateArmor, newVal)
end
function UnitStateUtil.addArmor(self, unitHandle, addVal)
    local newVal = GetUnitState(unitHandle, UnitStateArmor) + addVal
    if not isBigAttributeMode then
        newVal = math.min(newVal, 2100000000)
    end
    SetUnitState(unitHandle, UnitStateArmor, newVal)
end
function UnitStateUtil.addUnitState(self, unitHandle, whichUnitState, addVal)
    local newVal = GetUnitState(unitHandle, whichUnitState) + addVal
    SetUnitState(unitHandle, whichUnitState, newVal)
    return newVal
end
function UnitStateUtil.getMoveSpeed(self, unitHandle)
    return GetUnitMoveSpeed(unitHandle)
end
function UnitStateUtil.setMoveSpeed(self, unitHandle, newSpeed)
    SetUnitMoveSpeed(unitHandle, newSpeed)
end
function UnitStateUtil.addMoveSpeed(self, unitHandle, addSpeed)
    local newVal = GetUnitMoveSpeed(unitHandle) + addSpeed
    SetUnitMoveSpeed(unitHandle, newVal)
    return newVal
end
function UnitStateUtil.setMoveType(self, unitHandle, moveType)
    local moveTypeElement = MoveType[moveType]
    EXSetUnitMoveType(unitHandle, moveTypeElement)
    if SetUnitMoveType == nil then
        return
    end
    if moveTypeElement == 0 then
        SetUnitMoveType(unitHandle, "none")
    elseif moveTypeElement == 1 then
        SetUnitMoveType(unitHandle, "nomove")
    elseif moveTypeElement == 2 then
        SetUnitMoveType(unitHandle, "foot")
    elseif moveTypeElement == 4 then
        SetUnitMoveType(unitHandle, "fly")
    elseif moveTypeElement == 64 then
        SetUnitMoveType(unitHandle, "float")
    elseif moveTypeElement == 8 then
        SetUnitMoveType(unitHandle, "hover")
    elseif moveTypeElement == 128 then
        SetUnitMoveType(unitHandle, "amph")
    elseif moveTypeElement == 32 then
        SetUnitMoveType(unitHandle, "unbuild")
    end
end
function UnitStateUtil.setUnitFacing(self, unit, face)
    local x = GetUnitX(unit)
    local y = GetUnitY(unit)
    BaseUtil.runLater(
        0.01,
        function()
            SetUnitPosition(unit, x, y)
            EXSetUnitFacing(unit, face)
        end,
        3,
        true
    )
end
function UnitStateUtil.getUnitLifeP(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_LIFE) / GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE)
end
function UnitStateUtil.setUnitLifeP(self, unitHandle, proportion)
    return SetUnitState(
        unitHandle,
        UNIT_STATE_LIFE,
        GetUnitState(unitHandle, UNIT_STATE_MAX_LIFE) * proportion
    )
end
function UnitStateUtil.getUnitManaP(self, unitHandle)
    return GetUnitState(unitHandle, UNIT_STATE_MANA) / GetUnitState(unitHandle, UNIT_STATE_MAX_MANA)
end
function UnitStateUtil.setUnitManaP(self, unitHandle, proportion)
    return SetUnitState(
        unitHandle,
        UNIT_STATE_MANA,
        GetUnitState(unitHandle, UNIT_STATE_MAX_MANA) * proportion
    )
end
function UnitStateUtil.setUnitColor(self, whichUnit, red, green, blue, alpha)
    if green == nil then
        green = red
    end
    if blue == nil then
        blue = green
    end
    if alpha == nil then
        alpha = 255
    end
    SetUnitVertexColor(
        whichUnit,
        red,
        green,
        blue,
        alpha
    )
end
function UnitStateUtil.isInvulnerable(self, unitHandle)
    if GetUnitAbilityLevel(unitHandle, "Avul") > 0 then
        return true
    end
    return false
end
function UnitStateUtil.setInvulnerable(self, unitHandle, isInvulnerable)
    SetUnitInvulnerable(unitHandle, isInvulnerable)
end
function UnitStateUtil.addInvulnerableIfNot(self, unitHandle, dur)
    local unitSolarData = DataBase:getUnitSolarData(unitHandle, true)
    local invulnerable_endTime = unitSolarData.invulnerable_endTime
    if GetUnitAbilityLevel(unitHandle, "Avul") > 0 and invulnerable_endTime == nil then
        return false
    end
    local newInvulnerable_endTime = _g_time + math.floor(dur * 100) * 10
    if invulnerable_endTime and invulnerable_endTime >= newInvulnerable_endTime then
        return false
    end
    unitSolarData.invulnerable_endTime = newInvulnerable_endTime
    SetUnitInvulnerable(unitHandle, true)
    BaseUtil.runLater(
        dur,
        function()
            local solarDataTemp = DataBase:getUnitSolarData(unitHandle, false)
            if (solarDataTemp and solarDataTemp.invulnerable_endTime) == nil or _g_time >= solarDataTemp.invulnerable_endTime then
                SetUnitInvulnerable(unitHandle, false)
                if solarDataTemp then
                    solarDataTemp.invulnerable_endTime = nil
                end
            end
        end
    )
end
function UnitStateUtil.applyTimedLife(self, unitHandle, duration, buffid)
    if buffid == nil then
        buffid = "BHwe"
    end
    UnitApplyTimedLife(unitHandle, buffid, duration)
end
function UnitStateUtil.setNoMove(self, unitHandle)
    SetUnitPropWindow(unitHandle, 0)
end
function UnitStateUtil.isNoOrder(self, unitHandle)
    local order = GetUnitCurrentOrder(unitHandle)
    if order == 0 or order == nil then
        return true
    else
        return false
    end
end
function UnitStateUtil.orderPatrol(self, unitHandle, x, y)
    IssuePointOrder(unitHandle, "patrol", x, y)
end
function UnitStateUtil.orderAttack(self, unitHandle, x, y)
    IssuePointOrder(unitHandle, "attack", x, y)
end
function UnitStateUtil.orderAttackTarget(self, unitHandle, target)
    IssueTargetOrder(unitHandle, "attack", target)
end
function UnitStateUtil.orderMove(self, unitHandle, x, y)
    IssuePointOrder(unitHandle, "move", x, y)
end
function UnitStateUtil.stunUnit(self, unitHandle, dur, effectPath)
    if effectPath == nil then
        effectPath = "Abilities\\Spells\\Human\\Thunderclap\\ThunderclapTarget.mdx"
    end
    EXPauseUnit(unitHandle, true)
    local effect = AddSpecialEffectTarget(effectPath, unitHandle, "head")
    BaseUtil.runLater(
        dur,
        function()
            EXPauseUnit(unitHandle, false)
            DestroyEffect(effect)
        end
    )
end
function UnitStateUtil.enableFlyHeight(self, unitHandle)
    UnitAddAbility(
        unitHandle,
        FourCC("Amrf")
    )
    UnitRemoveAbility(
        unitHandle,
        FourCC("Amrf")
    )
end
function UnitStateUtil.calculateStateFormula(self, formula, srcUnit, targetUnit)
    if formula == nil then
        return 0
    end
    if formula.chance ~= nil and GetRandomReal(0, 1) > formula.chance then
        return 0
    end
    local value = formula.base or 0
    if srcUnit ~= nil then
        if formula.attack then
            value = value + GetUnitState(srcUnit, UnitStateDamageMax) * formula.attack
        end
        if formula.def then
            value = value + GetUnitState(srcUnit, UnitStateArmor) * formula.def
        end
        if formula.fullPros then
            value = value + (GetHeroStr(srcUnit, true) + GetHeroAgi(srcUnit, true) + GetHeroInt(srcUnit, true)) * formula.fullPros
        end
        if formula.primaryPros then
            value = value + HeroUtil:getHeroPrimaryValue(srcUnit, true) * formula.primaryPros
        end
        if formula.str then
            value = value + GetHeroStr(srcUnit, true) * formula.str
        end
        if formula.agi then
            value = value + GetHeroAgi(srcUnit, true) * formula.agi
        end
        if formula.int then
            value = value + GetHeroInt(srcUnit, true) * formula.int
        end
        if formula.hp then
            value = value + GetUnitState(srcUnit, UNIT_STATE_LIFE) * formula.hp
        end
        if formula.mana then
            value = value + GetUnitState(srcUnit, UNIT_STATE_MANA) * formula.mana
        end
        if formula.maxHp then
            value = value + GetUnitState(srcUnit, UNIT_STATE_MAX_LIFE) * formula.maxHp
        end
        if formula.maxMana then
            value = value + GetUnitState(srcUnit, UNIT_STATE_MAX_MANA) * formula.maxMana
        end
        if formula.loseHp then
            value = value + (GetUnitState(srcUnit, UNIT_STATE_MAX_LIFE) - GetUnitState(srcUnit, UNIT_STATE_LIFE)) * formula.loseHp
        end
        if formula.loseMana then
            value = value + (GetUnitState(srcUnit, UNIT_STATE_MAX_MANA) - GetUnitState(srcUnit, UNIT_STATE_MANA)) * formula.loseMana
        end
    end
    if targetUnit ~= nil then
        if formula.target_attack then
            value = value + GetUnitState(targetUnit, UnitStateDamageMax) * formula.target_attack
        end
        if formula.target_def then
            value = value + GetUnitState(targetUnit, UnitStateArmor) * formula.target_def
        end
        if formula.target_fullPros then
            value = value + (GetHeroStr(targetUnit, true) + GetHeroAgi(targetUnit, true) + GetHeroInt(targetUnit, true)) * formula.target_fullPros
        end
        if formula.target_primaryPros then
            value = value + HeroUtil:getHeroPrimaryValue(targetUnit, true) * formula.target_primaryPros
        end
        if formula.target_str then
            value = value + GetHeroStr(targetUnit, true) * formula.target_str
        end
        if formula.target_agi then
            value = value + GetHeroAgi(targetUnit, true) * formula.target_agi
        end
        if formula.target_int then
            value = value + GetHeroInt(targetUnit, true) * formula.target_int
        end
        if formula.target_hp then
            value = value + GetUnitState(targetUnit, UNIT_STATE_LIFE) * formula.target_hp
        end
        if formula.target_mana then
            value = value + GetUnitState(targetUnit, UNIT_STATE_MANA) * formula.target_mana
        end
        if formula.target_maxHp then
            value = value + GetUnitState(targetUnit, UNIT_STATE_MAX_LIFE) * formula.target_maxHp
        end
        if formula.target_maxMana then
            value = value + GetUnitState(targetUnit, UNIT_STATE_MAX_MANA) * formula.target_maxMana
        end
        if formula.target_loseHp then
            value = value + (GetUnitState(targetUnit, UNIT_STATE_MAX_LIFE) - GetUnitState(targetUnit, UNIT_STATE_LIFE)) * formula.target_loseHp
        end
        if formula.target_loseMana then
            value = value + (GetUnitState(targetUnit, UNIT_STATE_MAX_MANA) - GetUnitState(targetUnit, UNIT_STATE_MANA)) * formula.target_loseMana
        end
    end
    local player = GetOwningPlayer(srcUnit)
    if IsHandle(player) then
        if formula.gold then
            value = value + GetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD) * formula.gold
        end
        if formula.lumber then
            value = value + GetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER) * formula.lumber
        end
        if formula.food then
            value = value + GetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_USED) * formula.food
        end
        if formula.kills then
            local ____opt_2 = DataBase:getPlayerSolarData(player, false)
            value = value + (____opt_2 and ____opt_2.killCount or 0) * formula.kills
        end
    end
    if formula.increased then
        value = value * (1 + formula.increased)
    end
    return value
end
return ____exports
