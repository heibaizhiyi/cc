local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 3,["7"] = 3,["8"] = 4,["9"] = 4,["10"] = 5,["11"] = 5,["12"] = 6,["13"] = 6,["14"] = 11,["15"] = 11,["16"] = 11,["18"] = 11,["19"] = 17,["20"] = 18,["21"] = 17,["22"] = 25,["23"] = 26,["24"] = 26,["25"] = 25,["26"] = 32,["27"] = 33,["28"] = 34,["29"] = 35,["30"] = 36,["31"] = 37,["32"] = 38,["33"] = 39,["36"] = 34,["37"] = 43,["38"] = 32,["39"] = 49,["40"] = 50,["41"] = 51,["42"] = 52,["43"] = 53,["44"] = 54,["45"] = 55,["46"] = 56,["49"] = 51,["50"] = 60,["51"] = 61,["53"] = 63,["54"] = 49,["55"] = 70,["57"] = 71,["58"] = 71,["59"] = 72,["60"] = 73,["61"] = 74,["63"] = 71,["66"] = 70,["67"] = 83,["69"] = 84,["70"] = 84,["71"] = 85,["72"] = 86,["73"] = 87,["75"] = 84,["78"] = 83,["79"] = 101,["80"] = 101,["81"] = 101,["83"] = 101,["84"] = 101,["86"] = 101,["87"] = 101,["89"] = 102,["90"] = 102,["91"] = 102,["92"] = 102,["93"] = 102,["94"] = 102,["95"] = 102,["96"] = 101,["97"] = 114,["98"] = 114,["99"] = 114,["101"] = 114,["102"] = 114,["104"] = 114,["105"] = 114,["107"] = 114,["108"] = 114,["110"] = 115,["111"] = 115,["112"] = 115,["113"] = 115,["114"] = 115,["115"] = 115,["116"] = 115,["117"] = 114,["118"] = 123,["120"] = 124,["121"] = 124,["122"] = 125,["123"] = 126,["124"] = 127,["126"] = 124,["129"] = 123,["130"] = 138,["131"] = 139,["132"] = 138,["133"] = 147,["134"] = 148,["135"] = 147,["136"] = 156,["137"] = 157,["138"] = 156,["139"] = 165,["140"] = 166,["141"] = 165,["142"] = 175,["143"] = 176,["144"] = 176,["145"] = 176,["146"] = 176,["147"] = 176,["148"] = 175,["149"] = 184,["150"] = 185,["151"] = 186,["152"] = 186,["153"] = 186,["154"] = 186,["155"] = 187,["156"] = 188,["157"] = 184,["158"] = 195,["159"] = 196,["160"] = 195,["161"] = 203,["162"] = 204,["163"] = 203,["164"] = 211,["165"] = 212,["166"] = 211,["167"] = 220,["168"] = 221,["169"] = 220,["170"] = 228,["171"] = 229,["172"] = 228,["173"] = 236,["174"] = 237,["175"] = 236,["176"] = 246,["177"] = 247,["178"] = 246,["179"] = 254,["180"] = 255,["181"] = 254,["182"] = 264,["183"] = 265,["184"] = 264,["185"] = 274,["186"] = 275,["187"] = 276,["189"] = 278,["190"] = 279,["192"] = 281,["193"] = 274,["194"] = 290,["195"] = 291,["196"] = 292,["198"] = 294,["199"] = 295,["201"] = 297,["202"] = 298,["204"] = 300,["205"] = 301,["207"] = 303,["208"] = 290,["209"] = 310,["210"] = 311,["211"] = 310,["212"] = 317,["213"] = 318,["214"] = 317,["215"] = 324,["216"] = 325,["217"] = 324,["218"] = 335,["219"] = 336,["220"] = 337,["221"] = 338,["224"] = 341,["225"] = 335,["226"] = 349,["227"] = 350,["228"] = 351,["229"] = 352,["232"] = 355,["233"] = 349,["234"] = 363,["235"] = 363,["236"] = 364,["237"] = 365,["238"] = 366,["239"] = 367,["240"] = 368,["242"] = 363,["243"] = 373,["244"] = 374,["245"] = 373,["246"] = 378,["247"] = 379,["248"] = 378,["249"] = 386,["250"] = 387,["251"] = 388,["252"] = 389,["253"] = 390,["254"] = 391,["255"] = 392,["256"] = 393,["257"] = 394,["258"] = 395,["259"] = 396,["260"] = 397,["261"] = 398,["262"] = 399,["263"] = 400,["264"] = 401,["265"] = 402,["266"] = 403,["267"] = 404,["268"] = 386,["269"] = 412,["270"] = 415,["271"] = 415,["272"] = 415,["273"] = 416,["274"] = 415,["275"] = 415,["276"] = 412,["277"] = 424,["278"] = 425,["279"] = 426,["280"] = 426,["281"] = 426,["282"] = 426,["283"] = 426,["284"] = 431,["285"] = 424,["286"] = 439,["287"] = 440,["288"] = 441,["291"] = 444,["292"] = 445,["293"] = 445,["294"] = 445,["295"] = 446,["296"] = 447,["297"] = 448,["298"] = 448,["299"] = 448,["300"] = 449,["301"] = 448,["302"] = 448,["303"] = 451,["305"] = 453,["306"] = 454,["307"] = 455,["308"] = 456,["310"] = 458,["311"] = 445,["312"] = 445,["313"] = 439,["314"] = 463,["316"] = 464,["317"] = 464,["318"] = 465,["319"] = 466,["320"] = 467,["321"] = 468,["324"] = 464,["327"] = 473,["328"] = 463});
local ____exports = {}
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____player = require("solar.solar-common.w3ts.handles.player")
local MapPlayer = ____player.MapPlayer
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
____exports.default = __TS__Class()
local PlayerUtil = ____exports.default
PlayerUtil.name = "PlayerUtil"
function PlayerUtil.prototype.____constructor(self)
end
function PlayerUtil.setHero(self, player, hero)
    DataBase:getPlayerSolarData(player, true).hero = hero
end
function PlayerUtil.getHero(self, player)
    local ____opt_0 = DataBase:getPlayerSolarData(player, false)
    return ____opt_0 and ____opt_0.hero
end
function PlayerUtil.getAllPlayerHeroMaxLv(self)
    local nowHerosMaxLv = -1
    ____exports.default:forPlayingPlayers(function(____, player)
        local hero = ____exports.default:getHero(player)
        if IsHandle(hero) then
            local lv = GetHeroLevel(hero)
            if lv > nowHerosMaxLv then
                nowHerosMaxLv = lv
            end
        end
    end)
    return nowHerosMaxLv
end
function PlayerUtil.getAllPlayerHeroMinLv(self)
    local nowHerosMinLv = 2100000000
    ____exports.default:forPlayingPlayers(function(____, player)
        local hero = ____exports.default:getHero(player)
        if IsHandle(hero) then
            local lv = GetHeroLevel(hero)
            if lv < nowHerosMinLv then
                nowHerosMinLv = lv
            end
        end
    end)
    if nowHerosMinLv == 2100000000 then
        return nil
    end
    return nowHerosMinLv
end
function PlayerUtil.forPlayingPlayers(self, callback)
    do
        local i = 0
        while i < bj_MAX_PLAYER_SLOTS do
            local tempPlayer = Player(i)
            if GetPlayerSlotState(tempPlayer) == PLAYER_SLOT_STATE_PLAYING then
                callback(nil, tempPlayer)
            end
            i = i + 1
        end
    end
end
function PlayerUtil.forUsers(self, callback)
    do
        local i = 0
        while i < bj_MAX_PLAYER_SLOTS do
            local tempPlayer = Player(i)
            if GetPlayerController(tempPlayer) == MAP_CONTROL_USER and GetPlayerSlotState(tempPlayer) == PLAYER_SLOT_STATE_PLAYING then
                callback(nil, tempPlayer)
            end
            i = i + 1
        end
    end
end
function PlayerUtil.text(self, player, text, duration, x, y)
    if duration == nil then
        duration = 10
    end
    if x == nil then
        x = 0
    end
    if y == nil then
        y = 0
    end
    DisplayTimedTextToPlayer(
        player,
        x,
        y,
        duration,
        text
    )
end
function PlayerUtil.message(self, text, duration, player, x, y)
    if duration == nil then
        duration = 10
    end
    if player == nil then
        player = GetLocalPlayer()
    end
    if x == nil then
        x = 0
    end
    if y == nil then
        y = 0
    end
    DisplayTimedTextToPlayer(
        player,
        x,
        y,
        duration,
        text
    )
end
function PlayerUtil.firstOfUsers(self)
    do
        local i = 0
        while i < bj_MAX_PLAYER_SLOTS do
            local tempPlayer = Player(i)
            if GetPlayerController(tempPlayer) == MAP_CONTROL_USER and GetPlayerSlotState(tempPlayer) == PLAYER_SLOT_STATE_PLAYING then
                return tempPlayer
            end
            i = i + 1
        end
    end
end
function PlayerUtil.addGoldState(self, player, value)
    ____exports.default:addState(player, PLAYER_STATE_RESOURCE_GOLD, value)
end
function PlayerUtil.addLumberState(self, player, value)
    ____exports.default:addState(player, PLAYER_STATE_RESOURCE_LUMBER, value)
end
function PlayerUtil.addFoodCapState(self, player, value)
    ____exports.default:addState(player, PLAYER_STATE_RESOURCE_FOOD_CAP, value)
end
function PlayerUtil.addFoodUsedState(self, player, value)
    ____exports.default:addState(player, PLAYER_STATE_RESOURCE_FOOD_USED, value)
end
function PlayerUtil.addState(self, player, whichPlayerState, value)
    SetPlayerState(
        player,
        whichPlayerState,
        GetPlayerState(player, whichPlayerState) + value
    )
end
function PlayerUtil.getStartLoc(self, player)
    local loc = GetPlayerStartLocationLoc(player)
    local v = {
        x = GetLocationX(loc),
        y = GetLocationY(loc)
    }
    RemoveLocation(loc)
    return v
end
function PlayerUtil.getGold(self, player)
    return GetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD)
end
function PlayerUtil.setGold(self, player, gold)
    SetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD, gold)
end
function PlayerUtil.getLumber(self, player)
    return GetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER)
end
function PlayerUtil.setLumber(self, player, lumber)
    SetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER, lumber)
end
function PlayerUtil.getFoodCapLeft(self, player)
    return GetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_CAP) - GetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_USED)
end
function PlayerUtil.getFoodCap(self, player)
    return GetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_CAP)
end
function PlayerUtil.setFoodCap(self, player, foodCap)
    SetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_CAP, foodCap)
end
function PlayerUtil.getFoodUsed(self, player)
    return GetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_USED)
end
function PlayerUtil.setFoodUsed(self, player, foodUsed)
    SetPlayerState(player, PLAYER_STATE_RESOURCE_FOOD_USED, foodUsed)
end
function PlayerUtil.hasEnoughState(self, player, gold, lumber)
    if gold and gold > 0 and GetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD) < gold then
        return false
    end
    if lumber and lumber > 0 and GetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER) < lumber then
        return false
    end
    return true
end
function PlayerUtil.costEnoughState(self, player, gold, lumber)
    if gold and gold > 0 and GetPlayerState(player, PLAYER_STATE_RESOURCE_GOLD) < gold then
        return false
    end
    if lumber and lumber > 0 and GetPlayerState(player, PLAYER_STATE_RESOURCE_LUMBER) < lumber then
        return false
    end
    if gold then
        ____exports.default:addGoldState(player, -gold)
    end
    if lumber then
        ____exports.default:addLumberState(player, -lumber)
    end
    return true
end
function PlayerUtil.isOnlineUser(self, pid)
    return GetPlayerController(Player(pid)) == MAP_CONTROL_USER and GetPlayerSlotState(Player(pid)) == PLAYER_SLOT_STATE_PLAYING
end
function PlayerUtil.isUser(self, player)
    return GetPlayerController(player) == MAP_CONTROL_USER
end
function PlayerUtil.isComputer(self, player)
    return GetPlayerController(player) == MAP_CONTROL_COMPUTER
end
function PlayerUtil.hasAllUnitTypes(self, player, unitIds)
    for ____, unitId in ipairs(unitIds) do
        if GetPlayerTechCount(player, unitId, false) < 1 then
            return false
        end
    end
    return true
end
function PlayerUtil.hasUnitType(self, player, unitIds)
    for ____, unitId in ipairs(unitIds) do
        if GetPlayerTechCount(player, unitId, false) > 0 then
            return true
        end
    end
    return false
end
function PlayerUtil.allianceWithNeutralAggressive(self, ...)
    local playerIds = {...}
    local neutralAggressivePlayer = Player(PLAYER_NEUTRAL_AGGRESSIVE)
    for ____, playerId in ipairs(playerIds) do
        local player = Player(playerId)
        SetPlayerAlliance(player, neutralAggressivePlayer, ALLIANCE_PASSIVE, true)
        SetPlayerAlliance(neutralAggressivePlayer, player, ALLIANCE_PASSIVE, true)
    end
end
function PlayerUtil.neutralAggressivePlayer(self)
    return Player(PLAYER_NEUTRAL_AGGRESSIVE)
end
function PlayerUtil.neutralPassivePlayer(self)
    return Player(PLAYER_NEUTRAL_PASSIVE)
end
function PlayerUtil.getPlayerColorString(self, player)
    local playerColor = {}
    playerColor[1] = "|cFFFF0303"
    playerColor[2] = "|cFF0042FF"
    playerColor[3] = "|cFF1CE6B9"
    playerColor[4] = "|cFF540081"
    playerColor[5] = "|cFFFFFC01"
    playerColor[6] = "|cFFFE8A0E"
    playerColor[7] = "|cFF20C000"
    playerColor[8] = "|cFFE55BB0"
    playerColor[9] = "|cFF959697"
    playerColor[10] = "|cFF7EBFF1"
    playerColor[11] = "|cFF106246"
    playerColor[12] = "|cFF4E2A04"
    playerColor[13] = "|cFF282828"
    playerColor[14] = "|cFF282828"
    playerColor[15] = "|cFF282828"
    playerColor[16] = "|cFF282828"
    return playerColor[GetPlayerId(player) + 1]
end
function PlayerUtil.onSyncSelectedUnit(self, key, callBack)
    SyncUtil.onSyncObjData(
        "_sl_ssu" .. key,
        function(____, p, data)
            callBack(nil, p, data)
        end
    )
end
function PlayerUtil.syncSelectedUnit(self, key)
    local localSelectedUnit = selection()
    local data = {
        u = h2i(localSelectedUnit),
        x = DzGetMouseTerrainX(),
        y = DzGetMouseTerrainY()
    }
    SyncUtil.syncObjData("_sl_ssu" .. key, data)
end
function PlayerUtil.onUsersUidReady(self, callback)
    if GetUserId == nil then
        log.errorWithTraceBack("当前环境不支持使用此函数!")
        return
    end
    local gap = 0.05
    BaseUtil.onTimer(
        gap,
        function(____, count)
            if ____exports.default:_sl_isUsersUidReady() then
                print(("Uid同步完成:" .. tostring(gap * count)) .. "秒!")
                BaseUtil.runLater(
                    0.01,
                    function()
                        callback(nil)
                    end
                )
                return false
            end
            if count > 200 then
                BJDebugMsg("等待UID同步超时!请尝试重开游戏!")
                log.errorWithTraceBack("等待UID同步超时!")
                return false
            end
            return true
        end
    )
end
function PlayerUtil._sl_isUsersUidReady(self)
    do
        local i = 0
        while i < bj_MAX_PLAYER_SLOTS do
            local tempPlayer = Player(i)
            if GetPlayerController(tempPlayer) == MAP_CONTROL_USER and GetPlayerSlotState(tempPlayer) == PLAYER_SLOT_STATE_PLAYING then
                if MapPlayer:fromHandle(tempPlayer).userId == -1 then
                    return false
                end
            end
            i = i + 1
        end
    end
    return true
end
return ____exports
