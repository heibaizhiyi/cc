local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 1,["7"] = 1,["8"] = 2,["9"] = 2,["10"] = 3,["11"] = 3,["12"] = 13,["13"] = 13,["14"] = 13,["16"] = 13,["17"] = 25,["18"] = 26,["19"] = 27,["20"] = 28,["21"] = 29,["22"] = 30,["23"] = 31,["25"] = 33,["27"] = 35,["29"] = 25,["30"] = 42,["31"] = 43,["32"] = 44,["33"] = 45,["34"] = 46,["36"] = 48,["37"] = 49,["39"] = 51,["40"] = 43,["41"] = 42,["42"] = 60,["43"] = 61,["44"] = 62,["45"] = 60,["46"] = 70,["47"] = 71,["48"] = 72,["49"] = 73,["51"] = 75,["52"] = 70,["53"] = 84,["54"] = 84,["55"] = 84,["57"] = 85,["58"] = 86,["59"] = 87,["62"] = 90,["63"] = 91,["64"] = 95,["66"] = 97,["67"] = 98,["68"] = 84,["69"] = 106,["70"] = 106,["71"] = 106,["73"] = 107,["74"] = 107,["75"] = 106,["76"] = 115,["77"] = 115,["78"] = 115,["80"] = 116,["81"] = 117,["83"] = 119,["84"] = 119,["85"] = 115,["86"] = 127,["87"] = 127,["88"] = 127,["90"] = 128,["91"] = 129,["93"] = 131,["94"] = 131,["95"] = 127,["96"] = 20});
local ____exports = {}
local ____NumberUtil = require("solar.solar-common.util.math.NumberUtil")
local NumberUtil = ____NumberUtil.default
local ____ActorTypeUtil = require("solar.solar-common.actor.util.ActorTypeUtil")
local ActorTypeUtil = ____ActorTypeUtil.default
local ____AttributeUtil = require("solar.solar-common.util.system.AttributeUtil")
local AttributeUtil = ____AttributeUtil.default
____exports.default = __TS__Class()
local ShortIDUtil = ____exports.default
ShortIDUtil.name = "ShortIDUtil"
function ShortIDUtil.prototype.____constructor(self)
end
function ShortIDUtil.initAllAttributeKeyShortIDs()
    for key in pairs(AttributeUtil.keyInfos) do
        local keyInfo = AttributeUtil.keyInfos[key]
        local shortId = key
        if keyInfo.index == nil then
            print("keyInfo.index==null key=" .. key)
            shortId = ____exports.default.calculateShortId(key)
        else
            shortId = ____exports.default.calculateShortIdByIndexNumber(keyInfo.index)
        end
        ____exports.default.setFullIdAndShortIdMap(key, shortId, "属性key")
    end
end
function ShortIDUtil.initAllActorTypeShortIDs()
    ActorTypeUtil:forAllActorTypesAndLaterRegister(function(____, actorType)
        local shortId = actorType.shortId
        if actorType.shortIdindex then
            shortId = ____exports.default.calculateShortIdByIndexNumber(actorType.shortIdindex)
        end
        if shortId == nil then
            shortId = ____exports.default.calculateShortId(actorType.id)
        end
        ____exports.default.setFullIdAndShortIdMap(actorType.id, shortId)
    end)
end
function ShortIDUtil.calculateShortId(full_id)
    local stringHash = math.abs(StringHash(full_id))
    return NumberUtil.toUnsignedString(stringHash, 74)
end
function ShortIDUtil.calculateShortIdByIndexNumber(indexNumber, prefix)
    local ijz = NumberUtil.toUnsignedString(indexNumber, 86)
    if prefix then
        return (prefix .. ":") .. ijz
    end
    return ijz
end
function ShortIDUtil.setFullIdAndShortIdMap(full_id, shortId, clazz)
    if clazz == nil then
        clazz = "默认"
    end
    local clazzMap = ____exports.default.clazzMaps[clazz]
    if clazzMap and clazzMap.shortIdFullIdMap[shortId] then
        log.errorWithTraceBack((((((clazz .. "fullId2shortId映射冲突:[") .. clazzMap.shortIdFullIdMap[shortId]) .. "]和[") .. full_id) .. "]都映射到短id:") .. shortId)
        return
    end
    if not clazzMap then
        clazzMap = {fullIdShortIdMap = {}, shortIdFullIdMap = {}}
        ____exports.default.clazzMaps[clazz] = clazzMap
    end
    clazzMap.fullIdShortIdMap[full_id] = shortId
    clazzMap.shortIdFullIdMap[shortId] = full_id
end
function ShortIDUtil.hasFullIdAndShortIdMap(full_id, clazz)
    if clazz == nil then
        clazz = "默认"
    end
    local ____opt_2 = ____exports.default.clazzMaps[clazz]
    return (____opt_2 and ____opt_2.fullIdShortIdMap[full_id]) ~= nil
end
function ShortIDUtil.fullId2shortId(full_id, clazz)
    if clazz == nil then
        clazz = "默认"
    end
    if full_id == nil then
        return nil
    end
    local ____opt_4 = ____exports.default.clazzMaps[clazz]
    return ____opt_4 and ____opt_4.fullIdShortIdMap[full_id] or full_id
end
function ShortIDUtil.shortId2fullId(shortId, clazz)
    if clazz == nil then
        clazz = "默认"
    end
    if shortId == nil then
        return nil
    end
    local ____opt_6 = ____exports.default.clazzMaps[clazz]
    return ____opt_6 and ____opt_6.shortIdFullIdMap[shortId] or shortId
end
ShortIDUtil.clazzMaps = {}
return ____exports
