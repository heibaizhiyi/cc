local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 2,["8"] = 4,["9"] = 5,["10"] = 5,["11"] = 5,["13"] = 5,["14"] = 26,["15"] = 26,["16"] = 26,["18"] = 26,["19"] = 26,["21"] = 27,["22"] = 28,["24"] = 29,["25"] = 29,["26"] = 30,["27"] = 31,["28"] = 29,["31"] = 33,["32"] = 26,["33"] = 42,["34"] = 42,["35"] = 42,["37"] = 43,["38"] = 44,["41"] = 47,["42"] = 48,["43"] = 50,["44"] = 51,["45"] = 42,["46"] = 60,["47"] = 61,["48"] = 62,["49"] = 62,["50"] = 62,["51"] = 63,["52"] = 62,["53"] = 62,["54"] = 65,["55"] = 60,["56"] = 73,["57"] = 74,["58"] = 75,["59"] = 77,["61"] = 73,["62"] = 87,["63"] = 88,["64"] = 89,["65"] = 91,["67"] = 87,["68"] = 100,["69"] = 101,["70"] = 100,["71"] = 107,["72"] = 108,["73"] = 109,["76"] = 111,["77"] = 111,["78"] = 112,["79"] = 113,["80"] = 114,["82"] = 111,["85"] = 117,["86"] = 107,["87"] = 124,["88"] = 125,["89"] = 126,["91"] = 128,["92"] = 130,["94"] = 131,["95"] = 131,["96"] = 132,["97"] = 133,["98"] = 133,["100"] = 134,["101"] = 134,["103"] = 134,["104"] = 135,["105"] = 135,["106"] = 135,["107"] = 135,["109"] = 131,["112"] = 138,["114"] = 140,["115"] = 141,["117"] = 142,["118"] = 142,["119"] = 143,["120"] = 144,["121"] = 145,["122"] = 145,["123"] = 145,["124"] = 145,["126"] = 142,["129"] = 148,["131"] = 124,["132"] = 157,["133"] = 158,["134"] = 159,["137"] = 161,["138"] = 161,["139"] = 162,["140"] = 163,["141"] = 164,["143"] = 161,["146"] = 167,["147"] = 157,["148"] = 173,["149"] = 174,["150"] = 175,["151"] = 176,["154"] = 179,["155"] = 173,["156"] = 186,["158"] = 187,["159"] = 187,["160"] = 188,["161"] = 189,["162"] = 190,["164"] = 187,["167"] = 193,["168"] = 186,["169"] = 200,["170"] = 201,["172"] = 202,["173"] = 202,["174"] = 203,["175"] = 204,["176"] = 205,["178"] = 202,["181"] = 208,["182"] = 200,["183"] = 215,["184"] = 216,["186"] = 217,["187"] = 217,["188"] = 218,["189"] = 219,["190"] = 220,["192"] = 217,["195"] = 226,["196"] = 215,["197"] = 234,["198"] = 235,["200"] = 236,["201"] = 236,["203"] = 237,["204"] = 238,["205"] = 239,["207"] = 241,["208"] = 242,["209"] = 243,["210"] = 244,["212"] = 247,["213"] = 248,["214"] = 249,["216"] = 251,["219"] = 236,["222"] = 253,["223"] = 234,["224"] = 262,["225"] = 263,["226"] = 264,["228"] = 265,["229"] = 265,["231"] = 266,["232"] = 267,["233"] = 268,["235"] = 270,["236"] = 271,["237"] = 272,["239"] = 275,["240"] = 276,["241"] = 277,["243"] = 280,["244"] = 281,["245"] = 282,["246"] = 283,["247"] = 284,["248"] = 285,["252"] = 265,["255"] = 288,["256"] = 262,["257"] = 296,["258"] = 298,["259"] = 299,["260"] = 300,["261"] = 301,["262"] = 302,["263"] = 303,["264"] = 304,["266"] = 296,["267"] = 314,["268"] = 315,["269"] = 316,["270"] = 317,["272"] = 319,["273"] = 320,["274"] = 321,["276"] = 323,["277"] = 314,["278"] = 331,["279"] = 332,["281"] = 333,["282"] = 333,["283"] = 334,["284"] = 335,["285"] = 336,["287"] = 333,["290"] = 339,["291"] = 331,["292"] = 347,["294"] = 348,["295"] = 348,["296"] = 349,["297"] = 350,["298"] = 351,["300"] = 348,["303"] = 347,["304"] = 361,["306"] = 362,["307"] = 362,["308"] = 363,["309"] = 364,["310"] = 365,["311"] = 366,["313"] = 362,["316"] = 361,["317"] = 6,["318"] = 7,["319"] = 8,["320"] = 9,["321"] = 10,["322"] = 13,["323"] = 14,["326"] = 17,["328"] = 8});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local CJ = require("jass.common")
____exports.default = __TS__Class()
local ItemUtil = ____exports.default
ItemUtil.name = "ItemUtil"
function ItemUtil.prototype.____constructor(self)
end
function ItemUtil.createItems(self, itemid, x, y, count, owningPlayerId)
    if count == nil then
        count = 1
    end
    if owningPlayerId == nil then
        owningPlayerId = PLAYER_NEUTRAL_PASSIVE
    end
    local p = Player(owningPlayerId)
    local item = nil
    do
        local i = 0
        while i < count do
            item = CreateItem(itemid, x, y)
            SetItemPlayer(item, p, true)
            i = i + 1
        end
    end
    return item
end
function ItemUtil.forItemsInRect(self, r, callBack, onlyAlive)
    if onlyAlive == nil then
        onlyAlive = true
    end
    if ____exports.default._temp_callBack ~= nil then
        log.errorWithTraceBack("不能在此函数回调参数里 再使用此函数!")
        return
    end
    ____exports.default._temp_onlyAlive = onlyAlive
    ____exports.default._temp_callBack = callBack
    CJ.EnumItemsInRect(r, nil, ____exports.default._SL_EnumItemsInRectFunc)
    ____exports.default._temp_callBack = nil
end
function ItemUtil.getItemsInRect(self, r)
    local result = {}
    ____exports.default:forItemsInRect(
        r,
        function(item)
            result[#result + 1] = item
        end
    )
    return result
end
function ItemUtil.setItemTip(self, itemcode, value)
    EXSetItemDataString(itemcode, 4, value)
    if isEmbedJapi then
        EXSetItemDataString(itemcode, 2, value)
    end
end
function ItemUtil.setItemUbertip(self, itemcode, value)
    EXSetItemDataString(itemcode, 3, value)
    if isEmbedJapi then
        EXSetItemDataString(itemcode, 5, value)
    end
end
function ItemUtil.setItemArt(self, itemcode, value)
    EXSetItemDataString(itemcode, 1, value)
end
function ItemUtil.getItemOfTypeFromUnit(self, udw, otid)
    if type(otid) == "string" then
        otid = FourCC(otid)
    end
    do
        local index = 0
        while index < 6 do
            local item = UnitItemInSlot(udw, index)
            if GetItemTypeId(item) == otid then
                return item
            end
            index = index + 1
        end
    end
    return nil
end
function ItemUtil.getItemCountOfTypeFromUnit(self, udw, itemIdStr)
    if itemIdStr == nil then
        return 0
    end
    if DataBase:getSolarActorType(itemIdStr) then
        local count = 0
        do
            local index = 0
            while index < 6 do
                local item = UnitItemInSlot(udw, index)
                local ____opt_0 = DataBase:getItemSolarData(item, false)
                local actorItem = ____opt_0 and ____opt_0._SL_solarActorItem
                local ____opt_result_4
                if actorItem ~= nil then
                    ____opt_result_4 = actorItem.actorTypeId
                end
                if ____opt_result_4 == itemIdStr then
                    count = count + math.max(
                        GetItemCharges(item),
                        1
                    )
                end
                index = index + 1
            end
        end
        return count
    else
        local otid = FourCC(itemIdStr)
        local count = 0
        do
            local index = 0
            while index < 6 do
                local item = UnitItemInSlot(udw, index)
                if GetItemTypeId(item) == otid then
                    count = count + math.max(
                        GetItemCharges(item),
                        1
                    )
                end
                index = index + 1
            end
        end
        return count
    end
end
function ItemUtil.isUnitHasItem(self, udw, otid)
    if type(otid) == "string" then
        otid = FourCC(otid)
    end
    do
        local index = 0
        while index < 6 do
            local wpid = GetItemTypeId(UnitItemInSlot(udw, index))
            if wpid == otid then
                return true
            end
            index = index + 1
        end
    end
    return false
end
function ItemUtil.isUnitHasItems(self, udw, itAy)
    for ____, iterator in ipairs(itAy) do
        if not ____exports.default:isUnitHasItem(udw, iterator) then
            return false
        end
    end
    return true
end
function ItemUtil.getFirstItemFromUnit(self, unit)
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(unit, i)
            if IsHandle(item) then
                return item
            end
            i = i + 1
        end
    end
    return nil
end
function ItemUtil.getAllItemFromUnit(self, unit)
    local items = {}
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(unit, i)
            if IsHandle(item) then
                items[#items + 1] = item
            end
            i = i + 1
        end
    end
    return items
end
function ItemUtil.getAllItemInfoFromUnit(self, unit)
    local items = {}
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(unit, i)
            if IsHandle(item) then
                items[#items + 1] = {index = i, item = item}
            end
            i = i + 1
        end
    end
    return items
end
function ItemUtil.getItemAndChargesFromUnit(self, unit)
    local items = {}
    do
        local i = 0
        while i < 6 do
            do
                local item = UnitItemInSlot(unit, i)
                if not IsHandle(item) then
                    goto __continue53
                end
                local itemTypeStr = id2string(GetItemTypeId(item))
                local itemCharges = GetItemCharges(item)
                if not itemCharges or itemCharges < 1 then
                    itemCharges = 1
                end
                local oldCharges = items[itemTypeStr]
                if not oldCharges then
                    oldCharges = 0
                end
                items[itemTypeStr] = oldCharges + itemCharges
            end
            ::__continue53::
            i = i + 1
        end
    end
    return items
end
function ItemUtil.costItemChargesFromUnit(self, unit, itemId, charges)
    local costCharges = 0
    local needCostCharges = 0
    do
        local i = 0
        while i < 6 do
            do
                needCostCharges = charges - costCharges
                if costCharges >= charges then
                    return costCharges
                end
                local item = UnitItemInSlot(unit, i)
                if GetItemTypeId(item) ~= itemId then
                    goto __continue59
                end
                local itemCharges = GetItemCharges(item)
                if not itemCharges or itemCharges < 1 then
                    itemCharges = 1
                end
                if itemCharges <= needCostCharges then
                    costCharges = costCharges + itemCharges
                    RemoveItem(item)
                elseif itemCharges > needCostCharges then
                    costCharges = costCharges + needCostCharges
                    SetItemCharges(item, itemCharges - needCostCharges)
                end
            end
            ::__continue59::
            i = i + 1
        end
    end
    return costCharges
end
function ItemUtil.costItemCharges(self, item, needCostCharges)
    local itemCharges = GetItemCharges(item) or 1
    if itemCharges < needCostCharges then
        return false
    elseif itemCharges == needCostCharges then
        RemoveItem(item)
    elseif itemCharges > needCostCharges then
        SetItemCharges(item, itemCharges - needCostCharges)
    end
end
function ItemUtil.getItemSlotBySceneXY(self, sceneX, sceneY)
    local rX = math.floor((sceneX - 0.515) / 0.036)
    if rX < 0 or rX > 1 then
        return nil
    end
    local rY = 2 - math.floor((sceneY - 0.001) / 0.037)
    if rY < 0 or rY > 2 then
        return nil
    end
    return rY * 2 + rX
end
function ItemUtil.hasIdleItemGrid(self, unit)
    local inventorySize = UnitInventorySize(unit)
    do
        local i = 0
        while i < inventorySize do
            local item = UnitItemInSlot(unit, i)
            if not IsHandle(item) then
                return true
            end
            i = i + 1
        end
    end
    return false
end
function ItemUtil.removeUnitItems(self, unit)
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(unit, i)
            if IsHandle(item) then
                RemoveItem(item)
            end
            i = i + 1
        end
    end
end
function ItemUtil.transferItems(self, srcUnit, toUnit)
    do
        local i = 0
        while i < 6 do
            local item = UnitItemInSlot(srcUnit, i)
            if IsHandle(item) then
                UnitAddItem(toUnit, item)
                UnitDropItemSlot(toUnit, item, i)
            end
            i = i + 1
        end
    end
end
ItemUtil._temp_onlyAlive = true
ItemUtil._temp_callBack = nil
ItemUtil._SL_EnumItemsInRectFunc = function()
    local item = GetEnumItem()
    if ____exports.default._temp_onlyAlive then
        if GetWidgetLife(item) >= 1 and IsItemVisible(item) then
            ____exports.default._temp_callBack(item)
        end
    else
        ____exports.default._temp_callBack(item)
    end
end
return ____exports
