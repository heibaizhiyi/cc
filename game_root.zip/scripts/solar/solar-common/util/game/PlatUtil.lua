local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 5,["9"] = 5,["10"] = 6,["11"] = 6,["12"] = 7,["13"] = 7,["14"] = 11,["15"] = 11,["16"] = 11,["18"] = 11,["19"] = 20,["20"] = 21,["21"] = 20,["22"] = 30,["23"] = 31,["24"] = 30,["25"] = 41,["26"] = 42,["27"] = 41,["28"] = 49,["29"] = 50,["30"] = 49,["31"] = 57,["32"] = 58,["33"] = 57,["34"] = 65,["35"] = 66,["36"] = 65,["37"] = 73,["38"] = 74,["39"] = 73,["40"] = 81,["41"] = 82,["42"] = 81,["43"] = 89,["44"] = 90,["45"] = 89,["46"] = 101,["47"] = 102,["48"] = 101,["49"] = 109,["50"] = 110,["51"] = 109,["52"] = 119,["53"] = 120,["54"] = 121,["56"] = 123,["58"] = 119,["59"] = 135,["60"] = 136,["61"] = 137,["62"] = 137,["64"] = 139,["65"] = 135,["66"] = 148,["67"] = 149,["68"] = 150,["69"] = 150,["71"] = 152,["72"] = 148,["73"] = 162,["74"] = 163,["75"] = 164,["76"] = 164,["78"] = 166,["79"] = 166,["80"] = 166,["81"] = 166,["82"] = 166,["83"] = 162,["84"] = 175,["85"] = 176,["86"] = 177,["87"] = 177,["89"] = 179,["90"] = 175,["91"] = 189,["92"] = 190,["93"] = 191,["94"] = 192,["95"] = 193,["97"] = 195,["99"] = 197,["100"] = 199,["101"] = 200,["102"] = 189,["103"] = 207,["104"] = 208,["105"] = 208,["106"] = 208,["107"] = 208,["108"] = 207,["109"] = 215,["110"] = 216,["111"] = 215,["112"] = 223,["113"] = 226,["114"] = 223,["115"] = 232,["116"] = 233,["117"] = 233,["118"] = 233,["119"] = 233,["120"] = 233,["121"] = 233,["122"] = 233,["123"] = 233,["124"] = 233,["125"] = 233,["126"] = 232,["127"] = 241,["128"] = 242,["129"] = 242,["130"] = 242,["131"] = 242,["132"] = 242,["133"] = 242,["134"] = 242,["135"] = 242,["136"] = 242,["137"] = 242,["138"] = 241,["139"] = 250,["140"] = 251,["141"] = 251,["142"] = 251,["143"] = 251,["144"] = 251,["145"] = 251,["146"] = 251,["147"] = 251,["148"] = 251,["149"] = 251,["150"] = 250,["151"] = 260,["152"] = 261,["153"] = 261,["154"] = 261,["155"] = 261,["156"] = 261,["157"] = 261,["158"] = 261,["159"] = 261,["160"] = 261,["161"] = 261,["162"] = 260,["163"] = 270,["164"] = 271,["165"] = 271,["166"] = 271,["167"] = 271,["168"] = 271,["169"] = 271,["170"] = 271,["171"] = 271,["172"] = 271,["173"] = 271,["174"] = 270,["175"] = 283,["176"] = 284,["177"] = 284,["178"] = 284,["179"] = 284,["180"] = 284,["181"] = 284,["182"] = 284,["183"] = 284,["184"] = 284,["185"] = 284,["186"] = 283,["187"] = 294,["188"] = 295,["189"] = 295,["190"] = 295,["191"] = 295,["192"] = 295,["193"] = 295,["194"] = 295,["195"] = 295,["196"] = 295,["197"] = 295,["198"] = 294,["199"] = 303,["200"] = 304,["201"] = 304,["202"] = 304,["203"] = 304,["204"] = 304,["205"] = 304,["206"] = 304,["207"] = 304,["208"] = 304,["209"] = 304,["210"] = 303,["211"] = 312,["212"] = 313,["213"] = 313,["214"] = 313,["215"] = 313,["216"] = 313,["217"] = 313,["218"] = 313,["219"] = 313,["220"] = 313,["221"] = 313,["222"] = 312,["223"] = 321,["224"] = 322,["225"] = 322,["226"] = 322,["227"] = 322,["228"] = 322,["229"] = 322,["230"] = 322,["231"] = 322,["232"] = 322,["233"] = 322,["234"] = 321,["235"] = 331,["236"] = 332,["237"] = 332,["238"] = 332,["239"] = 332,["240"] = 332,["241"] = 332,["242"] = 332,["243"] = 332,["244"] = 332,["245"] = 332,["246"] = 331,["247"] = 347,["248"] = 348,["249"] = 349,["250"] = 349,["251"] = 349,["252"] = 350,["253"] = 351,["254"] = 352,["255"] = 353,["256"] = 354,["257"] = 355,["258"] = 355,["259"] = 355,["260"] = 355,["261"] = 355,["262"] = 355,["263"] = 355,["264"] = 356,["265"] = 357,["268"] = 349,["269"] = 349,["270"] = 349,["271"] = 361,["273"] = 363,["274"] = 364,["275"] = 365,["276"] = 366,["278"] = 368,["279"] = 368,["280"] = 368,["281"] = 369,["282"] = 369,["283"] = 369,["284"] = 369,["285"] = 369,["286"] = 369,["287"] = 369,["288"] = 369,["289"] = 368,["290"] = 368,["291"] = 368,["292"] = 347,["293"] = 379,["294"] = 380,["295"] = 380,["296"] = 380,["297"] = 380,["298"] = 380,["299"] = 380,["300"] = 380,["301"] = 380,["302"] = 380,["303"] = 380,["304"] = 379,["305"] = 388,["306"] = 389,["307"] = 390,["309"] = 392,["310"] = 388,["311"] = 13,["312"] = 336,["313"] = 340});
local ____exports = {}
local ____DataBase = require("solar.solar-common.common.DataBase")
local DataBase = ____DataBase.default
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local ____SolarTrigger = require("solar.solar-common.common.SolarTrigger")
local SolarTrigger = ____SolarTrigger.default
____exports.default = __TS__Class()
local PlatUtil = ____exports.default
PlatUtil.name = "PlatUtil"
function PlatUtil.prototype.____constructor(self)
end
function PlatUtil.hasMallItem(self, p, key)
    return DzAPI_Map_HasMallItem(p, key)
end
function PlatUtil.getMallItemCount(self, p, key)
    return DzAPI_Map_GetMallItemCount(p, key)
end
function PlatUtil.consumeMallItem(self, p, key, count)
    return DzAPI_Map_ConsumeMallItem(p, key, count)
end
function PlatUtil.getMapLevel(self, p)
    return DzAPI_Map_GetMapLevel(p)
end
function PlatUtil.continuousCount(self, p)
    return DzAPI_Map_ContinuousCount(p, 0)
end
function PlatUtil.getForumDataTotalLikes(self, p)
    return DzAPI_Map_GetForumData(p, 0)
end
function PlatUtil.getForumDataTotalSubject(self, p)
    return DzAPI_Map_GetForumData(p, 6)
end
function PlatUtil.isCollect(self, p)
    return DzAPI_Map_Returns(p, 16)
end
function PlatUtil.getGuildName(self, p)
    return DzAPI_Map_GetGuildName(p)
end
function PlatUtil.setStat(self, whichPlayer, key, value)
    DzAPI_Map_Stat_SetStat(whichPlayer, key, value)
end
function PlatUtil.mapsTotalPlayed(self, whichPlayer)
    return DzAPI_Map_MapsTotalPlayed(whichPlayer)
end
function PlatUtil.getLotteryUsedCount(self, whichPlayer, limitIndex)
    if limitIndex == nil then
        return DzAPI_Map_GetLotteryUsedCount(whichPlayer)
    else
        return DzAPI_Map_GetLotteryUsedCountEx(whichPlayer, limitIndex)
    end
end
function PlatUtil.storeStr(self, whichPlayer, key, value)
    if not __TS__ArrayIncludes(____exports.default.allArchiveKeys, key) then
        local ____exports_default_allArchiveKeys_0 = ____exports.default.allArchiveKeys
        ____exports_default_allArchiveKeys_0[#____exports_default_allArchiveKeys_0 + 1] = key
    end
    DzAPI_Map_SaveServerValue(whichPlayer, key, value)
end
function PlatUtil.getStoreStr(self, whichPlayer, key)
    if not __TS__ArrayIncludes(____exports.default.allArchiveKeys, key) then
        local ____exports_default_allArchiveKeys_1 = ____exports.default.allArchiveKeys
        ____exports_default_allArchiveKeys_1[#____exports_default_allArchiveKeys_1 + 1] = key
    end
    return DzAPI_Map_GetServerValue(whichPlayer, key)
end
function PlatUtil.storeInt(self, whichPlayer, key, value)
    if not __TS__ArrayIncludes(____exports.default.allArchiveKeys, key) then
        local ____exports_default_allArchiveKeys_2 = ____exports.default.allArchiveKeys
        ____exports_default_allArchiveKeys_2[#____exports_default_allArchiveKeys_2 + 1] = key
    end
    return DzAPI_Map_SaveServerValue(
        whichPlayer,
        key,
        I2S(value)
    )
end
function PlatUtil.getStoreInt(self, whichPlayer, key)
    if not __TS__ArrayIncludes(____exports.default.allArchiveKeys, key) then
        local ____exports_default_allArchiveKeys_3 = ____exports.default.allArchiveKeys
        ____exports_default_allArchiveKeys_3[#____exports_default_allArchiveKeys_3 + 1] = key
    end
    return S2I(DzAPI_Map_GetServerValue(whichPlayer, key))
end
function PlatUtil.addStoreInt(self, whichPlayer, key, addValue)
    local oldNum = 0
    local playerSolarData = DataBase:getPlayerSolarData(whichPlayer)
    if playerSolarData["_sl_addStoreInt:" .. key] then
        oldNum = playerSolarData["_sl_addStoreInt:" .. key]
    else
        oldNum = ____exports.default:getStoreInt(whichPlayer, key) or 0
    end
    local newNum = oldNum + addValue
    playerSolarData["_sl_addStoreInt:" .. key] = newNum
    return ____exports.default:storeInt(whichPlayer, key, newNum)
end
function PlatUtil.storeGlobalInt(self, key, val)
    return DzAPI_Map_Global_StoreString(
        key,
        tostring(val)
    )
end
function PlatUtil.getGlobalStoreInt(self, key)
    return S2I(____exports.default:getGlobalStoreString(key))
end
function PlatUtil.getGlobalStoreString(self, key)
    return DzAPI_Map_Global_GetStoreString(key) or DzAPI_Map_GetMapConfig(key)
end
function PlatUtil.getPlayerUserName(self, whichPlayer)
    return RequestExtraIntegerData(
        81,
        whichPlayer,
        nil,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.getCustomRank(self, whichPlayer, id)
    return RequestExtraIntegerData(
        52,
        whichPlayer,
        nil,
        nil,
        false,
        id,
        0,
        0
    )
end
function PlatUtil.getCustomRankCount(self, id)
    return RequestExtraIntegerData(
        78,
        nil,
        nil,
        nil,
        false,
        id,
        0,
        0
    )
end
function PlatUtil.getCustomRankPlayerName(self, id, ranking)
    return RequestExtraStringData(
        79,
        nil,
        nil,
        nil,
        false,
        id,
        ranking,
        0
    )
end
function PlatUtil.getCustomRankValue(self, id, ranking)
    return RequestExtraIntegerData(
        80,
        nil,
        nil,
        nil,
        false,
        id,
        ranking,
        0
    )
end
function PlatUtil.requestBackendLogic(self, whichPlayer, key, groupkey)
    return RequestExtraBooleanData(
        83,
        whichPlayer,
        key,
        groupkey,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.checkBackendLogicExists(self, whichPlayer, key)
    return RequestExtraBooleanData(
        84,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.getBackendLogicIntResult(self, whichPlayer, key)
    return RequestExtraIntegerData(
        85,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.getBackendLogicUpdateTime(self, whichPlayer, key)
    return RequestExtraIntegerData(
        87,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.getBackendLogicGroup(self, whichPlayer, key)
    return RequestExtraStringData(
        88,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.removeBackendLogicResult(self, whichPlayer, key)
    return RequestExtraBooleanData(
        89,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.onBackendLogicUpdateEvent(self, key, callBack)
    if ____exports.default._sl_onBackendLogicUpdateEvent_init then
        SyncUtil.onSyncData(
            "DZBLU",
            function(____, eventPlayer, eventKey)
                local callBacks = ____exports.default._sl_onBackendLogicUpdateEventCallBacks[eventKey]
                if callBacks then
                    local newRandomInt = ____exports.default:getBackendLogicIntResult(eventPlayer, eventKey)
                    local timeStamp = KKApiGetBackendLogicUpdateTime(eventPlayer, eventKey)
                    local groupKey = KKApiGetBackendLogicGroup(eventPlayer, eventKey)
                    local data = {
                        eventPlayer = eventPlayer,
                        newRandomInt = newRandomInt,
                        eventKey = eventKey,
                        groupKey = groupKey,
                        timeStamp = timeStamp
                    }
                    for ____, callBack in ipairs(callBacks) do
                        callBack:exec(data)
                    end
                end
            end,
            true
        )
        ____exports.default._sl_onBackendLogicUpdateEvent_init = false
    end
    local solarTriggerSet = ____exports.default._sl_onBackendLogicUpdateEventCallBacks[key]
    if solarTriggerSet == nil then
        solarTriggerSet = {}
        ____exports.default._sl_onBackendLogicUpdateEventCallBacks[key] = solarTriggerSet
    end
    return __TS__New(
        SolarTrigger,
        function(solarTrigger, data)
            callBack(
                nil,
                data.eventPlayer,
                data.newRandomInt,
                data.eventKey,
                data.groupKey,
                data.timeStamp
            )
        end,
        solarTriggerSet
    )
end
function PlatUtil.getServerValueLimitLeft(self, whichPlayer, key)
    return RequestExtraIntegerData(
        82,
        whichPlayer,
        key,
        nil,
        false,
        0,
        0,
        0
    )
end
function PlatUtil.getPlayerGUID(self, player)
    if KKApiPlayerGUID then
        return KKApiPlayerGUID(player)
    end
    return GetPlayerName(player)
end
PlatUtil.allArchiveKeys = {}
PlatUtil._sl_onBackendLogicUpdateEvent_init = true
PlatUtil._sl_onBackendLogicUpdateEventCallBacks = {}
return ____exports
