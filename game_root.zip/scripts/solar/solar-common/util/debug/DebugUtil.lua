local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 7,["21"] = 7,["22"] = 8,["23"] = 8,["24"] = 9,["25"] = 9,["26"] = 10,["27"] = 10,["28"] = 11,["29"] = 11,["30"] = 12,["31"] = 12,["32"] = 16,["33"] = 16,["34"] = 16,["36"] = 16,["37"] = 23,["38"] = 24,["41"] = 27,["42"] = 27,["43"] = 27,["44"] = 27,["45"] = 27,["46"] = 27,["47"] = 27,["48"] = 23,["49"] = 35,["50"] = 35,["51"] = 35,["53"] = 36,["54"] = 36,["55"] = 36,["56"] = 36,["57"] = 36,["58"] = 36,["59"] = 36,["60"] = 36,["61"] = 35,["62"] = 44,["63"] = 44,["64"] = 44,["66"] = 45,["69"] = 48,["70"] = 49,["71"] = 50,["72"] = 51,["73"] = 44,["74"] = 62,["75"] = 64,["76"] = 65,["77"] = 62,["78"] = 71,["79"] = 73,["80"] = 74,["81"] = 75,["82"] = 71,["83"] = 82,["84"] = 82,["85"] = 82,["87"] = 84,["88"] = 85,["89"] = 85,["90"] = 85,["91"] = 85,["92"] = 86,["93"] = 86,["94"] = 86,["95"] = 86,["96"] = 86,["97"] = 86,["98"] = 86,["99"] = 87,["100"] = 82,["101"] = 95,["102"] = 95,["103"] = 95,["105"] = 97,["106"] = 98,["107"] = 99,["108"] = 100,["109"] = 102,["110"] = 103,["111"] = 104,["112"] = 104,["113"] = 104,["114"] = 104,["115"] = 104,["116"] = 104,["117"] = 104,["118"] = 105,["119"] = 106,["120"] = 95,["121"] = 115,["122"] = 116,["123"] = 117,["124"] = 118,["125"] = 115,["126"] = 126,["127"] = 127,["128"] = 128,["129"] = 129,["130"] = 126,["131"] = 133,["132"] = 134,["133"] = 135,["134"] = 135,["135"] = 135,["136"] = 135,["137"] = 135,["138"] = 135,["139"] = 135,["140"] = 136,["141"] = 133,["142"] = 148,["143"] = 149,["144"] = 150,["146"] = 152,["147"] = 153,["149"] = 155,["150"] = 156,["151"] = 148,["152"] = 162,["154"] = 163,["155"] = 163,["156"] = 164,["157"] = 165,["160"] = 168,["161"] = 169,["162"] = 163,["165"] = 162,["166"] = 177,["167"] = 178,["168"] = 179,["169"] = 178,["170"] = 177,["171"] = 186,["172"] = 187,["173"] = 187,["174"] = 187,["175"] = 187,["176"] = 188,["177"] = 187,["178"] = 187,["179"] = 186,["180"] = 196,["181"] = 196,["182"] = 197,["183"] = 198,["184"] = 199,["185"] = 200,["187"] = 202,["190"] = 206,["191"] = 197,["192"] = 209,["193"] = 210,["194"] = 211,["196"] = 213,["198"] = 215,["199"] = 209,["200"] = 196,["201"] = 222,["202"] = 223,["203"] = 224,["206"] = 227,["207"] = 228,["208"] = 229,["209"] = 227,["210"] = 231,["211"] = 232,["212"] = 231,["213"] = 234,["214"] = 235,["215"] = 234,["216"] = 237,["217"] = 238,["218"] = 237,["219"] = 240,["220"] = 241,["221"] = 243,["223"] = 245,["224"] = 245,["225"] = 245,["226"] = 246,["227"] = 246,["228"] = 246,["229"] = 246,["230"] = 246,["231"] = 247,["232"] = 248,["233"] = 249,["234"] = 250,["235"] = 251,["236"] = 252,["237"] = 252,["238"] = 252,["239"] = 252,["240"] = 252,["241"] = 252,["242"] = 252,["243"] = 253,["244"] = 254,["247"] = 245,["248"] = 245,["249"] = 258,["250"] = 240,["251"] = 222,["252"] = 268,["253"] = 268,["254"] = 268,["256"] = 268,["257"] = 268,["259"] = 268,["260"] = 268,["262"] = 268,["263"] = 268,["265"] = 269,["266"] = 270,["267"] = 271,["268"] = 272,["269"] = 273,["270"] = 274,["272"] = 276,["273"] = 271,["275"] = 279,["276"] = 280,["277"] = 281,["278"] = 280,["279"] = 283,["280"] = 284,["281"] = 283,["283"] = 287,["284"] = 288,["285"] = 289,["286"] = 288,["288"] = 294,["289"] = 295,["290"] = 294,["291"] = 297,["292"] = 298,["293"] = 297,["294"] = 300,["295"] = 301,["296"] = 300,["297"] = 303,["298"] = 304,["299"] = 303,["300"] = 268,["301"] = 309,["302"] = 310,["303"] = 310,["304"] = 310,["305"] = 311,["306"] = 310,["307"] = 310,["308"] = 313,["309"] = 314,["310"] = 315,["311"] = 315,["312"] = 315,["313"] = 315,["314"] = 315,["315"] = 316,["316"] = 317,["317"] = 318,["318"] = 320,["319"] = 321,["320"] = 323,["321"] = 324,["322"] = 325,["323"] = 326,["325"] = 328,["326"] = 329,["327"] = 330,["328"] = 331,["329"] = 331,["330"] = 331,["331"] = 331,["332"] = 331,["333"] = 331,["334"] = 331,["335"] = 333,["336"] = 334,["337"] = 335,["338"] = 333,["339"] = 338,["340"] = 339,["341"] = 340,["342"] = 338,["343"] = 342,["344"] = 342,["345"] = 342,["346"] = 343,["347"] = 344,["348"] = 345,["349"] = 346,["350"] = 347,["351"] = 348,["353"] = 342,["354"] = 342,["355"] = 351,["356"] = 352,["357"] = 351,["358"] = 354,["359"] = 355,["360"] = 355,["361"] = 355,["362"] = 355,["363"] = 309,["364"] = 17,["365"] = 57,["366"] = 141});
local ____exports = {}
local ____trigger = require("solar.solar-common.w3ts.handles.trigger")
local Trigger = ____trigger.Trigger
local ____SelectUtil = require("solar.solar-common.util.unit.SelectUtil")
local SelectUtil = ____SelectUtil.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____unit = require("solar.solar-common.w3ts.handles.unit")
local Unit = ____unit.Unit
local ____ArchiveUtil = require("solar.solar-common.util.archive.ArchiveUtil")
local ArchiveUtil = ____ArchiveUtil.default
local ____InputUtil = require("solar.solar-common.util.system.InputUtil")
local InputUtil = ____InputUtil.default
local ____KeyCode = require("solar.solar-common.constant.KeyCode")
local KeyCode = ____KeyCode.default
local ____FramePoint = require("solar.solar-common.constant.FramePoint")
local FramePoint = ____FramePoint.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local ____PlatUtil = require("solar.solar-common.util.game.PlatUtil")
local PlatUtil = ____PlatUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
____exports.default = __TS__Class()
local DebugUtil = ____exports.default
DebugUtil.name = "DebugUtil"
function DebugUtil.prototype.____constructor(self)
end
function DebugUtil.showText(text)
    if ____exports.default.noDebug then
        return
    end
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        30,
        text
    )
end
function DebugUtil.createUnit(unitId)
    if unitId == nil then
        unitId = "Hamg"
    end
    return __TS__New(
        Unit,
        0,
        unitId,
        0,
        0,
        0
    )
end
function DebugUtil.showTexture(texFile, size)
    if size == nil then
        size = 0.04
    end
    if ____exports.default.noDebug then
        return
    end
    local frame = Frame:createBackDrop()
    frame:setSize(size, size)
    frame:setAbsPoint(4, 0.3, 0.3)
    frame:setTexture(texFile, 0)
end
function DebugUtil.refreshCodeExecStartTime()
    local o = os
    ____exports.default.codeExecStartTime = o.clock()
end
function DebugUtil.countCodeExecuteTime()
    local o = os
    local useTime = o.clock() - ____exports.default.codeExecStartTime
    return useTime
end
function DebugUtil.printCodeExecuteTime(title)
    if title == nil then
        title = "函数"
    end
    local stringTs = string
    local info = ((title .. "执行时间=") .. tostring(stringTs.format(
        "%.3f",
        ____exports.default.countCodeExecuteTime() * 1000
    ))) .. "毫秒"
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        20,
        info
    )
    print(info)
end
function DebugUtil.countExecuteTime(func, title)
    if title == nil then
        title = "函数"
    end
    local o = os
    local start = o.clock()
    func(nil)
    local useTime = o.clock() - start
    local stringTs = string
    local info = ((title .. "执行时间=") .. tostring(stringTs.format("%.3f", useTime * 1000))) .. "毫秒"
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        20,
        info
    )
    print(info)
    return useTime
end
function DebugUtil.onTime(time, actionFunc)
    local trigger = __TS__New(Trigger)
    trigger:registerTimerEvent(time, false)
    trigger:addAction(actionFunc)
end
function DebugUtil.onChat(char, actionFunc)
    local trigger = __TS__New(Trigger)
    trigger:registerAnyPlayerChatEvent(char, true)
    trigger:addAction(actionFunc)
end
function DebugUtil.onKeyEvent(key, actionFunc)
    local t = CreateTrigger()
    DzTriggerRegisterKeyEventByCode(
        t,
        key,
        1,
        true,
        nil
    )
    TriggerAddAction(t, actionFunc)
end
function DebugUtil.isLimitTime(key, time)
    if not ____exports.default.limitTimeCache[key] then
        ____exports.default.limitTimeCache[key] = 1
    end
    if ____exports.default.limitTimeCache[key] > time then
        return true
    end
    ____exports.default.limitTimeCache[key] = ____exports.default.limitTimeCache[key] + 1
    return false
end
function DebugUtil.printLocalVars()
    do
        local i = 1
        while i < 1000000 do
            local name, value = debug.getlocal(2, i)
            if not name then
                break
            end
            print(name .. " :")
            print_r(value)
            i = i + 1
        end
    end
end
function DebugUtil.removeAllUnits()
    SelectUtil.forAllUnits(function(____, unit)
        RemoveUnit(unit)
    end)
end
function DebugUtil.removeAllItems()
    EnumItemsInRect(
        bj_mapInitialPlayableArea,
        nil,
        function()
            RemoveItem(GetEnumItem())
        end
    )
end
function DebugUtil.openShop(...)
    local keys = {...}
    _G.DzAPI_Map_HasMallItem = function(whichPlayer, key)
        if keys then
            if __TS__ArrayIncludes(keys, key) then
                return true
            else
                return false
            end
        end
        return true
    end
    _G.DzAPI_Map_GetMallItemCount = function(whichPlayer, key)
        if __TS__ArrayIncludes(keys, key) then
            return 100
        else
            return 0
        end
        return 100
    end
end
function DebugUtil.startBackendLogicServer()
    if not isDebug then
        log.errorWithTraceBack("非测试环境不能调用此api。")
        return
    end
    PlatUtil.removeBackendLogicResult = function(____, whichPlayer, key)
        ArchiveUtil:set(whichPlayer, "_sldbug_rn_" .. key, nil)
        return true
    end
    PlatUtil.getBackendLogicIntResult = function(____, whichPlayer, key)
        return tonumber(ArchiveUtil:get(whichPlayer, "_sldbug_rn_" .. key)) or 0
    end
    PlatUtil.checkBackendLogicExists = function(____, whichPlayer, key)
        return ArchiveUtil:get(whichPlayer, "_sldbug_rn_" .. key) ~= nil
    end
    _G.KKApiRandomSaveGameCount = function(____, whichPlayer, groupkey)
        return 2100000000
    end
    PlatUtil.requestBackendLogic = function(____, whichPlayer, key, groupkey)
        if ArchiveUtil:get(whichPlayer, "_sldbug_rn_" .. key) then
            return false
        end
        BaseUtil.runLater(
            1.1,
            function()
                ArchiveUtil:set(
                    whichPlayer,
                    "_sldbug_rn_" .. key,
                    GetRandomInt(-200000000, 2000000000)
                )
                local callBacks = PlatUtil._sl_onBackendLogicUpdateEventCallBacks[key]
                if callBacks then
                    local newRandomInt = PlatUtil:getBackendLogicIntResult(whichPlayer, key)
                    local timeStamp = 0
                    local groupKey = "1"
                    local data = {
                        whichPlayer = whichPlayer,
                        newRandomInt = newRandomInt,
                        key = key,
                        groupKey = groupKey,
                        timeStamp = timeStamp
                    }
                    for ____, callBack in ipairs(callBacks) do
                        callBack:exec(data)
                    end
                end
            end
        )
        return true
    end
end
function DebugUtil.openShopArchiveMapLv(shop, Archive, mapLv, env)
    if shop == nil then
        shop = 0
    end
    if Archive == nil then
        Archive = 0
    end
    if mapLv == nil then
        mapLv = 0
    end
    if env == nil then
        env = _G
    end
    if Archive > 0 then
        local oldGet = ArchiveUtil.get
        ArchiveUtil.get = function(self, whichPlayer, key, mapLevelLimit)
            local val = oldGet(nil, whichPlayer, key, mapLevelLimit)
            if val == nil then
                val = Archive
            end
            return val
        end
    end
    if shop > 0 then
        env.DzAPI_Map_HasMallItem = function(whichPlayer, key)
            return true
        end
        env.DzAPI_Map_GetMallItemCount = function(whichPlayer, key)
            return shop
        end
    end
    if mapLv and mapLv > 0 then
        env.DzAPI_Map_GetMapLevel = function(whichPlayer)
            return mapLv
        end
    end
    env.DzAPI_Map_ContinuousCount = function(whichPlayer, id)
        return 100
    end
    env.DzAPI_Map_GetForumData = function(whichPlayer, id)
        return 100
    end
    env.DzAPI_Map_Returns = function(whichPlayer, id)
        return true
    end
    env.DzAPI_Map_GetGuildName = function(whichPlayer)
        return "太阳公会"
    end
end
function DebugUtil.numKeyFrame(num, name, callBack, info)
    SingletonUtil:executeOnce(
        "_sl_debug_test:numKeyFrame:tips",
        function()
            BJDebugMsg("按下键盘对应的数字可以执行测试示例!")
        end
    )
    local frame = Frame:createTEXTWithBorderBackDrop()
    local frameWidth = 0.06
    frame:setAbsPoint(
        FramePoint.topLeft,
        (frameWidth + 0.025) * ((num - 1) % 8) + 0.06,
        0.55 - 0.05 * math.floor((num - 1) / 8)
    )
    frame:setText((tostring(num) .. "、") .. name)
    frame:setFont(0.013)
    frame:setWidth(frameWidth)
    local button = Frame:createBUTTON(frame.current)
    button:setAllPoints(frame.current)
    local frameTip = Frame:createTEXTWithBorderBackDrop()
    local text = name
    if info then
        text = (text .. "|n|n") .. info
    end
    frameTip:setText(text)
    DzFrameShow(frameTip.current, false)
    DzFrameShow(frameTip.backdropFrame.handle, false)
    frameTip:setPoint(
        FramePoint.topLeft,
        frame.handle,
        FramePoint.bottom,
        0.02,
        -0.02
    )
    button:setOnMouseEnter(function()
        DzFrameShow(frameTip.current, true)
        DzFrameShow(frameTip.backdropFrame.handle, true)
    end)
    button:addOnMouseLeave(function()
        DzFrameShow(frameTip.current, false)
        DzFrameShow(frameTip.backdropFrame.handle, false)
    end)
    SyncUtil.onSyncData(
        "_sl_debug_test_:" .. tostring(num),
        function(____, t, d)
            callBack(nil, t)
            print("执行完毕:" .. name)
            BJDebugMsg("执行完毕:" .. name)
            if info then
                print(info)
                BJDebugMsg(info)
            end
        end
    )
    local function cb()
        SyncUtil.syncData("_sl_debug_test_:" .. tostring(num))
    end
    button:setOnClick(cb)
    InputUtil:onKeyPressed(
        KeyCode["VK_" .. tostring(num)],
        cb
    )
end
DebugUtil.noDebug = false
DebugUtil.codeExecStartTime = 0
DebugUtil.limitTimeCache = {}
return ____exports
