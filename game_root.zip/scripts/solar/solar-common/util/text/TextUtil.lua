local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__StringReplaceAll = ____lualib.__TS__StringReplaceAll
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["10"] = 13,["11"] = 13,["12"] = 13,["14"] = 13,["15"] = 30,["16"] = 31,["17"] = 31,["18"] = 31,["19"] = 31,["20"] = 31,["21"] = 31,["22"] = 31,["23"] = 31,["24"] = 31,["25"] = 31,["26"] = 31,["27"] = 31,["28"] = 32,["29"] = 32,["30"] = 32,["31"] = 32,["32"] = 32,["33"] = 32,["34"] = 32,["35"] = 32,["36"] = 32,["37"] = 32,["38"] = 32,["39"] = 33,["40"] = 34,["41"] = 35,["42"] = 36,["43"] = 37,["44"] = 38,["45"] = 39,["47"] = 41,["48"] = 42,["49"] = 43,["50"] = 44,["51"] = 45,["52"] = 46,["55"] = 49,["56"] = 50,["57"] = 51,["59"] = 53,["61"] = 55,["62"] = 56,["64"] = 58,["65"] = 59,["67"] = 61,["68"] = 30,["69"] = 71,["70"] = 71,["71"] = 71,["73"] = 71,["74"] = 71,["76"] = 72,["77"] = 73,["79"] = 74,["80"] = 75,["83"] = 78,["84"] = 79,["85"] = 74,["88"] = 81,["89"] = 82,["91"] = 84,["92"] = 85,["93"] = 86,["94"] = 87,["95"] = 88,["96"] = 89,["98"] = 91,["99"] = 92,["100"] = 93,["103"] = 96,["104"] = 71,["105"] = 104,["106"] = 104,["107"] = 104,["109"] = 105,["110"] = 106,["112"] = 108,["113"] = 109,["114"] = 110,["116"] = 112,["117"] = 113,["118"] = 114,["119"] = 115,["121"] = 117,["122"] = 104,["123"] = 126,["124"] = 126,["125"] = 126,["127"] = 127,["128"] = 128,["130"] = 130,["131"] = 131,["132"] = 132,["133"] = 133,["134"] = 134,["136"] = 136,["139"] = 140,["140"] = 141,["141"] = 142,["142"] = 144,["143"] = 145,["144"] = 146,["146"] = 148,["149"] = 151,["151"] = 126,["152"] = 160,["153"] = 161,["154"] = 162,["156"] = 164,["157"] = 165,["158"] = 166,["159"] = 166,["160"] = 166,["161"] = 166,["162"] = 166,["163"] = 167,["165"] = 169,["166"] = 170,["167"] = 170,["168"] = 170,["169"] = 170,["170"] = 170,["171"] = 171,["173"] = 173,["174"] = 174,["176"] = 160,["177"] = 178,["179"] = 179,["180"] = 179,["181"] = 180,["182"] = 179,["185"] = 182,["186"] = 178,["187"] = 185,["189"] = 186,["190"] = 186,["191"] = 187,["192"] = 186,["195"] = 189,["196"] = 185,["197"] = 197,["198"] = 197,["199"] = 197,["201"] = 198,["202"] = 199,["204"] = 201,["205"] = 202,["206"] = 203,["207"] = 204,["208"] = 205,["210"] = 206,["211"] = 207,["213"] = 209,["218"] = 212,["219"] = 197,["220"] = 222,["221"] = 222,["222"] = 223,["223"] = 224,["225"] = 226,["226"] = 227,["227"] = 228,["228"] = 228,["229"] = 228,["230"] = 228,["231"] = 228,["234"] = 231,["235"] = 232,["236"] = 232,["237"] = 232,["238"] = 232,["239"] = 232,["242"] = 235,["243"] = 222,["244"] = 14,["245"] = 16,["246"] = 16,["247"] = 16,["248"] = 16,["249"] = 16,["250"] = 16,["251"] = 16,["252"] = 16,["253"] = 16,["254"] = 16,["255"] = 16,["256"] = 16,["257"] = 16,["258"] = 16,["259"] = 16,["260"] = 16,["261"] = 16,["262"] = 16,["263"] = 16,["264"] = 16,["265"] = 16,["266"] = 16,["267"] = 16,["268"] = 16,["269"] = 16,["270"] = 16,["271"] = 16,["272"] = 16,["273"] = 14,["274"] = 18,["275"] = 18,["276"] = 18,["277"] = 18,["278"] = 18,["279"] = 18,["280"] = 18,["281"] = 18,["282"] = 18,["283"] = 18,["284"] = 18,["285"] = 18,["286"] = 18,["287"] = 18,["288"] = 18,["289"] = 18,["290"] = 18,["291"] = 18,["292"] = 18,["293"] = 18,["294"] = 18,["295"] = 18,["296"] = 18,["297"] = 18,["298"] = 18,["299"] = 18,["300"] = 18,["301"] = 18,["302"] = 14,["303"] = 20,["304"] = 20,["305"] = 20,["306"] = 20,["307"] = 20,["308"] = 20,["309"] = 20,["310"] = 20,["311"] = 20,["312"] = 20,["313"] = 20,["314"] = 20,["315"] = 20,["316"] = 20,["317"] = 20,["318"] = 20,["319"] = 20,["320"] = 20,["321"] = 20,["322"] = 20,["323"] = 14});
local ____exports = {}
____exports.default = __TS__Class()
local TextUtil = ____exports.default
TextUtil.name = "TextUtil"
function TextUtil.prototype.____constructor(self)
end
function TextUtil.toCn(self, digit)
    local chnNum = {
        "零",
        "一",
        "二",
        "三",
        "四",
        "五",
        "六",
        "七",
        "八",
        "九"
    }
    local chnNumUnit = {
        "",
        "十",
        "百",
        "千",
        "万",
        "十",
        "百",
        "千",
        "亿"
    }
    local tmp = ""
    local chnString = ""
    local zero = true
    local unitIndex = 0
    local isTen = false
    if digit > 9 and digit < 20 then
        isTen = true
    end
    while digit > 0 do
        local num = digit % 10
        if num == 0 then
            if not zero then
                zero = true
                chnString = chnNum[num + 1] .. chnString
            end
        else
            zero = false
            if isTen and unitIndex == 1 then
                tmp = ""
            else
                tmp = chnNum[num + 1]
            end
            tmp = tmp .. chnNumUnit[unitIndex + 1]
            chnString = tmp .. chnString
        end
        unitIndex = unitIndex + 1
        digit = math.floor(digit / 10)
    end
    return chnString
end
function TextUtil.toCnUnit(self, num, keepDecimalPoint, maxDigit)
    if keepDecimalPoint == nil then
        keepDecimalPoint = true
    end
    if maxDigit == nil then
        maxDigit = 4
    end
    local cnUnit = ""
    local index = 0
    do
        while index < #____exports.default.config.cnUnit do
            if math.abs(num) < 10000 then
                break
            end
            num = num / 10000
            cnUnit = ____exports.default.config.cnUnit[index + 1]
            index = index + 1
        end
    end
    if not keepDecimalPoint then
        num = math.floor(num)
    else
        local numStr = tostring(num) .. ""
        local indexOf = (string.find(numStr, ".", nil, true) or 0) - 1
        if indexOf < maxDigit then
            numStr = __TS__StringSubstring(numStr, 0, maxDigit + 1)
            if __TS__StringEndsWith(numStr, ".000") or __TS__StringEndsWith(numStr, ".00") or __TS__StringEndsWith(numStr, ".0") then
                numStr = __TS__StringSubstring(numStr, 0, indexOf)
            end
            return numStr .. cnUnit
        elseif indexOf == maxDigit then
            num = math.floor(num)
        end
    end
    return tostring(num) .. cnUnit
end
function TextUtil.toPercentage(self, num, decimalPrecision)
    if decimalPrecision == nil then
        decimalPrecision = 0
    end
    if num == nil then
        return "0%"
    end
    num = num * 100
    if decimalPrecision == 0 then
        return tostring(math.floor(num)) .. "%"
    end
    local percentageStr = tostring(num) .. ""
    local pointIndex = (string.find(percentageStr, ".", nil, true) or 0) - 1
    if pointIndex >= 0 and #percentageStr - pointIndex > decimalPrecision then
        return __TS__StringSubstring(percentageStr, 0, pointIndex + decimalPrecision + 1) .. "%"
    end
    return percentageStr .. "%"
end
function TextUtil.secondsToHMS(self, seconds, showSecondsMax)
    if showSecondsMax == nil then
        showSecondsMax = 300
    end
    if seconds <= showSecondsMax then
        return tostring(seconds) .. "秒"
    end
    if seconds < 3600 then
        local minutes = math.floor(seconds / 60)
        local secs = math.floor(seconds % 60)
        if secs == 0 then
            return tostring(minutes) .. "分"
        else
            return ((tostring(minutes) .. "分") .. tostring(secs)) .. "秒"
        end
    end
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor(seconds % 3600 / 60)
    local secs = math.floor(seconds % 60)
    if secs == 0 then
        if minutes == 0 then
            return tostring(hours) .. "小时"
        else
            return ((tostring(hours) .. "小时") .. tostring(minutes)) .. "分"
        end
    else
        return ((((tostring(hours) .. "小时") .. tostring(minutes)) .. "分") .. tostring(secs)) .. "秒"
    end
end
function TextUtil.removeColors(self, value)
    if value == nil then
        return value
    else
        local color
        while (string.find(value, "|c", nil, true) or 0) - 1 >= 0 do
            color = __TS__StringSubstring(
                value,
                (string.find(value, "|c", nil, true) or 0) - 1,
                (string.find(value, "|c", nil, true) or 0) - 1 + 10
            )
            value = __TS__StringReplaceAll(value, color, "")
        end
        while (string.find(value, "|C", nil, true) or 0) - 1 >= 0 do
            color = __TS__StringSubstring(
                value,
                (string.find(value, "|C", nil, true) or 0) - 1,
                (string.find(value, "|C", nil, true) or 0) - 1 + 10
            )
            value = __TS__StringReplaceAll(value, color, "")
        end
        value = __TS__StringReplaceAll(value, "|r", "")
        return value
    end
end
function TextUtil.leftPad(self, value, totalLength, pad)
    do
        local i = totalLength - #value
        while i > 0 do
            value = pad .. value
            i = i - 1
        end
    end
    return value
end
function TextUtil.rightPad(self, value, totalLength, pad)
    do
        local i = totalLength - #value
        while i > 0 do
            value = value .. pad
            i = i - 1
        end
    end
    return value
end
function TextUtil.splitLines(self, text, removeEmptyLines)
    if removeEmptyLines == nil then
        removeEmptyLines = false
    end
    if text == nil then
        return nil
    end
    local result = {}
    local tempLines1 = __TS__StringSplit(text, "|n")
    for ____, tempLine in ipairs(tempLines1) do
        local lines = __TS__StringSplit(tempLine, "\n")
        for ____, line in ipairs(lines) do
            do
                if removeEmptyLines and (line == nil or #line == 0) then
                    goto __continue47
                end
                result[#result + 1] = line
            end
            ::__continue47::
        end
    end
    return result
end
function TextUtil.replaceELParams(self, text, params, ...)
    local keys = {...}
    if text == nil or params == nil then
        return text
    end
    if keys == nil or #keys == 0 then
        for paramsKey in pairs(params) do
            text = __TS__StringReplaceAll(
                text,
                ("${" .. paramsKey) .. "}",
                tostring(params[paramsKey])
            )
        end
    else
        for ____, key in ipairs(keys) do
            text = __TS__StringReplaceAll(
                text,
                ("${" .. key) .. "}",
                tostring(params[key])
            )
        end
    end
    return text
end
TextUtil.config = {cnUnit = {
    "万",
    "亿",
    "兆",
    "京",
    "垓",
    "秭",
    "穰",
    "沟",
    "涧",
    "正",
    "载",
    "极",
    "恒",
    "阿",
    "那",
    "不",
    "大",
    "万大",
    "亿大",
    "兆大",
    "京大",
    "垓大",
    "秭大",
    "穰大",
    "沟大",
    "涧大",
    "正大",
    "载大"
}, cnUnit2 = {
    "万",
    "亿",
    "兆",
    "京",
    "垓E",
    "秭F",
    "穰G",
    "沟F",
    "涧G",
    "正H",
    "载I",
    "极J",
    "恒K",
    "阿L",
    "那M",
    "N",
    "大O",
    "万大P",
    "亿大Q",
    "兆大R",
    "京大S",
    "垓大T",
    "秭大U",
    "穰大V",
    "沟大W",
    "涧大X",
    "正大Y",
    "载大Z"
}, cnUnit3 = {
    "万",
    "亿",
    "兆",
    "京",
    "五",
    "六",
    "七",
    "八",
    "九",
    "十",
    "十一",
    "十二",
    "十三",
    "十四",
    "十五",
    "十六",
    "十七",
    "十八",
    "十九",
    "二十"
}}
return ____exports
