local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 1,["9"] = 1,["10"] = 2,["11"] = 2,["12"] = 3,["13"] = 3,["14"] = 4,["15"] = 4,["16"] = 5,["17"] = 5,["18"] = 6,["19"] = 6,["20"] = 6,["21"] = 7,["22"] = 7,["23"] = 8,["24"] = 8,["25"] = 9,["26"] = 9,["27"] = 10,["28"] = 10,["29"] = 11,["30"] = 11,["31"] = 12,["32"] = 12,["33"] = 13,["34"] = 13,["35"] = 14,["36"] = 14,["37"] = 15,["38"] = 15,["39"] = 16,["40"] = 16,["41"] = 17,["42"] = 17,["43"] = 18,["44"] = 18,["45"] = 19,["46"] = 19,["47"] = 20,["48"] = 20,["49"] = 21,["50"] = 21,["51"] = 22,["52"] = 22,["53"] = 25,["54"] = 25,["55"] = 25,["57"] = 28,["58"] = 29,["59"] = 30,["60"] = 31,["61"] = 32,["62"] = 32,["63"] = 32,["64"] = 33,["65"] = 32,["66"] = 32,["67"] = 35,["68"] = 35,["69"] = 35,["70"] = 36,["71"] = 35,["72"] = 35,["73"] = 38,["74"] = 38,["75"] = 38,["76"] = 39,["77"] = 40,["78"] = 41,["79"] = 41,["80"] = 41,["81"] = 42,["82"] = 41,["83"] = 41,["84"] = 40,["85"] = 45,["86"] = 45,["87"] = 45,["88"] = 46,["89"] = 45,["90"] = 45,["91"] = 49,["92"] = 51,["93"] = 49,["94"] = 53,["95"] = 55,["96"] = 53,["97"] = 57,["98"] = 58,["99"] = 57,["100"] = 38,["101"] = 38,["102"] = 63,["103"] = 65,["104"] = 65,["105"] = 66,["108"] = 70,["109"] = 71,["110"] = 72,["112"] = 74,["113"] = 74,["114"] = 74,["115"] = 74,["116"] = 74,["117"] = 74,["118"] = 74,["119"] = 65,["121"] = 27,["122"] = 80,["123"] = 81,["124"] = 82,["125"] = 80,["126"] = 86,["127"] = 87,["128"] = 88,["129"] = 87,["130"] = 90,["131"] = 91,["132"] = 92,["133"] = 90,["134"] = 94,["135"] = 94,["136"] = 94,["137"] = 95,["138"] = 94,["139"] = 94,["140"] = 86,["141"] = 103,["142"] = 104,["143"] = 104,["144"] = 104,["145"] = 105,["146"] = 106,["147"] = 106,["148"] = 106,["149"] = 106,["150"] = 106,["151"] = 106,["152"] = 106,["153"] = 106,["154"] = 107,["155"] = 107,["156"] = 107,["157"] = 107,["158"] = 107,["159"] = 107,["160"] = 107,["161"] = 107,["162"] = 108,["163"] = 109,["164"] = 110,["165"] = 104,["166"] = 104,["167"] = 114,["168"] = 116,["169"] = 116,["170"] = 116,["171"] = 117,["172"] = 116,["173"] = 116,["174"] = 120,["175"] = 122,["176"] = 122,["177"] = 122,["178"] = 123,["179"] = 123,["180"] = 123,["181"] = 124,["182"] = 125,["183"] = 123,["184"] = 123,["185"] = 128,["186"] = 128,["187"] = 128,["188"] = 129,["189"] = 130,["190"] = 128,["191"] = 128,["192"] = 122,["193"] = 122,["194"] = 103,["195"] = 135,["196"] = 136,["197"] = 136,["198"] = 136,["199"] = 137,["200"] = 138,["201"] = 138,["202"] = 138,["203"] = 138,["204"] = 138,["205"] = 138,["206"] = 138,["207"] = 138,["208"] = 139,["209"] = 139,["210"] = 139,["211"] = 140,["212"] = 142,["213"] = 143,["214"] = 144,["216"] = 146,["217"] = 147,["219"] = 149,["220"] = 150,["221"] = 151,["222"] = 152,["223"] = 153,["224"] = 155,["225"] = 156,["226"] = 157,["227"] = 157,["228"] = 157,["229"] = 157,["230"] = 162,["231"] = 162,["232"] = 162,["233"] = 162,["234"] = 162,["235"] = 162,["236"] = 162,["237"] = 162,["238"] = 162,["239"] = 162,["240"] = 162,["241"] = 162,["242"] = 174,["243"] = 175,["244"] = 157,["245"] = 178,["246"] = 179,["247"] = 139,["248"] = 139,["249"] = 136,["250"] = 136,["251"] = 135,["252"] = 185,["253"] = 186,["254"] = 187,["255"] = 188,["256"] = 189,["257"] = 190,["258"] = 191,["259"] = 192,["260"] = 192,["261"] = 192,["262"] = 192,["263"] = 192,["264"] = 192,["265"] = 192,["266"] = 191,["267"] = 196,["268"] = 196,["269"] = 196,["270"] = 197,["271"] = 197,["272"] = 197,["273"] = 197,["274"] = 197,["275"] = 197,["276"] = 197,["277"] = 196,["278"] = 196,["279"] = 200,["280"] = 201,["281"] = 200,["282"] = 185,["283"] = 206,["284"] = 207,["285"] = 208,["286"] = 209,["287"] = 210,["288"] = 211,["289"] = 212,["290"] = 214,["291"] = 215,["292"] = 215,["293"] = 215,["294"] = 215,["295"] = 215,["296"] = 215,["297"] = 215,["298"] = 209,["299"] = 217,["300"] = 218,["301"] = 219,["302"] = 220,["303"] = 221,["304"] = 224,["305"] = 218,["306"] = 206,["307"] = 228,["308"] = 231,["309"] = 232,["310"] = 232,["311"] = 232,["312"] = 232,["313"] = 233,["314"] = 234,["315"] = 234,["316"] = 234,["317"] = 234,["318"] = 234,["319"] = 234,["320"] = 234,["321"] = 235,["322"] = 235,["323"] = 235,["324"] = 235,["325"] = 235,["326"] = 236,["327"] = 236,["328"] = 236,["329"] = 235,["330"] = 235,["332"] = 238,["333"] = 238,["334"] = 238,["335"] = 238,["336"] = 238,["337"] = 240,["338"] = 240,["339"] = 240,["340"] = 240,["341"] = 240,["343"] = 228,["344"] = 246,["345"] = 247,["346"] = 247,["347"] = 247,["348"] = 249,["349"] = 250,["350"] = 252,["351"] = 253,["352"] = 254,["353"] = 255,["354"] = 256,["355"] = 257,["356"] = 247,["357"] = 247,["358"] = 246});
local ____exports = {}
local ____DebugUtil = require("solar.solar-common.util.debug.DebugUtil")
local DebugUtil = ____DebugUtil.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____unit = require("solar.solar-common.w3ts.handles.unit")
local Unit = ____unit.Unit
local ____Gui = require("Gui")
local Gui = ____Gui.default
local ____Log = require("solar.solar-wc3.common.Log")
local Log = ____Log.default
local ____tween = require("solar.solar-common.lib.tween.index")
local Easing = ____tween.Easing
local Tween = ____tween.Tween
local ____SyncUtil = require("solar.solar-common.util.net.SyncUtil")
local SyncUtil = ____SyncUtil.default
local ____frame = require("solar.solar-common.w3ts.handles.frame")
local Frame = ____frame.Frame
local ____ArchiveUtil = require("solar.solar-common.util.archive.ArchiveUtil")
local ArchiveUtil = ____ArchiveUtil.default
local ____AsyncUtil = require("solar.solar-common.util.net.AsyncUtil")
local AsyncUtil = ____AsyncUtil.default
local ____CameraUtil = require("solar.solar-common.util.game.CameraUtil")
local CameraUtil = ____CameraUtil.default
local ____InterpolationUtil = require("solar.solar-common.util.math.InterpolationUtil")
local InterpolationUtil = ____InterpolationUtil.default
local ____Vector3 = require("solar.solar-common.lib.mod.Vector3")
local Vector3 = ____Vector3.default
local ____SolarDamageState = require("solar.solar-common.attribute.SolarDamageState")
local SolarDamageState = ____SolarDamageState.default
local ____TextTagUtil = require("solar.solar-common.util.text.TextTagUtil")
local TextTagUtil = ____TextTagUtil.default
local ____DebugCheckSyncUtil = require("solar.solar-wc3.util.debug.DebugCheckSyncUtil")
local DebugCheckSyncUtil = ____DebugCheckSyncUtil.default
local ____GameUtil = require("solar.solar-common.util.game.GameUtil")
local GameUtil = ____GameUtil.default
local ____YiYiApiJassImpl = require("solar.solar-wc3.lib.compatible.yiyi.YiYiApiJassImpl")
local YiYiApiJassImpl = ____YiYiApiJassImpl.default
local ____FrameCallbackUtil = require("solar.solar-common.util.frame.FrameCallbackUtil")
local FrameCallbackUtil = ____FrameCallbackUtil.default
local ____SingletonUtil = require("solar.solar-common.util.lang.SingletonUtil")
local SingletonUtil = ____SingletonUtil.default
local ____InputUtil = require("solar.solar-common.util.system.InputUtil")
local InputUtil = ____InputUtil.default
local ____KeyCode = require("solar.solar-common.constant.KeyCode")
local KeyCode = ____KeyCode.default
____exports.default = __TS__Class()
local AppTest = ____exports.default
AppTest.name = "AppTest"
function AppTest.prototype.____constructor(self)
    if isDebug then
        GameUtil:openFullMapView()
        Cheat("greedisgood 100000")
        Cheat("warpten")
        se:onPlayerChat(
            "se",
            function()
                self:seTest()
            end
        )
        se:onPlayerChat(
            "cs",
            function()
                DebugCheckSyncUtil.start()
            end
        )
        se:onPlayerChat(
            "t11",
            function()
                YiYiApiJassImpl.init()
                FrameCallbackUtil:addFrameSetUpdateCallback(function()
                    SingletonUtil:executeOnce(
                        "1",
                        function()
                            print("on addFrameSetUpdateCallback")
                        end
                    )
                end)
                InputUtil:onKeyPressed(
                    KeyCode.VK_D,
                    function()
                        print("d 建 按下" .. tostring(DzGetTriggerKey()))
                    end
                )
                InputUtil:onMouseLeftButtonPressed(function()
                    print("左键点击" .. tostring(DzGetTriggerKey()))
                end)
                InputUtil:onMouseRightButtonPressed(function()
                    print("右键点击" .. tostring(DzGetTriggerKey()))
                end)
                InputUtil:onMouseMoveEvent(function()
                    print("onMouseMoveEvent x:" .. tostring(DzGetMouseXRelative()))
                end)
            end
        )
        self:solarTest()
        local ____SolarDamageState_config_damageEventHandlers_0 = SolarDamageState.config.damageEventHandlers
        ____SolarDamageState_config_damageEventHandlers_0[#____SolarDamageState_config_damageEventHandlers_0 + 1] = function(____, event)
            if not event.isCritical then
                return
            end
            local tag = "暴击:"
            if not event.isPhysical then
                tag = "法术" .. tag
            end
            TextTagUtil.text(
                tag .. tostring(math.floor(event.resultDamage)),
                event.unit0,
                8,
                2,
                200
            )
        end
    end
end
function AppTest.prototype.onUnitAttacked(self, triggerUnit, attacker)
    BJDebugMsg("触发单位=" .. GetUnitName(triggerUnit))
    BJDebugMsg("攻击单位=" .. GetUnitName(attacker))
end
function AppTest.prototype.seTest(self)
    se:unitAttacked(function(...)
        self:onUnitAttacked(...)
    end)
    se:unitAttacked(function(triggerUnit, attacker)
        BJDebugMsg("被攻击单位2222=" .. GetUnitName(triggerUnit))
        BJDebugMsg("攻击单位2222=" .. GetUnitName(attacker))
    end)
    se:onEnterRect(
        nil,
        function(e)
            BJDebugMsg("进入区域了=" .. GetUnitName(e.trigUnit))
        end
    )
end
function AppTest.prototype.solarTest(self)
    se:onPlayerChat(
        "1",
        function()
            DebugUtil.showText(tostring(BaseUtil.getGameTime()) .. "")
            local unit = __TS__New(
                Unit,
                0,
                "hpea",
                0,
                0,
                0
            )
            SetUnitState(
                unit.handle,
                ConvertUnitState(18),
                500 + GetUnitState(
                    GetTriggerUnit(),
                    ConvertUnitState(18)
                ) * 100
            )
            print_r(handledef(unit.handle).reference)
            DebugUtil.printLocalVars()
            self:uiTest()
        end
    )
    self:httpJsonTest()
    DebugUtil.onChat(
        "2",
        function()
            self:archiveTest()
        end
    )
    self:w2sTest()
    DebugUtil.onChat(
        "4",
        function()
            local sTimer = BaseUtil.onTimer(
                1,
                function(____, c)
                    BJDebugMsg("太阳计时器循环执行:" .. tostring(c))
                    return true
                end
            )
            BaseUtil.runLater(
                5,
                function()
                    BJDebugMsg("手动关闭太阳计时器循环执行:" .. tostring(sTimer))
                    sTimer:destroy()
                end
            )
        end
    )
end
function AppTest.prototype.w2sTest(self)
    se:onPlayerChat(
        "3",
        function()
            DebugUtil.showText(tostring(BaseUtil.getGameTime()) .. "测试世界坐标转屏幕坐标")
            local unit = __TS__New(
                Unit,
                0,
                "Hamg",
                0,
                0,
                0
            )
            BaseUtil.onTimer(
                0.05,
                function(____, c)
                    local screenCoordinates = CameraUtil:getScreenCoordinates(unit.x, unit.y)
                    log.debug("sc=" .. JSON:stringify(screenCoordinates))
                    if screenCoordinates.x < 0 or screenCoordinates.x > 0.8 then
                        return true
                    end
                    if screenCoordinates.y < 0 or screenCoordinates.y > 0.6 then
                        return true
                    end
                    local frame = Frame:createBackDrop()
                    frame:setTexture("ReplaceableTextures\\Selection\\SelectionCircleSmall.blp")
                    frame:setSize(0.04, 0.04)
                    screenCoordinates.x = screenCoordinates.x - 0.02
                    frame:setAbsPoint(FRAMEPOINT_TOPLEFT, screenCoordinates.x, screenCoordinates.y)
                    local toX = 0
                    local toY = 0
                    local tween = __TS__New(
                        Tween,
                        __TS__ObjectAssign({}, screenCoordinates, {p = 0, s = 0.04})
                    ):to({x = toX, y = toY, p = 1, s = 0}, 2000):easing(Easing.Quadratic.Out):onUpdate(function(____, temp)
                        local position = InterpolationUtil:bezier(
                            temp.p,
                            __TS__New(Vector3, screenCoordinates.x, screenCoordinates.y),
                            __TS__New(Vector3, 0, 0),
                            __TS__New(Vector3, 0, 0.8),
                            __TS__New(Vector3, 0.6, 0.8),
                            __TS__New(Vector3, 0.6, 0),
                            __TS__New(Vector3, 0, 0),
                            __TS__New(Vector3, 0, 0.8),
                            __TS__New(Vector3, 0.6, 0.8),
                            __TS__New(Vector3, 0.6, 0)
                        )
                        frame:setAbsPoint(FRAMEPOINT_TOPLEFT, position.x, position.y)
                        frame:setSize(temp.s, temp.s)
                    end)
                    tween:start()
                    return true
                end
            )
        end
    )
end
function AppTest.prototype.uiTest(self)
    local frame = Frame:createTEXTBUTTON()
    frame:setText("测试Frame按钮")
    frame:addBackgroundImage("ReplaceableTextures\\Selection\\SelectionCircleSmall.blp")
    frame:setSize(0.1, 0.2)
    frame:setAbsPoint(FRAMEPOINT_BOTTOMLEFT, 0.1, 0.2)
    frame:setOnClick(function()
        DisplayTimedTextToPlayer(
            GetLocalPlayer(),
            0,
            0,
            20,
            "测试Frame按钮 点击了！"
        )
    end)
    SyncUtil.onSyncData(
        "gui_test",
        function(____, p)
            DisplayTimedTextToPlayer(
                GetLocalPlayer(),
                0,
                0,
                20,
                "接收到数据同步！触发的玩家为:" .. GetPlayerName(p)
            )
        end
    )
    AsyncUtil:run(function()
        __TS__New(Gui)
    end)
end
function AppTest.prototype.hookTest(self)
    print(log.path)
    local jassCreateUnit = CreateUnit
    _G.CreateUnit = function(id, unitid, x, y, face)
        local info = (((((("你创建了单位id:" .. tostring(GetPlayerId(id))) .. " unitid=") .. tostring(unitid)) .. " x,y=") .. tostring(x)) .. ",") .. tostring(y)
        print(info)
        log.info(info)
        Log.enable = false
        return jassCreateUnit(
            id,
            unitid,
            x,
            y,
            face
        )
    end
    local jassRemoveItem = RemoveItem
    _G.RemoveItem = function(whichItem)
        local info = (("移除了物品:" .. GetItemName(whichItem)) .. " handle=") .. tostring(whichItem)
        print(info)
        log.info(info)
        jassRemoveItem(whichItem)
    end
end
function AppTest.prototype.archiveTest(self)
    local key = "key值也占用存档空间,推荐短命名比如a1,B2,C34,以及中文"
    local av = ArchiveUtil:get(
        Player(0),
        key
    )
    if av then
        DisplayTimedTextToPlayer(
            GetLocalPlayer(),
            0,
            0,
            60,
            "从存档拉出的数据是:" .. tostring(av)
        )
        DisplayTimedTextToPlayer(
            GetLocalPlayer(),
            0,
            0,
            60,
            "从存档读对象表:" .. tostring(ArchiveUtil:get(
                Player(0),
                "我存个对象"
            )["套娃"].a)
        )
    else
        ArchiveUtil:set(
            Player(0),
            key,
            "哈哈我使劲存啊，把存档占满，不用白不用！！！！，布尔值可存0跟1以节省空间。我这里其实可以存超过64个长度的字符串啊 最大可存1.9W个字符"
        )
        ArchiveUtil:set(
            Player(0),
            "我存个对象",
            {["存个整数"] = 1, ["存个布尔"] = true, ["存个字符"] = "a", ["套娃"] = {a = "我是对象里的对象的套娃a数据"}}
        )
    end
end
function AppTest.prototype.httpJsonTest(self)
    se:onPlayerChat(
        "tj",
        function()
            local result = JSON:stringify({a = {1, {b = 2}}})
            DebugUtil.showText((tostring(BaseUtil.getGameTime()) .. "[对象转Json字符串=]") .. tostring(result))
            result = JSON:parse("{\"a\":[1,{\"b\":2}]}")
            DebugUtil.showText((tostring(BaseUtil.getGameTime()) .. "[Json字符串转对象=]") .. tostring(result))
            print_r(result)
            local a = result.a
            DebugUtil.showText((tostring(BaseUtil.getGameTime()) .. "[Json字符串转对象a[0]=]") .. tostring(a[1]))
            DebugUtil.showText((tostring(BaseUtil.getGameTime()) .. "[Json字符串转对象a[1][\"b\"]=]") .. tostring(a[2].b))
        end
    )
end
return ____exports
