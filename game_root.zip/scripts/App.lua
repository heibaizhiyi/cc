local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 2,["8"] = 2,["9"] = 4,["10"] = 4,["11"] = 5,["12"] = 5,["13"] = 6,["14"] = 6,["15"] = 7,["16"] = 7,["17"] = 8,["18"] = 8,["19"] = 9,["20"] = 9,["21"] = 10,["22"] = 10,["23"] = 11,["24"] = 11,["25"] = 12,["26"] = 12,["27"] = 13,["28"] = 13,["29"] = 14,["30"] = 14,["31"] = 15,["32"] = 15,["33"] = 18,["34"] = 20,["35"] = 20,["36"] = 20,["38"] = 25,["39"] = 25,["40"] = 25,["41"] = 25,["42"] = 25,["43"] = 25,["44"] = 25,["45"] = 35,["46"] = 38,["47"] = 41,["48"] = 42,["49"] = 43,["50"] = 44,["51"] = 47,["52"] = 50,["53"] = 53,["54"] = 22,["55"] = 62,["56"] = 62,["57"] = 62,["58"] = 64,["59"] = 66,["60"] = 67,["61"] = 66,["63"] = 71,["65"] = 62,["66"] = 62,["67"] = 77,["68"] = 78,["69"] = 78,["70"] = 78,["71"] = 78,["72"] = 78,["73"] = 78,["74"] = 78,["75"] = 79,["76"] = 77,["77"] = 83,["78"] = 84,["79"] = 84,["80"] = 84,["81"] = 84,["82"] = 84,["83"] = 84,["84"] = 84,["85"] = 83});
local ____exports = {}
local ____GlobalVars = require("solar.solar-wc3.common.GlobalVars")
local GlobalVars = ____GlobalVars.default
local ____AppTest = require("AppTest")
local AppTest = ____AppTest.default
local ____StateInit = require("StateInit")
local StateInit = ____StateInit.default
local ____StateConfigInit = require("StateConfigInit")
local StateConfigInit = ____StateConfigInit.default
local ____BaseUtil = require("solar.solar-common.util.BaseUtil")
local BaseUtil = ____BaseUtil.default
local ____SolarDataClearState = require("solar.solar-common.attribute.SolarDataClearState")
local SolarDataClearState = ____SolarDataClearState.default
local ____UnitAttributeState = require("solar.solar-common.attribute.UnitAttributeState")
local UnitAttributeState = ____UnitAttributeState.default
local ____SolarDamageState = require("solar.solar-common.attribute.SolarDamageState")
local SolarDamageState = ____SolarDamageState.default
local ____ItemAttributeState = require("solar.solar-common.attribute.ItemAttributeState")
local ItemAttributeState = ____ItemAttributeState.default
local ____PlayerAttributeState = require("solar.solar-common.attribute.PlayerAttributeState")
local PlayerAttributeState = ____PlayerAttributeState.default
local ____PlayerUtil = require("solar.solar-common.util.game.PlayerUtil")
local PlayerUtil = ____PlayerUtil.default
local ____SolarActorState = require("solar.solar-common.actor.SolarActorState")
local SolarActorState = ____SolarActorState.default
local ____ActorUnit = require("solar.solar-common.actor.ActorUnit")
local ActorUnit = ____ActorUnit.default
GlobalVars:init()
____exports.default = __TS__Class()
local App = ____exports.default
App.name = "App"
function App.prototype.____constructor(self)
    DisplayTimedTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        60,
        "TS:App!"
    )
    StateConfigInit(nil)
    __TS__New(SolarDataClearState)
    __TS__New(SolarDamageState)
    __TS__New(ItemAttributeState)
    __TS__New(PlayerAttributeState)
    __TS__New(UnitAttributeState)
    __TS__New(SolarActorState)
    StateInit(nil)
    __TS__New(AppTest)
end
BaseUtil.runLater(
    0.01,
    function()
        if isEmbedJapi then
            PlayerUtil:onUsersUidReady(function()
                __TS__New(____exports.default)
            end)
        else
            __TS__New(____exports.default)
        end
    end
)
local function spawnActor(self, actorTypeId, owner, x, y)
    local actor = __TS__New(
        ActorUnit,
        actorTypeId,
        owner,
        x,
        y
    )
    return actor
end
local function spawnRawUnit(self, unitFourCC, owner, x, y)
    return CreateUnit(
        owner,
        unitFourCC,
        x,
        y,
        270
    )
end
return ____exports
